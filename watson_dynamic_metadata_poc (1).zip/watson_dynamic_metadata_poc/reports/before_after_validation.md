# Before / after validation

## Baseline

- Source archive contained React/Vite frontend, FastAPI backend, existing pharma ontology/RDF graph, GraphRAG and FAISS retrieval implementation, `data/seed/seed_vocabularies.json`, synthetic corpus and regression tests.
- `backend/app/main.py:get_current_user` trusted `X-User-ID`, used process-global persona state and defaulted unknown identities to `D4`.
- `/api/ingestion/upload` relied only on the ordinary persona dependency and did not have a distinct authenticated-admin session.
- KG Explorer was a static card with hardcoded summary counts, not an entity catalog driven by imported metadata.
- No Databricks metadata ingestion module or generated catalog/mapping outputs were present in the supplied archive.

## After changes in working copy

- A local baseline Git commit (`d8c064f`) was created before edits; the uploaded ZIP remains untouched.
- Added signed admin bootstrap sessions and server-side guards to `/api/ingestion/upload` and `/api/metadata/ingest`; UI requires an admin session before showing the upload console.
- Added reusable source/fixure metadata parser and generated fixture artifacts, with source hashes and explicit fixture disclosure.
- Added explicit-ID-only compatibility mapping policy; no similar-name equivalence is inferred.
- Replaced static KG summary with a searchable catalog/graph/detail panel and mapping register.
- Curated seed vocabulary is unchanged by test evidence.

## Evidence boundary

- **PASS:** 12 automated tests for parser, preservation, mapping policy and signed-session primitives.
- **BLOCKED:** Full API route tests, full app regressions, frontend build, authoritative model ingestion, running UI screenshot, and production IdP integration due missing FAISS/frontend dependencies and unavailable upstream network.
- **Not claimed:** Full upstream product counts, complete Watson RDF graph display, production security certification, Layer 2/3 integration, or regression success.
