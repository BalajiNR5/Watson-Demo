# Watson compatibility report

## Source separation

1. Watson curated vocabulary remains at `data/seed/seed_vocabularies.json` and is never written by the importer.
2. Databricks schema metadata is written to `outputs/databricks_pharma_product_catalog.json`.
3. Compatibility records are written separately to `outputs/semantic_mapping_report.json`.
4. `/api/metadata/graph` reads these sources and the existing seed vocabulary for UI display; it does not mutate the existing ontology or semantic graph.

## Mapping policy

Supported statuses are `EXACT`, `PROPOSED`, `UNRESOLVED`, and `CONFLICT`. The current importer emits `EXACT` only when a source record supplies an explicit stable Watson identifier (`watson_id`, `canonical_id`, or `mapping_target_id`) that uniquely resolves in the preserved vocabulary. It never infers equivalence from name similarity. With the labelled fixture, all **9** concepts (3 products + 6 attributes) are `UNRESOLVED`; no target concepts are invented. The report includes source concept, target if justified, rationale, provenance, validation status, and conflict notes.

## Layer 2 / Layer 3 impact

- **Not integrated into canonical Layer 2 ontology or graph store:** Imported schema graph remains a separate metadata graph for the explorer. This avoids unreviewed schema-to-business-semantic merging.
- **Not inserted into FAISS / Layer 3:** Metadata-only changes do not require document embedding rebuild. Existing `Watson.faiss` and `chunk_uri_map.json` are left untouched.
- **Existing SPARQL and GraphRAG:** Source code paths are retained, but full regression execution is blocked because `faiss` is not installed in the environment.

## Result

- **PASS:** Seed vocabulary bytes unchanged by ingestion tests.
- **PASS:** Similar names alone do not create mappings.
- **PASS:** Unresolved mappings remain in the JSON register and are exposed in the UI mapping table.
- **BLOCKED:** Full source model mapping and live Watson graph interoperability until upstream model can be downloaded and the existing application dependencies are installed.
