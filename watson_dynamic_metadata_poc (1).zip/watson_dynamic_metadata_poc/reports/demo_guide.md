# Demo guide

## Prerequisites

- Python 3.10–3.12 and the approved environment described in `START_HERE.txt`.
- Existing dependencies in `requirements-office.txt`, including `faiss-cpu`, FastAPI, RDFLib, NumPy, and parser packages.
- Set the two administrator secrets in the server environment. Use unique values from an approved secret manager; do not use test strings.
- Current environment could not fetch upstream `model.json`; the fixture demonstration is offline and labelled as such.

## Configure administrator session

Linux/macOS shell:

```bash
export WATSON_INGEST_ADMIN_TOKEN="<random-secret-at-least-32-characters>"
export WATSON_INGEST_SESSION_SECRET="<different-random-secret-at-least-32-characters>"
export WATSON_INGEST_SESSION_TTL="3600"
export WATSON_INGEST_COOKIE_SECURE="0" # localhost only; use 1 behind HTTPS
python office_launcher.py --check
python office_launcher.py
```

Windows PowerShell:

```powershell
$env:WATSON_INGEST_ADMIN_TOKEN = "<random-secret-at-least-32-characters>"
$env:WATSON_INGEST_SESSION_SECRET = "<different-random-secret-at-least-32-characters>"
$env:WATSON_INGEST_SESSION_TTL = "3600"
$env:WATSON_INGEST_COOKIE_SECURE = "0"
python office_launcher.py --check
python office_launcher.py
```

Open `http://127.0.0.1:8000`. If the environment's approved dependency set is incomplete, the launcher should stop and report missing prerequisites rather than this report claiming the app is running.

## Metadata ingestion

- UI: select **Administrator sign-in**, enter the bootstrap token, then use the Ingestion Console for document uploads.
- API fixture refresh (after admin login cookie is established): `POST /api/metadata/ingest` with `{"source":"fixture","fixture_name":"pharmaceuticals_product_mvm_fixture.json"}`.
- Upstream refresh: `POST /api/metadata/ingest` with `{"source":"upstream"}`. This needs network access to the configured GitHub raw URL.
- Outputs: `outputs/databricks_pharma_product_catalog.json`, `outputs/ingestion_summary.json`, `outputs/semantic_mapping_report.json`.
- Navigate to **KG Explorer**. Inspect a product node, its attributes and relationships; inspect the mapping register. Fixture mode is clearly displayed, and all mappings remain unresolved unless an explicit stable Watson identifier exists.
- Repeat the fixture refresh. Product IDs and source hash should remain stable; `ingested_at` changes. The importer does not rebuild FAISS for metadata-only changes.

## Tests

```bash
PYTHONPATH=. pytest -q tests/test_metadata_ingestion.py tests/test_ingestion_auth_primitives.py
PYTHONPATH=. pytest -q tests/test_dynamic_metadata_access_control.py
```

The second command skips if `faiss` is missing. Install the approved dependency set before treating API integration tests as verified. Existing app tests are under `tests/`; run them after dependencies are available.

## Expected offline fixture result

3 products/tables, 6 attributes, 2 relationships, 2 subdomains, 0 unresolved relationship endpoints, 9 unresolved semantic mappings. These are fixture-only counts, not the upstream model counts.
