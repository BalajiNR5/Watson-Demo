# Ingestion access control report

## Design

The existing identity mechanism (`X-User-ID`, global persona switching, unknown-user fallback to `D4`) is not authentication. A separate server-side bootstrap session was added for sensitive ingestion functions:

- `POST /api/auth/ingestion-session`: verifies `WATSON_INGEST_ADMIN_TOKEN` using constant-time comparison; token must be at least 32 characters.
- `WATSON_INGEST_SESSION_SECRET`: required HMAC secret, at least 32 characters, signs an expiring session cookie.
- Cookie is HttpOnly, SameSite=Strict, path `/api`, and Secure can be enabled with `WATSON_INGEST_COOKIE_SECURE=1`.
- `GET /api/auth/ingestion-session`: validates the signature and expiry server-side.
- `DELETE /api/auth/ingestion-session`: clears the cookie.
- `POST /api/ingestion/upload`: independently requires `require_admin`; the persona header is not considered proof of admin.
- `POST /api/metadata/ingest`: independently requires `require_admin`; local fixture names are constrained to basenames inside `fixtures/databricks`.
- Browser requests carrying an Origin header are checked against the request host.
- Audit log: `data/stores/ingestion_access_audit.jsonl`, with actor ID, timestamp, operation, outcome and document identifier; no document contents or tokens are logged.

The frontend hides the Ingestion Console nav entry until the new admin session status endpoint succeeds. An unauthenticated user sees an administrator sign-in form, not upload controls. This is a minimal environment-credential bootstrap for a local PoC; deploy behind the approved identity provider before production use.

## Setup

Set these in the server process environment (never commit actual values):

```bash
export WATSON_INGEST_ADMIN_TOKEN="<random-secret-at-least-32-characters>"
export WATSON_INGEST_SESSION_SECRET="<different-random-secret-at-least-32-characters>"
export WATSON_INGEST_SESSION_TTL="3600"
export WATSON_INGEST_COOKIE_SECURE="0"  # set 1 behind HTTPS
```

Generate secrets using an approved secret manager or a cryptographically secure random generator. Do not use the example strings from tests. Rotate the bootstrap token and session secret according to deployment policy. The application intentionally fails closed with HTTP 503 if the session secret is absent and rejects missing/invalid bootstrap tokens.

## Protected routes

| Route | Protection |
|---|---|
| `POST /api/ingestion/upload` | `Depends(require_admin)` before handler body; origin check; file extension/size check and safe basename handling retained |
| `POST /api/metadata/ingest` | `Depends(require_admin)` before handler body; fixture basename allowlist |
| `GET /api/auth/ingestion-session` | Signed session required |

`/api/ingestion/review` is the existing HITL review/activation path, not the upload API; it remains available under the pre-existing reviewer mechanism to avoid removing the HITL workflow. **Deployment limitation:** because the current persona system is client-selectable, that legacy reviewer identity mechanism requires separate production IdP/authorization hardening before exposure outside localhost. No claim is made that the entire platform is production-secure.

## Test evidence

- **PASS:** 4 isolated session primitive tests: valid signature, tampering, expiration and environment bootstrap credential checks.
- **PASS:** static inspection confirms `require_admin` is a FastAPI dependency on upload and metadata ingestion routes.
- **BLOCKED:** HTTP route integration tests could not be collected because importing `backend/app/main.py` imports the existing retrieval stack and `faiss` is missing from the current environment. Route integration tests are included and auto-skip when FAISS is unavailable.
- **NOT RUN:** Live administrator upload through a running UI, CSRF browser test, external IdP integration and production deployment verification.

Security status: **partially implemented and not yet production-verified**. Do not expose publicly until route integration tests pass with the supported dependency set and the approved identity provider is connected.
