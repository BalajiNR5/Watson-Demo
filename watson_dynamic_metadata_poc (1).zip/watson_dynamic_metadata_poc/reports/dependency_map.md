# Watson repository dependency map

## Baseline and confidence

- Input archive: `Watson_Office_Ingestion_Fixed.zip`.
- Baseline working-copy Git commit: `d8c064f` (`Baseline from supplied Watson_Office_Ingestion_Fixed.zip`). Original uploaded ZIP was not modified.
- Verification labels: **Verified** means read from the supplied files or executed locally; **Blocked** means the dependency or upstream source was unavailable; **Assumption** is explicitly marked.
- No original `.git` metadata was present in the ZIP; the baseline commit is a new local commit of the extracted project.

## Frameworks and entry points

- **Backend — Verified:** FastAPI application `backend/app/main.py`, global `app = FastAPI(...)`; `office_launcher.py` is the current approved local launcher according to `START_HERE.txt`.
- **Frontend — Verified:** React 18 + TypeScript + Vite in `frontend/package.json`; entry point `frontend/src/main.tsx`, root application `frontend/src/App.tsx`, API wrapper `frontend/src/services/api.ts`.
- **Graph dependencies — Verified:** RDFLib is declared in `requirements-office.txt`; RDF/Turtle files `ontology/pharma.ttl`, `ontology/pharma_kg.ttl`, `ontology/pharma_kg_inferred.ttl`; semantic construction in `backend/watson/semantics/populate_graph.py`, enrichment in `backend/watson/semantics/enrichment_pipeline.py`, entity resolution in `backend/watson/semantics/entity_resolver.py`, SPARQL in `backend/watson/semantics/sparql_service.py`.
- **Retrieval — Verified:** `backend/watson/retrieval/graphrag_assembler.py`, `query_router.py`, `vector_index.py`, `guardrails.py`, `qwen_interface.py`; FAISS index `data/indexes/Watson.faiss`, mapping `data/indexes/chunk_uri_map.json`.
- **Ingestion — Verified:** `backend/watson/ingestion/ingestion_coordinator.py`, `parser.py`, `chunker.py`, `updated_chunker.py`, `metadata_extractor.py`, `dedup_detector.py`, `pii_detector.py`, `staging_state.py`.

## Identity, permissions and session behavior

- **Verified:** `backend/app/main.py:get_current_user` uses `X-User-ID` or a process-global persona and falls back to `D4` when the identity is unknown. `/api/auth/switch` changes that process-global persona. This is a demo persona mechanism, not authenticated identity.
- **Verified:** curated roles/capabilities are stored in `data/seed/seed_vocabularies.json` and identities in `data/stores/user_registry.json`; ABAC checks are implemented in `backend/watson/governance/abac_engine.py`.
- **Change added:** `backend/app/security/ingestion_auth.py` implements a separate HMAC-signed, expiring admin session cookie bootstrapped from environment credentials. The ingestion route does not accept a client role or `X-User-ID` as admin proof.
- **Blocked:** production IdP integration cannot be confirmed from the provided repository. The new environment bootstrap is a minimal PoC mechanism, not an enterprise IdP replacement.

## Routes and data flow

| Route | Existing behavior / relevant code | PoC change |
|---|---|---|
| `GET /api/health` | `backend/app/main.py:health` | Remains available |
| `GET /api/auth/current` | `current_user` → `get_current_user` | Existing persona mechanism remains for non-ingestion features |
| `GET /api/auth/personas` | `list_personas` | Existing demo persona list remains |
| `POST /api/auth/switch` | `switch_persona` | Does not grant the new admin session |
| `POST /api/auth/ingestion-session` | New `create_ingestion_session` | Requires environment bootstrap token; issues HttpOnly, SameSite=Strict signed cookie |
| `GET /api/auth/ingestion-session` | New `ingestion_session_status` | Requires valid signed session |
| `DELETE /api/auth/ingestion-session` | New `delete_ingestion_session` | Clears cookie |
| `POST /api/ingestion/upload` | Existing `upload_document` → `IngestionCoordinator.stage_file` | New `require_admin` dependency, origin validation, attempt/result audit events |
| `GET /api/ingestion/pending` | Existing `pending_documents` | Existing HITL path retained; API integration test blocked by missing FAISS dependency |
| `POST /api/ingestion/review` | Existing `review_document` → `review_and_activate` → refresh retrieval graph/index | Existing reviewer flow retained; requires separate security review because persona identity is not a production identity provider |
| `POST /api/metadata/ingest` | New `ingest_databricks_metadata` | Requires admin session; upstream or allowlisted fixture refresh |
| `GET /api/metadata/graph` | New `metadata_graph` | Reads generated catalog, mapping report, and original curated vocabulary |
| `POST /api/search`, `/api/chat`, `/api/graph/sparql` | Existing retrieval and SPARQL APIs | Kept available; regression execution blocked by missing FAISS |

## Vocabulary consumers and preservation

- `data/seed/seed_vocabularies.json` is the existing curated source; `backend/watson/governance/abac_engine.py`, taxonomy/semantic code and frontend identity/persona screens use the repository's role and curated records.
- New metadata code reads the vocabulary to produce compatibility records only; it never writes to or regenerates the seed file.
- `outputs/databricks_pharma_product_catalog.json` is the imported schema catalog; `outputs/semantic_mapping_report.json` is a separate explicit mapping register. The graph endpoint combines these sources only for visualization and does not merge them into the seed vocabulary.

## Frontend flow

- `frontend/src/App.tsx` contains tab navigation, upload UI and the existing KG Explorer tab.
- `frontend/src/services/api.ts` wraps existing APIs, including `uploadDocument`.
- `frontend/src/components/MetadataGraphExplorer.tsx` replaces the prior static KG summary with generated-artifact graph/catalog UI: search, type/relationship filters, selectable nodes, node details, relationship labels, inventory and mapping status table.
- **Blocked:** Node dependencies are not installed in the provided archive, and network access to the package registry was unavailable; frontend typecheck/build was not executed successfully in this environment.
