# Test results

Run date: 2026-10-29 (workspace runtime reported 2026-10-28 timestamps in generated artifacts).

| Test / check | Status | Type | Evidence / limitation |
|---|---|---|---|
| Local fixture product/attribute/relationship extraction | PASS | Automated | `tests/test_metadata_ingestion.py`; 3 products, 6 attributes, 2 relationships |
| Product MVM selection metadata on local fixture | PASS | Automated | Fixture declares pharmaceuticals / product / mvm / v1-fixture; it is not authoritative |
| Relationship integrity | PASS | Automated | 0 unresolved endpoints for fixture |
| Malformed model preserves last-known-good catalog | PASS | Automated | Validation fails before output write |
| Seed vocabulary remains byte-identical | PASS | Automated | `test_vocabulary_is_not_modified_by_ingestion` |
| Name similarity does not infer mapping | PASS | Automated | All fixture concepts unresolved without explicit target identifiers |
| Repeat ingestion does not duplicate product IDs | PASS | Automated | Stable IDs and source SHA-256 idempotency key |
| Multi-output replace failure rolls back prior artifacts | PASS | Automated | Injected failure after first replacement; all prior files restored |
| Graph adapter nodes and edges match generated artifacts | PASS | Automated | Product/attribute counts and unresolved mapping state asserted |
| Signed admin session creation/verification | PASS | Automated | `tests/test_ingestion_auth_primitives.py` |
| Tampered session rejected | PASS | Automated | HTTP 401 primitive check |
| Expired session rejected | PASS | Automated | HTTP 401 primitive check |
| Bootstrap token must be configured and match | PASS | Automated | Environment credential primitive check |
| Protected routes declare server-side admin dependency | PASS | Static AST test | `upload_document` and `ingest_databricks_metadata` signatures require `Depends(require_admin)` |
| HTTP upload authorization integration | BLOCKED | Automated | `faiss` package missing; importing FastAPI application fails during collection. Integration tests are present and skipped when FAISS is unavailable |
| Non-admin direct upload and alternative route API tests | BLOCKED | Automated | Same FAISS import blocker; see `tests/test_dynamic_metadata_access_control.py` |
| Admin upload end-to-end | BLOCKED | Automated | Same blocker; route test patches the coordinator to avoid corpus mutation |
| Existing regression suite | NOT RUN | Automated | Full suite depends on existing FAISS/retrieval dependencies not installed |
| Python bytecode compilation | PASS | Static/automated | `python -m compileall -q backend ...` |
| Frontend TypeScript/Vite build | BLOCKED | Build | `frontend/node_modules` is absent; no package-registry network access |
| Live browser graph interactions / screenshot | NOT RUN | Manual | No frontend dev server/browser automation available |
| Authoritative Databricks source download | BLOCKED | Integration | Container DNS could not resolve `raw.githubusercontent.com`; GitHub viewer reports source file is 6.76 MB and not renderable in page |
| Layer 2 canonical graph integration | NOT RUN | Static/integration | Metadata graph is intentionally separate to avoid unreviewed semantic merging |
| Layer 3/FAISS integration | NOT RUN | Static/integration | Metadata-only changes do not rebuild document embeddings; retrieval regression requires FAISS |
| Copilot citations and known-answer Dupixent/Keytruda queries | NOT RUN | Regression | Full retrieval application could not import because FAISS is absent |
| SPARQL Studio regression | NOT RUN | Regression | Full retrieval application could not import because FAISS is absent |
| ZIP integrity/content listing/SHA-256 | PASS | Packaging | `unzip -t` reports no errors; 240 archive entries inspected; SHA-256 sidecar generated after final rebuild |
