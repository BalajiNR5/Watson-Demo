# Metadata ingestion report

## Execution source

**Local test fixture only; authoritative upstream import is BLOCKED in this environment.** The runtime could not resolve `raw.githubusercontent.com` (DNS/network failure), and the GitHub file viewer reports the authoritative `model.json` is 6.76 MB and cannot render it in-page. The fixture at `fixtures/databricks/pharmaceuticals_product_mvm_fixture.json` is explicitly labeled synthetic and is not represented as the authoritative source.

Authoritative URL configured in code: `https://raw.githubusercontent.com/databricks-industry-solutions/lakehouse-industry-data-models/main/data-models/pharmaceuticals/v1/mvm/model.json`.

## Executed fixture result

- Source mode: `local_fixture`
- Source SHA-256: `ba16f95efa4ff90521706f422c47253986d2f759bc5f60468caa8af384054335`
- Products/tables extracted: **3**
- Attributes/columns extracted: **6**
- Relationships extracted: **2**
- Subdomains extracted: **2** (Product Identity and Market Authorization in the test fixture)
- Relationships with unresolved endpoints: **0**
- Validation: **PASS** for the local fixture only
- Idempotency key: source SHA-256

These are counts from the local test fixture, not counts for the full Databricks Pharmaceuticals Product MVM model.

## Implementation

`backend/watson/metadata/databricks_product.py` supports upstream fetch or local fixture, JSON root validation, extraction for the documented `model.domains[].products[].attributes[]` structure and common product/table variants, attributes/columns, keys, explicit relationships and `foreign_key_to` metadata, relationship endpoint validation, source hash/provenance, deterministic IDs, explicit-ID-only mapping, and generated artifacts. Parsing/validation happens before artifact replacement. Metadata refresh does not trigger FAISS re-embedding.

Outputs generated from the fixture:
- `outputs/databricks_pharma_product_catalog.json`
- `outputs/ingestion_summary.json`
- `outputs/semantic_mapping_report.json`

## Remaining validation

- **BLOCKED:** Parse the full upstream JSON in this environment.
- **BLOCKED:** Verify full-source product, attribute, key and foreign-key counts.
- **BLOCKED:** Confirm actual source-specific domain/subdomain structure against the downloaded model.
- **PASS:** Offline fixture parser and relationship validation tests.
- **PASS:** Last-known-good catalog survives malformed-input validation failure.
