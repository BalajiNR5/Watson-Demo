# Graph Explorer validation

## Implemented

- Existing `activeTab === 'kg'` view in `frontend/src/App.tsx` now renders `MetadataGraphExplorer`; no separate duplicate route was created.
- `GET /api/metadata/graph` assembles nodes from the generated Databricks catalog and the unchanged Watson seed vocabulary, plus schema relationship edges and mapping status data.
- UI supports search, node-type filtering, relationship filtering, selecting nodes, connected relationship listing, node detail/provenance panel, catalog inventory, mapping register/status counts, refresh action, zoom controls and reset. Nodes can be repositioned using pointer dragging.
- Relationship labels include `CONTAINS_ATTRIBUTE`, `FOREIGN_KEY_TO`, and `MAPPED_TO` only when corresponding source artifacts support them. No mapping edge is created for unresolved mappings.
- Local fixture mode and last refresh are visibly disclosed; a failed API refresh shows an error and retry control rather than silently showing a fabricated graph.

## Acceptance evidence

| Acceptance criterion | Status | Evidence |
|---|---|---|
| Graph nodes generated from actual imported catalog artifact | PASS (fixture only) | `backend/app/main.py:metadata_graph`; fixture catalog contains 3 product records and 6 attributes |
| Existing Watson vocabulary displayed separately | PASS (static implementation + preservation test) | Reads `data/seed/seed_vocabularies.json`; `test_vocabulary_is_not_modified_by_ingestion` passes |
| Relationship endpoints are validated during ingestion | PASS (fixture) | 2 relationships; 0 unresolved endpoints |
| Unresolved mappings are visible and not implied verified | PASS (artifact + UI implementation) | 9 UNRESOLVED entries, no `MAPPED_TO` edge for these entries; UI mapping register labels status and rationale |
| Product/attribute detail panel and catalog table | PASS (static implementation) | `frontend/src/components/MetadataGraphExplorer.tsx` |
| Search/filter/refresh and error states | PASS (static inspection) | Component state and API error handling; browser test not run |
| Full upstream Product MVM entities and real Watson semantic graph | BLOCKED | 6.76 MB source model could not be downloaded in current environment; current graph reads curated vocabulary, not full live RDF graph |
| Running explorer screenshot | NOT RUN | Frontend dependencies are absent; no running browser available in this execution environment |
| Automated browser interaction test | NOT RUN | Playwright/browser harness is not included in this archive |

This is a working implementation path backed by fixture artifacts, not evidence that the complete upstream model has been ingested.
