import os, time, json, base64
import pytest
from fastapi import HTTPException
os.environ['WATSON_INGEST_SESSION_SECRET']='unit-test-session-secret-at-least-32-bytes'
from backend.app.security.ingestion_auth import create_session, verify_session, verify_bootstrap_credential

def test_signed_admin_session_round_trip():
    data=verify_session(create_session())
    assert data['role']=='ADMIN' and data['exp']>int(time.time())

def test_tampered_session_rejected():
    token=create_session()
    with pytest.raises(HTTPException) as e: verify_session(token+'x')
    assert e.value.status_code==401

def test_expired_session_rejected():
    payload={'sub':'x','role':'ADMIN','exp':int(time.time())-10}
    body=base64.urlsafe_b64encode(json.dumps(payload).encode()).decode().rstrip('=')
    import hmac,hashlib
    sig=hmac.new(os.environ['WATSON_INGEST_SESSION_SECRET'].encode(),body.encode(),hashlib.sha256).hexdigest()
    with pytest.raises(HTTPException) as e: verify_session(body+'.'+sig)
    assert e.value.status_code==401

def test_bootstrap_credential_must_be_environment_configured(monkeypatch):
    monkeypatch.delenv('WATSON_INGEST_ADMIN_TOKEN',raising=False)
    assert not verify_bootstrap_credential('D4')
    monkeypatch.setenv('WATSON_INGEST_ADMIN_TOKEN','a-valid-token-of-at-least-32-characters')
    assert verify_bootstrap_credential('a-valid-token-of-at-least-32-characters')
    assert not verify_bootstrap_credential('a-valid-token-of-at-least-32-characterX')

def test_protected_routes_declare_server_side_admin_dependency():
    import ast
    from pathlib import Path
    source=(Path(__file__).resolve().parents[1]/'backend'/'app'/'main.py').read_text()
    tree=ast.parse(source)
    protected={}
    for node in ast.walk(tree):
        if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)) and node.name in {'upload_document','ingest_databricks_metadata'}:
            protected[node.name]=ast.unparse(node.args)
    assert set(protected)=={'upload_document','ingest_databricks_metadata'}
    assert all('Depends(require_admin)' in args for args in protected.values())
