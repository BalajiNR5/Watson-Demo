import json
from pathlib import Path
import pytest
from backend.watson.metadata.databricks_product import load_source, parse_model, ingest
ROOT=Path(__file__).resolve().parents[1]

def test_local_fixture_extracts_products_attributes_and_relationships():
    data,source=load_source(ROOT/'fixtures/databricks/pharmaceuticals_product_mvm_fixture.json')
    catalog=parse_model(data,source)
    assert catalog['industry']=='pharmaceuticals' and catalog['domain']=='product'
    assert catalog['validation']['product_count']==3
    assert catalog['validation']['attribute_count']==6
    assert catalog['validation']['relationship_count']==2
    assert catalog['validation']['valid'] is True
    assert {x['name'] for x in catalog['subdomains']} >= {'Product Identity','Market Authorization'}

def test_invalid_model_does_not_overwrite_last_known_good(tmp_path):
    out=tmp_path/'out';out.mkdir(); target=out/'databricks_pharma_product_catalog.json';target.write_text('{"known_good":true}')
    invalid=tmp_path/'bad.json';invalid.write_text('{"not":"a model"}')
    with pytest.raises(ValueError): ingest(invalid,out,ROOT/'data/seed/seed_vocabularies.json')
    assert json.loads(target.read_text())=={'known_good':True}

def test_vocabulary_is_not_modified_by_ingestion(tmp_path):
    vocab=ROOT/'data/seed/seed_vocabularies.json'; before=vocab.read_bytes()
    ingest(ROOT/'fixtures/databricks/pharmaceuticals_product_mvm_fixture.json',tmp_path,vocab)
    assert vocab.read_bytes()==before

def test_mappings_do_not_use_name_similarity(tmp_path):
    ingest(ROOT/'fixtures/databricks/pharmaceuticals_product_mvm_fixture.json',tmp_path,ROOT/'data/seed/seed_vocabularies.json')
    report=json.loads((tmp_path/'semantic_mapping_report.json').read_text())
    assert report['statuses']['EXACT']==0
    assert report['statuses']['UNRESOLVED']==9

def test_deterministic_identity_and_duplicate_free_entities(tmp_path):
    one=ingest(ROOT/'fixtures/databricks/pharmaceuticals_product_mvm_fixture.json',tmp_path,ROOT/'data/seed/seed_vocabularies.json')
    catalog1=json.loads((tmp_path/'databricks_pharma_product_catalog.json').read_text())
    two=ingest(ROOT/'fixtures/databricks/pharmaceuticals_product_mvm_fixture.json',tmp_path,ROOT/'data/seed/seed_vocabularies.json')
    catalog2=json.loads((tmp_path/'databricks_pharma_product_catalog.json').read_text())
    assert one['idempotency_key']==two['idempotency_key']
    assert [x['id'] for x in catalog1['products']]==[x['id'] for x in catalog2['products']]
    assert len({x['id'] for x in catalog2['products']})==len(catalog2['products'])

def test_graph_adapter_matches_generated_catalog_and_preserves_unresolved_status(tmp_path):
    from backend.watson.metadata.graph_adapter import build_metadata_graph
    ingest(ROOT/'fixtures/databricks/pharmaceuticals_product_mvm_fixture.json',tmp_path,ROOT/'data/seed/seed_vocabularies.json')
    graph=build_metadata_graph(tmp_path/'databricks_pharma_product_catalog.json',tmp_path/'semantic_mapping_report.json',ROOT/'data/seed/seed_vocabularies.json')
    catalog=json.loads((tmp_path/'databricks_pharma_product_catalog.json').read_text())
    assert sum(n['type']=='PRODUCT' for n in graph['nodes'])==len(catalog['products'])
    assert sum(n['type']=='ATTRIBUTE' for n in graph['nodes'])==catalog['validation']['attribute_count']
    assert sum(e['label']=='CONTAINS_ATTRIBUTE' for e in graph['edges'])==catalog['validation']['attribute_count']
    assert graph['mapping_statuses']['UNRESOLVED']==9
    assert not any(e['label']=='MAPPED_TO' for e in graph['edges'])
    assert graph['source_mode']=='local_fixture' and graph['fixture_notice']

def test_output_replace_failure_rolls_back_all_prior_artifacts(tmp_path, monkeypatch):
    import backend.watson.metadata.databricks_product as module
    out=tmp_path/'out';out.mkdir()
    names=['databricks_pharma_product_catalog.json','ingestion_summary.json','semantic_mapping_report.json']
    for name in names: (out/name).write_text('previous:'+name)
    real_replace=module.os.replace; count={'n':0}
    def fail_once(src,dst):
        count['n']+=1
        if count['n']==2: raise OSError('injected replace failure')
        return real_replace(src,dst)
    monkeypatch.setattr(module.os,'replace',fail_once)
    with pytest.raises(OSError,match='injected replace failure'):
        ingest(ROOT/'fixtures/databricks/pharmaceuticals_product_mvm_fixture.json',out,ROOT/'data/seed/seed_vocabularies.json')
    assert all((out/name).read_text()=='previous:'+name for name in names)
