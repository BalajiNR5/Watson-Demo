import json, os
from pathlib import Path
from fastapi.testclient import TestClient
import pytest
pytest.importorskip('faiss', reason='Watson API imports existing FAISS retrieval layer; install requirements-office.txt to run route integration tests')

ROOT=Path(__file__).resolve().parents[1]
os.environ.setdefault('WATSON_INGEST_ADMIN_TOKEN','test-only-bootstrap-token-32-bytes-minimum')
os.environ.setdefault('WATSON_INGEST_SESSION_SECRET','test-only-session-secret-32-bytes-minimum')
from backend.app.main import app
from backend.watson.metadata.databricks_product import load_source, parse_model, ingest

@pytest.fixture
def client():
    with TestClient(app) as c: yield c

def test_local_fixture_extracts_products_attributes_and_relationships():
    data,source=load_source(ROOT/'fixtures/databricks/pharmaceuticals_product_mvm_fixture.json')
    catalog=parse_model(data,source)
    assert catalog['industry']=='pharmaceuticals' and catalog['domain']=='product'
    assert catalog['validation']['product_count']==3
    assert catalog['validation']['attribute_count']==6
    assert catalog['validation']['relationship_count']==2
    assert catalog['validation']['valid'] is True
    assert {x['name'] for x in catalog['subdomains']} >= {'Product Identity','Market Authorization'}

def test_invalid_model_does_not_overwrite_last_known_good(tmp_path):
    out=tmp_path/'out';out.mkdir(); target=out/'databricks_pharma_product_catalog.json';target.write_text('{"known_good":true}')
    invalid=tmp_path/'bad.json';invalid.write_text('{"not":"a model"}')
    with pytest.raises(ValueError): ingest(invalid,out,ROOT/'data/seed/seed_vocabularies.json')
    assert json.loads(target.read_text())=={'known_good':True}

def test_vocabulary_is_not_modified_by_ingestion(tmp_path):
    vocab=ROOT/'data/seed/seed_vocabularies.json'; before=vocab.read_bytes()
    ingest(ROOT/'fixtures/databricks/pharmaceuticals_product_mvm_fixture.json',tmp_path,vocab)
    assert vocab.read_bytes()==before

def test_upload_requires_admin_session_even_with_admin_header(client,tmp_path):
    before=set((ROOT/'data/staging').glob('*_staged.json'))
    r=client.post('/api/ingestion/upload',headers={'x-user-id':'D4'},files={'file':('auth-test.txt',b'Clinical study for Keytruda with safety and efficacy results.')})
    assert r.status_code==401
    assert set((ROOT/'data/staging').glob('*_staged.json'))==before

def test_persona_switch_does_not_grant_ingestion_access(client):
    switched=client.post('/api/auth/switch',json={'user_id':'D4'})
    assert switched.status_code==200
    r=client.post('/api/metadata/ingest',headers={'x-user-id':'D4'},json={'source':'fixture','fixture_name':'pharmaceuticals_product_mvm_fixture.json'})
    assert r.status_code==401

def test_invalid_admin_bootstrap_token_rejected(client):
    r=client.post('/api/auth/ingestion-session',json={'admin_token':'D4'})
    assert r.status_code==401

def test_admin_session_can_ingest_fixture_and_upload(client, monkeypatch):
    login=client.post('/api/auth/ingestion-session',json={'admin_token':os.environ['WATSON_INGEST_ADMIN_TOKEN']})
    assert login.status_code==200,login.text
    graph=client.post('/api/metadata/ingest',json={'source':'fixture','fixture_name':'pharmaceuticals_product_mvm_fixture.json'})
    assert graph.status_code==200,graph.text
    from backend.app import main as main_module
    monkeypatch.setattr(main_module.coordinator, 'stage_file', lambda path, actor_id: {'doc_id':'test-doc', 'document_uri':'watson:Doc_test-doc', 'source_filename':Path(path).name, 'status':'UNDER_REVIEW'})
    upload=client.post('/api/ingestion/upload',files={'file':('admin-test.txt',b'Clinical study on Keytruda oncology safety and efficacy.')})
    assert upload.status_code==200,upload.text
    events=(ROOT/'data/stores/ingestion_access_audit.jsonl').read_text().splitlines()
    assert any(json.loads(e).get('operation')=='document_upload' and json.loads(e).get('outcome')=='SUCCESS' for e in events)

def test_non_ingestion_features_remain_available(client):
    assert client.get('/api/health').status_code==200
    assert client.get('/api/metadata/graph').status_code==200
