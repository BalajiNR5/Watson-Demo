#!/usr/bin/env python3
"""Import the Databricks Pharmaceuticals Product MVM model or a local fixture."""
import argparse, json, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from backend.watson.metadata.databricks_product import ingest

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--fixture', help='JSON fixture path for offline testing; otherwise fetch upstream source')
    p.add_argument('--output-dir', default=str(ROOT/'outputs'))
    args=p.parse_args()
    summary=ingest(args.fixture, args.output_dir, ROOT/'data'/'seed'/'seed_vocabularies.json')
    print(json.dumps(summary,indent=2))
if __name__=='__main__': main()
