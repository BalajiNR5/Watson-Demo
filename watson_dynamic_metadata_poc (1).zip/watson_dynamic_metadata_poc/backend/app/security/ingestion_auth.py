"""Minimal environment-bootstrapped admin session for ingestion-only operations.

Production deployments should replace this bootstrap credential with the approved IdP.
No identity is derived from X-User-ID, query parameters, or browser role flags.
"""
from __future__ import annotations
import base64, hashlib, hmac, json, os, secrets, time
from http.cookies import SimpleCookie
from fastapi import HTTPException, Request

COOKIE_NAME = "watson_ingest_admin"

def _secret() -> bytes:
    value = os.getenv("WATSON_INGEST_SESSION_SECRET", "")
    if len(value) < 32:
        raise HTTPException(status_code=503, detail="Administrator session authentication is not configured.")
    return value.encode()

def _sign(payload: bytes) -> str:
    return hmac.new(_secret(), payload, hashlib.sha256).hexdigest()

def create_session() -> str:
    payload = json.dumps({"sub":os.getenv("WATSON_INGEST_ADMIN_ACTOR_ID", "environment-bootstrap-admin"),"role":"ADMIN","exp":int(time.time())+int(os.getenv("WATSON_INGEST_SESSION_TTL","3600")),"nonce":secrets.token_hex(8)},separators=(",",":"),sort_keys=True).encode()
    token = base64.urlsafe_b64encode(payload).decode().rstrip("=")
    return token + "." + _sign(token.encode())

def verify_session(token: str | None) -> dict:
    if not token or "." not in token:
        raise HTTPException(status_code=401, detail="Administrator authentication required.")
    body, signature = token.rsplit(".",1)
    if not hmac.compare_digest(_sign(body.encode()), signature):
        raise HTTPException(status_code=401, detail="Invalid administrator session.")
    try:
        payload = base64.urlsafe_b64decode(body + "="*((4-len(body)%4)%4))
        data=json.loads(payload)
    except Exception as exc:
        raise HTTPException(status_code=401, detail="Invalid administrator session.") from exc
    if data.get("role") != "ADMIN" or not isinstance(data.get("exp"),int) or data["exp"] < int(time.time()):
        raise HTTPException(status_code=401, detail="Administrator session expired or invalid.")
    return data

def require_admin(request: Request) -> dict:
    return verify_session(request.cookies.get(COOKIE_NAME))

def verify_bootstrap_credential(value: str) -> bool:
    expected = os.getenv("WATSON_INGEST_ADMIN_TOKEN", "")
    return bool(len(expected) >= 32 and value and hmac.compare_digest(expected, value))
