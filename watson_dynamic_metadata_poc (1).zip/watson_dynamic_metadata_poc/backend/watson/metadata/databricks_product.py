from __future__ import annotations
import hashlib, json, os, urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

SOURCE_URL = "https://raw.githubusercontent.com/databricks-industry-solutions/lakehouse-industry-data-models/main/data-models/pharmaceuticals/v1/mvm/model.json"

def load_source(source_path: str | Path | None = None, timeout: int = 20) -> tuple[dict[str, Any], str]:
    """Load a local JSON fixture or fetch the authoritative upstream JSON."""
    if source_path:
        p = Path(source_path)
        raw = p.read_bytes()
        source = f"local-fixture:{p.as_posix()}"
    else:
        req = urllib.request.Request(SOURCE_URL, headers={"User-Agent": "Watson-Metadata-POC/1.0"})
        with urllib.request.urlopen(req, timeout=timeout) as response:
            raw = response.read()
        source = SOURCE_URL
    try:
        data = json.loads(raw)
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError(f"Source is not valid UTF-8 JSON: {exc}") from exc
    if not isinstance(data, dict):
        raise ValueError("Model JSON root must be an object")
    return data, source

def _name(obj: dict[str, Any]) -> str | None:
    for k in ("name", "logicalName", "logical_name", "tableName", "table_name", "entityName", "entity_name", "id"):
        v = obj.get(k)
        if isinstance(v, str) and v.strip(): return v.strip()
    return None

def _items(value: Any):
    if isinstance(value, list):
        for x in value:
            if isinstance(x, dict): yield x
    elif isinstance(value, dict):
        for k, x in value.items():
            if isinstance(x, dict):
                y = dict(x)
                y.setdefault("name", k)
                yield y

def parse_model(data: dict[str, Any], source: str) -> dict[str, Any]:
    """Extract entities/attributes/relationships from common model JSON shapes.

    Does not infer semantic equivalence. Unknown fields are retained as raw metadata
    on extracted objects so schema variations remain inspectable.
    """
    if not isinstance(data, dict) or not data:
        raise ValueError("Model must be a non-empty JSON object")
    model_data = data.get("model") if isinstance(data.get("model"), dict) else data
    identity = {k: model_data.get(k, data.get(k)) for k in ("name", "id", "version", "industry", "flavour", "flavor", "description") if model_data.get(k, data.get(k)) is not None}
    products: list[dict[str, Any]] = []
    relationships: list[dict[str, Any]] = []
    subdomains: list[dict[str, Any]] = []
    seen: set[str] = set()
    relationship_keys = {"relationships", "relations", "foreignKeys", "foreign_keys", "references", "relationshipsList"}
    product_keys = {"products", "tables", "entities", "dataProducts", "data_products", "nodes", "objects"}
    subdomain_keys = {"subdomains"}

    def walk(obj: Any, context: dict[str, Any] | None = None, parent_key: str = ""):
        if isinstance(obj, list):
            for item in obj: walk(item, context, parent_key)
            return
        if not isinstance(obj, dict): return
        ctx = context or {}
        if parent_key.lower() in {"domains", "domain"} and _name(obj):
            ctx = {**ctx, "domain": _name(obj)}
        if parent_key.lower() in subdomain_keys and _name(obj):
            subdomains.append({"id": str(obj.get("id", _name(obj))), "name": _name(obj), "description": obj.get("description"), "domain": ctx.get("domain"), "source_metadata": {k:v for k,v in obj.items() if k not in ("tables", "entities", "products")}})
            ctx = {**ctx, "subdomain": _name(obj)}
        candidate = _name(obj)
        attrs_raw = next((obj[k] for k in ("attributes", "columns", "fields", "properties") if isinstance(obj.get(k), (list, dict))), None)
        is_product = bool(candidate and (attrs_raw is not None or parent_key.lower() in product_keys or any(k in obj for k in ("primaryKey", "primary_key", "keys", "foreignKeys", "foreign_keys"))))
        this_ctx = ctx
        if is_product:
            stable_id = str(obj.get("id") or obj.get("urn") or obj.get("fullyQualifiedName") or f"{ctx.get('subdomain','model')}:{candidate}")
            key = stable_id.casefold()
            if key not in seen:
                seen.add(key)
                attrs = []
                for a in _items(attrs_raw):
                    an = _name(a) or str(a.get("name", "attribute"))
                    attrs.append({"id": str(a.get("id") or f"{stable_id}.{an}"), "name": an, "type": a.get("type", a.get("dataType", a.get("datatype"))), "description": a.get("description", a.get("comment")), "nullable": a.get("nullable"), "key": bool(a.get("key") or a.get("primaryKey") or a.get("isPrimaryKey")), "source_metadata": a})
                keys = obj.get("keys", [])
                for k in ("primaryKey", "primary_key", "primaryKeys", "primary_keys"):
                    if obj.get(k) is not None: keys = list(keys) + ([obj[k]] if not isinstance(obj[k], list) else obj[k])
                products.append({"id": stable_id, "name": candidate, "description": obj.get("description", obj.get("comment")), "domain": ctx.get("domain") or obj.get("domain"), "subdomain": ctx.get("subdomain") or obj.get("subdomain"), "attributes": attrs, "keys": keys, "source_metadata": {k:v for k,v in obj.items() if k not in ("attributes", "columns", "fields", "properties")}})
                for attr in attrs:
                    fk = attr.get("source_metadata", {}).get("foreign_key_to") or attr.get("source_metadata", {}).get("foreignKeyTo")
                    if fk:
                        if isinstance(fk, dict): target = fk.get("product") or fk.get("table") or fk.get("target") or fk.get("name")
                        else: target = str(fk).split(".")[-2] if str(fk).count(".") >= 1 else str(fk)
                        relationships.append({"source": stable_id, "target": target, "name": f"{candidate}.{attr['name']}", "type": "FOREIGN_KEY_TO", "source_metadata": {"attribute": attr['name'], "foreign_key_to": fk}})
                this_ctx = {**ctx, "product_id": stable_id, "product_name": candidate}
        for rk in relationship_keys:
            if rk in obj:
                for rel in _items(obj[rk]):
                    relationships.append({"source": rel.get("source", rel.get("from", rel.get("sourceTable", rel.get("source_table", this_ctx.get("product_id"))))), "target": rel.get("target", rel.get("to", rel.get("targetTable", rel.get("target_table", rel.get("referencedTable", rel.get("referenced_table")))))), "name": _name(rel) or str(rel.get("type", "relationship")), "type": rel.get("type", rel.get("kind", "RELATIONSHIP")), "source_metadata": rel})
        for k,v in obj.items():
            if isinstance(v, (dict,list)):
                walk(v, this_ctx, k)
    walk(model_data)
    # Remove duplicate relationships deterministically and validate endpoint references where resolvable.
    unique = {}
    ids = {p["id"] for p in products}; names = {p["name"] for p in products}
    for r in relationships:
        if r["source"] is None or r["target"] is None: continue
        key = json.dumps(r, sort_keys=True, default=str)
        unique[key] = r
    rels = sorted(unique.values(), key=lambda r:(str(r["source"]),str(r["target"]),str(r["name"])))
    unresolved = [r for r in rels if str(r["source"]) not in ids|names or str(r["target"]) not in ids|names]
    # A source may use table IDs that were not exposed as products; report rather than fabricate links.
    if not products:
        raise ValueError("No product/table/entity records could be extracted from the supplied JSON shape")
    return {"model": identity, "industry": model_data.get("industry", data.get("industry", "pharmaceuticals")), "domain": model_data.get("domain", data.get("domain", "product")), "flavour": model_data.get("flavour", model_data.get("flavor", data.get("flavour", data.get("flavor", "mvm")))), "version": model_data.get("version", data.get("version", "v1")), "source": source, "source_mode": ("local_fixture" if source.startswith("local-fixture:") else "authoritative_upstream"), "fixture_notice": data.get("fixture_notice"), "source_sha256": hashlib.sha256(json.dumps(data, sort_keys=True, default=str).encode()).hexdigest(), "ingested_at": datetime.now(timezone.utc).isoformat(), "products": sorted(products, key=lambda p:p["id"]), "subdomains": sorted({json.dumps(x,sort_keys=True,default=str):x for x in subdomains}.values(), key=lambda x:x["name"]), "relationships": rels, "validation": {"product_count":len(products), "attribute_count":sum(len(p["attributes"]) for p in products), "relationship_count":len(rels), "subdomain_count":len(subdomains), "relationships_with_unresolved_endpoints":len(unresolved), "unresolved_relationships":unresolved, "valid":len(unresolved)==0}}

def ingest(source_path: str | Path | None, output_dir: str | Path, vocabulary_path: str | Path | None = None) -> dict[str, Any]:
    data, source = load_source(source_path)
    catalog = parse_model(data, source)
    if not catalog["validation"]["valid"]:
        raise ValueError(f"Model validation failed: {catalog['validation']['unresolved_relationships']}")
    out = Path(output_dir); out.mkdir(parents=True, exist_ok=True)
    # Build mappings only when explicit identifiers or exact canonical names/aliases prove equivalence.
    vocab = json.loads(Path(vocabulary_path).read_text()) if vocabulary_path and Path(vocabulary_path).exists() else {}
    canonical = {}
    def add_vocab(value):
        if isinstance(value, dict):
            name=value.get("canonical_name") or value.get("name"); cid=value.get("id")
            if cid: canonical.setdefault(str(cid), []).append({"id":cid,"name":name or str(cid),"aliases":value.get("aliases",[])})
            for v in value.values(): add_vocab(v)
        elif isinstance(value,list):
            for v in value: add_vocab(v)
    add_vocab(vocab.get("vocabularies",{}))
    mappings=[]
    concepts=[]
    for p in catalog["products"]:
        concepts.append((p["id"],p["name"],p.get("source_metadata",{})))
        for a in p.get("attributes",[]): concepts.append((a["id"],a["name"],a.get("source_metadata",{})))
    for concept_id, concept_name, raw in concepts:
        explicit_id=raw.get("watson_id") or raw.get("canonical_id") or raw.get("mapping_target_id")
        matches=canonical.get(str(explicit_id),[]) if explicit_id else []
        status="EXACT" if len(matches)==1 else ("CONFLICT" if len(matches)>1 else "UNRESOLVED")
        mappings.append({"source_concept":{"id":concept_id,"name":concept_name,"source_model":catalog["model"],"version":catalog["version"]},"target_concept":({"id":matches[0]["id"],"name":matches[0]["name"]} if status=="EXACT" else None),"mapping_status":status,"rationale":"Source contains an explicit Watson canonical identifier that uniquely resolves in the preserved vocabulary." if status=="EXACT" else "No explicit stable identifier or curated mapping establishes equivalence; name similarity is deliberately not used.","provenance":{"source":source,"source_sha256":catalog["source_sha256"]},"conflict_notes":("Explicit target identifier resolves to multiple canonical records." if status=="CONFLICT" else None),"validation_status":"VALIDATED_EXPLICIT_ID" if status=="EXACT" else "REQUIRES_REVIEW"})
    mapping_report={"generated_at":datetime.now(timezone.utc).isoformat(),"source_model":catalog["model"],"source_sha256":catalog["source_sha256"],"statuses":{s:sum(m["mapping_status"]==s for m in mappings) for s in ("EXACT","PROPOSED","UNRESOLVED","CONFLICT")},"mappings":mappings}
    summary={"source":source,"source_sha256":catalog["source_sha256"],"ingested_at":catalog["ingested_at"],"validation":catalog["validation"],"products_added":len(catalog["products"]),"attributes_added":catalog["validation"]["attribute_count"],"relationships_added":len(catalog["relationships"]),"idempotency_key":catalog["source_sha256"]}
    # Stage all outputs first, then replace as a rollback-capable transaction.
    payloads=(("databricks_pharma_product_catalog.json",catalog),("ingestion_summary.json",summary),("semantic_mapping_report.json",mapping_report))
    staged={}; previous={}; replaced=[]
    try:
        for name, obj in payloads:
            target=out/name; tmp=out/(name+".tmp")
            tmp.write_text(json.dumps(obj,indent=2,sort_keys=True,default=str)+"\n",encoding="utf-8")
            staged[target]=tmp
            previous[target]=target.read_bytes() if target.exists() else None
        for target,tmp in staged.items():
            os.replace(tmp,target); replaced.append(target)
    except Exception:
        for target in reversed(replaced):
            old=previous[target]
            if old is None:
                target.unlink(missing_ok=True)
            else:
                rollback=out/(target.name+".rollback.tmp"); rollback.write_bytes(old); os.replace(rollback,target)
        raise
    finally:
        for tmp in staged.values(): tmp.unlink(missing_ok=True)
    return summary
