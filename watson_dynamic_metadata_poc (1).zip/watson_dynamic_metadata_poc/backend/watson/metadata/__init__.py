"""Databricks industry model metadata ingestion and Watson compatibility helpers."""
