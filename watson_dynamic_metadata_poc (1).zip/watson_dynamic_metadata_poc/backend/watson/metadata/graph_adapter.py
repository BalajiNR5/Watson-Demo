"""Read-only adapter combining imported schema metadata with Watson-owned vocabulary."""
from __future__ import annotations
import json
from pathlib import Path
from typing import Any

def build_metadata_graph(catalog_path: str | Path, mapping_path: str | Path, vocabulary_path: str | Path) -> dict[str, Any]:
    catalog_path, mapping_path, vocabulary_path = map(Path, (catalog_path, mapping_path, vocabulary_path))
    nodes: list[dict[str, Any]]=[]; edges: list[dict[str, Any]]=[]
    catalog=json.loads(catalog_path.read_text(encoding="utf-8")) if catalog_path.exists() else None
    mapping_report=json.loads(mapping_path.read_text(encoding="utf-8")) if mapping_path.exists() else {"mappings":[],"statuses":{}}
    mapping_by_id={str(m.get("source_concept",{}).get("id")):m for m in mapping_report.get("mappings",[])}
    byid={}; byname={}
    if catalog:
        for product in catalog.get("products",[]):
            pid="db:"+str(product["id"]); byid[str(product["id"])]=pid; byname[product["name"]]=pid
            mapping=mapping_by_id.get(str(product["id"]),{})
            nodes.append({"id":pid,"name":product["name"],"type":"PRODUCT","domain":product.get("domain"),"subdomain":product.get("subdomain"),"source":"Databricks Pharmaceuticals Product MVM","version":catalog.get("version"),"description":product.get("description"),"attributes":product.get("attributes",[]),"keys":product.get("keys",[]),"mapping_status":mapping.get("mapping_status","UNRESOLVED"),"mapping_rationale":mapping.get("rationale"),"provenance":{"source":catalog.get("source"),"sha256":catalog.get("source_sha256"),"source_mode":catalog.get("source_mode"),"fixture_notice":catalog.get("fixture_notice")}})
            for attr in product.get("attributes",[]):
                aid="attr:"+str(attr["id"]); amapping=mapping_by_id.get(str(attr["id"]),{})
                nodes.append({"id":aid,"name":attr["name"],"type":"ATTRIBUTE","domain":product.get("domain"),"subdomain":product.get("subdomain"),"source":"Databricks Pharmaceuticals Product MVM","version":catalog.get("version"),"description":attr.get("description"),"attributes":[],"mapping_status":amapping.get("mapping_status","UNRESOLVED"),"mapping_rationale":amapping.get("rationale"),"provenance":{"source":catalog.get("source"),"sha256":catalog.get("source_sha256"),"attribute_source_metadata":attr.get("source_metadata",{})}})
                edges.append({"source":pid,"target":aid,"label":"CONTAINS_ATTRIBUTE"})
        for rel in catalog.get("relationships",[]):
            src=byid.get(str(rel.get("source")),byname.get(str(rel.get("source"))))
            dst=byid.get(str(rel.get("target")),byname.get(str(rel.get("target"))))
            if src and dst: edges.append({"source":src,"target":dst,"label":str(rel.get("type") or "RELATIONSHIP").upper(),"metadata":rel})
    if vocabulary_path.exists():
        vocab=json.loads(vocabulary_path.read_text(encoding="utf-8"))
        def visit(obj):
            if isinstance(obj,dict):
                cid=obj.get("id"); name=obj.get("canonical_name") or obj.get("name")
                if cid and name:
                    nodes.append({"id":"watson:"+str(cid),"name":str(name),"type":"WATSON_ENTITY","source":"Watson curated vocabulary","version":vocab.get("vocabulary_version"),"description":obj.get("description"),"attributes":[],"aliases":obj.get("aliases",[]),"mapping_status":"WATSON_CANONICAL","provenance":{"file":"data/seed/seed_vocabularies.json"}})
                for val in obj.values(): visit(val)
            elif isinstance(obj,list):
                for val in obj: visit(val)
        visit(vocab.get("vocabularies",{}))
    ids={n["id"] for n in nodes}
    for mapping in mapping_report.get("mappings",[]):
        target=mapping.get("target_concept"); sid="db:"+str(mapping.get("source_concept",{}).get("id")); tid="watson:"+str(target.get("id")) if target else None
        if tid and sid in ids and tid in ids: edges.append({"source":sid,"target":tid,"label":"MAPPED_TO","status":mapping.get("mapping_status"),"metadata":mapping})
    return {"nodes":nodes,"edges":edges,"mappings":mapping_report.get("mappings",[]),"mapping_statuses":mapping_report.get("statuses",{}),"source_version":catalog.get("version") if catalog else None,"last_refresh":catalog.get("ingested_at") if catalog else None,"catalog_loaded":bool(catalog),"source_mode":catalog.get("source_mode") if catalog else None,"fixture_notice":catalog.get("fixture_notice") if catalog else None}
