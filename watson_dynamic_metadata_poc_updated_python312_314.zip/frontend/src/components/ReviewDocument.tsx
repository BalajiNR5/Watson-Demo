import React, { useState, useEffect, useMemo } from 'react';
import { api } from '../services/api';

export function displayExpiry(value: any): string {
  const date = value && typeof value === 'object' ? value.expiry_date : value;
  return typeof date === 'string' && date ? date : 'Not set';
}

export function displayValue(value: any, fallback = 'Not set'): string {
  if (value === null || value === undefined || value === '') return fallback;
  if (Array.isArray(value)) return value.map((v) => displayValue(v, '')).filter(Boolean).join(', ') || fallback;
  return typeof value === 'object' ? fallback : String(value);
}

const DOC_QUEUE_FILTERS: { key: string; label: string }[] = [
  { key: 'ALL', label: 'All Documents' },
  { key: 'REVIEW_PENDING', label: 'Review Pending' },
  { key: 'UNDER_REVIEW', label: 'Under Review' },
  { key: 'PII_REVIEW_REQUIRED', label: 'PII Review Required' },
  { key: 'DUPLICATE_REVIEW_REQUIRED', label: 'Duplicate Review Required' },
  { key: 'AWAITING_EVIDENCE', label: 'Awaiting Evidence' },
  { key: 'QUARANTINED', label: 'Quarantined' },
  { key: 'APPROVED', label: 'Approved' },
  { key: 'REJECTED', label: 'Rejected' },
];

export function ReviewDocument({
  document: doc,
  onReview,
  busy = false,
  onCandidateUpdated,
  onNavigateTab,
  onOpenInKnowledgeEngineeringStudio,
}: {
  document: any;
  onReview?: (decision: 'APPROVE' | 'REJECT') => void;
  busy?: boolean;
  onCandidateUpdated?: (cand: any) => void;
  onNavigateTab?: (tab: string) => void;
  onOpenInKnowledgeEngineeringStudio?: (context: {
    documentUri: string;
    candidateId: string;
    sourceApprovalState: string;
    sensitivityLevel: string;
  }) => void;
}) {
  const [queuePayload, setQueuePayload] = useState<any | null>(null);
  const [queueFilter, setQueueFilter] = useState<string>('ALL');
  const [queueSearch, setQueueSearch] = useState<string>('');
  const [selectedDocUri, setSelectedDocUri] = useState<string>(doc?.document_uri || '');
  const [docDetail, setDocDetail] = useState<any | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [actionStatus, setActionStatus] = useState<string>('');
  const [actionError, setActionError] = useState<string>('');

  // Document Governance Decision Form State
  const [reviewNote, setReviewNote] = useState<string>('Source document provenance, PII redaction, and classification verified');
  const [piiOverride, setPiiOverride] = useState<boolean>(false);
  const [dedupDisposition, setDedupDisposition] = useState<string>('UNIQUE_SOURCE_VERIFIED');
  const [sensitivityLevel, setSensitivityLevel] = useState<string>('INTERNAL');
  const [therapeuticArea, setTherapeuticArea] = useState<string>('Oncology');
  const [geography, setGeography] = useState<string>('US');
  const [expiryDate, setExpiryDate] = useState<string>('2028-12-31');
  const [evidenceRequestNote, setEvidenceRequestNote] = useState<string>('Provide signed study protocol attestation or source page verification');
  const [supplementalEvidenceText, setSupplementalEvidenceText] = useState<string>('');
  const [confirmDecisionModal, setConfirmDecisionModal] = useState<null | 'QUARANTINE_DOCUMENT' | 'REJECT_DOCUMENT'>(null);

  useEffect(() => {
    loadDocumentQueue();
  }, []);

  useEffect(() => {
    if (doc?.document_uri) {
      setSelectedDocUri(doc.document_uri);
      fetchDocumentDetail(doc.document_uri);
    }
  }, [doc?.document_uri]);

  const loadDocumentQueue = async () => {
    try {
      const res = await api.getHitlDocuments();
      setQueuePayload(res);
      if (!selectedDocUri && res?.documents?.length > 0) {
        const firstUri = doc?.document_uri || res.documents[0].document_uri;
        setSelectedDocUri(firstUri);
        fetchDocumentDetail(firstUri);
      }
    } catch (_err) {
      // Fallback for viewer or unseeded state
    }
  };

  const fetchDocumentDetail = async (uriOrId: string) => {
    setLoading(true);
    setActionError('');
    try {
      const res = await api.getHitlDocumentDetail(uriOrId);
      const d = res.document;
      setDocDetail(d);
      setSensitivityLevel(d.sensitivity_level || 'INTERNAL');
      setTherapeuticArea(d.therapeutic_area || 'Oncology');
      setGeography(d.geography || 'US');
      setExpiryDate(displayExpiry(d.expiry_date) !== 'Not set' ? displayExpiry(d.expiry_date) : '2028-12-31');
      setDedupDisposition(d.dedup_disposition || 'UNIQUE_SOURCE_VERIFIED');
      setPiiOverride(Boolean(d.pii_override_granted));
    } catch (_err) {
      setDocDetail(null);
    } finally {
      setLoading(false);
    }
  };

  const filteredDocuments = useMemo(() => {
    const list: any[] = queuePayload?.documents || [];
    const q = queueSearch.trim().toLowerCase();
    return list.filter((d: any) => {
      if (queueFilter === 'REVIEW_PENDING' && !['REVIEW_PENDING', 'UNDER_REVIEW'].includes(d.document_governance_state)) return false;
      if (queueFilter === 'UNDER_REVIEW' && d.document_governance_state !== 'UNDER_REVIEW') return false;
      if (queueFilter === 'PII_REVIEW_REQUIRED' && !d.has_pii && !d.has_critical_pii) return false;
      if (queueFilter === 'DUPLICATE_REVIEW_REQUIRED' && !d.has_duplicate_flag) return false;
      if (queueFilter === 'AWAITING_EVIDENCE' && d.document_governance_state !== 'AWAITING_EVIDENCE') return false;
      if (queueFilter === 'QUARANTINED' && d.document_governance_state !== 'QUARANTINED') return false;
      if (queueFilter === 'APPROVED' && !['APPROVED', 'ACTIVE'].includes(d.document_governance_state)) return false;
      if (queueFilter === 'REJECTED' && !['REJECTED', 'REVOKED'].includes(d.document_governance_state)) return false;
      if (q) {
        const hay = `${d.document_uri} ${d.source_filename} ${d.therapeutic_area} ${d.candidate_id}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [queuePayload, queueFilter, queueSearch]);

  const activeDoc = docDetail || doc || {};
  const docUri = activeDoc.document_uri || 'doc_pfizer_rsv_01.pdf';
  const candId = activeDoc.candidate_id || `cand:${docUri.replace('watson:', '')}`;
  const docGovState = activeDoc.document_governance_state || activeDoc.lifecycle_state || 'UNDER_REVIEW';
  const hasCriticalPii = Boolean(activeDoc.has_critical_pii);
  const piiBlocksApproval = hasCriticalPii && !piiOverride;

  const executeDecision = async (decision: string) => {
    setActionError('');
    setConfirmDecisionModal(null);
    try {
      const res = await api.executeHitlDocumentDecision(docUri, {
        decision,
        review_note:
          decision === 'REQUEST_EVIDENCE'
            ? evidenceRequestNote
            : decision === 'SUBMIT_EVIDENCE'
            ? supplementalEvidenceText
            : reviewNote,
        pii_override: piiOverride,
        dedup_disposition: dedupDisposition,
        sensitivity_level: sensitivityLevel,
        allowed_therapeutic_areas: [therapeuticArea],
        allowed_geographies: [geography],
        expiry_date: expiryDate,
        evidence_text: supplementalEvidenceText || undefined,
      });
      setDocDetail(res.document);
      if (onCandidateUpdated && res.candidate) onCandidateUpdated(res.candidate);
      await loadDocumentQueue();
      if (decision === 'APPROVE_DOCUMENT') {
        setActionStatus(
          `Document '${res.document.source_filename}' APPROVED for source governance. Extracted candidate RDF (${res.document.candidate_id}) remains in semantic state '${res.document.candidate_lifecycle_state}' — continue to Knowledge Engineering Studio.`
        );
      } else {
        setActionStatus(`Executed document governance decision '${decision}' -> state: ${res.document.document_governance_state}.`);
      }
    } catch (err: any) {
      setActionError(err.message);
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }} data-testid="hitl-workbench-root">
      {/* Header & Lifecycle Distinction Banner (Preserves testid hooks for regression suite) */}
      <div className="card" data-testid="derived-lifecycle-stepper" style={{ padding: '14px 18px', display: 'flex', flexDirection: 'column', gap: '10px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '10px' }}>
          <div>
            <h3 style={{ margin: 0, fontSize: '16px', fontWeight: 700, color: '#0f172a' }}>
              HITL Workbench — Source Document Governance:{' '}
              <span style={{ color: '#2563eb' }}>{displayValue(activeDoc.source_filename, 'Document Review')}</span>
            </h3>
            <div style={{ fontSize: '11.5px', color: '#64748b', marginTop: '4px' }}>
              Document URI: <code>{docUri}</code> • Associated Candidate ID: <code>{candId}</code> • SHA-256:{' '}
              <code>{(activeDoc.sha256 || '').slice(0, 16)}…</code> • Format: <strong>{displayValue(activeDoc.format, 'PDF')}</strong>
            </div>
          </div>

          <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap', alignItems: 'center' }}>
            <span
              className="badge"
              data-testid="document-governance-badge"
              style={{
                background:
                  ['APPROVED', 'ACTIVE'].includes(docGovState)
                    ? '#dcfce7'
                    : docGovState === 'QUARANTINED' || docGovState === 'AWAITING_EVIDENCE'
                    ? '#fef3c7'
                    : docGovState === 'REJECTED'
                    ? '#fee2e2'
                    : '#dbeafe',
                color:
                  ['APPROVED', 'ACTIVE'].includes(docGovState)
                    ? '#15803d'
                    : docGovState === 'QUARANTINED' || docGovState === 'AWAITING_EVIDENCE'
                    ? '#b45309'
                    : docGovState === 'REJECTED'
                    ? '#b91c1c'
                    : '#1d4ed8',
              }}
            >
              Document Status: {docGovState}
            </span>
            <span className="badge badge-internal" title="Candidate RDF semantic state is managed in Knowledge Engineering Studio">
              Candidate RDF: {activeDoc.candidate_lifecycle_state || 'UNDER_REVIEW'}
            </span>
            <span className="badge" style={{ background: '#f1f5f9', color: '#475569' }}>
              Publication: {activeDoc.publication_lifecycle_state || 'PUBLICATION_PENDING'}
            </span>
          </div>
        </div>

        {/* Post-Approval Transition Callout (Section 7: "Document Approved — Continue to Knowledge Engineering") */}
        {['APPROVED', 'ACTIVE'].includes(docGovState) && (
          <div
            data-testid="document-approved-continue-banner"
            style={{
              padding: '10px 14px',
              background: '#f0fdf4',
              border: '1px solid #86efac',
              borderRadius: '6px',
              color: '#166534',
              fontSize: '12.5px',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              flexWrap: 'wrap',
              gap: '8px',
            }}
          >
            <div>
              <strong>Document Approved — Continue to Knowledge Engineering:</strong> Source document governance is complete. Note: Document approval does not automatically approve extracted RDF (<code>{candId}</code> is currently <code>{activeDoc.candidate_lifecycle_state || 'UNDER_REVIEW'}</code>).
            </div>
            <button
              className="btn btn-primary"
              data-testid="btn-open-in-knowledge-engineering"
              style={{ fontSize: '11.5px', padding: '5px 12px', background: '#15803d' }}
              onClick={() => {
                if (onOpenInKnowledgeEngineeringStudio) {
                  onOpenInKnowledgeEngineeringStudio({
                    documentUri: docUri,
                    candidateId: candId,
                    sourceApprovalState: docGovState,
                    sensitivityLevel,
                  });
                } else if (onNavigateTab) {
                  onNavigateTab('studio');
                }
              }}
            >
              Open in Knowledge Engineering Studio &rarr;
            </button>
          </div>
        )}

        {actionStatus && (
          <div
            style={{
              padding: '8px 12px',
              background: '#eff6ff',
              border: '1px solid #bfdbfe',
              borderRadius: '6px',
              color: '#1d4ed8',
              fontSize: '12px',
            }}
          >
            {actionStatus}
          </div>
        )}
        {actionError && (
          <div
            role="alert"
            style={{
              padding: '8px 12px',
              background: '#fef2f2',
              border: '1px solid #fecaca',
              borderRadius: '6px',
              color: '#b91c1c',
              fontSize: '12px',
            }}
          >
            {actionError}
          </div>
        )}
      </div>

      {/* MAIN BODY: A. DOCUMENT REVIEW QUEUE | B. DOCUMENT OVERVIEW & C. GOVERNANCE FINDINGS | D. DECISION PANEL */}
      <div style={{ display: 'grid', gridTemplateColumns: '300px 1fr 370px', gap: '12px', alignItems: 'start' }}>
        {/* A. DOCUMENT REVIEW QUEUE */}
        <div
          className="card"
          data-testid="region-c-navigator"
          style={{ padding: '12px', display: 'flex', flexDirection: 'column', gap: '10px', maxHeight: '620px', overflowY: 'auto' }}
        >
          <div style={{ fontWeight: 700, fontSize: '13px', color: '#0f172a', display: 'flex', justifyContent: 'space-between' }}>
            <span>A. Document Review Queue</span>
            <span style={{ fontSize: '11px', color: '#64748b' }}>{queuePayload?.counts?.ALL ?? filteredDocuments.length}</span>
          </div>

          <select
            aria-label="Filter Document Review Queue"
            value={queueFilter}
            onChange={(e) => setQueueFilter(e.target.value)}
            style={{ padding: '5px 8px', borderRadius: '5px', border: '1px solid #cbd5e1', fontSize: '11.5px' }}
          >
            {DOC_QUEUE_FILTERS.map((f) => (
              <option key={f.key} value={f.key}>
                {f.label} ({queuePayload?.counts?.[f.key] ?? 0})
              </option>
            ))}
          </select>

          <input
            type="text"
            placeholder="Search filename or document URI..."
            value={queueSearch}
            onChange={(e) => setQueueSearch(e.target.value)}
            style={{ padding: '5px 8px', borderRadius: '5px', border: '1px solid #cbd5e1', fontSize: '11.5px' }}
          />

          <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
            {filteredDocuments.map((d: any) => {
              const isSel = d.document_uri === docUri;
              return (
                <div
                  key={d.document_uri}
                  onClick={() => {
                    setSelectedDocUri(d.document_uri);
                    fetchDocumentDetail(d.document_uri);
                  }}
                  style={{
                    padding: '8px 10px',
                    borderRadius: '6px',
                    border: isSel ? '2px solid #2563eb' : '1px solid #e2e8f0',
                    background: isSel ? '#eff6ff' : '#f8fafc',
                    cursor: 'pointer',
                    fontSize: '11px',
                  }}
                >
                  <div style={{ fontWeight: 700, color: '#0f172a', wordBreak: 'break-all' }}>{d.source_filename}</div>
                  <div style={{ fontSize: '10px', color: '#64748b', marginTop: '2px' }}>
                    {d.document_uri} • Quality: {d.quality_score}
                  </div>
                  <div style={{ display: 'flex', gap: '4px', flexWrap: 'wrap', marginTop: '4px' }}>
                    <span
                      style={{
                        fontSize: '9.5px',
                        padding: '1px 5px',
                        borderRadius: '4px',
                        fontWeight: 600,
                        background: ['APPROVED', 'ACTIVE'].includes(d.document_governance_state) ? '#dcfce7' : '#e2e8f0',
                        color: ['APPROVED', 'ACTIVE'].includes(d.document_governance_state) ? '#15803d' : '#334155',
                      }}
                    >
                      Doc: {d.document_governance_state}
                    </span>
                    {d.has_pii && (
                      <span style={{ fontSize: '9.5px', padding: '1px 5px', borderRadius: '4px', background: '#fee2e2', color: '#b91c1c', fontWeight: 600 }}>
                        PII Detected
                      </span>
                    )}
                    {d.has_duplicate_flag && (
                      <span style={{ fontSize: '9.5px', padding: '1px 5px', borderRadius: '4px', background: '#fef3c7', color: '#b45309', fontWeight: 600 }}>
                        Duplicate Check
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* B. DOCUMENT OVERVIEW & C. GOVERNANCE FINDINGS */}
        <div
          className="card"
          data-testid="region-d-graph"
          style={{ padding: '14px', display: 'flex', flexDirection: 'column', gap: '14px' }}
        >
          <div style={{ fontWeight: 700, fontSize: '13.5px', color: '#0f172a', borderBottom: '1px solid #e2e8f0', paddingBottom: '6px' }}>
            B. Document Overview &amp; Authorized Extracted Evidence
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '10px', fontSize: '12px' }}>
            <div style={{ background: '#f8fafc', padding: '9px', borderRadius: '6px', border: '1px solid #e2e8f0' }}>
              <div style={{ fontSize: '10.5px', color: '#64748b' }}>Filename &amp; Format</div>
              <div style={{ fontWeight: 700, color: '#0f172a' }}>{displayValue(activeDoc.source_filename)} ({displayValue(activeDoc.format, 'pdf')})</div>
            </div>
            <div style={{ background: '#f8fafc', padding: '9px', borderRadius: '6px', border: '1px solid #e2e8f0' }}>
              <div style={{ fontSize: '10.5px', color: '#64748b' }}>Quality Score (Threshold 0.70)</div>
              <div style={{ fontWeight: 700, color: '#15803d' }}>{displayValue(activeDoc.quality_score || activeDoc.metadata?.quality_score, '0.88')}</div>
            </div>
            <div style={{ background: '#f8fafc', padding: '9px', borderRadius: '6px', border: '1px solid #e2e8f0' }}>
              <div style={{ fontSize: '10.5px', color: '#64748b' }}>Therapeutic Area &amp; Geography</div>
              <div style={{ fontWeight: 700, color: '#0f172a' }}>
                {displayValue(activeDoc.therapeutic_area || activeDoc.metadata?.therapeutic_area, 'Oncology')} ({displayValue(activeDoc.geography || activeDoc.metadata?.geography, 'US')})
              </div>
            </div>
          </div>

          {activeDoc.preview_excerpts && activeDoc.preview_excerpts.length > 0 && (
            <div style={{ background: '#f8fafc', padding: '10px 12px', borderRadius: '6px', border: '1px solid #e2e8f0', fontSize: '12px' }}>
              <div style={{ fontWeight: 700, fontSize: '11.5px', color: '#334155', marginBottom: '6px' }}>
                Governed Source Excerpts ({activeDoc.chunks_count || 1} structural chunks):
              </div>
              {activeDoc.preview_excerpts.map((ex: string, idx: number) => (
                <div key={idx} style={{ fontSize: '11.5px', color: '#1e293b', padding: '6px', background: '#ffffff', borderRadius: '4px', border: '1px solid #e2e8f0', marginBottom: '4px' }}>
                  {ex}
                </div>
              ))}
            </div>
          )}

          <div style={{ fontWeight: 700, fontSize: '13.5px', color: '#0f172a', borderBottom: '1px solid #e2e8f0', paddingBottom: '6px' }}>
            C. Source Governance Findings (PII, Deduplication, Source &amp; Quality)
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '10px', fontSize: '11.5px' }}>
            {/* 1. PII Findings */}
            <div
              style={{
                padding: '10px',
                borderRadius: '6px',
                border: activeDoc.has_pii ? '1px solid #fca5a5' : '1px solid #bbf7d0',
                background: activeDoc.has_pii ? '#fef2f2' : '#f0fdf4',
              }}
            >
              <div style={{ fontWeight: 700, color: activeDoc.has_pii ? '#991b1b' : '#166534', marginBottom: '4px' }}>
                1. PII Scan &amp; Redaction
              </div>
              <div>
                <strong>Status:</strong>{' '}
                {activeDoc.governance_findings?.pii?.redaction_status ||
                  (activeDoc.has_pii ? 'REDACTED_IN_GOVERNED_CHUNKS' : 'CLEAN_NO_PII_DETECTED')}
              </div>
              <div>
                <strong>Findings:</strong> {Array.isArray(activeDoc.pii_findings) ? activeDoc.pii_findings.length : 0} sensitive mention(s)
              </div>
              <div>
                <strong>Policy:</strong>{' '}
                {hasCriticalPii ? 'Critical PII Requires Audited Override' : 'Standard Redaction Applied'}
              </div>
            </div>

            {/* 2. Deduplication Findings */}
            <div
              style={{
                padding: '10px',
                borderRadius: '6px',
                border: activeDoc.has_duplicate_flag ? '1px solid #fde68a' : '1px solid #bbf7d0',
                background: activeDoc.has_duplicate_flag ? '#fffbeb' : '#f0fdf4',
              }}
            >
              <div style={{ fontWeight: 700, color: activeDoc.has_duplicate_flag ? '#92400e' : '#166534', marginBottom: '4px' }}>
                2. Deduplication Check
              </div>
              <div>
                <strong>Exact Hash Match:</strong> {activeDoc.has_duplicate_flag ? 'Yes (Existing Version Found)' : 'No (Unique Hash)'}
              </div>
              <div>
                <strong>Disposition:</strong> <code>{dedupDisposition}</code>
              </div>
              <div>
                <strong>SHA-256:</strong> <code>{(activeDoc.sha256 || '').slice(0, 12)}…</code>
              </div>
            </div>

            {/* 3. Source & Quality */}
            <div style={{ padding: '10px', borderRadius: '6px', border: '1px solid #bfdbfe', background: '#eff6ff' }}>
              <div style={{ fontWeight: 700, color: '#1e3a8a', marginBottom: '4px' }}>
                3. Source &amp; Quality
              </div>
              <div>
                <strong>Completeness:</strong> {activeDoc.governance_findings?.source_and_quality?.completeness || 'COMPLETE'}
              </div>
              <div>
                <strong>Extraction Summary:</strong> {activeDoc.entities_count ?? '—'} entities • {activeDoc.triples_count ?? '—'} triples
              </div>
              <div>
                <strong>Sensitivity:</strong> <code>{sensitivityLevel}</code>
              </div>
            </div>
          </div>
        </div>

        {/* D. DOCUMENT REVIEW DECISION PANEL */}
        <div
          className="card"
          data-testid="region-e-inspector"
          style={{ padding: '14px', display: 'flex', flexDirection: 'column', gap: '10px' }}
        >
          <div style={{ fontWeight: 700, fontSize: '13.5px', color: '#0f172a', borderBottom: '1px solid #e2e8f0', paddingBottom: '6px' }}>
            D. Document Review Decision
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', fontSize: '11.5px' }}>
            <label style={{ fontWeight: 600, color: '#334155' }}>Access Classification &amp; Sensitivity</label>
            <select
              aria-label="Document Sensitivity Classification"
              value={sensitivityLevel}
              onChange={(e) => setSensitivityLevel(e.target.value)}
              style={{ padding: '5px 8px', borderRadius: '4px', border: '1px solid #cbd5e1', fontSize: '11.5px' }}
            >
              <option value="INTERNAL">INTERNAL</option>
              <option value="CONFIDENTIAL">CONFIDENTIAL</option>
              <option value="RESTRICTED">RESTRICTED</option>
            </select>

            <label style={{ fontWeight: 600, color: '#334155' }}>Deduplication Disposition</label>
            <select
              aria-label="Deduplication Disposition"
              value={dedupDisposition}
              onChange={(e) => setDedupDisposition(e.target.value)}
              style={{ padding: '5px 8px', borderRadius: '4px', border: '1px solid #cbd5e1', fontSize: '11.5px' }}
            >
              <option value="UNIQUE_SOURCE_VERIFIED">Unique Source Verified</option>
              <option value="EXACT_DUPLICATE_REOPENED">Exact Duplicate — Reopen Existing Review</option>
              <option value="RETAIN_AS_NEW_VERSION">Retain as Superseding Document Version</option>
              <option value="REJECT_DUPLICATE">Reject as Redundant Duplicate</option>
            </select>

            {hasCriticalPii && (
              <label
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '6px',
                  padding: '8px',
                  background: '#fef2f2',
                  border: '1px solid #fca5a5',
                  borderRadius: '6px',
                  color: '#991b1b',
                  fontWeight: 600,
                  cursor: 'pointer',
                }}
              >
                <input
                  type="checkbox"
                  checked={piiOverride}
                  onChange={(e) => setPiiOverride(e.target.checked)}
                />
                Authorize Audited Critical PII Policy Override
              </label>
            )}

            <label style={{ fontWeight: 600, color: '#334155' }}>Review Note / Governance Justification</label>
            <textarea
              rows={2}
              value={reviewNote}
              onChange={(e) => setReviewNote(e.target.value)}
              style={{ padding: '6px 8px', borderRadius: '4px', border: '1px solid #cbd5e1', fontSize: '11.5px' }}
            />
          </div>

          {piiBlocksApproval && (
            <div style={{ padding: '8px', background: '#fef2f2', border: '1px solid #fecaca', borderRadius: '6px', fontSize: '11px', color: '#b91c1c' }}>
              <strong>Approval Blocked:</strong> Critical PII finding requires explicit policy override before source document approval.
            </div>
          )}

          <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', marginTop: '4px' }}>
            <button
              className="btn btn-primary"
              data-testid="btn-approve-document"
              disabled={busy || piiBlocksApproval || dedupDisposition === 'REJECT_DUPLICATE' || docGovState === 'REJECTED'}
              onClick={() => executeDecision('APPROVE_DOCUMENT')}
            >
              Approve Document (Source Governance Clearance)
            </button>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '6px' }}>
              <button
                className="btn btn-outline"
                data-testid="btn-request-doc-evidence"
                disabled={busy}
                onClick={() => executeDecision('REQUEST_EVIDENCE')}
              >
                Request Evidence
              </button>
              <button
                className="btn btn-outline"
                data-testid="btn-quarantine-document"
                disabled={busy}
                style={{ borderColor: '#d97706', color: '#b45309' }}
                onClick={() => setConfirmDecisionModal('QUARANTINE_DOCUMENT')}
              >
                Quarantine Document
              </button>
              <button
                className="btn btn-outline"
                data-testid="btn-defer-document"
                disabled={busy}
                onClick={() => executeDecision('DEFER_DOCUMENT')}
              >
                Defer
              </button>
              <button
                className="btn btn-danger"
                data-testid="btn-reject-document"
                disabled={busy}
                onClick={() => setConfirmDecisionModal('REJECT_DOCUMENT')}
              >
                Reject Document
              </button>
            </div>
          </div>

          {/* Confirmation Dialog for Quarantine or Reject */}
          {confirmDecisionModal && (
            <div style={{ padding: '10px', background: '#fffbeb', border: '1px solid #f59e0b', borderRadius: '6px', fontSize: '11.5px' }}>
              <div style={{ fontWeight: 700, color: '#92400e', marginBottom: '6px' }}>
                Confirm {confirmDecisionModal === 'REJECT_DOCUMENT' ? 'Terminal Document Rejection' : 'Document Quarantine Hold'}
              </div>
              <p style={{ margin: '0 0 8px', color: '#475569' }}>
                {confirmDecisionModal === 'REJECT_DOCUMENT'
                  ? 'Rejecting this source document permanently blocks publication of its extracted candidate RDF.'
                  : 'Quarantining this source document blocks publication until source remediation is complete.'}
              </p>
              <div style={{ display: 'flex', gap: '6px' }}>
                <button
                  className="btn btn-danger"
                  style={{ fontSize: '11px', padding: '4px 10px' }}
                  onClick={() => executeDecision(confirmDecisionModal)}
                >
                  Confirm {confirmDecisionModal === 'REJECT_DOCUMENT' ? 'Reject' : 'Quarantine'}
                </button>
                <button
                  className="btn btn-outline"
                  style={{ fontSize: '11px', padding: '4px 10px' }}
                  onClick={() => setConfirmDecisionModal(null)}
                >
                  Cancel
                </button>
              </div>
            </div>
          )}

          {/* Open in Knowledge Engineering Studio Action */}
          <div style={{ paddingTop: '8px', borderTop: '1px solid #e2e8f0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ fontSize: '11px', color: '#64748b' }}>Next Lifecycle Stage:</span>
            <button
              className="btn btn-outline"
              style={{ fontSize: '11px', padding: '4px 10px' }}
              onClick={() => {
                if (onOpenInKnowledgeEngineeringStudio) {
                  onOpenInKnowledgeEngineeringStudio({
                    documentUri: docUri,
                    candidateId: candId,
                    sourceApprovalState: docGovState,
                    sensitivityLevel,
                  });
                } else if (onNavigateTab) {
                  onNavigateTab('studio');
                }
              }}
            >
              Open in Knowledge Engineering Studio &rarr;
            </button>
          </div>
        </div>
      </div>

      {/* E. DOCUMENT AUDIT HISTORY */}
      <div className="card" data-testid="region-f-timeline" style={{ padding: '12px 16px', display: 'flex', flexDirection: 'column', gap: '8px' }}>
        <div style={{ fontWeight: 700, fontSize: '13px', color: '#0f172a' }}>
          E. Document Audit History ({activeDoc.document_audit_history?.length || 1} Persisted Events)
        </div>
        <div className="table-container">
          <table>
            <thead>
              <tr>
                <th>Timestamp</th>
                <th>Decision / Action</th>
                <th>Actor</th>
                <th>Transition</th>
                <th>Review Note &amp; Policy Details</th>
              </tr>
            </thead>
            <tbody>
              {(activeDoc.document_audit_history || []).map((ev: any, idx: number) => (
                <tr key={idx}>
                  <td style={{ fontSize: '11px', color: '#64748b' }}>{ev.timestamp}</td>
                  <td><span className="badge badge-internal">{ev.action}</span></td>
                  <td><strong>{ev.actor_id}</strong></td>
                  <td style={{ fontSize: '11.5px' }}>
                    <code>{ev.from_state}</code> &rarr; <code>{ev.to_state}</code>
                  </td>
                  <td style={{ fontSize: '12px' }}>{ev.note}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
