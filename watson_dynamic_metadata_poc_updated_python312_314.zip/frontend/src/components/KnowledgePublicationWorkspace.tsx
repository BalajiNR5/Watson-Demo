import React, { useState, useEffect, useMemo } from 'react';
import { api } from '../services/api';

export interface KnowledgePublicationWorkspaceProps {
  initialCandidateId?: string;
  initialDocumentUri?: string;
  onNavigateWorkspace?: (
    tab: 'hitl' | 'studio' | 'kg' | 'sparql' | 'governance' | 'copilot',
    context?: { documentUri?: string; candidateId?: string }
  ) => void;
}

const PUB_QUEUE_FILTERS: { key: string; label: string }[] = [
  { key: 'ALL', label: 'All Candidate Releases' },
  { key: 'APPROVED_AWAITING_PUBLICATION', label: 'Approved Awaiting Publication' },
  { key: 'BLOCKED_BY_GOVERNANCE', label: 'Blocked by Missing Governance' },
  { key: 'STAGED_RELEASES', label: 'Staged Releases' },
  { key: 'PUBLISHED_RELEASES', label: 'Published Releases' },
  { key: 'FAILED_RELEASES', label: 'Failed Releases (Recovery Required)' },
  { key: 'WITHDRAWN_OR_SUPERSEDED', label: 'Withdrawn / Superseded Releases' },
];

export const KnowledgePublicationWorkspace: React.FC<KnowledgePublicationWorkspaceProps> = ({
  initialCandidateId,
  initialDocumentUri,
  onNavigateWorkspace,
}) => {
  const [queuePayload, setQueuePayload] = useState<any | null>(null);
  const [selectedFilter, setSelectedFilter] = useState<string>('ALL');
  const [selectedCandidateId, setSelectedCandidateId] = useState<string>(initialCandidateId || '');
  const [selectedReleaseDetail, setSelectedReleaseDetail] = useState<any | null>(null);
  const [showManifestModal, setShowManifestModal] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [busy, setBusy] = useState<boolean>(false);

  useEffect(() => {
    loadPublicationQueue();
  }, []);

  useEffect(() => {
    if (initialCandidateId) {
      setSelectedCandidateId(initialCandidateId);
    } else if (initialDocumentUri && queuePayload?.releases) {
      const matched = queuePayload.releases.find((r: any) => r.document_uri === initialDocumentUri);
      if (matched) setSelectedCandidateId(matched.candidate_id);
    }
  }, [initialCandidateId, initialDocumentUri]);

  useEffect(() => {
    if (selectedCandidateId) {
      loadReleaseReadiness(selectedCandidateId);
    }
  }, [selectedCandidateId]);

  const loadPublicationQueue = async () => {
    try {
      const q = await api.getPublicationsQueue();
      setQueuePayload(q);
      if (!selectedCandidateId && q?.releases?.length > 0) {
        const firstId = initialCandidateId || q.releases[0].candidate_id;
        setSelectedCandidateId(firstId);
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to load Knowledge Publication queue');
    }
  };

  const loadReleaseReadiness = async (cid: string) => {
    try {
      const [candRes, trRes] = await Promise.all([
        api.getCandidateDetail(cid),
        api.getThreeTrackPublicationReadiness(cid),
      ]);
      setSelectedReleaseDetail({
        candidate: candRes.candidate,
        readiness: trRes,
      });
    } catch (_err) {
      // Fallback
    }
  };

  const filteredReleases = useMemo(() => {
    if (!queuePayload) return [];
    if (selectedFilter === 'ALL') return queuePayload.releases || [];
    const mapKey: Record<string, string> = {
      APPROVED_AWAITING_PUBLICATION: 'approved_awaiting_publication',
      BLOCKED_BY_GOVERNANCE: 'blocked_by_governance',
      STAGED_RELEASES: 'staged_releases',
      PUBLISHED_RELEASES: 'published_releases',
      FAILED_RELEASES: 'failed_releases',
      WITHDRAWN_OR_SUPERSEDED: 'withdrawn_or_superseded',
    };
    return queuePayload.queues?.[mapKey[selectedFilter]] || [];
  }, [queuePayload, selectedFilter]);

  const activeCand = selectedReleaseDetail?.candidate;
  const activeReadiness = selectedReleaseDetail?.readiness || activeCand?.three_track_readiness;
  const derivedOutcome: string = activeReadiness?.derived_outcome || 'Semantic Review Pending';
  const canStage = Boolean(activeReadiness?.can_stage);
  const canVerify = Boolean(activeReadiness?.can_verify);
  const canActivate = Boolean(activeReadiness?.can_activate);
  const pState = activeCand?.publication_lifecycle_state || 'PUBLICATION_PENDING';

  const handleStageRelease = async () => {
    if (!activeCand || busy) return;
    setBusy(true);
    setErrorMessage('');
    setStatusMessage('Staging RDF graph and eligible FAISS chunk vectors into isolated release manifest...');
    try {
      const res = await api.stageCandidateRelease(activeCand.candidate_id);
      setStatusMessage(
        `Release '${res.release_manifest.release_id}' staged (${res.release_manifest.staged_rdf_triples_count} triples, ${res.release_manifest.staged_faiss_chunks_count} chunks). Run "Verify Staged Release" next.`
      );
      await loadPublicationQueue();
      await loadReleaseReadiness(activeCand.candidate_id);
    } catch (err: any) {
      setErrorMessage(err.message);
    } finally {
      setBusy(false);
    }
  };

  const handleVerifyStagedRelease = async () => {
    if (!activeCand || busy) return;
    setBusy(true);
    setErrorMessage('');
    setStatusMessage('Verifying staged release manifest, SHA-256 digest, and source-to-chunk-to-RDF provenance...');
    try {
      const res = await api.verifyStagedRelease(activeCand.candidate_id);
      setStatusMessage(
        `Staged release '${res.release_manifest.release_id}' verified -> READY TO ACTIVATE.`
      );
      await loadPublicationQueue();
      await loadReleaseReadiness(activeCand.candidate_id);
    } catch (err: any) {
      setErrorMessage(err.message);
    } finally {
      setBusy(false);
    }
  };

  const handleActivatePublication = async () => {
    if (!activeCand || busy) return;
    setBusy(true);
    setErrorMessage('');
    setStatusMessage('Activating controlled production release into Trusted Knowledge Graph and FAISS index...');
    try {
      const res = await api.publishCandidate(activeCand.candidate_id, {});
      setStatusMessage(
        `Release Activated (tx=${res.transaction.transaction_id}): Trusted Graph=${res.transaction.trusted_graph_version_after}, Active FAISS Vectors=${res.transaction.faiss_vectors_after}.`
      );
      await loadPublicationQueue();
      await loadReleaseReadiness(activeCand.candidate_id);
    } catch (err: any) {
      setErrorMessage(err.message);
    } finally {
      setBusy(false);
    }
  };

  const handleWithdrawRelease = async (mode: 'WITHDRAWN' | 'SUPERSEDED') => {
    if (!activeCand || busy) return;
    setBusy(true);
    setErrorMessage('');
    try {
      const txId = activeCand.publication_record?.transaction_id || activeCand.candidate_id;
      const res = await api.withdrawPublication(txId, {
        reason: `Controlled ${mode.toLowerCase()} action executed from Knowledge Publication workspace`,
        mode,
      });
      setStatusMessage(`Release '${res.transaction_id}' transitioned to ${res.status} and rolled back from active serving.`);
      await loadPublicationQueue();
      await loadReleaseReadiness(activeCand.candidate_id);
    } catch (err: any) {
      setErrorMessage(err.message);
    } finally {
      setBusy(false);
    }
  };

  const outcomeStyle = (outcome: string) => {
    if (outcome === 'Published') return { bg: '#dcfce7', text: '#15803d', border: '#86efac' };
    if (outcome === 'Ready to Activate' || outcome === 'Eligible for Staging')
      return { bg: '#dbeafe', text: '#1d4ed8', border: '#93c5fd' };
    if (outcome === 'Release Blocked' || outcome === 'Recovery Required')
      return { bg: '#fef2f2', text: '#b91c1c', border: '#fca5a5' };
    return { bg: '#fffbeb', text: '#b45309', border: '#fde68a' };
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }} data-testid="knowledge-publication-workspace-root">
      {/* Header */}
      <div className="card" style={{ padding: '14px 18px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '10px' }}>
        <div>
          <h3 style={{ margin: 0, fontSize: '16px', fontWeight: 700, color: '#0f172a' }}>
            Knowledge Publication &amp; Controlled Release Management
          </h3>
          <p style={{ margin: '4px 0 0', fontSize: '12px', color: '#64748b' }}>
            Independently verifies <strong>Document Governance</strong>, <strong>Semantic Governance</strong>, and <strong>Release Integrity</strong> before promoting approved RDF triples and FAISS retrieval chunks into production.
          </p>
        </div>
        <button className="btn btn-outline" style={{ fontSize: '11.5px', padding: '5px 11px' }} onClick={loadPublicationQueue}>
          Refresh Release Queue
        </button>
      </div>

      {statusMessage && (
        <div
          data-testid="publication-status-banner"
          style={{
            padding: '10px 14px',
            background: '#eff6ff',
            border: '1px solid #bfdbfe',
            borderRadius: '6px',
            color: '#1d4ed8',
            fontSize: '12.5px',
          }}
        >
          {statusMessage}
        </div>
      )}
      {errorMessage && (
        <div
          role="alert"
          style={{
            padding: '10px 14px',
            background: '#fef2f2',
            border: '1px solid #fecaca',
            borderRadius: '6px',
            color: '#b91c1c',
            fontSize: '12.5px',
          }}
        >
          {errorMessage}
        </div>
      )}

      <div style={{ display: 'grid', gridTemplateColumns: '330px 1fr', gap: '14px', alignItems: 'start' }}>
        {/* LEFT: PUBLICATION QUEUE */}
        <div className="card" style={{ padding: '12px', display: 'flex', flexDirection: 'column', gap: '10px' }}>
          <div style={{ fontWeight: 700, fontSize: '13px', color: '#0f172a' }}>Publication Queue</div>
          <select
            aria-label="Filter Publication Queue"
            value={selectedFilter}
            onChange={(e) => setSelectedFilter(e.target.value)}
            style={{ padding: '6px 8px', borderRadius: '5px', border: '1px solid #cbd5e1', fontSize: '12px' }}
          >
            {PUB_QUEUE_FILTERS.map((f) => (
              <option key={f.key} value={f.key}>
                {f.label} ({queuePayload?.counts?.[f.key] ?? 0})
              </option>
            ))}
          </select>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', maxHeight: '520px', overflowY: 'auto' }}>
            {filteredReleases.map((rel: any) => {
              const isSel = rel.candidate_id === selectedCandidateId;
              const st = outcomeStyle(rel.derived_outcome);
              return (
                <div
                  key={rel.candidate_id}
                  data-testid={`pub-queue-item-${rel.candidate_id}`}
                  onClick={() => setSelectedCandidateId(rel.candidate_id)}
                  style={{
                    padding: '9px 10px',
                    borderRadius: '6px',
                    border: isSel ? '2px solid #2563eb' : '1px solid #e2e8f0',
                    background: isSel ? '#eff6ff' : '#f8fafc',
                    cursor: 'pointer',
                    fontSize: '11.5px',
                  }}
                >
                  <div style={{ fontWeight: 700, color: '#0f172a', display: 'flex', justifyContent: 'space-between', gap: '4px' }}>
                    <span style={{ wordBreak: 'break-all' }}>{rel.source_filename}</span>
                    <span style={{ color: '#2563eb' }}>v{rel.graph_version}</span>
                  </div>
                  <div style={{ fontSize: '10.5px', color: '#64748b', marginTop: '2px' }}>
                    Doc: <code>{rel.document_governance_state}</code> • Sem: <code>{rel.candidate_lifecycle_state}</code>
                  </div>
                  <div style={{ marginTop: '5px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span
                      style={{
                        fontSize: '10px',
                        fontWeight: 700,
                        padding: '2px 7px',
                        borderRadius: '999px',
                        background: st.bg,
                        color: st.text,
                        border: `1px solid ${st.border}`,
                      }}
                    >
                      {rel.derived_outcome}
                    </span>
                    <span style={{ fontSize: '10px', color: '#475569' }}>
                      {rel.triples_count}T / {rel.chunks_count}C
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* RIGHT: 3-TRACK READINESS VERIFICATION & RELEASE CONTROLS */}
        <div className="card" style={{ padding: '16px', display: 'flex', flexDirection: 'column', gap: '14px' }}>
          {activeCand && activeReadiness ? (
            <>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '10px', borderBottom: '1px solid #e2e8f0', paddingBottom: '12px' }}>
                <div>
                  <h4 style={{ margin: 0, fontSize: '15px', fontWeight: 700, color: '#0f172a' }}>
                    Release Candidate: {activeCand.source_filename} (v{activeCand.graph_version})
                  </h4>
                  <div style={{ fontSize: '11.5px', color: '#64748b', marginTop: '4px' }}>
                    Candidate ID: <code>{activeCand.candidate_id}</code> • Document URI: <code>{activeCand.document_uri}</code> • Content Hash:{' '}
                    <code>{(activeCand.content_hash || '').slice(0, 16)}…</code>
                  </div>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <span style={{ fontSize: '11px', color: '#475569', fontWeight: 600 }}>Derived Release Status:</span>
                  <span
                    data-testid="publication-derived-outcome"
                    style={{
                      fontSize: '12px',
                      fontWeight: 700,
                      padding: '4px 12px',
                      borderRadius: '999px',
                      background: outcomeStyle(derivedOutcome).bg,
                      color: outcomeStyle(derivedOutcome).text,
                      border: `1px solid ${outcomeStyle(derivedOutcome).border}`,
                    }}
                  >
                    {derivedOutcome}
                  </span>
                </div>
              </div>

              {/* Blocker Callout if Blocked or Pending */}
              {activeReadiness.blockers && activeReadiness.blockers.length > 0 && pState !== 'PUBLISHED' && (
                <div
                  data-testid="publication-blocker-callout"
                  style={{
                    padding: '10px 12px',
                    background: '#fef2f2',
                    border: '1px solid #fecaca',
                    borderRadius: '6px',
                    fontSize: '12px',
                    color: '#991b1b',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    flexWrap: 'wrap',
                    gap: '8px',
                  }}
                >
                  <div>
                    <strong>Release Gate Blockers:</strong> {activeReadiness.blockers.join(' • ')}
                  </div>
                  <div style={{ display: 'flex', gap: '6px' }}>
                    {onNavigateWorkspace && (
                      <>
                        <button
                          className="btn btn-outline"
                          style={{ fontSize: '11px', padding: '3px 8px', background: '#fff' }}
                          onClick={() =>
                            onNavigateWorkspace('hitl', {
                              documentUri: activeCand.document_uri,
                              candidateId: activeCand.candidate_id,
                            })
                          }
                        >
                          Open HITL Workbench
                        </button>
                        <button
                          className="btn btn-outline"
                          style={{ fontSize: '11px', padding: '3px 8px', background: '#fff' }}
                          onClick={() =>
                            onNavigateWorkspace('studio', {
                              documentUri: activeCand.document_uri,
                              candidateId: activeCand.candidate_id,
                            })
                          }
                        >
                          Open Knowledge Engineering Studio
                        </button>
                      </>
                    )}
                  </div>
                </div>
              )}

              {/* 3-Track Publication Readiness Grid */}
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '12px' }}>
                {/* Track 1: Document Governance */}
                <div style={{ border: '1px solid #cbd5e1', borderRadius: '8px', padding: '12px', background: '#f8fafc' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                    <strong style={{ fontSize: '12.5px', color: '#0f172a' }}>1. Document Governance</strong>
                    <span
                      style={{
                        fontSize: '10px',
                        fontWeight: 700,
                        padding: '2px 6px',
                        borderRadius: '4px',
                        background: activeReadiness.tracks?.document_governance?.track_passed ? '#dcfce7' : '#fee2e2',
                        color: activeReadiness.tracks?.document_governance?.track_passed ? '#15803d' : '#b91c1c',
                      }}
                    >
                      {activeReadiness.tracks?.document_governance?.track_passed ? 'CLEARED' : 'PENDING / BLOCKED'}
                    </span>
                  </div>
                  {(activeReadiness.tracks?.document_governance?.checks || []).map((c: any) => (
                    <div key={c.key} style={{ padding: '5px 0', borderBottom: '1px solid #e2e8f0', fontSize: '11px' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 600 }}>
                        <span>{c.label}</span>
                        <span style={{ color: c.status === 'PASSED' ? '#15803d' : c.status === 'BLOCKED' ? '#b91c1c' : '#b45309' }}>
                          {c.status}
                        </span>
                      </div>
                      <div style={{ fontSize: '10px', color: '#64748b' }}>{c.detail}</div>
                    </div>
                  ))}
                </div>

                {/* Track 2: Semantic Governance */}
                <div style={{ border: '1px solid #cbd5e1', borderRadius: '8px', padding: '12px', background: '#f8fafc' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                    <strong style={{ fontSize: '12.5px', color: '#0f172a' }}>2. Semantic Governance</strong>
                    <span
                      style={{
                        fontSize: '10px',
                        fontWeight: 700,
                        padding: '2px 6px',
                        borderRadius: '4px',
                        background: activeReadiness.tracks?.semantic_governance?.track_passed ? '#dcfce7' : '#fee2e2',
                        color: activeReadiness.tracks?.semantic_governance?.track_passed ? '#15803d' : '#b91c1c',
                      }}
                    >
                      {activeReadiness.tracks?.semantic_governance?.track_passed ? 'APPROVED' : 'PENDING / BLOCKED'}
                    </span>
                  </div>
                  {(activeReadiness.tracks?.semantic_governance?.checks || []).map((c: any) => (
                    <div key={c.key} style={{ padding: '5px 0', borderBottom: '1px solid #e2e8f0', fontSize: '11px' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 600 }}>
                        <span>{c.label}</span>
                        <span style={{ color: c.status === 'PASSED' ? '#15803d' : c.status === 'BLOCKED' ? '#b91c1c' : '#b45309' }}>
                          {c.status}
                        </span>
                      </div>
                      <div style={{ fontSize: '10px', color: '#64748b' }}>{c.detail}</div>
                    </div>
                  ))}
                </div>

                {/* Track 3: Release Integrity */}
                <div style={{ border: '1px solid #cbd5e1', borderRadius: '8px', padding: '12px', background: '#f8fafc' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                    <strong style={{ fontSize: '12.5px', color: '#0f172a' }}>3. Release Integrity</strong>
                    <span
                      style={{
                        fontSize: '10px',
                        fontWeight: 700,
                        padding: '2px 6px',
                        borderRadius: '4px',
                        background:
                          pState === 'PUBLISHED' || activeReadiness.tracks?.release_integrity?.track_passed
                            ? '#dcfce7'
                            : '#f1f5f9',
                        color:
                          pState === 'PUBLISHED' || activeReadiness.tracks?.release_integrity?.track_passed
                            ? '#15803d'
                            : '#475569',
                      }}
                    >
                      {pState}
                    </span>
                  </div>
                  {(activeReadiness.tracks?.release_integrity?.checks || []).map((c: any) => (
                    <div key={c.key} style={{ padding: '5px 0', borderBottom: '1px solid #e2e8f0', fontSize: '11px' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 600 }}>
                        <span>{c.label}</span>
                        <span style={{ color: c.status === 'PASSED' ? '#15803d' : c.status === 'BLOCKED' ? '#b91c1c' : '#64748b' }}>
                          {c.status}
                        </span>
                      </div>
                      <div style={{ fontSize: '10px', color: '#64748b' }}>{c.detail}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Release Action Bar (Only displays production release controls when eligible) */}
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '8px', paddingTop: '8px', borderTop: '1px solid #e2e8f0' }}>
                <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
                  {canStage && pState !== 'PUBLISHED' && (
                    <button
                      className="btn btn-outline"
                      data-testid="btn-stage-release"
                      disabled={busy}
                      onClick={handleStageRelease}
                    >
                      1. Stage Release
                    </button>
                  )}
                  {(canStage || canVerify) && pState !== 'PUBLISHED' && (
                    <button
                      className="btn btn-outline"
                      data-testid="btn-verify-release"
                      disabled={busy}
                      onClick={handleVerifyStagedRelease}
                    >
                      2. Verify Staged Release
                    </button>
                  )}
                  {canActivate && pState !== 'PUBLISHED' && (
                    <button
                      className="btn btn-primary"
                      data-testid="btn-activate-publication"
                      disabled={busy}
                      style={{ background: '#0f766e' }}
                      onClick={handleActivatePublication}
                    >
                      3. Activate Publication (Promote RDF + FAISS)
                    </button>
                  )}
                  {(activeCand.staged_release_manifest || activeCand.publication_record) && (
                    <button
                      className="btn btn-outline"
                      onClick={() => setShowManifestModal((v) => !v)}
                    >
                      {showManifestModal ? 'Hide Publication Manifest' : 'View Publication Manifest'}
                    </button>
                  )}
                  {pState === 'PUBLICATION_FAILED' && canActivate && (
                    <button
                      className="btn btn-primary"
                      onClick={handleActivatePublication}
                    >
                      Recover Failed Publication
                    </button>
                  )}
                  {pState === 'PUBLISHED' && (
                    <>
                      <button
                        className="btn btn-outline"
                        style={{ color: '#b45309', borderColor: '#d97706' }}
                        onClick={() => handleWithdrawRelease('SUPERSEDED')}
                      >
                        Supersede Release
                      </button>
                      <button
                        className="btn btn-danger"
                        onClick={() => handleWithdrawRelease('WITHDRAWN')}
                      >
                        Withdraw Release
                      </button>
                    </>
                  )}
                </div>

                {/* Downstream Consumption & Audit Verification Links */}
                <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
                  {onNavigateWorkspace && (
                    <>
                      <button
                        className="btn btn-outline"
                        style={{ fontSize: '11px', padding: '4px 9px' }}
                        onClick={() => onNavigateWorkspace('kg')}
                      >
                        View Published Graph (KG Explorer)
                      </button>
                      <button
                        className="btn btn-outline"
                        style={{ fontSize: '11px', padding: '4px 9px' }}
                        onClick={() => onNavigateWorkspace('sparql')}
                      >
                        Open in SPARQL Studio
                      </button>
                      <button
                        className="btn btn-outline"
                        style={{ fontSize: '11px', padding: '4px 9px' }}
                        onClick={() => onNavigateWorkspace('governance')}
                      >
                        View Publication Audit
                      </button>
                    </>
                  )}
                </div>
              </div>

              {showManifestModal && (activeCand.staged_release_manifest || activeCand.publication_record) && (
                <div style={{ background: '#0f172a', color: '#f8fafc', padding: '12px', borderRadius: '8px', fontFamily: 'var(--font-mono)', fontSize: '11px', overflowX: 'auto' }}>
                  <div style={{ fontWeight: 700, marginBottom: '6px', color: '#93c5fd' }}>
                    Persisted Release Manifest &amp; Transaction Metadata:
                  </div>
                  <pre style={{ margin: 0 }}>
                    {JSON.stringify(
                      {
                        staged_release_manifest: activeCand.staged_release_manifest,
                        publication_record: activeCand.publication_record,
                      },
                      null,
                      2
                    )}
                  </pre>
                </div>
              )}
            </>
          ) : (
            <div style={{ padding: '30px', textAlign: 'center', color: '#64748b' }}>
              Select a candidate release from the Publication Queue to inspect its 3-Track Readiness and release controls.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
