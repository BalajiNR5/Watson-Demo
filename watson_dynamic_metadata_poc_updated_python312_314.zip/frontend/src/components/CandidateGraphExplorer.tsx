import React, { useState, useEffect, useMemo, useRef } from 'react';
import { api } from '../services/api';

export interface CandidateGraphExplorerProps {
  initialCandidateId?: string;
  initialDocumentUri?: string;
  mode?: 'admin' | 'hitl' | 'ingestion_preview';
  embeddedInWorkbench?: boolean;
  semanticFirstDefault?: boolean;
  focusedNodeUri?: string | null;
  focusedEdgeId?: string | null;
  recentlyChangedResources?: string[];
  refreshTrigger?: number;
  onOpenInHitl?: (documentUri: string, candidateId: string) => void;
  onSelectResourceForEdit?: (resourceUri: string) => void;
  onSelectNode?: (node: any | null, connectedEdges: any[]) => void;
  onSelectEdge?: (edge: any | null) => void;
  onGraphPayloadLoaded?: (payload: any) => void;
}

export const CATEGORY_STYLES: Record<
  string,
  { fill: string; stroke: string; badgeBg: string; badgeText: string; label: string; radius: number }
> = {
  NEW_CANDIDATE_ENTITY: {
    fill: '#eff6ff',
    stroke: '#2563eb',
    badgeBg: '#dbeafe',
    badgeText: '#1d4ed8',
    label: 'Newly Extracted Candidate Entity',
    radius: 22,
  },
  EXISTING_TRUSTED_ENTITY: {
    fill: '#f0fdf4',
    stroke: '#16a34a',
    badgeBg: '#dcfce7',
    badgeText: '#15803d',
    label: 'Matched Trusted Canonical Entity',
    radius: 23,
  },
  DUPLICATE_CANDIDATE: {
    fill: '#fff7ed',
    stroke: '#ea580c',
    badgeBg: '#ffedd5',
    badgeText: '#c2410c',
    label: 'Duplicate Candidate Mention',
    radius: 22,
  },
  UNRESOLVED_ENTITY: {
    fill: '#fefce8',
    stroke: '#ca8a04',
    badgeBg: '#fef9c3',
    badgeText: '#854d0e',
    label: 'Unresolved / Provisional Entity',
    radius: 21,
  },
  SEMANTIC_CONFLICT: {
    fill: '#fef2f2',
    stroke: '#dc2626',
    badgeBg: '#fee2e2',
    badgeText: '#b91c1c',
    label: 'Semantic Conflict',
    radius: 23,
  },
  SHACL_VIOLATION: {
    fill: '#fdf2f8',
    stroke: '#db2777',
    badgeBg: '#fce7f3',
    badgeText: '#be185d',
    label: 'SHACL Violation',
    radius: 24,
  },
  DOCUMENT_NODE: {
    fill: '#faf5ff',
    stroke: '#7c3aed',
    badgeBg: '#f3e8ff',
    badgeText: '#6d28d9',
    label: 'Staged Document Root',
    radius: 25,
  },
  CHUNK_NODE: {
    fill: '#f8fafc',
    stroke: '#64748b',
    badgeBg: '#f1f5f9',
    badgeText: '#475569',
    label: 'Governed Evidence Chunk',
    radius: 17,
  },
  SENTIMENT_NODE: {
    fill: '#f0fdfa',
    stroke: '#0d9488',
    badgeBg: '#ccfbf1',
    badgeText: '#0f766e',
    label: 'HCP Sentiment Assertion',
    radius: 18,
  },
};

export const EDGE_CATEGORY_STYLES: Record<string, { stroke: string; dash?: string; width: number; label: string }> = {
  PROPOSED_RELATIONSHIP: {
    stroke: '#2563eb',
    dash: '5,3',
    width: 2.0,
    label: 'Proposed Candidate Relationship',
  },
  EXISTING_TRUSTED_RELATIONSHIP: {
    stroke: '#16a34a',
    width: 2.2,
    label: 'Existing Trusted Graph Relationship',
  },
  CONFLICTING_RELATIONSHIP: {
    stroke: '#dc2626',
    dash: '3,2',
    width: 2.6,
    label: 'Conflicting Relationship vs Trusted Graph',
  },
};

export const CandidateGraphExplorer: React.FC<CandidateGraphExplorerProps> = ({
  initialCandidateId,
  initialDocumentUri,
  mode = 'admin',
  embeddedInWorkbench = false,
  semanticFirstDefault = true,
  focusedNodeUri,
  focusedEdgeId,
  recentlyChangedResources = [],
  refreshTrigger = 0,
  onOpenInHitl,
  onSelectResourceForEdit,
  onSelectNode,
  onSelectEdge,
  onGraphPayloadLoaded,
}) => {
  const [payload, setPayload] = useState<any | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const [selectedCandidateId, setSelectedCandidateId] = useState<string>(initialCandidateId || '');
  const [batchFilter, setBatchFilter] = useState<string>('ALL');
  const [classFilter, setClassFilter] = useState<string>('ALL');
  const [namespaceFilter, setNamespaceFilter] = useState<string>('ALL');
  const [validationFilter, setValidationFilter] = useState<string>('ALL');
  const [mappingFilter, setMappingFilter] = useState<string>('ALL');
  const [categoryFilter, setCategoryFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [includeTrustedContext, setIncludeTrustedContext] = useState<boolean>(true);
  const [candidateOnlyMode, setCandidateOnlyMode] = useState<boolean>(false);
  const [semanticFirstMode, setSemanticFirstMode] = useState<boolean>(semanticFirstDefault);
  const [showProvenanceLinks, setShowProvenanceLinks] = useState<boolean>(!semanticFirstDefault);
  const [hopIsolation, setHopIsolation] = useState<'ALL' | '1_HOP' | '2_HOP'>('ALL');
  const [activeSubTab, setActiveSubTab] = useState<'canvas' | 'comparison' | 'triples'>('canvas');

  const [selectedNodeId, setSelectedNodeId] = useState<string>('');
  const [selectedEdgeId, setSelectedEdgeId] = useState<string>('');

  // Interactive Canvas Zoom, Pan & Dragging
  const [zoom, setZoom] = useState<number>(0.92);
  const [pan, setPan] = useState<{ x: number; y: number }>({ x: 20, y: 18 });
  const [nodePositions, setNodePositions] = useState<Record<string, { x: number; y: number }>>({});
  const [draggingNodeId, setDraggingNodeId] = useState<string | null>(null);
  const [isPanning, setIsPanning] = useState<boolean>(false);
  const panStartRef = useRef<{ x: number; y: number; panX: number; panY: number }>({ x: 0, y: 0, panX: 0, panY: 0 });
  const svgRef = useRef<SVGSVGElement | null>(null);

  useEffect(() => {
    if (initialCandidateId !== undefined && initialCandidateId !== selectedCandidateId) {
      setSelectedCandidateId(initialCandidateId || '');
    }
  }, [initialCandidateId]);

  useEffect(() => {
    loadCandidateGraph();
  }, [selectedCandidateId, initialDocumentUri, includeTrustedContext, refreshTrigger]);

  // Synchronize external focus from Issue Navigator or Workbench Inspector
  useEffect(() => {
    if (focusedNodeUri && payload?.nodes) {
      const match = payload.nodes.find((n: any) => n.id === focusedNodeUri || n.uri === focusedNodeUri);
      if (match) {
        setSelectedNodeId(match.id);
        setSelectedEdgeId('');
        const pos = nodePositions[match.id];
        if (pos) {
          setPan({ x: Math.round(320 - pos.x * zoom), y: Math.round(220 - pos.y * zoom) });
        }
      }
    }
  }, [focusedNodeUri, payload]);

  useEffect(() => {
    if (focusedEdgeId && payload?.edges) {
      const match = payload.edges.find((e: any) => e.id === focusedEdgeId);
      if (match) {
        setSelectedEdgeId(match.id);
      }
    }
  }, [focusedEdgeId, payload]);

  const loadCandidateGraph = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await api.getCandidateGraphExplorer({
        candidate_id: selectedCandidateId || undefined,
        document_uri: !selectedCandidateId && initialDocumentUri ? initialDocumentUri : undefined,
        include_trusted_context: includeTrustedContext,
      });
      setPayload(res);
      if (onGraphPayloadLoaded) {
        onGraphPayloadLoaded(res);
      }
      if (!embeddedInWorkbench && !selectedNodeId && res.nodes && res.nodes.length > 0) {
        setSelectedNodeId(res.nodes[0].id);
      }
    } catch (err: any) {
      setError(err.message || 'Failed to load Candidate Knowledge Graph Explorer');
    } finally {
      setLoading(false);
    }
  };

  // Compute deterministic layered radial/column layout for candidate nodes
  useEffect(() => {
    if (!payload?.nodes || payload.nodes.length === 0) return;
    const pos: Record<string, { x: number; y: number }> = {};
    const docs = payload.nodes.filter((n: any) => n.node_category === 'DOCUMENT_NODE');
    const chunks = payload.nodes.filter((n: any) => n.node_category === 'CHUNK_NODE');
    const trustedEnts = payload.nodes.filter((n: any) => n.is_trusted && n.node_category !== 'DOCUMENT_NODE');
    const candEnts = payload.nodes.filter(
      (n: any) => !n.is_trusted && !['DOCUMENT_NODE', 'CHUNK_NODE'].includes(n.node_category)
    );

    docs.forEach((n: any, idx: number) => {
      pos[n.id] = { x: 110, y: 110 + idx * 120 };
    });
    chunks.forEach((n: any, idx: number) => {
      pos[n.id] = { x: 295, y: 75 + idx * 72 };
    });
    candEnts.forEach((n: any, idx: number) => {
      const col = idx % 2;
      const row = Math.floor(idx / 2);
      pos[n.id] = { x: 515 + col * 165, y: 72 + row * 74 };
    });
    trustedEnts.forEach((n: any, idx: number) => {
      const col = idx % 2;
      const row = Math.floor(idx / 2);
      pos[n.id] = { x: 855 + col * 175, y: 72 + row * 74 };
    });
    setNodePositions(pos);
  }, [payload]);

  const availableClasses = useMemo(() => {
    const s = new Set<string>();
    (payload?.nodes || []).forEach((n: any) => {
      if (n.rdf_class) s.add(n.rdf_class);
    });
    return Array.from(s).sort();
  }, [payload]);

  const availableNamespaces = useMemo(() => {
    const s = new Set<string>();
    (payload?.nodes || []).forEach((n: any) => {
      if (n.namespace) s.add(n.namespace);
    });
    return Array.from(s).sort();
  }, [payload]);

  const availableBatches = useMemo(() => {
    const s = new Set<string>();
    (payload?.candidates_summary || []).forEach((c: any) => {
      if (c.batch_id) s.add(c.batch_id);
    });
    return Array.from(s).sort();
  }, [payload]);

  const recentSet = useMemo(() => new Set(recentlyChangedResources || []), [recentlyChangedResources]);

  const { filteredNodes, filteredEdges, neighborSet } = useMemo(() => {
    const allNodes: any[] = payload?.nodes || [];
    const allEdges: any[] = payload?.edges || [];
    const q = searchQuery.trim().toLowerCase();

    let cNodes = allNodes.filter((n: any) => {
      if (candidateOnlyMode && n.is_trusted) return false;
      if ((semanticFirstMode && !showProvenanceLinks) && (n.node_category === 'DOCUMENT_NODE' || n.node_category === 'CHUNK_NODE')) {
        if (selectedNodeId !== n.id) return false;
      }
      if (batchFilter !== 'ALL' && n.batch_id !== batchFilter && n.batch_id !== 'TRUSTED_CONTEXT') return false;
      if (classFilter !== 'ALL' && n.rdf_class !== classFilter) return false;
      if (namespaceFilter !== 'ALL' && n.namespace !== namespaceFilter) return false;
      if (validationFilter !== 'ALL' && n.validation_status !== validationFilter) return false;
      if (mappingFilter !== 'ALL' && n.mapping_status !== mappingFilter) return false;
      if (categoryFilter !== 'ALL' && n.node_category !== categoryFilter) return false;
      if (q) {
        const mLabel = (n.label || '').toLowerCase().includes(q);
        const mUri = (n.uri || '').toLowerCase().includes(q);
        const mClass = (n.rdf_class || '').toLowerCase().includes(q);
        if (!mLabel && !mUri && !mClass) return false;
      }
      return true;
    });

    const nb1Set = new Set<string>();
    const nb2Set = new Set<string>();
    if (selectedNodeId) {
      nb1Set.add(selectedNodeId);
      allEdges.forEach((e: any) => {
        if (e.source === selectedNodeId) nb1Set.add(e.target);
        if (e.target === selectedNodeId) nb1Set.add(e.source);
      });
      nb1Set.forEach((n1) => nb2Set.add(n1));
      allEdges.forEach((e: any) => {
        if (nb1Set.has(e.source)) nb2Set.add(e.target);
        if (nb1Set.has(e.target)) nb2Set.add(e.source);
      });
    }

    const activeNbSet = hopIsolation === '2_HOP' ? nb2Set : nb1Set;

    if (hopIsolation === '1_HOP' && selectedNodeId) {
      cNodes = cNodes.filter((n: any) => nb1Set.has(n.id));
    } else if (hopIsolation === '2_HOP' && selectedNodeId) {
      cNodes = cNodes.filter((n: any) => nb2Set.has(n.id));
    }

    const visIds = new Set(cNodes.map((n: any) => n.id));
    const cEdges = allEdges.filter((e: any) => visIds.has(e.source) && visIds.has(e.target));

    return { filteredNodes: cNodes, filteredEdges: cEdges, neighborSet: activeNbSet };
  }, [
    payload,
    candidateOnlyMode,
    semanticFirstMode,
    showProvenanceLinks,
    batchFilter,
    classFilter,
    namespaceFilter,
    validationFilter,
    mappingFilter,
    categoryFilter,
    searchQuery,
    hopIsolation,
    selectedNodeId,
  ]);

  const selectedNode = useMemo(() => {
    return (payload?.nodes || []).find((n: any) => n.id === selectedNodeId) || null;
  }, [payload, selectedNodeId]);

  const selectedEdge = useMemo(() => {
    return (payload?.edges || []).find((e: any) => e.id === selectedEdgeId) || null;
  }, [payload, selectedEdgeId]);

  const handleSelectNodeInternal = (node: any | null) => {
    if (!node) {
      setSelectedNodeId('');
      if (onSelectNode) onSelectNode(null, []);
      return;
    }
    setSelectedNodeId(node.id);
    setSelectedEdgeId('');
    if (onSelectNode) {
      const conn = (payload?.edges || []).filter((e: any) => e.source === node.id || e.target === node.id);
      onSelectNode(node, conn);
    }
  };

  const handleSelectEdgeInternal = (edge: any | null) => {
    if (!edge) {
      setSelectedEdgeId('');
      if (onSelectEdge) onSelectEdge(null);
      return;
    }
    setSelectedEdgeId(edge.id);
    if (onSelectEdge) {
      onSelectEdge(edge);
    }
  };

  const centerOnSelected = () => {
    if (selectedNodeId && nodePositions[selectedNodeId]) {
      const p = nodePositions[selectedNodeId];
      setPan({ x: Math.round(320 - p.x * zoom), y: Math.round(220 - p.y * zoom) });
    }
  };

  const handleMouseDownCanvas = (e: React.MouseEvent<SVGSVGElement>) => {
    const tag = (e.target as HTMLElement).tagName;
    if (tag === 'svg' || (e.target as HTMLElement).getAttribute('data-bg') === 'true') {
      setIsPanning(true);
      panStartRef.current = { x: e.clientX, y: e.clientY, panX: pan.x, panY: pan.y };
      if (embeddedInWorkbench) {
        setSelectedNodeId('');
        setSelectedEdgeId('');
        if (onSelectNode) onSelectNode(null, []);
        if (onSelectEdge) onSelectEdge(null);
      }
    }
  };

  const handleMouseMoveCanvas = (e: React.MouseEvent<SVGSVGElement>) => {
    if (draggingNodeId && svgRef.current) {
      const rect = svgRef.current.getBoundingClientRect();
      const rawX = (e.clientX - rect.left - pan.x) / zoom;
      const rawY = (e.clientY - rect.top - pan.y) / zoom;
      setNodePositions((prev) => ({
        ...prev,
        [draggingNodeId]: { x: Math.max(40, Math.min(1260, rawX)), y: Math.max(40, Math.min(760, rawY)) },
      }));
    } else if (isPanning) {
      const dx = e.clientX - panStartRef.current.x;
      const dy = e.clientY - panStartRef.current.y;
      setPan({ x: panStartRef.current.panX + dx, y: panStartRef.current.panY + dy });
    }
  };

  const handleMouseUpCanvas = () => {
    setDraggingNodeId(null);
    setIsPanning(false);
  };

  if (loading && !payload) {
    return (
      <div className="card" style={{ padding: '24px', textAlign: 'center', color: '#64748b' }}>
        Loading Interactive Candidate Knowledge Graph &amp; Integrated Trusted Preview...
      </div>
    );
  }

  if (error || !payload) {
    return (
      <div className="card" style={{ padding: '20px', borderLeft: '4px solid #dc2626', background: '#fef2f2' }}>
        <div style={{ fontWeight: 700, color: '#991b1b', marginBottom: '6px' }}>Candidate Graph Explorer Error</div>
        <div style={{ fontSize: '12.5px', color: '#b91c1c', marginBottom: '10px' }}>{error || 'No candidate payload'}</div>
        <button className="btn btn-outline" onClick={loadCandidateGraph}>
          Retry
        </button>
      </div>
    );
  }

  const preview = payload.integrated_preview || {};
  const counts = payload.counts || {};

  return (
    <div
      className={embeddedInWorkbench ? '' : 'card'}
      style={{
        display: 'flex',
        flexDirection: 'column',
        gap: '10px',
        padding: embeddedInWorkbench ? '10px' : '16px',
        background: '#ffffff',
        borderRadius: '8px',
        border: embeddedInWorkbench ? '1px solid #e2e8f0' : undefined,
        height: '100%',
      }}
    >
      {/* Header & Sub-tab Controls */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '8px' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' }}>
            <h3 style={{ fontSize: embeddedInWorkbench ? '14px' : '16px', fontWeight: 700, color: '#0f172a', margin: 0 }}>
              🕸️ {embeddedInWorkbench ? 'Central Interactive Knowledge Graph (Region D)' : 'Interactive Candidate Knowledge Graph Explorer & Integrated Trusted Preview'}
            </h3>
            <span
              style={{
                fontSize: '10px',
                fontWeight: 700,
                padding: '2px 7px',
                borderRadius: '999px',
                background: '#dcfce7',
                color: '#15803d',
              }}
            >
              🔒 Trusted Graph Read-Only Isolated
            </span>
            {recentlyChangedResources.length > 0 && (
              <span
                style={{
                  fontSize: '10px',
                  fontWeight: 700,
                  padding: '2px 7px',
                  borderRadius: '999px',
                  background: '#fef3c7',
                  color: '#b45309',
                }}
              >
                ✨ {recentlyChangedResources.length} Recently Mutated Resource(s) Highlighted
              </span>
            )}
          </div>
          {!embeddedInWorkbench && (
            <p style={{ fontSize: '11.5px', color: '#64748b', margin: '3px 0 0' }}>
              <code>INTEGRATED_PREVIEW = CANDIDATE_GRAPH + APPROVED_MAPPINGS + SCOPED_TRUSTED_GRAPH_CONTEXT</code>
            </p>
          )}
        </div>

        <div style={{ display: 'flex', gap: '5px', flexWrap: 'wrap' }}>
          <button
            className="btn"
            style={{
              fontSize: '11px',
              padding: '4px 10px',
              background: activeSubTab === 'canvas' ? '#2563eb' : '#f1f5f9',
              color: activeSubTab === 'canvas' ? '#fff' : '#334155',
            }}
            onClick={() => setActiveSubTab('canvas')}
          >
            🕸️ Graph Canvas ({filteredNodes.length}N / {filteredEdges.length}E)
          </button>
          <button
            className="btn"
            style={{
              fontSize: '11px',
              padding: '4px 10px',
              background: activeSubTab === 'comparison' ? '#2563eb' : '#f1f5f9',
              color: activeSubTab === 'comparison' ? '#fff' : '#334155',
            }}
            onClick={() => setActiveSubTab('comparison')}
          >
            ⚖️ Trusted Diff (+{preview.candidate_additions_count || 0} / {preview.conflicting_facts_count || 0} Conflicts)
          </button>
          <button
            className="btn"
            style={{
              fontSize: '11px',
              padding: '4px 10px',
              background: activeSubTab === 'triples' ? '#2563eb' : '#f1f5f9',
              color: activeSubTab === 'triples' ? '#fff' : '#334155',
            }}
            onClick={() => setActiveSubTab('triples')}
          >
            📜 RDF Triples ({payload.triples?.length || 0})
          </button>
          <button className="btn btn-outline" style={{ fontSize: '11px', padding: '4px 9px' }} onClick={loadCandidateGraph}>
            ⟳ Refresh
          </button>
        </div>
      </div>

      {/* Filter & Graph Toggle Bar */}
      <div
        style={{
          display: 'flex',
          gap: '6px',
          flexWrap: 'wrap',
          alignItems: 'center',
          background: '#f8fafc',
          padding: '8px 10px',
          borderRadius: '6px',
          border: '1px solid #e2e8f0',
        }}
      >
        {!embeddedInWorkbench && (
          <select
            aria-label="Select Candidate Graph"
            value={selectedCandidateId}
            onChange={(e) => setSelectedCandidateId(e.target.value)}
            style={{ padding: '4px 7px', borderRadius: '5px', border: '1px solid #cbd5e1', fontSize: '11.5px' }}
          >
            <option value="">All Staged Candidates ({payload.candidates_summary?.length || 0})</option>
            {(payload.candidates_summary || []).map((c: any) => (
              <option key={c.candidate_id} value={c.candidate_id}>
                {c.source_filename} (v{c.graph_version} • {c.candidate_lifecycle_state})
              </option>
            ))}
          </select>
        )}

        {!embeddedInWorkbench && (
          <select
            aria-label="Filter by Batch"
            value={batchFilter}
            onChange={(e) => setBatchFilter(e.target.value)}
            style={{ padding: '4px 7px', borderRadius: '5px', border: '1px solid #cbd5e1', fontSize: '11.5px' }}
          >
            <option value="ALL">Batch: ALL</option>
            {availableBatches.map((b) => (
              <option key={b} value={b}>
                {b}
              </option>
            ))}
          </select>
        )}

        <select
          aria-label="Filter by Ontology Class"
          value={classFilter}
          onChange={(e) => setClassFilter(e.target.value)}
          style={{ padding: '4px 7px', borderRadius: '5px', border: '1px solid #cbd5e1', fontSize: '11.5px' }}
        >
          <option value="ALL">Class: ALL</option>
          {availableClasses.map((cls) => (
            <option key={cls} value={cls}>
              {cls}
            </option>
          ))}
        </select>

        <select
          aria-label="Filter by Namespace"
          value={namespaceFilter}
          onChange={(e) => setNamespaceFilter(e.target.value)}
          style={{ padding: '4px 7px', borderRadius: '5px', border: '1px solid #cbd5e1', fontSize: '11.5px' }}
        >
          <option value="ALL">Namespace: ALL</option>
          {availableNamespaces.map((ns) => (
            <option key={ns} value={ns}>
              {ns}
            </option>
          ))}
        </select>

        <select
          aria-label="Filter by Validation Status"
          value={validationFilter}
          onChange={(e) => setValidationFilter(e.target.value)}
          style={{ padding: '4px 7px', borderRadius: '5px', border: '1px solid #cbd5e1', fontSize: '11.5px' }}
        >
          <option value="ALL">SHACL: ALL</option>
          <option value="CONFORMING">CONFORMING</option>
          <option value="VIOLATION">VIOLATION</option>
          <option value="STALE">STALE</option>
        </select>

        <select
          aria-label="Filter by Mapping Status"
          value={mappingFilter}
          onChange={(e) => setMappingFilter(e.target.value)}
          style={{ padding: '4px 7px', borderRadius: '5px', border: '1px solid #cbd5e1', fontSize: '11.5px' }}
        >
          <option value="ALL">Mapping: ALL</option>
          <option value="MATCHED_CANONICAL">MATCHED_CANONICAL</option>
          <option value="NEW_CANDIDATE">NEW_CANDIDATE</option>
          <option value="POTENTIAL_DUPLICATE">POTENTIAL_DUPLICATE</option>
          <option value="UNRESOLVED">UNRESOLVED</option>
          <option value="CONFLICT">CONFLICT</option>
        </select>

        <select
          aria-label="Filter by Semantic Highlight"
          value={categoryFilter}
          onChange={(e) => setCategoryFilter(e.target.value)}
          style={{ padding: '4px 7px', borderRadius: '5px', border: '1px solid #cbd5e1', fontSize: '11.5px' }}
        >
          <option value="ALL">Category: ALL</option>
          <option value="NEW_CANDIDATE_ENTITY">New Candidate ({counts.new_candidate_entities || 0})</option>
          <option value="EXISTING_TRUSTED_ENTITY">Trusted Matched ({counts.existing_trusted_entities || 0})</option>
          <option value="DUPLICATE_CANDIDATE">Duplicate Mention ({counts.duplicate_candidates || 0})</option>
          <option value="UNRESOLVED_ENTITY">Unresolved ({counts.unresolved_entities || 0})</option>
          <option value="SEMANTIC_CONFLICT">Semantic Conflict</option>
          <option value="SHACL_VIOLATION">SHACL Violation ({counts.shacl_violations || 0})</option>
        </select>

        <select
          aria-label="Neighborhood Isolation"
          value={hopIsolation}
          onChange={(e) => setHopIsolation(e.target.value as any)}
          style={{ padding: '4px 7px', borderRadius: '5px', border: '1px solid #cbd5e1', fontSize: '11.5px' }}
        >
          <option value="ALL">Subgraph: Full Graph</option>
          <option value="1_HOP">Isolate 1-Hop Neighborhood</option>
          <option value="2_HOP">Isolate 2-Hop Neighborhood</option>
        </select>

        <input
          type="text"
          placeholder="Search entity, URI, or predicate..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          style={{
            padding: '4px 9px',
            borderRadius: '5px',
            border: '1px solid #cbd5e1',
            fontSize: '11.5px',
            minWidth: '150px',
            flex: 1,
          }}
        />

        <label style={{ display: 'flex', alignItems: 'center', gap: '3px', fontSize: '11px', color: '#334155', cursor: 'pointer' }}>
          <input
            type="checkbox"
            checked={candidateOnlyMode}
            onChange={(e) => setCandidateOnlyMode(e.target.checked)}
          />
          Candidate Only
        </label>

        <label style={{ display: 'flex', alignItems: 'center', gap: '3px', fontSize: '11px', color: '#334155', cursor: 'pointer' }}>
          <input
            type="checkbox"
            checked={includeTrustedContext && !candidateOnlyMode}
            onChange={(e) => {
              setCandidateOnlyMode(false);
              setIncludeTrustedContext(e.target.checked);
            }}
          />
          Trusted Overlay
        </label>

        <label style={{ display: 'flex', alignItems: 'center', gap: '3px', fontSize: '11px', color: '#334155', cursor: 'pointer' }}>
          <input
            type="checkbox"
            checked={semanticFirstMode && !showProvenanceLinks}
            onChange={(e) => {
              setSemanticFirstMode(e.target.checked);
              setShowProvenanceLinks(!e.target.checked);
            }}
          />
          Semantic-First Focus
        </label>

        <label style={{ display: 'flex', alignItems: 'center', gap: '3px', fontSize: '11px', color: '#334155', cursor: 'pointer' }}>
          <input
            type="checkbox"
            checked={showProvenanceLinks}
            onChange={(e) => {
              setShowProvenanceLinks(e.target.checked);
              if (e.target.checked) setSemanticFirstMode(false);
            }}
          />
          Complete RDF Graph (Provenance Links)
        </label>
      </div>

      {/* Semantic Legend Strip */}
      <div style={{ display: 'flex', gap: '9px', flexWrap: 'wrap', fontSize: '10.5px', color: '#475569' }}>
        {Object.entries(CATEGORY_STYLES).map(([key, st]) => (
          <span key={key} style={{ display: 'inline-flex', alignItems: 'center', gap: '4px' }}>
            <span
              style={{
                width: '9px',
                height: '9px',
                borderRadius: '50%',
                background: st.fill,
                border: `2px solid ${st.stroke}`,
                display: 'inline-block',
              }}
            />
            {st.label}
          </span>
        ))}
        <span style={{ display: 'inline-flex', alignItems: 'center', gap: '4px', marginLeft: 'auto', fontWeight: 600 }}>
          Components: {counts.connected_components || 1} ({counts.disconnected_nodes || 0} disconnected)
        </span>
      </div>

      {/* SUB-TAB 1: INTERACTIVE GRAPH CANVAS (+ OPTIONAL STANDALONE INSPECTOR) */}
      {activeSubTab === 'canvas' && (
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: embeddedInWorkbench ? '1fr' : '1.65fr 1fr',
            gap: '14px',
            minHeight: embeddedInWorkbench ? '470px' : '480px',
            flex: 1,
          }}
        >
          <div
            style={{
              position: 'relative',
              border: '1px solid #cbd5e1',
              borderRadius: '8px',
              background: '#ffffff',
              overflow: 'hidden',
              minHeight: '460px',
            }}
          >
            {/* Zoom, Pan & Center Controls */}
            <div
              style={{
                position: 'absolute',
                top: '10px',
                left: '10px',
                zIndex: 5,
                display: 'flex',
                gap: '4px',
                background: 'rgba(255,255,255,0.94)',
                padding: '4px 6px',
                borderRadius: '6px',
                border: '1px solid #e2e8f0',
              }}
            >
              <button
                className="btn btn-outline"
                style={{ padding: '2px 7px', fontSize: '11px' }}
                onClick={() => setZoom((z) => Math.min(2.2, +(z + 0.15).toFixed(2)))}
              >
                ＋ Zoom In
              </button>
              <button
                className="btn btn-outline"
                style={{ padding: '2px 7px', fontSize: '11px' }}
                onClick={() => setZoom((z) => Math.max(0.4, +(z - 0.15).toFixed(2)))}
              >
                － Zoom Out
              </button>
              <button
                className="btn btn-outline"
                style={{ padding: '2px 7px', fontSize: '11px' }}
                onClick={() => {
                  setZoom(0.92);
                  setPan({ x: 20, y: 18 });
                }}
              >
                Fit Screen
              </button>
              <button
                className="btn btn-outline"
                style={{ padding: '2px 7px', fontSize: '11px' }}
                onClick={centerOnSelected}
                disabled={!selectedNodeId}
              >
                ◎ Center Selection
              </button>
            </div>

            <svg
              ref={svgRef}
              width="100%"
              height={embeddedInWorkbench ? '490' : '480'}
              data-bg="true"
              onMouseDown={handleMouseDownCanvas}
              onMouseMove={handleMouseMoveCanvas}
              onMouseUp={handleMouseUpCanvas}
              style={{ cursor: isPanning ? 'grabbing' : 'grab', userSelect: 'none' }}
            >
              <defs>
                <marker
                  id="cand-arrow"
                  viewBox="0 0 10 10"
                  refX="24"
                  refY="5"
                  markerWidth="6"
                  markerHeight="6"
                  orient="auto-start-reverse"
                >
                  <path d="M 0 1 L 10 5 L 0 9 z" fill="#64748b" />
                </marker>
              </defs>
              <g transform={`translate(${pan.x}, ${pan.y}) scale(${zoom})`}>
                {filteredEdges.map((e: any) => {
                  const p1 = nodePositions[e.source] || { x: 200, y: 200 };
                  const p2 = nodePositions[e.target] || { x: 400, y: 200 };
                  const est = EDGE_CATEGORY_STYLES[e.edge_category] || EDGE_CATEGORY_STYLES.PROPOSED_RELATIONSHIP;
                  const isSel = selectedEdgeId === e.id;
                  const isRecentlyMutated =
                    recentSet.has(e.source) && recentSet.has(e.target);
                  const mx = (p1.x + p2.x) / 2;
                  const my = (p1.y + p2.y) / 2;
                  return (
                    <g
                      key={e.id}
                      data-testid={`graph-edge-${e.id}`}
                      onClick={(ev) => {
                        ev.stopPropagation();
                        handleSelectEdgeInternal(e);
                      }}
                      style={{ cursor: 'pointer' }}
                    >
                      <line
                        x1={p1.x}
                        y1={p1.y}
                        x2={p2.x}
                        y2={p2.y}
                        stroke={isSel ? '#0f172a' : isRecentlyMutated ? '#d97706' : est.stroke}
                        strokeWidth={isSel ? est.width + 1.5 : isRecentlyMutated ? est.width + 1.0 : est.width}
                        strokeDasharray={est.dash}
                        markerEnd="url(#cand-arrow)"
                        opacity={
                          selectedNodeId && !neighborSet.has(e.source) && !neighborSet.has(e.target) ? 0.28 : 0.92
                        }
                      />
                      <text
                        x={mx}
                        y={my - 5}
                        textAnchor="middle"
                        fontSize="9.5"
                        fill={isSel ? '#0f172a' : '#334155'}
                        fontWeight={isSel ? 700 : 500}
                      >
                        {e.predicate_label}
                      </text>
                    </g>
                  );
                })}

                {filteredNodes.map((n: any) => {
                  const pos = nodePositions[n.id] || { x: 300, y: 240 };
                  const st = CATEGORY_STYLES[n.node_category] || CATEGORY_STYLES.NEW_CANDIDATE_ENTITY;
                  const isSelected = selectedNodeId === n.id;
                  const isRecentlyMutated = recentSet.has(n.uri) || recentSet.has(n.id);
                  return (
                    <g
                      key={n.id}
                      data-testid={`graph-node-${n.id}`}
                      transform={`translate(${pos.x}, ${pos.y})`}
                      style={{ cursor: 'pointer' }}
                      onMouseDown={(ev) => {
                        ev.stopPropagation();
                        handleSelectNodeInternal(n);
                        setDraggingNodeId(n.id);
                      }}
                    >
                      {isRecentlyMutated && (
                        <circle
                          r={st.radius + 8}
                          fill="none"
                          stroke="#f59e0b"
                          strokeWidth={2.5}
                          strokeDasharray="4,2"
                        />
                      )}
                      {isSelected && (
                        <circle
                          r={st.radius + 6}
                          fill="none"
                          stroke="#1e293b"
                          strokeWidth={2}
                        />
                      )}
                      <circle
                        r={isSelected ? st.radius + 3 : st.radius}
                        fill={st.fill}
                        stroke={isSelected ? '#0f172a' : st.stroke}
                        strokeWidth={isSelected ? 3 : 2}
                        strokeDasharray={n.is_disconnected_component ? '3,3' : undefined}
                      />
                      <text y={4} textAnchor="middle" fontSize="10" fontWeight={700} fill="#0f172a">
                        {(n.label || '').slice(0, 14)}
                      </text>
                      <text y={st.radius + 13} textAnchor="middle" fontSize="9.5" fill="#334155" fontWeight={600}>
                        {(n.label || '').slice(0, 26)}
                      </text>
                    </g>
                  );
                })}
              </g>
            </svg>
          </div>

          {/* Standalone Right Inspector Pane (used when not embedded inside Region D of Unified Workbench) */}
          {!embeddedInWorkbench && (
            <div
              style={{
                border: '1px solid #e2e8f0',
                borderRadius: '8px',
                padding: '12px',
                background: '#f8fafc',
                display: 'flex',
                flexDirection: 'column',
                gap: '10px',
                overflowY: 'auto',
                maxHeight: '480px',
              }}
            >
              <div
                style={{
                  fontWeight: 700,
                  fontSize: '13px',
                  color: '#0f172a',
                  borderBottom: '1px solid #e2e8f0',
                  paddingBottom: '6px',
                }}
              >
                🔍 Selected RDF Resource &amp; Provenance Inspector
              </div>

              {selectedNode ? (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', fontSize: '12px' }}>
                  <div
                    style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      gap: '6px',
                      flexWrap: 'wrap',
                    }}
                  >
                    <span style={{ fontWeight: 700, color: '#1e293b', fontSize: '13.5px' }}>{selectedNode.label}</span>
                    <span
                      style={{
                        fontSize: '10px',
                        fontWeight: 700,
                        padding: '2px 7px',
                        borderRadius: '999px',
                        background: CATEGORY_STYLES[selectedNode.node_category]?.badgeBg || '#dbeafe',
                        color: CATEGORY_STYLES[selectedNode.node_category]?.badgeText || '#1d4ed8',
                      }}
                    >
                      {selectedNode.node_category}
                    </span>
                  </div>

                  <div
                    style={{
                      background: '#ffffff',
                      padding: '8px',
                      borderRadius: '6px',
                      border: '1px solid #e2e8f0',
                      fontFamily: 'var(--font-mono)',
                      fontSize: '11px',
                      wordBreak: 'break-all',
                    }}
                  >
                    <div>
                      <strong>URI:</strong> {selectedNode.uri}
                    </div>
                    <div>
                      <strong>RDF Class:</strong> {selectedNode.rdf_class}
                    </div>
                    <div>
                      <strong>Namespace:</strong> {selectedNode.namespace}
                    </div>
                    <div>
                      <strong>Graph Origin:</strong>{' '}
                      {selectedNode.is_trusted ? 'TRUSTED_GRAPH (Read-Only)' : 'CANDIDATE_STAGED'}
                    </div>
                    <div>
                      <strong>Mapping Status:</strong> {selectedNode.mapping_status}
                    </div>
                    <div>
                      <strong>SHACL Validation:</strong> {selectedNode.validation_status}
                    </div>
                    <div>
                      <strong>Extraction Confidence:</strong> {(selectedNode.confidence * 100).toFixed(1)}%
                    </div>
                  </div>

                  {selectedNode.properties && (
                    <div style={{ background: '#ffffff', padding: '8px', borderRadius: '6px', border: '1px solid #e2e8f0' }}>
                      <div style={{ fontWeight: 600, fontSize: '11px', color: '#475569', marginBottom: '4px' }}>
                        Node Properties:
                      </div>
                      {Object.entries(selectedNode.properties).map(([k, v]) => (
                        <div key={k} style={{ fontSize: '11px', color: '#1e293b' }}>
                          <strong>{k}:</strong> {String(v ?? '—')}
                        </div>
                      ))}
                    </div>
                  )}

                  {selectedNode.evidence_snippets && selectedNode.evidence_snippets.length > 0 && (
                    <div style={{ background: '#ffffff', padding: '8px', borderRadius: '6px', border: '1px solid #e2e8f0' }}>
                      <div style={{ fontWeight: 600, fontSize: '11px', color: '#475569', marginBottom: '4px' }}>
                        Source Evidence Snippets ({selectedNode.source_document_uri}):
                      </div>
                      {selectedNode.evidence_snippets.map((snip: string, si: number) => (
                        <div
                          key={si}
                          style={{
                            fontSize: '11px',
                            fontStyle: 'italic',
                            color: '#334155',
                            background: '#f8fafc',
                            padding: '6px',
                            borderRadius: '4px',
                            marginBottom: '4px',
                          }}
                        >
                          "{snip}"
                        </div>
                      ))}
                    </div>
                  )}

                  <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap', marginTop: '4px' }}>
                    {mode === 'admin' &&
                      onOpenInHitl &&
                      selectedNode.source_document_uri &&
                      selectedNode.candidate_id !== 'TRUSTED_CONTEXT' && (
                        <button
                          className="btn btn-primary"
                          style={{ fontSize: '11px', padding: '5px 10px' }}
                          onClick={() => onOpenInHitl(selectedNode.source_document_uri, selectedNode.candidate_id)}
                        >
                          ⚖️ Open Candidate in HITL Review
                        </button>
                      )}
                    {onSelectResourceForEdit && (
                      <button
                        className="btn btn-outline"
                        style={{ fontSize: '11px', padding: '5px 10px' }}
                        onClick={() => onSelectResourceForEdit(selectedNode.uri)}
                      >
                        ✏️ Inspect / Edit Resource in HITL
                      </button>
                    )}
                  </div>
                </div>
              ) : (
                <div style={{ fontSize: '12px', color: '#64748b' }}>
                  Select a node on the canvas to inspect its RDF class, properties, and source evidence.
                </div>
              )}

              {selectedEdge && (
                <div style={{ marginTop: '8px', paddingTop: '8px', borderTop: '1px solid #cbd5e1', fontSize: '11.5px' }}>
                  <div style={{ fontWeight: 700, color: '#0f172a', marginBottom: '4px' }}>Selected Edge / Triple:</div>
                  <div>
                    <strong>Subject:</strong> <code>{selectedEdge.source}</code>
                  </div>
                  <div>
                    <strong>Predicate:</strong> <code>{selectedEdge.predicate}</code> ({selectedEdge.predicate_label})
                  </div>
                  <div>
                    <strong>Object:</strong> <code>{selectedEdge.target}</code>
                  </div>
                  <div>
                    <strong>Category:</strong> {selectedEdge.edge_category}
                  </div>
                  <div>
                    <strong>Chunk Provenance:</strong>{' '}
                    {selectedEdge.source_chunk_uri || 'Document-level / Trusted Context'}
                  </div>
                  {selectedEdge.evidence_snippet && (
                    <div style={{ marginTop: '4px', fontStyle: 'italic', color: '#475569' }}>
                      "{selectedEdge.evidence_snippet}"
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* SUB-TAB 2: CANDIDATE VS TRUSTED KNOWLEDGE COMPARISON (INTEGRATED_PREVIEW) */}
      {activeSubTab === 'comparison' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: '8px' }}>
            <div style={{ padding: '10px', background: '#eff6ff', borderRadius: '6px', border: '1px solid #bfdbfe' }}>
              <div style={{ fontSize: '10px', fontWeight: 700, color: '#1d4ed8', textTransform: 'uppercase' }}>
                Candidate Additions
              </div>
              <div style={{ fontSize: '18px', fontWeight: 700, color: '#1e3a8a' }}>
                {preview.candidate_additions_count || 0}
              </div>
            </div>
            <div style={{ padding: '10px', background: '#f0fdf4', borderRadius: '6px', border: '1px solid #bbf7d0' }}>
              <div style={{ fontSize: '10px', fontWeight: 700, color: '#15803d', textTransform: 'uppercase' }}>
                Trusted Facts Matched
              </div>
              <div style={{ fontSize: '18px', fontWeight: 700, color: '#14532d' }}>
                {preview.existing_trusted_facts_count || 0}
              </div>
            </div>
            <div style={{ padding: '10px', background: '#fef2f2', borderRadius: '6px', border: '1px solid #fecaca' }}>
              <div style={{ fontSize: '10px', fontWeight: 700, color: '#b91c1c', textTransform: 'uppercase' }}>
                Conflicting Facts
              </div>
              <div style={{ fontSize: '18px', fontWeight: 700, color: '#7f1d1d' }}>
                {preview.conflicting_facts_count || 0}
              </div>
            </div>
            <div style={{ padding: '10px', background: '#fff7ed', borderRadius: '6px', border: '1px solid #fed7aa' }}>
              <div style={{ fontSize: '10px', fontWeight: 700, color: '#c2410c', textTransform: 'uppercase' }}>
                Duplicate Mentions
              </div>
              <div style={{ fontSize: '18px', fontWeight: 700, color: '#7c2d12' }}>
                {preview.duplicate_entities_count || 0}
              </div>
            </div>
            <div style={{ padding: '10px', background: '#fefce8', borderRadius: '6px', border: '1px solid #fde047' }}>
              <div style={{ fontSize: '10px', fontWeight: 700, color: '#854d0e', textTransform: 'uppercase' }}>
                Unresolved Mappings
              </div>
              <div style={{ fontSize: '18px', fontWeight: 700, color: '#713f12' }}>
                {preview.unresolved_mappings_count || 0}
              </div>
            </div>
            <div style={{ padding: '10px', background: '#fdf2f8', borderRadius: '6px', border: '1px solid #fbcfe8' }}>
              <div style={{ fontSize: '10px', fontWeight: 700, color: '#be185d', textTransform: 'uppercase' }}>
                SHACL Findings
              </div>
              <div style={{ fontSize: '18px', fontWeight: 700, color: '#831843' }}>
                {preview.shacl_violations_count || 0}
              </div>
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
            <div style={{ border: '1px solid #e2e8f0', borderRadius: '8px', padding: '10px', maxHeight: '280px', overflowY: 'auto' }}>
              <div style={{ fontWeight: 700, fontSize: '12.5px', color: '#1d4ed8', marginBottom: '6px' }}>
                ➕ Candidate Additions (Proposed Triples Not Yet in Trusted Graph)
              </div>
              {(preview.candidate_additions || []).slice(0, 25).map((t: any, idx: number) => (
                <div
                  key={idx}
                  style={{ fontSize: '11px', fontFamily: 'var(--font-mono)', padding: '4px 6px', borderBottom: '1px solid #f1f5f9' }}
                >
                  <span style={{ color: '#2563eb' }}>{t.subject.split('/').pop()}</span>{' '}
                  <span style={{ color: '#64748b' }}>{t.predicate_label}</span>{' '}
                  <span style={{ color: '#0f172a', fontWeight: 600 }}>{String(t.object).split('/').pop()}</span>
                </div>
              ))}
            </div>

            <div style={{ border: '1px solid #e2e8f0', borderRadius: '8px', padding: '10px', maxHeight: '280px', overflowY: 'auto' }}>
              <div style={{ fontWeight: 700, fontSize: '12.5px', color: '#15803d', marginBottom: '6px' }}>
                ✓ Existing Trusted Facts Confirmed in Scoped Context
              </div>
              {(preview.existing_trusted_facts || []).slice(0, 25).map((t: any, idx: number) => (
                <div
                  key={idx}
                  style={{ fontSize: '11px', fontFamily: 'var(--font-mono)', padding: '4px 6px', borderBottom: '1px solid #f1f5f9' }}
                >
                  <span style={{ color: '#15803d' }}>{t.subject.split('/').pop()}</span>{' '}
                  <span style={{ color: '#64748b' }}>{t.predicate_label}</span>{' '}
                  <span style={{ color: '#0f172a', fontWeight: 600 }}>{String(t.object).split('/').pop()}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* SUB-TAB 3: PERSISTED CANDIDATE RDF TRIPLES TABLE */}
      {activeSubTab === 'triples' && (
        <div className="table-container" style={{ maxHeight: '420px', overflowY: 'auto' }}>
          <table>
            <thead>
              <tr>
                <th>Origin</th>
                <th>Subject</th>
                <th>Predicate</th>
                <th>Object</th>
                <th>Confidence</th>
                <th>Chunk Provenance</th>
              </tr>
            </thead>
            <tbody>
              {(payload.triples || []).slice(0, 120).map((t: any, i: number) => (
                <tr key={i}>
                  <td>
                    <span className={`badge ${t.in_trusted_graph ? 'badge-internal' : 'badge-review'}`}>
                      {t.in_trusted_graph ? 'TRUSTED' : 'CANDIDATE'}
                    </span>
                  </td>
                  <td style={{ fontFamily: 'var(--font-mono)', fontSize: '11px' }}>{t.subject}</td>
                  <td style={{ fontFamily: 'var(--font-mono)', fontSize: '11px', color: '#2563eb' }}>{t.predicate_label}</td>
                  <td style={{ fontFamily: 'var(--font-mono)', fontSize: '11px' }}>{String(t.object).slice(0, 80)}</td>
                  <td style={{ fontSize: '11px' }}>{(t.confidence * 100).toFixed(0)}%</td>
                  <td style={{ fontSize: '11px', color: '#64748b' }}>{t.source_chunk_uri || t.source_document_uri}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
