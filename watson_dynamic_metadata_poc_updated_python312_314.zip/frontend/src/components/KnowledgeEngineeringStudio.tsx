import React, { useState, useEffect, useMemo } from 'react';
import { api } from '../services/api';
import { CandidateGraphExplorer } from './CandidateGraphExplorer';
import { displayValue } from './ReviewDocument';

const QUEUE_CATEGORY_LABELS: { key: string; label: string }[] = [
  { key: 'ALL', label: 'All Candidates' },
  { key: 'PENDING_REVIEW', label: 'Pending Semantic Review' },
  { key: 'SHACL_VIOLATIONS', label: 'SHACL Violations' },
  { key: 'SEMANTIC_CONFLICTS', label: 'Mapping Conflicts' },
  { key: 'DUPLICATE_ENTITIES', label: 'Duplicate Entities' },
  { key: 'UNRESOLVED_MAPPINGS', label: 'Unresolved Mappings' },
  { key: 'MISSING_EVIDENCE', label: 'Missing Semantic Evidence' },
  { key: 'QUARANTINED', label: 'Semantic Quarantine' },
  { key: 'AWAITING_EVIDENCE', label: 'Awaiting Evidence' },
  { key: 'READY_FOR_APPROVAL', label: 'Ready for Semantic Approval' },
  { key: 'APPROVED_AWAITING_PUBLICATION', label: 'Semantically Approved' },
  { key: 'PUBLISHED', label: 'Published' },
];

export interface KnowledgeEngineeringStudioProps {
  initialCandidateId?: string;
  initialDocumentUri?: string;
  onOpenInPublication?: (context: { candidateId: string; documentUri: string; graphVersion: number }) => void;
  onOpenInHitlDocument?: (context: { documentUri: string; candidateId: string }) => void;
}

export const KnowledgeEngineeringStudio: React.FC<KnowledgeEngineeringStudioProps> = ({
  initialCandidateId,
  initialDocumentUri,
  onOpenInPublication,
  onOpenInHitlDocument,
}) => {
  const [studioViewMode, setStudioViewMode] = useState<'graph_first' | 'advanced_rdf'>('graph_first');
  const [advancedSubTab, setAdvancedSubTab] = useState<'shacl' | 'triples' | 'revisions'>('shacl');
  const [showDevWalkthroughUtility, setShowDevWalkthroughUtility] = useState<boolean>(false);

  const [candidate, setCandidate] = useState<any | null>(null);
  const [queueData, setQueueData] = useState<any | null>(null);
  const [queueFilter, setQueueFilter] = useState<string>('ALL');
  const [queueSearch, setQueueSearch] = useState<string>('');
  const [isLeftNavigatorOpen, setIsLeftNavigatorOpen] = useState<boolean>(true);
  const [actionStatus, setActionStatus] = useState<string>('');
  const [actionError, setActionError] = useState<string>('');
  const [graphRefreshCounter, setGraphRefreshCounter] = useState<number>(0);

  // Contextual Inspector State (SUMMARY | NODE | EDGE | ISSUE)
  const [inspectorState, setInspectorState] = useState<'SUMMARY' | 'NODE' | 'EDGE' | 'ISSUE'>('SUMMARY');
  const [selectedGraphNode, setSelectedGraphNode] = useState<any | null>(null);
  const [selectedNodeEdges, setSelectedNodeEdges] = useState<any[]>([]);
  const [selectedGraphEdge, setSelectedGraphEdge] = useState<any | null>(null);
  const [selectedIssue, setSelectedIssue] = useState<any | null>(null);
  const [focusedNodeUri, setFocusedNodeUri] = useState<string | null>(null);
  const [focusedEdgeId, setFocusedEdgeId] = useState<string | null>(null);

  // Active Resolution Drawer ('NONE' | 'EDIT' | 'MERGE' | 'QUARANTINE_EVIDENCE')
  const [activeResolutionDrawer, setActiveResolutionDrawer] = useState<'NONE' | 'EDIT' | 'MERGE' | 'QUARANTINE_EVIDENCE'>('NONE');

  // Graph-First Semantic Edit State & Preview Diff
  const [editModeType, setEditModeType] = useState<
    'REPLACE_TRIPLE' | 'ADD_TRIPLE' | 'UPDATE_ENTITY' | 'REMOVE_TRIPLE' | 'ADVANCED_JSON'
  >('ADD_TRIPLE');
  const [oldTripleSubject, setOldTripleSubject] = useState<string>('');
  const [oldTriplePredicate, setOldTriplePredicate] = useState<string>('');
  const [oldTripleObject, setOldTripleObject] = useState<string>('');
  const [editSubject, setEditSubject] = useState<string>('http://watson.pharma.org/entity/brand/keytruda');
  const [editPredicate, setEditPredicate] = useState<string>('http://watson.pharma.org/ontology/manufacturedBy');
  const [editObject, setEditObject] = useState<string>('http://watson.pharma.org/entity/manufacturer/merck');
  const [editEntityLabel, setEditEntityLabel] = useState<string>('');
  const [editEntityClass, setEditEntityClass] = useState<string>('BrandDrug');
  const [editEntityMappingStatus, setEditEntityMappingStatus] = useState<string>('MATCHED_CANONICAL');
  const [editReason, setEditReason] = useState<string>('Curated semantic relationship alignment in Knowledge Engineering Studio');
  const [advancedEditJson, setAdvancedEditJson] = useState<string>('');
  const [editPreviewResult, setEditPreviewResult] = useState<any | null>(null);

  // Visual Entity Merge State
  const [duplicatePairs, setDuplicatePairs] = useState<any[]>([]);
  const [mergeSource, setMergeSource] = useState<string>('http://watson.pharma.org/entity/brand/keytruda_dup');
  const [mergeTarget, setMergeTarget] = useState<string>('http://watson.pharma.org/entity/brand/keytruda');
  const [mergeName, setMergeName] = useState<string>('Keytruda');
  const [mergePreviewResult, setMergePreviewResult] = useState<any | null>(null);

  // Semantic Quarantine & Evidence State
  const [quarantineReason, setQuarantineReason] = useState<string>('Semantic mapping or clinical subgroup claim requires verification');
  const [evidenceRequestNote, setEvidenceRequestNote] = useState<string>(
    'Provide Phase 3 subgroup survival data and canonical drug mapping'
  );
  const [supplementalEvidenceText, setSupplementalEvidenceText] = useState<string>(
    'Supplemental Clinical Evidence: Keytruda (Pembrolizumab) demonstrated statistically significant OS benefit in NSCLC (Oncology, US).'
  );
  const [evidenceSourceDocUri, setEvidenceSourceDocUri] = useState<string>('');
  const [evidenceDocVersion, setEvidenceDocVersion] = useState<string>('v2.0');
  const [evidenceChunkRef, setEvidenceChunkRef] = useState<string>('page_4_chunk_2');
  const [evidenceType, setEvidenceType] = useState<string>('CLINICAL_STUDY_REPORT');
  const [evidenceSensitivity, setEvidenceSensitivity] = useState<string>('CONFIDENTIAL');
  const [evidenceAddManufacturerTriple, setEvidenceAddManufacturerTriple] = useState<boolean>(true);

  const [selectedRevision, setSelectedRevision] = useState<any | null>(null);

  useEffect(() => {
    loadQueueNavigator();
  }, []);

  useEffect(() => {
    const targetId = initialCandidateId || initialDocumentUri;
    if (targetId) {
      fetchCandidateRecord(targetId);
    }
  }, [initialCandidateId, initialDocumentUri]);

  const loadQueueNavigator = async () => {
    try {
      const q = await api.getReviewQueueNavigator();
      setQueueData(q);
      if (!candidate && !initialCandidateId && !initialDocumentUri && q?.candidates?.length > 0) {
        fetchCandidateRecord(q.candidates[0].candidate_id);
      }
    } catch (_err) {
      // Ignore unauthorized access
    }
  };

  const fetchCandidateRecord = async (idOrUri: string) => {
    setActionError('');
    try {
      const res = await api.getCandidateDetail(idOrUri);
      const cand = res.candidate;
      setCandidate(cand);
      setEvidenceSourceDocUri(cand?.document_uri || 'doc_supplemental_clinical.pdf');
      if (cand?.revision_history?.length > 0) {
        setSelectedRevision(cand.revision_history[cand.revision_history.length - 1]);
      }
      try {
        const dupRes = await api.findPotentialDuplicates(cand.candidate_id);
        setDuplicatePairs(dupRes.duplicate_pairs || []);
      } catch (_e) {
        setDuplicatePairs([]);
      }
      await loadQueueNavigator();
    } catch (_err: any) {
      setCandidate(null);
    }
  };

  const candId = candidate?.candidate_id || initialCandidateId || initialDocumentUri || 'cand_doc_pfizer_rsv_01_pdf';
  const cState = candidate?.candidate_lifecycle_state || 'UNDER_REVIEW';
  const dGovState = candidate?.document_governance_state || candidate?.document_lifecycle_state || 'UNDER_REVIEW';
  const pState = candidate?.publication_lifecycle_state || 'PUBLICATION_PENDING';
  const shaclRep = candidate?.shacl_report;
  const isStale = Boolean(shaclRep?.is_stale);
  const shaclConforms = Boolean(shaclRep?.conforms && !isStale);
  const issues: any[] = candidate?.issues || [];
  const threeTrack = candidate?.three_track_readiness || null;

  const semanticApprovalBlockedByValidation =
    cState === 'VALIDATION_PENDING' || cState === 'VALIDATION_FAILED' || isStale || !shaclConforms;
  const semanticApprovalBlockedByState = ['QUARANTINED', 'AWAITING_EVIDENCE', 'REJECTED', 'BLOCKED'].includes(cState);

  const filteredQueueCandidates = useMemo(() => {
    const list: any[] = queueData?.candidates || [];
    const q = queueSearch.trim().toLowerCase();
    return list.filter((c: any) => {
      if (
        queueFilter === 'PENDING_REVIEW' &&
        !['UNDER_REVIEW', 'VALIDATION_PENDING', 'VALIDATION_FAILED', 'REVALIDATED'].includes(c.candidate_lifecycle_state)
      )
        return false;
      if (
        queueFilter === 'SHACL_VIOLATIONS' &&
        (c.shacl_violation_count || 0) === 0 &&
        c.candidate_lifecycle_state !== 'VALIDATION_FAILED'
      )
        return false;
      if (queueFilter === 'SEMANTIC_CONFLICTS' && !c.has_conflicts) return false;
      if (queueFilter === 'DUPLICATE_ENTITIES' && !c.has_duplicates) return false;
      if (queueFilter === 'UNRESOLVED_MAPPINGS' && !c.has_unresolved) return false;
      if (queueFilter === 'MISSING_EVIDENCE' && !c.has_missing_evidence) return false;
      if (queueFilter === 'QUARANTINED' && c.candidate_lifecycle_state !== 'QUARANTINED') return false;
      if (queueFilter === 'AWAITING_EVIDENCE' && c.candidate_lifecycle_state !== 'AWAITING_EVIDENCE') return false;
      if (queueFilter === 'READY_FOR_APPROVAL' && !c.ready_for_approval) return false;
      if (
        queueFilter === 'APPROVED_AWAITING_PUBLICATION' &&
        !(c.candidate_lifecycle_state === 'APPROVED' && c.publication_lifecycle_state !== 'PUBLISHED')
      )
        return false;
      if (queueFilter === 'PUBLISHED' && c.publication_lifecycle_state !== 'PUBLISHED') return false;
      if (q) {
        const hay = `${c.candidate_id} ${c.source_filename} ${c.document_uri} ${c.therapeutic_area}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [queueData, queueFilter, queueSearch]);

  const buildEditPayload = () => {
    if (editModeType === 'ADVANCED_JSON' && advancedEditJson.trim()) {
      const parsed = JSON.parse(advancedEditJson);
      return { ...parsed, reason: editReason, expected_version: candidate?.graph_version };
    }
    if (editModeType === 'REPLACE_TRIPLE') {
      return {
        replace_triples: [
          {
            old_triple: {
              subject: oldTripleSubject.trim(),
              predicate: oldTriplePredicate.trim(),
              object: oldTripleObject.trim(),
            },
            new_triple: {
              subject: editSubject.trim(),
              predicate: editPredicate.trim(),
              object: editObject.trim(),
              object_type: editObject.trim().startsWith('http://') ? 'uri' : 'literal',
            },
          },
        ],
        reason: editReason,
        expected_version: candidate?.graph_version,
      };
    }
    if (editModeType === 'REMOVE_TRIPLE') {
      return {
        remove_triples: [
          {
            subject: oldTripleSubject.trim() || editSubject.trim(),
            predicate: oldTriplePredicate.trim() || editPredicate.trim(),
            object: oldTripleObject.trim() || editObject.trim(),
          },
        ],
        reason: editReason,
        expected_version: candidate?.graph_version,
      };
    }
    if (editModeType === 'UPDATE_ENTITY') {
      return {
        update_entities: [
          {
            entity_uri: editSubject.trim(),
            label: editEntityLabel.trim() || undefined,
            rdf_class: editEntityClass.trim() || undefined,
            mapping_status: editEntityMappingStatus || undefined,
          },
        ],
        reason: editReason,
        expected_version: candidate?.graph_version,
      };
    }
    return {
      add_triples: [
        {
          subject: editSubject.trim(),
          predicate: editPredicate.trim(),
          object: editObject.trim(),
          object_type: editObject.trim().startsWith('http://') ? 'uri' : 'literal',
        },
      ],
      reason: editReason,
      expected_version: candidate?.graph_version,
    };
  };

  const handlePreviewEdit = async () => {
    setActionError('');
    try {
      const payload = buildEditPayload();
      const res = await api.previewEditCandidate(candId, payload);
      setEditPreviewResult(res);
      setActionStatus(
        `Previewed RDF Edit Diff: ${res.diff.added_count} addition(s), ${res.diff.removed_count} removal(s). Next version: v${res.predicted_next_version} (${res.post_edit_state}).`
      );
    } catch (err: any) {
      setActionError(err.message);
    }
  };

  const handleEditCandidate = async () => {
    setActionError('');
    setActionStatus('Applying controlled semantic edit and transitioning to VALIDATION_PENDING...');
    try {
      const payload = buildEditPayload();
      const res = await api.editCandidate(candId, payload);
      setCandidate(res.candidate);
      setEditPreviewResult(null);
      setGraphRefreshCounter((c) => c + 1);
      if (res.candidate.revision_history?.length > 0) {
        setSelectedRevision(res.candidate.revision_history[res.candidate.revision_history.length - 1]);
      }
      await loadQueueNavigator();
      setActionStatus(
        `Edited candidate to v${res.candidate.graph_version} (${res.candidate.candidate_lifecycle_state}). Previous SHACL report marked STALE — run Revalidate SHACL next.`
      );
    } catch (err: any) {
      setActionError(err.message);
    }
  };

  const handlePreviewMerge = async () => {
    setActionError('');
    try {
      const res = await api.previewMergeEntities(candId, {
        source_entity_uri: mergeSource.trim(),
        target_entity_uri: mergeTarget.trim(),
        target_canonical_name: mergeName.trim() || undefined,
      });
      setMergePreviewResult(res);
      setActionStatus(
        `Previewed Entity Merge: ${res.rewritten_triples_count} triple(s) redirected from '${mergeSource.split('/').pop()}' into '${mergeTarget.split('/').pop()}'.`
      );
    } catch (err: any) {
      setActionError(err.message);
    }
  };

  const handleMergeEntities = async () => {
    setActionError('');
    setActionStatus('Merging duplicate entity into canonical target and invalidating prior SHACL report...');
    try {
      const res = await api.mergeCandidateEntities(candId, {
        source_entity_uri: mergeSource.trim(),
        target_entity_uri: mergeTarget.trim(),
        target_canonical_name: mergeName.trim() || undefined,
        reason: 'Merged duplicate entity mention into canonical trusted entity',
        expected_version: candidate?.graph_version,
      });
      setCandidate(res.candidate);
      setMergePreviewResult(null);
      setGraphRefreshCounter((c) => c + 1);
      if (res.candidate.revision_history?.length > 0) {
        setSelectedRevision(res.candidate.revision_history[res.candidate.revision_history.length - 1]);
      }
      await loadQueueNavigator();
      setActionStatus(
        `Merged '${mergeSource.split('/').pop()}' into '${mergeTarget.split('/').pop()}' -> v${res.candidate.graph_version} (${res.candidate.candidate_lifecycle_state}). Revalidation required.`
      );
    } catch (err: any) {
      setActionError(err.message);
    }
  };

  const handleRunShaclValidation = async () => {
    setActionError('');
    setActionStatus('Executing standards-based SHACL validation over Integrated Knowledge Preview...');
    try {
      const res = await api.validateCandidateShacl(candId);
      setCandidate(res.candidate);
      setGraphRefreshCounter((c) => c + 1);
      if (res.candidate.revision_history?.length > 0) {
        setSelectedRevision(res.candidate.revision_history[res.candidate.revision_history.length - 1]);
      }
      await loadQueueNavigator();
      setActionStatus(
        `SHACL Validation complete for v${res.candidate.graph_version}: ${res.shacl_report.status} (${res.shacl_report.violation_count} violations, ${res.shacl_report.warning_count} warnings).`
      );
    } catch (err: any) {
      setActionError(err.message);
    }
  };

  const handleQuarantineCandidate = async () => {
    setActionError('');
    try {
      const res = await api.quarantineCandidate(candId, {
        reason: quarantineReason,
        triggering_issue: 'SEMANTIC_GOVERNANCE_HOLD',
      });
      setCandidate(res.candidate);
      setGraphRefreshCounter((c) => c + 1);
      await loadQueueNavigator();
      setActionStatus(`Candidate placed in non-terminal semantic QUARANTINED state.`);
    } catch (err: any) {
      setActionError(err.message);
    }
  };

  const handleRequestSemanticChanges = async () => {
    setActionError('');
    try {
      const res = await api.requestCandidateEvidence(candId, {
        request_note: evidenceRequestNote,
        requested_fields: ['manufacturedBy', 'clinicalSubgroupSurvivalEvidence'],
        expected_version: candidate?.graph_version,
      });
      setCandidate(res.candidate);
      await loadQueueNavigator();
      setActionStatus(`Requested semantic changes / supplemental evidence (state -> AWAITING_EVIDENCE).`);
    } catch (err: any) {
      setActionError(err.message);
    }
  };

  const handleSubmitEvidence = async () => {
    setActionError('');
    try {
      const extraTriples = evidenceAddManufacturerTriple
        ? [
            {
              subject: 'http://watson.pharma.org/entity/brand/keytruda',
              predicate: 'http://watson.pharma.org/ontology/manufacturedBy',
              object: 'http://watson.pharma.org/entity/manufacturer/merck',
              object_type: 'uri',
            },
          ]
        : undefined;
      const res = await api.submitCandidateEvidence(candId, {
        evidence_text: supplementalEvidenceText,
        source_reference: `${evidenceType} (${evidenceDocVersion})`,
        source_document_uri: evidenceSourceDocUri || candidate?.document_uri || 'doc_supplemental_clinical.pdf',
        document_version: evidenceDocVersion || 'v2.0',
        chunk_or_page_ref: evidenceChunkRef || 'page_4_chunk_2',
        evidence_type: evidenceType || 'CLINICAL_STUDY_REPORT',
        sensitivity_level: evidenceSensitivity || 'CONFIDENTIAL',
        additional_triples: extraTriples,
        expected_version: candidate?.graph_version,
      });
      setCandidate(res.candidate);
      setGraphRefreshCounter((c) => c + 1);
      await loadQueueNavigator();
      setActionStatus(
        `Attached source-bound semantic evidence -> v${res.candidate.graph_version} (${res.candidate.candidate_lifecycle_state}). Run Revalidate SHACL next.`
      );
    } catch (err: any) {
      setActionError(err.message);
    }
  };

  const handleRejectCandidate = async () => {
    setActionError('');
    try {
      const res = await api.rejectCandidate(
        candId,
        quarantineReason || 'Rejected during Knowledge Engineering semantic review'
      );
      setCandidate(res.candidate);
      await loadQueueNavigator();
      setActionStatus(`Candidate version v${res.candidate.graph_version} terminally REJECTED.`);
    } catch (err: any) {
      setActionError(err.message);
    }
  };

  const handleApproveSemanticCandidate = async () => {
    setActionError('');
    try {
      const res = await api.approveCandidate(candId, {
        expected_version: candidate?.graph_version,
        review_note: `Semantic Candidate v${candidate?.graph_version || 1} approved in Knowledge Engineering Studio`,
        pii_override: Boolean(candidate?.has_critical_pii),
      });
      setCandidate(res.candidate);
      await loadQueueNavigator();
      const docCleared = ['APPROVED', 'ACTIVE'].includes(
        res.candidate.document_governance_state || res.candidate.document_lifecycle_state
      );
      setActionStatus(
        docCleared
          ? `Semantic Candidate v${res.candidate.graph_version} APPROVED. Proceed to Knowledge Publication to stage and activate release.`
          : `Semantic Candidate v${res.candidate.graph_version} APPROVED (Conditional: Not publishable until Source Document Governance clearance in HITL Workbench).`
      );
    } catch (err: any) {
      setActionError(err.message);
    }
  };

  const handleSelectIssueFromNavigator = (issue: any) => {
    setSelectedIssue(issue);
    setInspectorState('ISSUE');
    if (issue.focus_node) {
      setFocusedNodeUri(issue.focus_node);
    }
    if (issue.issue_type === 'POTENTIAL_DUPLICATE') {
      setMergeSource(issue.focus_node || 'http://watson.pharma.org/entity/brand/keytruda_dup');
      setMergeTarget(issue.suggested_target_uri || 'http://watson.pharma.org/entity/brand/keytruda');
      setMergeName('Keytruda');
      setActiveResolutionDrawer('MERGE');
    } else if (
      issue.issue_type === 'QUARANTINED' ||
      issue.issue_type === 'QUARANTINE_HOLD' ||
      issue.issue_type === 'AWAITING_EVIDENCE' ||
      issue.issue_type === 'MISSING_EVIDENCE'
    ) {
      setActiveResolutionDrawer('QUARANTINE_EVIDENCE');
    } else if (issue.issue_type === 'SHACL_VIOLATION' || issue.issue_type === 'SEMANTIC_CONFLICT') {
      setEditSubject(issue.focus_node || 'http://watson.pharma.org/entity/brand/keytruda');
      setEditPredicate(issue.result_path || 'http://watson.pharma.org/ontology/manufacturedBy');
      setEditObject('http://watson.pharma.org/entity/manufacturer/merck');
      setEditModeType('ADD_TRIPLE');
      setActiveResolutionDrawer('EDIT');
    } else {
      setActiveResolutionDrawer('NONE');
    }
  };

  // Developer Test Utility Handlers (isolated in collapsible drawer)
  const handleSeedDemoFixtures = async () => {
    setActionError('');
    try {
      const res = await api.seedDemoFixtures();
      await loadQueueNavigator();
      await fetchCandidateRecord('cand_demo_a_edit');
      setActionStatus(`Seeded ${res.demo_candidates?.length || 4} isolated synthetic demo fixtures.`);
    } catch (err: any) {
      setActionError(err.message);
    }
  };

  const handleResetDemoFixtures = async () => {
    setActionError('');
    try {
      const res = await api.resetDemoFixtures();
      await loadQueueNavigator();
      setActionStatus(`Reset ${res.removed_count || 0} synthetic demo fixture(s).`);
    } catch (err: any) {
      setActionError(err.message);
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }} data-testid="knowledge-engineering-studio-root">
      {/* TOP: CANDIDATE IDENTITY, MULTI-OBJECT GOVERNANCE STATES & SEMANTIC TOOLBAR */}
      <div className="card" style={{ padding: '14px 16px', display: 'flex', flexDirection: 'column', gap: '12px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '10px' }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' }}>
              <h3 style={{ margin: 0, fontSize: '16px', fontWeight: 700, color: '#0f172a' }}>
                Knowledge Engineering Studio (Graph-First Knowledge Engineering & Governance):{' '}
                <span style={{ color: '#2563eb' }}>
                  {displayValue(candidate?.source_filename, 'Select Candidate Graph')}
                </span>
              </h3>
              {candidate?.is_synthetic_candidate && (
                <span
                  style={{
                    fontSize: '10px',
                    fontWeight: 700,
                    padding: '2px 8px',
                    borderRadius: '999px',
                    background: '#f3e8ff',
                    color: '#6d28d9',
                    border: '1px solid #d8b4fe',
                  }}
                >
                  ISOLATED SYNTHETIC FIXTURE
                </span>
              )}
            </div>
            <div style={{ fontSize: '11.5px', color: '#64748b', marginTop: '4px' }}>
              Source Document: <code>{candidate?.document_uri || '—'}</code> • Candidate ID: <code>{candId}</code> • Graph Version:{' '}
              <strong data-testid="studio-graph-version">v{candidate?.graph_version || 1}</strong> • Graph Hash:{' '}
              <code>{(candidate?.content_hash || '').slice(0, 14)}…</code>
            </div>
          </div>

          {/* 4 Distinct Multi-Object Status Badges (Never Conflated) */}
          <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap', alignItems: 'center' }}>
            <span
              className="badge"
              style={{
                background: ['APPROVED', 'ACTIVE'].includes(dGovState) ? '#dcfce7' : dGovState === 'QUARANTINED' ? '#fef3c7' : '#f1f5f9',
                color: ['APPROVED', 'ACTIVE'].includes(dGovState) ? '#15803d' : dGovState === 'QUARANTINED' ? '#b45309' : '#334155',
              }}
              title="Source Document Governance State (HITL Workbench)"
            >
              Source Doc: {dGovState}
            </span>
            <span
              className="badge"
              data-testid="studio-candidate-state"
              style={{
                background:
                  cState === 'APPROVED'
                    ? '#dcfce7'
                    : cState === 'UNDER_REVIEW'
                    ? '#dbeafe'
                    : cState === 'VALIDATION_PENDING'
                    ? '#fef3c7'
                    : '#fee2e2',
                color:
                  cState === 'APPROVED'
                    ? '#15803d'
                    : cState === 'UNDER_REVIEW'
                    ? '#1d4ed8'
                    : cState === 'VALIDATION_PENDING'
                    ? '#b45309'
                    : '#b91c1c',
              }}
              title="Candidate RDF Lifecycle State"
            >
              Candidate State: {cState}
            </span>
            <span
              className="badge"
              data-testid="studio-shacl-state"
              style={{
                background: shaclConforms ? '#dcfce7' : isStale ? '#fef3c7' : '#fee2e2',
                color: shaclConforms ? '#15803d' : isStale ? '#b45309' : '#b91c1c',
              }}
            >
              SHACL: {isStale ? 'STALE (Revalidate Required)' : shaclRep?.status || 'CONFORMING'}
            </span>
            <span
              className="badge"
              style={{
                background: cState === 'APPROVED' ? '#dcfce7' : '#f1f5f9',
                color: cState === 'APPROVED' ? '#15803d' : '#475569',
              }}
            >
              Semantic Approval: {cState === 'APPROVED' ? `APPROVED (v${candidate?.approval_record?.approved_version || candidate?.graph_version})` : 'PENDING'}
            </span>

            <div style={{ display: 'inline-flex', border: '1px solid #cbd5e1', borderRadius: '6px', overflow: 'hidden', marginLeft: '4px' }}>
              <button
                className="btn"
                style={{
                  fontSize: '11px',
                  padding: '4px 9px',
                  borderRadius: 0,
                  background: studioViewMode === 'graph_first' ? '#0f172a' : '#f8fafc',
                  color: studioViewMode === 'graph_first' ? '#ffffff' : '#475569',
                }}
                onClick={() => setStudioViewMode('graph_first')}
              >
                Graph-First Studio
              </button>
              <button
                className="btn"
                style={{
                  fontSize: '11px',
                  padding: '4px 9px',
                  borderRadius: 0,
                  background: studioViewMode === 'advanced_rdf' ? '#0f172a' : '#f8fafc',
                  color: studioViewMode === 'advanced_rdf' ? '#ffffff' : '#475569',
                }}
                onClick={() => setStudioViewMode('advanced_rdf')}
              >
                Advanced RDF &amp; SHACL Views
              </button>
            </div>
          </div>
        </div>

        {/* Linked Source Document Governance Blocker Banner (PII / Source Quarantine kept distinct from SHACL violations) */}
        {(candidate?.has_critical_pii || ['QUARANTINED', 'AWAITING_EVIDENCE', 'REJECTED'].includes(dGovState)) && (
          <div
            data-testid="studio-source-blocker-banner"
            style={{
              padding: '8px 12px',
              background: '#fffbeb',
              border: '1px solid #fde68a',
              borderRadius: '6px',
              fontSize: '12px',
              color: '#92400e',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              flexWrap: 'wrap',
              gap: '8px',
            }}
          >
            <div>
              <strong>Linked Source Governance Notice (Not a SHACL Violation):</strong> Source document{' '}
              <code>{candidate?.document_uri}</code> has status <code>{dGovState}</code>
              {candidate?.has_critical_pii ? ' and contains critical PII findings' : ''}. Production publication remains gated until source document clearance is completed in HITL Workbench.
            </div>
            {onOpenInHitlDocument && candidate?.document_uri && (
              <button
                className="btn btn-outline"
                style={{ fontSize: '11px', padding: '3px 9px', background: '#fff' }}
                onClick={() =>
                  onOpenInHitlDocument({
                    documentUri: candidate.document_uri,
                    candidateId: candId,
                  })
                }
              >
                Open Source in HITL Workbench
              </button>
            )}
          </div>
        )}

        {/* Semantic Action Toolbar (Dedicated to Semantic Validation & Approval) */}
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            flexWrap: 'wrap',
            gap: '8px',
            paddingTop: '6px',
            borderTop: '1px solid #f1f5f9',
          }}
        >
          <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap', alignItems: 'center' }}>
            <button
              className="btn btn-outline"
              style={{ fontSize: '11.5px', padding: '5px 10px' }}
              onClick={() => setIsLeftNavigatorOpen((o) => !o)}
            >
              {isLeftNavigatorOpen ? 'Hide Candidate & Issue Queue' : 'Show Candidate & Issue Queue'} ({issues.length})
            </button>

            <button
              className="btn"
              data-testid="studio-btn-revalidate-shacl"
              style={{
                fontSize: '11.5px',
                padding: '5px 11px',
                background: isStale || cState === 'VALIDATION_PENDING' ? '#d97706' : '#f1f5f9',
                color: isStale || cState === 'VALIDATION_PENDING' ? '#ffffff' : '#1e293b',
                fontWeight: 600,
              }}
              onClick={handleRunShaclValidation}
            >
              Revalidate SHACL {isStale ? '(Required)' : ''}
            </button>

            <button
              className="btn btn-outline"
              style={{ fontSize: '11.5px', padding: '5px 10px' }}
              onClick={() => setActiveResolutionDrawer(activeResolutionDrawer === 'EDIT' ? 'NONE' : 'EDIT')}
            >
              Edit Relationship / Node
            </button>

            <button
              className="btn btn-outline"
              style={{ fontSize: '11.5px', padding: '5px 10px' }}
              onClick={() => setActiveResolutionDrawer(activeResolutionDrawer === 'MERGE' ? 'NONE' : 'MERGE')}
            >
              Merge Duplicate Entities ({duplicatePairs.length})
            </button>

            <button
              className="btn btn-outline"
              style={{ fontSize: '11.5px', padding: '5px 10px' }}
              onClick={() =>
                setActiveResolutionDrawer(
                  activeResolutionDrawer === 'QUARANTINE_EVIDENCE' ? 'NONE' : 'QUARANTINE_EVIDENCE'
                )
              }
            >
              Request Semantic Changes / Evidence
            </button>

            <button
              className="btn btn-outline"
              style={{ fontSize: '11.5px', padding: '5px 10px' }}
              onClick={handleQuarantineCandidate}
            >
              Quarantine Candidate
            </button>

            <button
              className="btn btn-primary"
              data-testid="studio-btn-approve-semantic"
              disabled={semanticApprovalBlockedByValidation || semanticApprovalBlockedByState}
              style={{ fontSize: '11.5px', padding: '5px 12px' }}
              onClick={handleApproveSemanticCandidate}
              title={
                semanticApprovalBlockedByValidation
                  ? 'Blocked: Fresh conforming SHACL report required'
                  : semanticApprovalBlockedByState
                  ? `Blocked: Candidate is in ${cState}`
                  : 'Approve Semantic Candidate'
              }
            >
              Approve Semantic Candidate
            </button>

            <button
              className="btn btn-danger"
              style={{ fontSize: '11.5px', padding: '5px 10px' }}
              onClick={handleRejectCandidate}
            >
              Reject Candidate
            </button>
          </div>

          <div style={{ display: 'flex', gap: '6px', alignItems: 'center' }}>
            {cState === 'APPROVED' && onOpenInPublication && (
              <button
                className="btn btn-primary"
                data-testid="studio-btn-open-publication"
                style={{ fontSize: '11.5px', padding: '5px 12px', background: '#0f766e' }}
                onClick={() =>
                  onOpenInPublication({
                    candidateId: candId,
                    documentUri: candidate?.document_uri || '',
                    graphVersion: candidate?.graph_version || 1,
                  })
                }
              >
                Open in Knowledge Publication &rarr;
              </button>
            )}
            <button
              className="btn btn-outline"
              style={{ fontSize: '11px', padding: '4px 8px', color: '#64748b' }}
              onClick={() => setShowDevWalkthroughUtility((v) => !v)}
            >
              {showDevWalkthroughUtility ? 'Hide Dev Test Fixtures' : 'Dev Test Fixtures'}
            </button>
          </div>
        </div>

        {/* Scoped Developer / Test Walkthrough Utility (Isolated from Production Approval Controls) */}
        {showDevWalkthroughUtility && (
          <div
            style={{
              padding: '8px 12px',
              background: '#f8fafc',
              border: '1px dashed #cbd5e1',
              borderRadius: '6px',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              flexWrap: 'wrap',
              gap: '8px',
              fontSize: '11px',
            }}
          >
            <span style={{ fontWeight: 600, color: '#475569' }}>
              Development &amp; Test Fixture Utility (Isolated Synthetic Candidates Only):
            </span>
            <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
              <button className="btn btn-outline" style={{ fontSize: '10.5px', padding: '3px 8px' }} onClick={handleSeedDemoFixtures}>
                Seed Isolated Demo Fixtures (A–D)
              </button>
              <button className="btn btn-outline" style={{ fontSize: '10.5px', padding: '3px 8px' }} onClick={handleResetDemoFixtures}>
                Reset Synthetic Demo Fixtures
              </button>
            </div>
          </div>
        )}

        {/* Post-Semantic-Approval Callout Banner */}
        {cState === 'APPROVED' && (
          <div
            data-testid="semantic-approved-banner"
            style={{
              padding: '10px 14px',
              background: '#f0fdf4',
              border: '1px solid #86efac',
              borderRadius: '6px',
              color: '#166534',
              fontSize: '12.5px',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              flexWrap: 'wrap',
              gap: '8px',
            }}
          >
            <div>
              <strong>Semantic Candidate Approved (v{candidate?.graph_version}):</strong> SHACL conformance and semantic provenance verified.{' '}
              {!['APPROVED', 'ACTIVE'].includes(dGovState)
                ? `Note: Source document (${dGovState}) must also be approved in HITL Workbench before release activation.`
                : 'Ready for release staging and activation in Knowledge Publication.'}
            </div>
            {onOpenInPublication && (
              <button
                className="btn btn-primary"
                style={{ fontSize: '11.5px', padding: '5px 12px', background: '#15803d' }}
                onClick={() =>
                  onOpenInPublication({
                    candidateId: candId,
                    documentUri: candidate?.document_uri || '',
                    graphVersion: candidate?.graph_version || 1,
                  })
                }
              >
                Open in Knowledge Publication &rarr;
              </button>
            )}
          </div>
        )}

        {actionStatus && (
          <div
            style={{
              padding: '8px 12px',
              background: '#eff6ff',
              border: '1px solid #bfdbfe',
              borderRadius: '6px',
              color: '#1d4ed8',
              fontSize: '12px',
            }}
          >
            {actionStatus}
          </div>
        )}
        {actionError && (
          <div
            role="alert"
            style={{
              padding: '8px 12px',
              background: '#fef2f2',
              border: '1px solid #fecaca',
              borderRadius: '6px',
              color: '#b91c1c',
              fontSize: '12px',
            }}
          >
            {actionError}
          </div>
        )}
      </div>

      {/* GRAPH-FIRST STUDIO WORKSPACE (LEFT QUEUE, CENTER GRAPH, RIGHT CONTEXTUAL INSPECTOR, BOTTOM TIMELINE) */}
      {studioViewMode === 'graph_first' && (
        <>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: isLeftNavigatorOpen ? '290px 1fr 410px' : '1fr 430px',
              gap: '12px',
              alignItems: 'stretch',
              minHeight: '550px',
            }}
          >
            {/* LEFT: CANDIDATE & SEMANTIC ISSUES QUEUE */}
            {isLeftNavigatorOpen && (
              <div
                className="card"
                style={{
                  padding: '12px',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '10px',
                  maxHeight: '610px',
                  overflowY: 'auto',
                }}
              >
                <div style={{ fontWeight: 700, fontSize: '13px', color: '#0f172a', display: 'flex', justifyContent: 'space-between' }}>
                  <span>Candidate &amp; Semantic Issues Queue</span>
                  <span style={{ fontSize: '11px', color: '#64748b' }}>
                    {queueData?.counts?.ALL ?? filteredQueueCandidates.length}
                  </span>
                </div>

                <select
                  aria-label="Filter Semantic Queue Category"
                  value={queueFilter}
                  onChange={(e) => setQueueFilter(e.target.value)}
                  style={{ padding: '5px 8px', borderRadius: '5px', border: '1px solid #cbd5e1', fontSize: '11.5px' }}
                >
                  {QUEUE_CATEGORY_LABELS.map((cat) => (
                    <option key={cat.key} value={cat.key}>
                      {cat.label} ({queueData?.counts?.[cat.key] ?? 0})
                    </option>
                  ))}
                </select>

                <input
                  type="text"
                  placeholder="Filter candidates by name or ID..."
                  value={queueSearch}
                  onChange={(e) => setQueueSearch(e.target.value)}
                  style={{ padding: '5px 8px', borderRadius: '5px', border: '1px solid #cbd5e1', fontSize: '11.5px' }}
                />

                <div
                  style={{
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '6px',
                    maxHeight: '210px',
                    overflowY: 'auto',
                    borderBottom: '1px solid #e2e8f0',
                    paddingBottom: '8px',
                  }}
                >
                  {filteredQueueCandidates.map((qc: any) => {
                    const isSelected = qc.candidate_id === candId;
                    return (
                      <div
                        key={qc.candidate_id}
                        onClick={() => fetchCandidateRecord(qc.candidate_id)}
                        style={{
                          padding: '7px 9px',
                          borderRadius: '6px',
                          border: isSelected ? '2px solid #2563eb' : '1px solid #e2e8f0',
                          background: isSelected ? '#eff6ff' : '#f8fafc',
                          cursor: 'pointer',
                          fontSize: '11px',
                        }}
                      >
                        <div style={{ fontWeight: 700, color: '#0f172a', display: 'flex', justifyContent: 'space-between', gap: '4px' }}>
                          <span style={{ wordBreak: 'break-all' }}>{qc.source_filename}</span>
                          <span style={{ color: '#2563eb', whiteSpace: 'nowrap' }}>v{qc.graph_version}</span>
                        </div>
                        <div style={{ display: 'flex', gap: '4px', flexWrap: 'wrap', marginTop: '4px' }}>
                          <span
                            style={{
                              fontSize: '9.5px',
                              padding: '1px 5px',
                              borderRadius: '4px',
                              background: qc.candidate_lifecycle_state === 'APPROVED' ? '#dcfce7' : '#e2e8f0',
                              color: qc.candidate_lifecycle_state === 'APPROVED' ? '#15803d' : '#334155',
                              fontWeight: 600,
                            }}
                          >
                            {qc.candidate_lifecycle_state}
                          </span>
                          <span
                            style={{
                              fontSize: '9.5px',
                              padding: '1px 5px',
                              borderRadius: '4px',
                              background: qc.issue_count > 0 ? '#fee2e2' : '#dcfce7',
                              color: qc.issue_count > 0 ? '#b91c1c' : '#15803d',
                              fontWeight: 600,
                            }}
                          >
                            {qc.issue_count} Semantic Issue(s)
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>

                <div style={{ fontWeight: 700, fontSize: '12px', color: '#0f172a' }}>
                  Semantic &amp; SHACL Issues ({issues.length})
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', flex: 1, overflowY: 'auto' }}>
                  {issues.length === 0 ? (
                    <div
                      style={{
                        padding: '10px',
                        background: '#f0fdf4',
                        border: '1px solid #bbf7d0',
                        borderRadius: '6px',
                        color: '#15803d',
                        fontSize: '11.5px',
                      }}
                    >
                      Zero open SHACL, mapping conflict, duplicate entity, or semantic evidence issues.
                    </div>
                  ) : (
                    issues.map((iss: any) => {
                      const isIssSel = selectedIssue?.issue_id === iss.issue_id && inspectorState === 'ISSUE';
                      return (
                        <div
                          key={iss.issue_id}
                          onClick={() => handleSelectIssueFromNavigator(iss)}
                          style={{
                            padding: '8px',
                            borderRadius: '6px',
                            border: isIssSel ? '2px solid #0f172a' : '1px solid #fecaca',
                            background: '#fef2f2',
                            cursor: 'pointer',
                            fontSize: '11px',
                          }}
                        >
                          <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 700, color: '#991b1b' }}>
                            <span>{iss.issue_type}</span>
                            <span>{iss.severity}</span>
                          </div>
                          <div style={{ color: '#1e293b', fontWeight: 600, marginTop: '3px' }}>{iss.message}</div>
                          {iss.focus_node && (
                            <div style={{ fontSize: '10px', fontFamily: 'var(--font-mono)', color: '#475569', marginTop: '2px' }}>
                              Resource: {iss.focus_node.split('/').pop()}
                            </div>
                          )}
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            )}

            {/* CENTER: INTERACTIVE CANDIDATE KNOWLEDGE GRAPH (SEMANTIC-FIRST RENDERING DEFAULT) */}
            <div style={{ display: 'flex', flexDirection: 'column', minHeight: '550px' }}>
              <CandidateGraphExplorer
                initialCandidateId={candId}
                initialDocumentUri={candidate?.document_uri}
                mode="hitl"
                embeddedInWorkbench={true}
                semanticFirstDefault={true}
                focusedNodeUri={focusedNodeUri}
                focusedEdgeId={focusedEdgeId}
                recentlyChangedResources={candidate?.recently_changed_resources || []}
                refreshTrigger={graphRefreshCounter}
                onSelectNode={(node, connEdges) => {
                  if (node) {
                    setSelectedGraphNode(node);
                    setSelectedNodeEdges(connEdges || []);
                    setInspectorState('NODE');
                    setEditSubject(node.uri);
                    setEditEntityLabel(node.label || '');
                    setEditEntityClass(node.rdf_class || 'BrandDrug');
                  } else {
                    setSelectedGraphNode(null);
                    setInspectorState('SUMMARY');
                  }
                }}
                onSelectEdge={(edge) => {
                  if (edge) {
                    setSelectedGraphEdge(edge);
                    setInspectorState('EDGE');
                    setOldTripleSubject(edge.source);
                    setOldTriplePredicate(edge.predicate);
                    setOldTripleObject(edge.target);
                    setEditSubject(edge.source);
                    setEditPredicate(edge.predicate);
                    setEditObject(edge.target);
                  } else {
                    setSelectedGraphEdge(null);
                    setInspectorState('SUMMARY');
                  }
                }}
              />
            </div>

            {/* RIGHT: CONTEXTUAL SEMANTIC INSPECTOR */}
            <div
              className="card"
              style={{
                padding: '12px',
                display: 'flex',
                flexDirection: 'column',
                gap: '10px',
                maxHeight: '610px',
                overflowY: 'auto',
              }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid #e2e8f0', paddingBottom: '6px' }}>
                <span style={{ fontWeight: 700, fontSize: '13px', color: '#0f172a' }}>Contextual Semantic Inspector</span>
                <div style={{ display: 'flex', gap: '3px' }}>
                  {(
                    [
                      { id: 'SUMMARY', label: 'Summary' },
                      { id: 'NODE', label: 'Node' },
                      { id: 'EDGE', label: 'Edge' },
                      { id: 'ISSUE', label: 'Issue' },
                    ] as const
                  ).map((st) => (
                    <button
                      key={st.id}
                      className="btn"
                      style={{
                        fontSize: '10px',
                        padding: '2px 6px',
                        background: inspectorState === st.id ? '#2563eb' : '#f1f5f9',
                        color: inspectorState === st.id ? '#fff' : '#475569',
                      }}
                      onClick={() => setInspectorState(st.id)}
                    >
                      {st.label}
                    </button>
                  ))}
                </div>
              </div>

              {inspectorState === 'SUMMARY' && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', fontSize: '12px' }}>
                  <div style={{ background: '#f8fafc', padding: '10px', borderRadius: '6px', border: '1px solid #e2e8f0' }}>
                    <div style={{ fontWeight: 700, color: '#0f172a', marginBottom: '6px' }}>Candidate Semantic Summary</div>
                    <div><strong>Source Document:</strong> {displayValue(candidate?.source_filename)}</div>
                    <div><strong>Source Governance:</strong> {dGovState}</div>
                    <div><strong>Candidate Entities / Triples:</strong> {candidate?.entities?.length ?? 0} entities • {candidate?.triples?.length ?? 0} triples</div>
                    <div><strong>SHACL Status:</strong> {shaclRep?.status || 'CONFORMING'} ({shaclRep?.violation_count || 0} violations)</div>
                    <div><strong>Graph Version:</strong> v{candidate?.graph_version || 1} ({cState})</div>
                  </div>

                  {threeTrack?.tracks?.semantic_governance && (
                    <div style={{ background: '#ffffff', padding: '10px', borderRadius: '6px', border: '1px solid #cbd5e1', display: 'flex', flexDirection: 'column', gap: '6px' }}>
                      <div style={{ fontWeight: 700, fontSize: '12px', color: '#0f172a' }}>
                        Semantic Governance Track &amp; 10-Point Publication Readiness
                      </div>
                      {(threeTrack.tracks.semantic_governance.checks || []).map((chk: any) => (
                        <div
                          key={chk.key}
                          style={{
                            display: 'flex',
                            justifyContent: 'space-between',
                            padding: '5px 7px',
                            borderRadius: '4px',
                            fontSize: '11px',
                            background: chk.status === 'PASSED' ? '#f0fdf4' : chk.status === 'BLOCKED' ? '#fef2f2' : '#f8fafc',
                          }}
                        >
                          <div>
                            <div style={{ fontWeight: 600, color: '#0f172a' }}>{chk.label}</div>
                            <div style={{ fontSize: '10px', color: '#475569' }}>{chk.detail}</div>
                          </div>
                          <span style={{ fontWeight: 700, fontSize: '10px', color: chk.status === 'PASSED' ? '#15803d' : chk.status === 'BLOCKED' ? '#b91c1c' : '#64748b' }}>
                            {chk.status}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {inspectorState === 'NODE' && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', fontSize: '12px' }}>
                  {selectedGraphNode ? (
                    <>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <strong style={{ fontSize: '13.5px', color: '#0f172a' }}>{selectedGraphNode.label}</strong>
                        <span className="badge badge-review">{selectedGraphNode.node_category}</span>
                      </div>
                      {selectedGraphNode.is_trusted && (
                        <div style={{ padding: '6px 8px', background: '#f0fdf4', border: '1px solid #86efac', borderRadius: '6px', fontSize: '11px', color: '#166534' }}>
                          <strong>Read-Only Canonical Trusted Entity:</strong> Protected by <code>TRUSTED_RESOURCE_IMMUTABLE</code>. Cannot be mutated directly or merged away as a duplicate source.
                        </div>
                      )}
                      <div style={{ background: '#f8fafc', padding: '8px', borderRadius: '6px', border: '1px solid #e2e8f0', fontFamily: 'var(--font-mono)', fontSize: '11px', wordBreak: 'break-all' }}>
                        <div><strong>URI:</strong> {selectedGraphNode.uri}</div>
                        <div><strong>RDF Class:</strong> {selectedGraphNode.rdf_class}</div>
                        <div><strong>Graph Origin:</strong> {selectedGraphNode.is_trusted ? 'TRUSTED_GRAPH' : 'CANDIDATE_STAGED'}</div>
                        <div><strong>Mapping Status:</strong> {selectedGraphNode.mapping_status}</div>
                        <div><strong>SHACL Status:</strong> {selectedGraphNode.validation_status}</div>
                      </div>
                      <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
                        {!selectedGraphNode.is_trusted && (
                          <button
                            className="btn btn-primary"
                            style={{ fontSize: '11px', padding: '4px 9px' }}
                            onClick={() => {
                              setEditSubject(selectedGraphNode.uri);
                              setEditEntityLabel(selectedGraphNode.label || '');
                              setEditEntityClass(selectedGraphNode.rdf_class || 'BrandDrug');
                              setEditModeType('UPDATE_ENTITY');
                              setActiveResolutionDrawer('EDIT');
                            }}
                          >
                            Edit Entity
                          </button>
                        )}
                        <button
                          className="btn btn-outline"
                          style={{ fontSize: '11px', padding: '4px 9px' }}
                          onClick={() => {
                            setEditSubject(selectedGraphNode.uri);
                            setEditModeType('ADD_TRIPLE');
                            setActiveResolutionDrawer('EDIT');
                          }}
                        >
                          Add Relationship
                        </button>
                        {!selectedGraphNode.is_trusted && (
                          <button
                            className="btn btn-outline"
                            style={{ fontSize: '11px', padding: '4px 9px' }}
                            onClick={() => {
                              setMergeSource(selectedGraphNode.uri);
                              setActiveResolutionDrawer('MERGE');
                            }}
                          >
                            Review Duplicate / Merge
                          </button>
                        )}
                      </div>
                    </>
                  ) : (
                    <div style={{ color: '#64748b' }}>Select a node in the graph canvas to inspect its RDF identity, mappings, and relationships.</div>
                  )}
                </div>
              )}

              {inspectorState === 'EDGE' && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', fontSize: '12px' }}>
                  {selectedGraphEdge ? (
                    <>
                      <div style={{ fontWeight: 700, color: '#0f172a' }}>Selected RDF Relationship Triple</div>
                      <div style={{ background: '#f8fafc', padding: '8px', borderRadius: '6px', border: '1px solid #e2e8f0', fontFamily: 'var(--font-mono)', fontSize: '11px', wordBreak: 'break-all' }}>
                        <div><strong>Subject:</strong> {selectedGraphEdge.source}</div>
                        <div><strong>Predicate:</strong> {selectedGraphEdge.predicate} ({selectedGraphEdge.predicate_label})</div>
                        <div><strong>Object:</strong> {selectedGraphEdge.target}</div>
                        <div><strong>Provenance Chunk:</strong> {selectedGraphEdge.source_chunk_uri || 'Document-level'}</div>
                      </div>
                      {!selectedGraphEdge.in_trusted_graph && (
                        <div style={{ display: 'flex', gap: '6px' }}>
                          <button
                            className="btn btn-primary"
                            style={{ fontSize: '11px', padding: '4px 9px' }}
                            onClick={() => {
                              setOldTripleSubject(selectedGraphEdge.source);
                              setOldTriplePredicate(selectedGraphEdge.predicate);
                              setOldTripleObject(selectedGraphEdge.target);
                              setEditSubject(selectedGraphEdge.source);
                              setEditPredicate(selectedGraphEdge.predicate);
                              setEditObject(selectedGraphEdge.target);
                              setEditModeType('REPLACE_TRIPLE');
                              setActiveResolutionDrawer('EDIT');
                            }}
                          >
                            Edit Relationship
                          </button>
                          <button
                            className="btn btn-danger"
                            style={{ fontSize: '11px', padding: '4px 9px' }}
                            onClick={() => {
                              setOldTripleSubject(selectedGraphEdge.source);
                              setOldTriplePredicate(selectedGraphEdge.predicate);
                              setOldTripleObject(selectedGraphEdge.target);
                              setEditModeType('REMOVE_TRIPLE');
                              setActiveResolutionDrawer('EDIT');
                            }}
                          >
                            Remove Triple
                          </button>
                        </div>
                      )}
                    </>
                  ) : (
                    <div style={{ color: '#64748b' }}>Select an edge in the graph canvas to inspect its exact subject, predicate, object, and provenance.</div>
                  )}
                </div>
              )}

              {inspectorState === 'ISSUE' && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', fontSize: '12px' }}>
                  {selectedIssue ? (
                    <div style={{ padding: '10px', background: '#fef2f2', border: '1px solid #fecaca', borderRadius: '6px', display: 'flex', flexDirection: 'column', gap: '6px' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 700, color: '#991b1b' }}>
                        <span>{selectedIssue.issue_type}</span>
                        <span>{selectedIssue.severity}</span>
                      </div>
                      <div style={{ fontWeight: 600, color: '#1e293b' }}>{selectedIssue.message}</div>
                      <div style={{ fontSize: '11px', color: '#475569' }}>{selectedIssue.explanation}</div>
                      {selectedIssue.focus_node && (
                        <div style={{ fontSize: '10.5px', fontFamily: 'var(--font-mono)' }}>
                          <strong>Affected Resource:</strong> {selectedIssue.focus_node}
                        </div>
                      )}
                    </div>
                  ) : (
                    <div style={{ color: '#64748b' }}>Select a semantic or SHACL issue from the left queue to inspect and remediate it.</div>
                  )}
                </div>
              )}

              {/* CONTEXTUAL DRAWER 1: SEMANTIC EDIT + DIFF PREVIEW */}
              {activeResolutionDrawer === 'EDIT' && (
                <div style={{ padding: '10px', background: '#eff6ff', border: '1px solid #93c5fd', borderRadius: '8px', display: 'flex', flexDirection: 'column', gap: '8px', fontSize: '11.5px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <strong style={{ color: '#1e3a8a' }}>Semantic Edit &amp; Before/After RDF Diff</strong>
                    <button className="btn btn-outline" style={{ fontSize: '10px', padding: '2px 6px' }} onClick={() => setActiveResolutionDrawer('NONE')}>
                      Close
                    </button>
                  </div>
                  <select
                    value={editModeType}
                    onChange={(e) => setEditModeType(e.target.value as any)}
                    style={{ padding: '5px 8px', borderRadius: '4px', border: '1px solid #cbd5e1', fontSize: '11.5px' }}
                  >
                    <option value="ADD_TRIPLE">Insert Triple (Subject / Predicate / Object)</option>
                    <option value="REPLACE_TRIPLE">Replace Existing Triple (Before &rarr; After)</option>
                    <option value="UPDATE_ENTITY">Update Entity Label / Class / Mapping</option>
                    <option value="REMOVE_TRIPLE">Remove Triple</option>
                    <option value="ADVANCED_JSON">Advanced RDF Mutation JSON</option>
                  </select>

                  {editModeType === 'REPLACE_TRIPLE' && (
                    <div style={{ background: '#fef2f2', padding: '6px', borderRadius: '4px', border: '1px solid #fecaca' }}>
                      <div style={{ fontWeight: 700, fontSize: '10px', color: '#991b1b' }}>Existing Statement (Before):</div>
                      <input type="text" value={oldTripleSubject} onChange={(e) => setOldTripleSubject(e.target.value)} placeholder="Old Subject URI" style={{ width: '100%', padding: '4px', fontSize: '11px', marginTop: '3px' }} />
                      <input type="text" value={oldTriplePredicate} onChange={(e) => setOldTriplePredicate(e.target.value)} placeholder="Old Predicate URI" style={{ width: '100%', padding: '4px', fontSize: '11px', marginTop: '3px' }} />
                      <input type="text" value={oldTripleObject} onChange={(e) => setOldTripleObject(e.target.value)} placeholder="Old Object Value" style={{ width: '100%', padding: '4px', fontSize: '11px', marginTop: '3px' }} />
                    </div>
                  )}

                  {(editModeType === 'ADD_TRIPLE' || editModeType === 'REPLACE_TRIPLE' || editModeType === 'REMOVE_TRIPLE') && (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                      <input type="text" value={editSubject} onChange={(e) => setEditSubject(e.target.value)} placeholder="Subject URI" style={{ padding: '5px', fontSize: '11px' }} />
                      <input type="text" value={editPredicate} onChange={(e) => setEditPredicate(e.target.value)} placeholder="Predicate URI" style={{ padding: '5px', fontSize: '11px' }} />
                      <input type="text" value={editObject} onChange={(e) => setEditObject(e.target.value)} placeholder="Object URI or Literal" style={{ padding: '5px', fontSize: '11px' }} />
                    </div>
                  )}

                  {editModeType === 'UPDATE_ENTITY' && (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                      <input type="text" value={editSubject} onChange={(e) => setEditSubject(e.target.value)} placeholder="Entity URI" style={{ padding: '5px', fontSize: '11px' }} />
                      <input type="text" value={editEntityLabel} onChange={(e) => setEditEntityLabel(e.target.value)} placeholder="Canonical Label" style={{ padding: '5px', fontSize: '11px' }} />
                      <input type="text" value={editEntityClass} onChange={(e) => setEditEntityClass(e.target.value)} placeholder="Ontology Class" style={{ padding: '5px', fontSize: '11px' }} />
                    </div>
                  )}

                  <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
                    <button className="btn btn-outline" style={{ fontSize: '11px', padding: '4px 9px', background: '#fff' }} onClick={handlePreviewEdit}>
                      Preview Before/After RDF Diff
                    </button>
                    <button className="btn btn-primary" style={{ fontSize: '11px', padding: '4px 10px' }} onClick={handleEditCandidate}>
                      Save Semantic Change (v{(candidate?.graph_version || 1) + 1})
                    </button>
                  </div>

                  {editPreviewResult && (
                    <div style={{ background: '#fff', padding: '8px', borderRadius: '6px', border: '1px solid #93c5fd', fontSize: '10.5px', fontFamily: 'var(--font-mono)' }}>
                      <div style={{ fontWeight: 700 }}>
                        Diff Preview (v{editPreviewResult.current_version} &rarr; v{editPreviewResult.predicted_next_version}):
                      </div>
                      {(editPreviewResult.diff?.removed_triples || []).map((rt: any, i: number) => (
                        <div key={`rm-${i}`} style={{ color: '#b91c1c' }}>− {rt.subject.split('/').pop()} {rt.predicate.split('/').pop()} {String(rt.object).split('/').pop()}</div>
                      ))}
                      {(editPreviewResult.diff?.added_triples || []).map((at: any, i: number) => (
                        <div key={`add-${i}`} style={{ color: '#15803d' }}>+ {at.subject.split('/').pop()} {at.predicate.split('/').pop()} {String(at.object).split('/').pop()}</div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* CONTEXTUAL DRAWER 2: ENTITY MERGE */}
              {activeResolutionDrawer === 'MERGE' && (
                <div style={{ padding: '10px', background: '#fff7ed', border: '1px solid #fdba74', borderRadius: '8px', display: 'flex', flexDirection: 'column', gap: '8px', fontSize: '11.5px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <strong style={{ color: '#9a3412' }}>Visual Entity Merge &amp; Side-by-Side Comparison</strong>
                    <button className="btn btn-outline" style={{ fontSize: '10px', padding: '2px 6px' }} onClick={() => setActiveResolutionDrawer('NONE')}>
                      Close
                    </button>
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '6px' }}>
                    <div style={{ background: '#fff', padding: '6px', borderRadius: '4px', border: '1px solid #fca5a5' }}>
                      <div style={{ fontWeight: 700, fontSize: '10px', color: '#b91c1c' }}>Duplicate Candidate Source</div>
                      <input type="text" value={mergeSource} onChange={(e) => setMergeSource(e.target.value)} style={{ width: '100%', fontSize: '10.5px', marginTop: '3px' }} />
                    </div>
                    <div style={{ background: '#fff', padding: '6px', borderRadius: '4px', border: '1px solid #86efac' }}>
                      <div style={{ fontWeight: 700, fontSize: '10px', color: '#15803d' }}>Canonical Target URI</div>
                      <input type="text" value={mergeTarget} onChange={(e) => setMergeTarget(e.target.value)} style={{ width: '100%', fontSize: '10.5px', marginTop: '3px' }} />
                    </div>
                  </div>
                  <div style={{ display: 'flex', gap: '6px' }}>
                    <button className="btn btn-outline" style={{ fontSize: '11px', padding: '4px 9px', background: '#fff' }} onClick={handlePreviewMerge}>
                      Preview Redirected Relationships
                    </button>
                    <button className="btn btn-primary" style={{ fontSize: '11px', padding: '4px 10px' }} onClick={handleMergeEntities}>
                      Execute Controlled Merge
                    </button>
                  </div>
                  {mergePreviewResult && (
                    <div style={{ background: '#fff', padding: '8px', borderRadius: '6px', fontSize: '10.5px', fontFamily: 'var(--font-mono)' }}>
                      Redirected triples: {mergePreviewResult.rewritten_triples_count} &rarr; v{mergePreviewResult.predicted_next_version} ({mergePreviewResult.post_merge_state})
                    </div>
                  )}
                </div>
              )}

              {/* CONTEXTUAL DRAWER 3: SEMANTIC QUARANTINE & EVIDENCE REMEDIATION */}
              {activeResolutionDrawer === 'QUARANTINE_EVIDENCE' && (
                <div style={{ padding: '10px', background: '#fffbeb', border: '1px solid #fde68a', borderRadius: '8px', display: 'flex', flexDirection: 'column', gap: '8px', fontSize: '11.5px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <strong style={{ color: '#92400e' }}>Semantic Evidence &amp; Quarantine Remediation</strong>
                    <button className="btn btn-outline" style={{ fontSize: '10px', padding: '2px 6px' }} onClick={() => setActiveResolutionDrawer('NONE')}>
                      Close
                    </button>
                  </div>
                  <input type="text" value={evidenceRequestNote} onChange={(e) => setEvidenceRequestNote(e.target.value)} placeholder="Semantic change or evidence request note" style={{ padding: '5px', fontSize: '11px' }} />
                  <button className="btn btn-outline" style={{ fontSize: '11px', padding: '4px 9px', background: '#fff' }} onClick={handleRequestSemanticChanges}>
                    Request Semantic Evidence (&rarr; AWAITING_EVIDENCE)
                  </button>
                  <textarea rows={2} value={supplementalEvidenceText} onChange={(e) => setSupplementalEvidenceText(e.target.value)} style={{ padding: '5px', fontSize: '11px' }} />
                  <button className="btn btn-primary" style={{ fontSize: '11px', padding: '4px 9px' }} onClick={handleSubmitEvidence}>
                    Attach Traceable Evidence &amp; Reconcile (&rarr; VALIDATION_PENDING)
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* BOTTOM: VALIDATION & REVISION TIMELINE */}
          <div className="card" style={{ padding: '12px 16px', display: 'flex', flexDirection: 'column', gap: '10px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '8px' }}>
              <div style={{ fontWeight: 700, fontSize: '13px', color: '#0f172a' }}>
                Validation &amp; Revision Timeline ({candidate?.revision_history?.length || 1} Version Snapshots • SHACL Violations: {shaclRep?.violation_count || 0})
              </div>
              <div style={{ fontSize: '11px', color: '#64748b' }}>
                Select any revision snapshot to inspect its content hash, actor, and persisted RDF diff.
              </div>
            </div>
            <div style={{ display: 'flex', gap: '8px', overflowX: 'auto', paddingBottom: '4px' }}>
              {(candidate?.revision_history || []).map((rev: any, idx: number) => {
                const isSel = selectedRevision?.version === rev.version && selectedRevision?.action === rev.action;
                return (
                  <div
                    key={idx}
                    onClick={() => setSelectedRevision(rev)}
                    style={{
                      minWidth: '175px',
                      padding: '8px 10px',
                      borderRadius: '6px',
                      border: isSel ? '2px solid #2563eb' : '1px solid #cbd5e1',
                      background: isSel ? '#eff6ff' : '#f8fafc',
                      cursor: 'pointer',
                      fontSize: '11px',
                    }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 700 }}>
                      <span>v{rev.version}</span>
                      <span className="badge badge-internal" style={{ fontSize: '9.5px' }}>{rev.action}</span>
                    </div>
                    <div style={{ fontSize: '10px', color: '#475569', marginTop: '3px' }}>
                      Actor: <strong>{rev.actor_id}</strong> • <code>{(rev.content_hash || '').slice(0, 8)}…</code>
                    </div>
                    <div style={{ fontSize: '10.5px', color: '#1e293b', marginTop: '3px' }}>{(rev.reason || '').slice(0, 55)}</div>
                  </div>
                );
              })}
            </div>
            {selectedRevision && (
              <div style={{ padding: '8px 12px', background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '6px', fontSize: '11.5px' }}>
                <strong>Snapshot v{selectedRevision.version} ({selectedRevision.action}):</strong> {selectedRevision.reason} — Actor: <code>{selectedRevision.actor_id}</code> • Timestamp: <code>{selectedRevision.timestamp}</code> • Hash: <code>{selectedRevision.content_hash}</code>
              </div>
            )}
          </div>
        </>
      )}

      {/* ADVANCED RDF & SHACL TECHNICAL VIEWS */}
      {studioViewMode === 'advanced_rdf' && (
        <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
          <div style={{ display: 'flex', gap: '6px', borderBottom: '1px solid #e2e8f0', paddingBottom: '8px' }}>
            <button
              className="btn"
              style={{
                fontSize: '12px',
                padding: '5px 11px',
                background: advancedSubTab === 'shacl' ? '#2563eb' : '#f1f5f9',
                color: advancedSubTab === 'shacl' ? '#fff' : '#334155',
              }}
              onClick={() => setAdvancedSubTab('shacl')}
            >
              Detailed SHACL Validation Report ({shaclRep?.violation_count || 0} Violations)
            </button>
            <button
              className="btn"
              style={{
                fontSize: '12px',
                padding: '5px 11px',
                background: advancedSubTab === 'triples' ? '#2563eb' : '#f1f5f9',
                color: advancedSubTab === 'triples' ? '#fff' : '#334155',
              }}
              onClick={() => setAdvancedSubTab('triples')}
            >
              Raw Candidate RDF Triples ({candidate?.triples?.length || 0})
            </button>
            <button
              className="btn"
              style={{
                fontSize: '12px',
                padding: '5px 11px',
                background: advancedSubTab === 'revisions' ? '#2563eb' : '#f1f5f9',
                color: advancedSubTab === 'revisions' ? '#fff' : '#334155',
              }}
              onClick={() => setAdvancedSubTab('revisions')}
            >
              Full Revision Ledger ({candidate?.revision_history?.length || 1})
            </button>
          </div>

          {advancedSubTab === 'shacl' && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', fontSize: '12px' }}>
              <div style={{ background: '#f8fafc', padding: '10px', borderRadius: '6px', border: '1px solid #e2e8f0' }}>
                <div><strong>Report ID:</strong> <code>{shaclRep?.report_id}</code> • <strong>Status:</strong> {shaclRep?.status} {isStale ? '(STALE)' : '(FRESH)'}</div>
                <div><strong>Bound Version:</strong> v{shaclRep?.candidate_version} • <strong>Bound Hash:</strong> <code>{shaclRep?.candidate_content_hash}</code></div>
                <div><strong>SHACL Shapes Version:</strong> <code>{shaclRep?.shacl_shapes_version}</code> • <strong>Trusted Graph Version:</strong> <code>{shaclRep?.trusted_graph_version}</code></div>
              </div>
              {(shaclRep?.violations || []).map((v: any, idx: number) => (
                <div key={idx} style={{ padding: '10px', background: '#fef2f2', border: '1px solid #fecaca', borderRadius: '6px' }}>
                  <div><strong>Shape:</strong> <code>{v.source_shape}</code> ({v.constraint_component})</div>
                  <div><strong>Focus Node:</strong> <code>{v.focus_node}</code> | <strong>Path:</strong> <code>{v.result_path}</code></div>
                  <div style={{ fontWeight: 600, color: '#991b1b' }}>{v.message}</div>
                </div>
              ))}
            </div>
          )}

          {advancedSubTab === 'triples' && (
            <div className="table-container" style={{ maxHeight: '420px', overflowY: 'auto' }}>
              <table>
                <thead>
                  <tr>
                    <th>Subject</th>
                    <th>Predicate</th>
                    <th>Object</th>
                    <th>Type</th>
                    <th>Origin</th>
                  </tr>
                </thead>
                <tbody>
                  {(candidate?.triples || []).map((t: any, idx: number) => (
                    <tr key={idx}>
                      <td style={{ fontFamily: 'var(--font-mono)', fontSize: '11px' }}>{t.subject}</td>
                      <td style={{ fontFamily: 'var(--font-mono)', fontSize: '11px', color: '#2563eb' }}>{t.predicate_label}</td>
                      <td style={{ fontFamily: 'var(--font-mono)', fontSize: '11px' }}>{String(t.object)}</td>
                      <td style={{ fontSize: '11px' }}>{t.object_type}</td>
                      <td style={{ fontSize: '11px' }}>{t.graph_origin}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {advancedSubTab === 'revisions' && (
            <div className="table-container">
              <table>
                <thead>
                  <tr>
                    <th>Version</th>
                    <th>Action</th>
                    <th>Actor</th>
                    <th>Timestamp</th>
                    <th>Content Hash</th>
                    <th>Reason</th>
                  </tr>
                </thead>
                <tbody>
                  {(candidate?.revision_history || []).map((rev: any, idx: number) => (
                    <tr key={idx}>
                      <td><strong>v{rev.version}</strong></td>
                      <td><span className="badge badge-internal">{rev.action}</span></td>
                      <td>{rev.actor_id}</td>
                      <td style={{ fontSize: '11px' }}>{rev.timestamp}</td>
                      <td><code>{(rev.content_hash || '').slice(0, 14)}…</code></td>
                      <td style={{ fontSize: '12px' }}>{rev.reason}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
