"""
Watson Pharmaceutical Knowledge Intelligence Platform (WIP)
===========================================================
Mandatory 21 End-to-End Acceptance Tests (Phase 13: TEST 01 – TEST 21)
Executes against actual FastAPI backend, SHACL validation engine, Candidate
Governance & Publication coordinator, FAISS vector index, and RDFLib SPARQL engine
in an isolated temporary workspace.
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import sys
import tempfile
import time
from pathlib import Path

import pytest

PROJECT = Path(__file__).resolve().parents[1]
WORK = Path(tempfile.mkdtemp(prefix="watson-21-acceptance-"))
import atexit
atexit.register(lambda: shutil.rmtree(WORK, ignore_errors=True))

for folder in ["data", "ontology", "queries", "outputs", "reports"]:
    src = PROJECT / folder
    if src.exists():
        shutil.copytree(src, WORK / folder)

(WORK / "dedup_store.json").write_text(json.dumps({"exact_hashes": {}, "title_registry": []}))
os.environ.update(
    WATSON_BASE_DIR=str(WORK),
    HF_HUB_OFFLINE="1",
    TRANSFORMERS_OFFLINE="1",
    WATSON_ALLOW_CLOUD="0",
)
if (PROJECT / "approved_models/all-MiniLM-L6-v2").is_dir():
    os.environ["WATSON_EMBEDDING_MODEL"] = str(PROJECT / "approved_models/all-MiniLM-L6-v2")

sys.path[:0] = [str(PROJECT), str(PROJECT / "backend")]
from office_policy import disable_tokenizer_downloads
disable_tokenizer_downloads()

from fastapi.testclient import TestClient
from app import main as api_main
from watson.semantics.candidate_governance_service import CandidateGovernanceService
from watson.semantics.shacl_validator import SHACLValidator
from watson.shared.config import (
    AUDIT_LOG_FILE,
    CHUNK_URI_MAP_FILE,
    FAISS_INDEX_FILE,
    LIFECYCLE_STORE_FILE,
    PHARMA_KG_FILE,
    SEED_VOCABULARIES_FILE,
    STAGING_DATA_DIR,
)

ADMIN_HEADERS = {"x-user-id": "D4"}
SPOC_HEADERS = {"x-user-id": "U_SPOC"}
VIEWER_HEADERS = {"x-user-id": "D3"}
EXTERNAL_HEADERS = {"x-user-id": "U_EXTERNAL"}


@pytest.fixture
def client():
    with TestClient(api_main.app, base_url="http://localhost") as c:
        yield c


def _make_pharma_doc(tag: str, extra_text: str = "") -> bytes:
    return (
        f"HCP Perception Survey — Clinical Dossier {tag}\n"
        f"Therapeutic Area: Oncology\n"
        f"Geography: US\n"
        f"Brand: Keytruda (Pembrolizumab) manufactured by Merck treats Non-Small Cell Lung Cancer (NSCLC).\n"
        f"Comparator Opdivo (Nivolumab) evaluated across 420 oncologists in US cancer centers.\n"
        f"HCP perception survey indicates 91% physician confidence in first-line PD-L1 positive NSCLC.\n"
        f"{extra_text}\n"
    ).encode("utf-8")


# ============================================================================
# TEST 01 – Admin Candidate Graph Exploration
# ============================================================================
def test_01_admin_candidate_graph_exploration(client):
    doc_bytes = _make_pharma_doc("TEST01_EXPLORE", "Candidate Drug: MK-7684A (Vibostolimab) in NSCLC.")
    up = client.post(
        "/api/ingestion/upload",
        files={"file": ("test01_oncology_study.txt", doc_bytes, "text/plain")},
        headers=ADMIN_HEADERS,
    )
    assert up.status_code == 200, up.text
    staged = up.json()
    cand_id = staged["candidate_id"]
    doc_uri = staged["document_uri"]

    explorer_res = client.get(
        f"/api/candidates/graph/explorer?candidate_id={cand_id}&include_trusted_context=true",
        headers=ADMIN_HEADERS,
    )
    assert explorer_res.status_code == 200, explorer_res.text
    payload = explorer_res.json()
    assert payload["status"] == "SUCCESS"
    assert payload["counts"]["total_nodes"] >= 5
    assert payload["counts"]["total_edges"] >= 5
    assert payload["counts"]["total_triples"] >= 10
    assert any(n["label"] == "Keytruda" for n in payload["nodes"])
    assert any(t["source_document_uri"] == doc_uri for t in payload["triples"])
    # Verify persisted backing in candidate_governance_store.json
    gov_store_path = WORK / "data/stores/candidate_governance_store.json"
    assert gov_store_path.exists()
    persisted = json.loads(gov_store_path.read_text(encoding="utf-8"))
    assert cand_id in persisted["candidates"]


# ============================================================================
# TEST 02 – Candidate vs Trusted Graph Comparison
# ============================================================================
def test_02_candidate_vs_trusted_graph_comparison(client):
    kg_before = PHARMA_KG_FILE.read_bytes()
    doc_bytes = _make_pharma_doc("TEST02_COMPARE", "Candidate Drug: Dato-DXd in NSCLC.")
    up = client.post(
        "/api/ingestion/upload",
        files={"file": ("test02_comparison.txt", doc_bytes, "text/plain")},
        headers=ADMIN_HEADERS,
    ).json()
    cand_id = up["candidate_id"]

    res = client.get(
        f"/api/candidates/graph/explorer?candidate_id={cand_id}&include_trusted_context=true",
        headers=ADMIN_HEADERS,
    )
    assert res.status_code == 200
    preview = res.json()["integrated_preview"]
    assert preview["trusted_graph_readonly_verified"] is True
    assert preview["candidate_additions_count"] > 0
    assert preview["existing_trusted_facts_count"] > 0
    assert isinstance(preview["conflicting_facts"], list)
    assert isinstance(preview["unresolved_mappings"], list)
    assert PHARMA_KG_FILE.read_bytes() == kg_before, "Trusted graph must not be mutated during comparison!"


# ============================================================================
# TEST 03 – Edit-Revalidate Enforcement
# ============================================================================
def test_03_edit_revalidate_enforcement(client):
    up = client.post(
        "/api/ingestion/upload",
        files={"file": ("test03_edit_revalidate.txt", _make_pharma_doc("TEST03_EDIT"), "text/plain")},
        headers=ADMIN_HEADERS,
    ).json()
    cand_id = up["candidate_id"]
    assert up["candidate_lifecycle_state"] == "UNDER_REVIEW"
    assert up["shacl_report"]["conforms"] is True

    # Execute EDIT
    edit_res = client.post(
        f"/api/candidates/{cand_id}/edit",
        json={
            "add_triples": [
                {
                    "subject": "http://watson.pharma.org/entity/brand/keytruda",
                    "predicate": "http://watson.pharma.org/ontology/manufacturedBy",
                    "object": "http://watson.pharma.org/entity/manufacturer/merck",
                    "object_type": "uri",
                }
            ],
            "reason": "Added manufacturer link during HITL review",
        },
        headers=ADMIN_HEADERS,
    )
    assert edit_res.status_code == 200, edit_res.text
    edited_cand = edit_res.json()["candidate"]
    assert edited_cand["graph_version"] == 2
    assert edited_cand["candidate_lifecycle_state"] == "VALIDATION_PENDING"
    assert edited_cand["shacl_report"]["is_stale"] is True

    # Attempt approval before revalidation -> MUST BE REJECTED (400)
    appr_blocked = client.post(
        f"/api/candidates/{cand_id}/approve",
        json={"expected_version": 2, "review_note": "Premature approval attempt"},
        headers=ADMIN_HEADERS,
    )
    assert appr_blocked.status_code == 400, appr_blocked.text
    assert "VALIDATION_FRESHNESS_REQUIRED" in appr_blocked.json()["detail"]

    # Also verify legacy /api/ingestion/review blocks premature approval when in VALIDATION_PENDING
    rev_blocked = client.post(
        "/api/ingestion/review",
        json={"document_uri": up["document_uri"], "decision": "APPROVE"},
        headers=ADMIN_HEADERS,
    )
    assert rev_blocked.status_code == 400

    # Revalidate -> transitions VALIDATION_PENDING -> VALIDATING -> UNDER_REVIEW
    val_res = client.post(f"/api/candidates/{cand_id}/validate", headers=ADMIN_HEADERS)
    assert val_res.status_code == 200, val_res.text
    revalidated = val_res.json()["candidate"]
    assert revalidated["candidate_lifecycle_state"] == "UNDER_REVIEW"
    assert revalidated["shacl_report"]["is_stale"] is False
    assert revalidated["shacl_report"]["conforms"] is True
    assert revalidated["shacl_report"]["candidate_version"] == 2

    # Now approval succeeds
    appr_ok = client.post(
        f"/api/candidates/{cand_id}/approve",
        json={"expected_version": 2, "review_note": "Approved after fresh SHACL validation"},
        headers=ADMIN_HEADERS,
    )
    assert appr_ok.status_code == 200, appr_ok.text
    assert appr_ok.json()["candidate"]["candidate_lifecycle_state"] == "APPROVED"


# ============================================================================
# TEST 04 – Merge-Revalidate Enforcement
# ============================================================================
def test_04_merge_revalidate_enforcement(client):
    up = client.post(
        "/api/ingestion/upload",
        files={"file": ("test04_merge.txt", _make_pharma_doc("TEST04_MERGE", "Candidate Drug: Pembrolizumab-Biosimilar"), "text/plain")},
        headers=ADMIN_HEADERS,
    ).json()
    cand_id = up["candidate_id"]
    v1_hash = up["content_hash"]

    merge_res = client.post(
        f"/api/candidates/{cand_id}/merge",
        json={
            "source_entity_uri": "http://watson.pharma.org/entity/drug/pembrolizumab_biosimilar",
            "target_entity_uri": "http://watson.pharma.org/entity/drug/pembrolizumab",
            "target_canonical_name": "Pembrolizumab",
            "reason": "Merged biosimilar mention into canonical Pembrolizumab entity",
        },
        headers=ADMIN_HEADERS,
    )
    assert merge_res.status_code == 200, merge_res.text
    merged = merge_res.json()["candidate"]
    assert merged["graph_version"] == 2
    assert merged["content_hash"] != v1_hash
    assert merged["candidate_lifecycle_state"] == "VALIDATION_PENDING"
    assert merged["shacl_report"]["is_stale"] is True

    # Approval blocked before revalidation
    assert client.post(f"/api/candidates/{cand_id}/approve", json={"expected_version": 2}, headers=ADMIN_HEADERS).status_code == 400

    # Revalidate and approve
    val = client.post(f"/api/candidates/{cand_id}/validate", headers=ADMIN_HEADERS)
    assert val.status_code == 200
    assert val.json()["shacl_report"]["conforms"] is True
    assert client.post(f"/api/candidates/{cand_id}/approve", json={"expected_version": 2}, headers=ADMIN_HEADERS).status_code == 200


# ============================================================================
# TEST 05 – Cross-Graph SHACL Validation
# ============================================================================
def test_05_cross_graph_shacl_validation(client):
    up = client.post(
        "/api/ingestion/upload",
        files={"file": ("test05_shacl_cross_graph.txt", _make_pharma_doc("TEST05_SHACL"), "text/plain")},
        headers=ADMIN_HEADERS,
    ).json()
    cand_id = up["candidate_id"]

    # 1. Add a candidate Drug referencing an existing trusted Manufacturer (Merck) in SCOPED_TRUSTED_GRAPH_CONTEXT
    client.post(
        f"/api/candidates/{cand_id}/edit",
        json={
            "add_triples": [
                {
                    "subject": "http://watson.pharma.org/entity/drug/pembrolizumab",
                    "predicate": "http://watson.pharma.org/ontology/manufacturedBy",
                    "object": "http://watson.pharma.org/entity/manufacturer/merck",
                    "object_type": "uri",
                }
            ],
            "reason": "Reference trusted manufacturer Merck",
        },
        headers=ADMIN_HEADERS,
    )
    val_ok = client.post(f"/api/candidates/{cand_id}/validate", headers=ADMIN_HEADERS).json()
    rep_ok = val_ok["shacl_report"]
    assert rep_ok["conforms"] is True
    assert rep_ok["shacl_shapes_version"].startswith("1.0.0+")
    assert rep_ok["trusted_graph_version"].startswith("kg-v2.1+")
    assert any(
        r["target_node"] == "http://watson.pharma.org/entity/manufacturer/merck"
        and r["resolved_via"] == "SCOPED_TRUSTED_GRAPH_CONTEXT"
        for r in rep_ok["cross_graph_references_resolved"]
    )

    # 2. Introduce a genuine violation: reference an untyped/unknown entity as manufacturer
    client.post(
        f"/api/candidates/{cand_id}/edit",
        json={
            "add_triples": [
                {
                    "subject": "http://watson.pharma.org/entity/drug/pembrolizumab",
                    "predicate": "http://watson.pharma.org/ontology/manufacturedBy",
                    "object": "http://watson.pharma.org/entity/unknown/non_existent_manufacturer_xyz",
                    "object_type": "uri",
                }
            ],
            "reason": "Inject invalid untyped manufacturer target to verify violation detection",
        },
        headers=ADMIN_HEADERS,
    )
    val_fail = client.post(f"/api/candidates/{cand_id}/validate", headers=ADMIN_HEADERS).json()
    rep_fail = val_fail["shacl_report"]
    assert rep_fail["conforms"] is False
    assert val_fail["candidate"]["candidate_lifecycle_state"] == "VALIDATION_FAILED"
    assert rep_fail["violation_count"] >= 1
    assert "http://watson.pharma.org/entity/drug/pembrolizumab" in rep_fail["affected_resources"]


# ============================================================================
# TEST 06 – Trusted Graph Isolation
# ============================================================================
def test_06_trusted_graph_isolation(client):
    kg_bytes_before = PHARMA_KG_FILE.read_bytes()
    triples_before = len(api_main.assembler.graph)

    up = client.post(
        "/api/ingestion/upload",
        files={"file": ("test06_isolation.txt", _make_pharma_doc("TEST06_ISOLATION"), "text/plain")},
        headers=ADMIN_HEADERS,
    ).json()
    cand_id = up["candidate_id"]
    client.post(
        f"/api/candidates/{cand_id}/edit",
        json={
            "add_triples": [
                {
                    "subject": "http://watson.pharma.org/entity/brand/keytruda",
                    "predicate": "http://watson.pharma.org/ontology/manufacturedBy",
                    "object": "http://watson.pharma.org/entity/manufacturer/merck",
                    "object_type": "uri",
                }
            ]
        },
        headers=ADMIN_HEADERS,
    )
    client.post(f"/api/candidates/{cand_id}/validate", headers=ADMIN_HEADERS)

    assert PHARMA_KG_FILE.read_bytes() == kg_bytes_before
    assert len(api_main.assembler.graph) == triples_before


# ============================================================================
# TEST 07 – Unapproved FAISS Evidence Isolation
# ============================================================================
def test_07_unapproved_faiss_evidence_isolation(client):
    secret_token = "UNAPPROVED_STAGED_MARKER_OMEGA_7744"
    faiss_bytes_before = FAISS_INDEX_FILE.read_bytes()
    up = client.post(
        "/api/ingestion/upload",
        files={"file": ("test07_staged_only.txt", _make_pharma_doc("TEST07_FAISS", f"Confidential finding: {secret_token}"), "text/plain")},
        headers=ADMIN_HEADERS,
    ).json()
    doc_uri = up["document_uri"]

    # Production FAISS index must be unchanged while unapproved
    assert FAISS_INDEX_FILE.read_bytes() == faiss_bytes_before

    # Production search & chat must NOT return unapproved evidence
    s_res = client.post("/api/search", json={"query": f"Keytruda NSCLC {secret_token}", "top_k": 10}, headers=ADMIN_HEADERS).json()
    assert all(c["doc_uri"] != doc_uri for c in s_res["scored_chunks"])
    assert all(not u.startswith(doc_uri) for u in s_res["allowed_chunk_uris"])
    assert secret_token not in json.dumps(s_res["scored_chunks"])


# ============================================================================
# TEST 08 – Authorized Staged Evidence Access
# ============================================================================
def test_08_authorized_staged_evidence_access(client):
    up = client.post(
        "/api/ingestion/upload",
        files={"file": ("test08_rbac_staged.txt", _make_pharma_doc("TEST08_RBAC"), "text/plain")},
        headers=ADMIN_HEADERS,
    ).json()
    cand_id = up["candidate_id"]

    # Admin (D4) and SPOC (U_SPOC) can inspect staged candidate
    assert client.get(f"/api/candidates/{cand_id}", headers=ADMIN_HEADERS).status_code == 200
    assert client.get(f"/api/candidates/{cand_id}", headers=SPOC_HEADERS).status_code == 200

    # Ordinary Viewer (D3) and External Partner (U_EXTERNAL) are blocked with HTTP 403
    assert client.get(f"/api/candidates/{cand_id}", headers=VIEWER_HEADERS).status_code == 403
    assert client.get(f"/api/candidates/{cand_id}", headers=EXTERNAL_HEADERS).status_code == 403
    assert client.get("/api/candidates/graph/explorer", headers=VIEWER_HEADERS).status_code == 403


# ============================================================================
# TEST 09 – Coordinated RDF and FAISS Publication
# ============================================================================
def test_09_coordinated_rdf_and_faiss_publication(client):
    unique_phrase = "KEYTRUDA_PUBLISHED_COORDINATED_SIGNAL_9001"
    up = client.post(
        "/api/ingestion/upload",
        files={"file": ("test09_publish.txt", _make_pharma_doc("TEST09_PUB", f"Verified outcome: {unique_phrase}"), "text/plain")},
        headers=ADMIN_HEADERS,
    ).json()
    cand_id = up["candidate_id"]
    doc_uri = up["document_uri"]

    # Add a custom verified triple, revalidate, approve, and publish
    client.post(
        f"/api/candidates/{cand_id}/edit",
        json={
            "add_triples": [
                {
                    "subject": "http://watson.pharma.org/entity/brand/keytruda",
                    "predicate": "http://watson.pharma.org/ontology/manufacturedBy",
                    "object": "http://watson.pharma.org/entity/manufacturer/merck",
                    "object_type": "uri",
                }
            ]
        },
        headers=ADMIN_HEADERS,
    )
    client.post(f"/api/candidates/{cand_id}/validate", headers=ADMIN_HEADERS)
    appr = client.post(f"/api/candidates/{cand_id}/approve", json={"expected_version": 2, "pii_override": True}, headers=ADMIN_HEADERS)
    assert appr.status_code == 200

    pub = client.post(f"/api/candidates/{cand_id}/publish", json={"transaction_id": "tx_test09_coord"}, headers=ADMIN_HEADERS)
    assert pub.status_code == 200, pub.text
    pub_data = pub.json()
    assert pub_data["status"] == "PUBLISHED"
    assert pub_data["transaction"]["faiss_vectors_after"] > pub_data["transaction"]["faiss_vectors_before"]

    # Verify custom triple is now in trusted SPARQL graph
    sparql_res = client.post(
        "/api/graph/sparql",
        json={
            "query": """
            PREFIX watson: <http://watson.pharma.org/ontology/>
            SELECT ?mfg WHERE {
                <http://watson.pharma.org/entity/brand/keytruda> watson:manufacturedBy ?mfg .
            }
            """
        },
        headers=ADMIN_HEADERS,
    ).json()
    assert sparql_res["row_count"] >= 1
    assert any("merck" in r["mfg"] for r in sparql_res["results"])

    # Verify published evidence chunk is now active and retrievable via production /api/search
    search_res = client.post("/api/search", json={"query": f"Keytruda oncology evidence {unique_phrase}", "top_k": 20}, headers=ADMIN_HEADERS).json()
    assert any(u.startswith(doc_uri) for u in search_res["allowed_chunk_uris"])
    assert any(c["doc_uri"] == doc_uri for c in search_res["scored_chunks"]) or doc_uri in json.dumps(search_res)


# ============================================================================
# TEST 10 – Publication Failure Recovery
# ============================================================================
def test_10_publication_failure_recovery(client):
    up = client.post(
        "/api/ingestion/upload",
        files={"file": ("test10_fail_recovery.txt", _make_pharma_doc("TEST10_RECOVERY"), "text/plain")},
        headers=ADMIN_HEADERS,
    ).json()
    cand_id = up["candidate_id"]
    client.post(f"/api/candidates/{cand_id}/approve", json={"expected_version": 1, "pii_override": True}, headers=ADMIN_HEADERS)

    kg_before = PHARMA_KG_FILE.read_bytes()
    faiss_before = FAISS_INDEX_FILE.read_bytes()
    tx_id = "tx_test10_recoverable"

    # 1. Simulate failure during promotion
    fail_res = client.post(
        f"/api/candidates/{cand_id}/publish",
        json={"transaction_id": tx_id, "simulate_failure": True},
        headers=ADMIN_HEADERS,
    )
    assert fail_res.status_code == 400
    assert "PUBLICATION_FAILED" in fail_res.json()["detail"]

    # Verify active graph & FAISS are untouched (no partial release)
    assert PHARMA_KG_FILE.read_bytes() == kg_before
    assert FAISS_INDEX_FILE.read_bytes() == faiss_before

    # 2. Retry using the exact same transaction_id
    retry_res = client.post(
        f"/api/candidates/{cand_id}/publish",
        json={"transaction_id": tx_id, "simulate_failure": False},
        headers=ADMIN_HEADERS,
    )
    assert retry_res.status_code == 200, retry_res.text
    assert retry_res.json()["status"] == "PUBLISHED"
    assert retry_res.json()["transaction"]["attempt_count"] == 2

    # 3. Verify idempotent replay with same transaction_id
    replay_res = client.post(
        f"/api/candidates/{cand_id}/publish",
        json={"transaction_id": tx_id, "simulate_failure": False},
        headers=ADMIN_HEADERS,
    )
    assert replay_res.status_code == 200
    assert replay_res.json()["idempotent_replay"] is True


# ============================================================================
# TEST 11 – Quarantine Edit Path (Path A)
# ============================================================================
def test_11_quarantine_edit_path(client):
    up = client.post(
        "/api/ingestion/upload",
        files={"file": ("test11_quar_edit.txt", _make_pharma_doc("TEST11_QUAR_A"), "text/plain")},
        headers=ADMIN_HEADERS,
    ).json()
    cand_id = up["candidate_id"]

    # Quarantine candidate
    q_res = client.post(
        f"/api/candidates/{cand_id}/quarantine",
        json={"reason": "Missing explicit manufacturer attribution", "triggering_issue": "INCOMPLETE_ATTRIBUTION"},
        headers=ADMIN_HEADERS,
    )
    assert q_res.status_code == 200
    assert q_res.json()["candidate"]["candidate_lifecycle_state"] == "QUARANTINED"

    # Path A: Execute EDIT -> transitions QUARANTINED -> VALIDATION_PENDING
    e_res = client.post(
        f"/api/candidates/{cand_id}/edit",
        json={
            "add_triples": [
                {
                    "subject": "http://watson.pharma.org/entity/brand/keytruda",
                    "predicate": "http://watson.pharma.org/ontology/manufacturedBy",
                    "object": "http://watson.pharma.org/entity/manufacturer/merck",
                    "object_type": "uri",
                }
            ],
            "reason": "Remediated manufacturer attribution via Path A Edit",
        },
        headers=ADMIN_HEADERS,
    )
    assert e_res.status_code == 200
    assert e_res.json()["candidate"]["candidate_lifecycle_state"] == "VALIDATION_PENDING"

    # Revalidate -> returns to UNDER_REVIEW
    v_res = client.post(f"/api/candidates/{cand_id}/validate", headers=ADMIN_HEADERS)
    assert v_res.status_code == 200
    assert v_res.json()["candidate"]["candidate_lifecycle_state"] == "UNDER_REVIEW"
    assert v_res.json()["candidate"]["quarantine_record"]["final_disposition"] == "RETURNED_TO_UNDER_REVIEW"


# ============================================================================
# TEST 12 – Quarantine Evidence Path (Path B)
# ============================================================================
def test_12_quarantine_evidence_path(client):
    up = client.post(
        "/api/ingestion/upload",
        files={"file": ("test12_quar_evidence.txt", _make_pharma_doc("TEST12_QUAR_B"), "text/plain")},
        headers=ADMIN_HEADERS,
    ).json()
    cand_id = up["candidate_id"]

    client.post(
        f"/api/candidates/{cand_id}/quarantine",
        json={"reason": "Insufficient sample size evidence", "triggering_issue": "INSUFFICIENT_EVIDENCE"},
        headers=ADMIN_HEADERS,
    )

    # Step 1: Request Evidence -> AWAITING_EVIDENCE
    req_ev = client.post(
        f"/api/candidates/{cand_id}/request-evidence",
        json={"request_note": "Provide Phase 3 sample size and Dupixent immunology comparator data"},
        headers=ADMIN_HEADERS,
    )
    assert req_ev.status_code == 200
    assert req_ev.json()["candidate"]["candidate_lifecycle_state"] == "AWAITING_EVIDENCE"

    # Step 2: Submit Evidence -> EVIDENCE_RECEIVED -> SEMANTIC_RECONCILIATION -> VALIDATION_PENDING
    sub_ev = client.post(
        f"/api/candidates/{cand_id}/submit-evidence",
        json={
            "evidence_text": "Supplemental Dossier: Keytruda (Pembrolizumab) evaluated in 610 NSCLC patients in Oncology (US).",
            "source_reference": "KEYNOTE-Supplemental-2026.pdf",
        },
        headers=ADMIN_HEADERS,
    )
    assert sub_ev.status_code == 200
    assert sub_ev.json()["candidate"]["candidate_lifecycle_state"] == "VALIDATION_PENDING"

    # Step 3: Revalidate -> returns to UNDER_REVIEW
    val_ev = client.post(f"/api/candidates/{cand_id}/validate", headers=ADMIN_HEADERS)
    assert val_ev.status_code == 200
    assert val_ev.json()["candidate"]["candidate_lifecycle_state"] == "UNDER_REVIEW"


# ============================================================================
# TEST 13 – Quarantine Rejection Path (Path C)
# ============================================================================
def test_13_quarantine_rejection_path(client):
    up = client.post(
        "/api/ingestion/upload",
        files={"file": ("test13_quar_reject.txt", _make_pharma_doc("TEST13_QUAR_C"), "text/plain")},
        headers=ADMIN_HEADERS,
    ).json()
    cand_id = up["candidate_id"]

    client.post(
        f"/api/candidates/{cand_id}/quarantine",
        json={"reason": "Unverifiable third-party claim", "triggering_issue": "UNVERIFIABLE_SOURCE"},
        headers=ADMIN_HEADERS,
    )

    rej = client.post(
        f"/api/candidates/{cand_id}/reject",
        json={"reason": "Terminally rejected under Quarantine Path C due to unverifiable provenance"},
        headers=ADMIN_HEADERS,
    )
    assert rej.status_code == 200
    cand = rej.json()["candidate"]
    assert cand["candidate_lifecycle_state"] == "REJECTED"
    assert cand["document_lifecycle_state"] == "REJECTED"
    assert cand["quarantine_record"]["final_disposition"] == "REJECTED_TERMINAL"

    # Verify both approval and publication are blocked
    assert client.post(f"/api/candidates/{cand_id}/approve", json={}, headers=ADMIN_HEADERS).status_code == 400
    assert client.post(f"/api/candidates/{cand_id}/publish", json={}, headers=ADMIN_HEADERS).status_code == 400


# ============================================================================
# TEST 14 – Audit and Provenance Integrity
# ============================================================================
def test_14_audit_and_provenance_integrity(client):
    # Attempt unauthorized audit modification/deletion -> must return 403
    del_res = client.delete("/api/audit/logs", headers=ADMIN_HEADERS)
    assert del_res.status_code == 403
    put_res = client.put("/api/audit/logs", headers=ADMIN_HEADERS)
    assert put_res.status_code == 403

    logs = client.get("/api/audit/logs", headers=ADMIN_HEADERS).json()
    assert len(logs) > 0
    event_types = {e["event_type"] for e in logs}
    assert "AUDIT_MODIFICATION_BLOCKED" in event_types
    assert "SHACL_VALIDATION_EXECUTED" in event_types
    assert "CANDIDATE_APPROVED" in event_types
    assert "PUBLICATION_COMPLETED" in event_types

    for entry in logs[-10:]:
        assert "event_id" in entry
        assert "timestamp" in entry
        assert "user_id" in entry
        assert "correlation_id" in entry


# ============================================================================
# TEST 15 – Existing Retrieval Regression
# ============================================================================
def test_15_existing_retrieval_regression(client):
    # 1. FAISS + RAG + GraphRAG
    chat_res = client.post(
        "/api/chat",
        json={"query": "What is the clinical evidence for Keytruda in NSCLC?"},
        headers=ADMIN_HEADERS,
    )
    assert chat_res.status_code == 200
    cdata = chat_res.json()
    assert cdata["pipeline_execution_status"] == "COMPLETED"
    assert cdata["answer_grounding_status"] == "GROUNDED"
    assert len(cdata["citations"]) > 0
    assert len(cdata["kg_facts"]) > 0

    # 2. SPARQL Templates Q01-Q11
    tmpl_res = client.get("/api/graph/sparql/templates", headers=ADMIN_HEADERS).json()
    assert len(tmpl_res["templates"]) >= 11
    q01 = tmpl_res["templates"][0]["sparql"]
    q01_exec = client.post("/api/graph/sparql", json={"query": q01}, headers=ADMIN_HEADERS)
    assert q01_exec.status_code == 200
    assert q01_exec.json()["row_count"] >= 1

    # 3. Seed vocabulary & Databricks catalog integrity
    assert SEED_VOCABULARIES_FILE.exists()
    cat_res = client.get("/api/graph/catalog", headers=ADMIN_HEADERS)
    assert cat_res.status_code == 200
    assert len(cat_res.json()["products"]) == 15


# ============================================================================
# TEST 16 – RBAC/ABAC Security
# ============================================================================
def test_16_rbac_abac_security(client):
    # Admin allowed
    assert client.get("/api/ingestion/console", headers=ADMIN_HEADERS).status_code == 200
    assert client.get("/api/candidates", headers=ADMIN_HEADERS).status_code == 200

    # Viewer restricted on ingestion, candidate governance, and document archiving
    assert client.get("/api/ingestion/console", headers=VIEWER_HEADERS).status_code == 403
    assert client.get("/api/candidates", headers=VIEWER_HEADERS).status_code == 403
    assert client.post("/api/documents/Doc_001/archive", headers=VIEWER_HEADERS).status_code == 403

    # Viewer ABAC pre-filter on search restricts CONFIDENTIAL/RESTRICTED docs outside scope
    viewer_search = client.post("/api/search", json={"query": "Spinraza SMA Japan", "top_k": 5}, headers=VIEWER_HEADERS).json()
    admin_search = client.post("/api/search", json={"query": "Spinraza SMA Japan", "top_k": 5}, headers=ADMIN_HEADERS).json()
    assert len(viewer_search["allowed_chunk_uris"]) < len(admin_search["allowed_chunk_uris"])


# ============================================================================
# TEST 17 – Concurrent Edit and Stale Approval
# ============================================================================
def test_17_concurrent_edit_and_stale_approval(client):
    up = client.post(
        "/api/ingestion/upload",
        files={"file": ("test17_concurrency.txt", _make_pharma_doc("TEST17_CONCURRENT"), "text/plain")},
        headers=ADMIN_HEADERS,
    ).json()
    cand_id = up["candidate_id"]
    assert up["graph_version"] == 1

    # Session B modifies candidate (v1 -> v2) and revalidates v2
    client.post(
        f"/api/candidates/{cand_id}/edit",
        json={
            "add_triples": [
                {
                    "subject": "http://watson.pharma.org/entity/brand/keytruda",
                    "predicate": "http://watson.pharma.org/ontology/manufacturedBy",
                    "object": "http://watson.pharma.org/entity/manufacturer/merck",
                    "object_type": "uri",
                }
            ],
            "reason": "Concurrent edit by Session B",
        },
        headers=SPOC_HEADERS,
    )
    client.post(f"/api/candidates/{cand_id}/validate", headers=SPOC_HEADERS)

    # Session A attempts to approve using stale expected_version=1 -> MUST FAIL WITH 409 CONFLICT
    stale_appr = client.post(
        f"/api/candidates/{cand_id}/approve",
        json={"expected_version": 1, "review_note": "Stale approval from Session A"},
        headers=ADMIN_HEADERS,
    )
    assert stale_appr.status_code == 409, stale_appr.text
    assert "STALE_CANDIDATE_VERSION" in stale_appr.json()["detail"]


# ============================================================================
# TEST 18 – Graph Explorer Rendering (Admin Candidate, HITL & Main Trusted KG)
# ============================================================================
def test_18_graph_explorer_rendering(client):
    # 1. Admin Candidate Graph Explorer API
    cand_exp = client.get("/api/candidates/graph/explorer?include_trusted_context=true", headers=ADMIN_HEADERS)
    assert cand_exp.status_code == 200
    ce_data = cand_exp.json()
    assert ce_data["counts"]["total_nodes"] > 0
    assert ce_data["counts"]["total_edges"] > 0
    assert ce_data["integrated_preview"]["trusted_graph_readonly_verified"] is True

    # 2. Main Trusted Knowledge Graph Explorer API
    main_exp = client.get("/api/graph/explorer", headers=ADMIN_HEADERS)
    assert main_exp.status_code == 200
    me_data = main_exp.json()
    assert me_data["status"] == "READY"
    assert me_data["counts"]["total_nodes"] > 30
    assert me_data["counts"]["total_edges"] > 50

    # 3. Verify compiled frontend bundle includes CandidateGraphExplorer, ReviewDocument, and GraphExplorer
    bundle_js = (PROJECT / "frontend/dist/assets/index-G7ZawakF.js").read_text(encoding="utf-8")
    assert "./components/CandidateGraphExplorer" in bundle_js
    assert "./components/GraphExplorer" in bundle_js
    assert "./components/ReviewDocument" in bundle_js
    assert "INTEGRATED_PREVIEW = CANDIDATE_GRAPH + APPROVED_MAPPINGS + SCOPED_TRUSTED_GRAPH_CONTEXT" in bundle_js


# ============================================================================
# TEST 19 – Batch Ingestion and Idempotency
# ============================================================================
def test_19_batch_ingestion_and_idempotency(client):
    doc_a = _make_pharma_doc("TEST19_BATCH_A")
    doc_b = _make_pharma_doc("TEST19_BATCH_B")

    batch_res = client.post(
        "/api/ingestion/upload/batch",
        files=[
            ("files", ("batch19_a.txt", doc_a, "text/plain")),
            ("files", ("batch19_b.txt", doc_b, "text/plain")),
        ],
        headers=ADMIN_HEADERS,
    )
    assert batch_res.status_code == 200, batch_res.text
    b_data = batch_res.json()
    assert b_data["succeeded"] == 2
    uris_first = [d["document_uri"] for d in b_data["staged_documents"]]

    # Retry uploading the exact same batch -> idempotent reopening of pending reviews without duplicate candidates
    batch_retry = client.post(
        "/api/ingestion/upload/batch",
        files=[
            ("files", ("batch19_a.txt", doc_a, "text/plain")),
            ("files", ("batch19_b.txt", doc_b, "text/plain")),
        ],
        headers=ADMIN_HEADERS,
    )
    assert batch_retry.status_code == 200
    retry_docs = batch_retry.json()["staged_documents"]
    assert [d["document_uri"] for d in retry_docs] == uris_first
    assert all(d.get("duplicate_upload") is True for d in retry_docs)


# ============================================================================
# TEST 20 – Restart and Persistence
# ============================================================================
def test_20_restart_and_persistence(client):
    up = client.post(
        "/api/ingestion/upload",
        files={"file": ("test20_persistence.txt", _make_pharma_doc("TEST20_RESTART"), "text/plain")},
        headers=ADMIN_HEADERS,
    ).json()
    cand_id = up["candidate_id"]
    client.post(
        f"/api/candidates/{cand_id}/quarantine",
        json={"reason": "Hold across restart test", "triggering_issue": "RESTART_TEST"},
        headers=ADMIN_HEADERS,
    )

    # Re-instantiate CandidateGovernanceService from disk to simulate service restart
    restarted_gov = CandidateGovernanceService(coordinator=api_main.coordinator, assembler=api_main.assembler)
    reloaded_cand = restarted_gov.get_candidate(cand_id)
    assert reloaded_cand["candidate_lifecycle_state"] == "QUARANTINED"
    assert reloaded_cand["quarantine_record"]["reason"] == "Hold across restart test"

    # Active retrieval and SPARQL remain operational
    assert client.post("/api/search", json={"query": "Keytruda NSCLC", "top_k": 3}, headers=ADMIN_HEADERS).status_code == 200


# ============================================================================
# TEST 21 – Real Pharmaceutical Document End-to-End (20-Step Full Lifecycle)
# ============================================================================
def test_21_real_pharmaceutical_document_end_to_end(client):
    # Use a real pharmaceutical PDF format generated with legitimate clinical study content
    import pymupdf
    pdf_doc = pymupdf.open()
    page = pdf_doc.new_page()
    real_clinical_text = (
        "Market Access & Clinical Evidence Study — KEYNOTE-2026-EU\n"
        "Study Type: HCP Perception Survey\n"
        "Therapeutic Area: Oncology\n"
        "Geography: EU\n"
        "Executive Summary:\n"
        "Keytruda (Pembrolizumab) manufactured by Merck demonstrates durable overall survival in Non-Small Cell Lung Cancer (NSCLC).\n"
        "Comparator Opdivo (Nivolumab) was evaluated across European Union oncology centers.\n"
        "Unique End-to-End Verification Token: E2E_PHARMA_VERIFIED_2026_OMEGA.\n"
    )
    page.insert_textbox((50, 50, 550, 750), real_clinical_text, fontsize=11)
    pdf_tmp = WORK / "KEYNOTE_2026_EU_Real_Pharma_Study.pdf"
    pdf_doc.save(pdf_tmp)
    pdf_doc.close()
    pdf_bytes = pdf_tmp.read_bytes()

    # Steps 1-6: Upload, Metadata Registration, Parsing, Structural Chunking, NER/Rel Extraction, Candidate RDF
    up_res = client.post(
        "/api/ingestion/upload",
        files={"file": ("KEYNOTE_2026_EU_Real_Pharma_Study.pdf", pdf_bytes, "application/pdf")},
        headers=ADMIN_HEADERS,
    )
    assert up_res.status_code == 200, up_res.text
    staged = up_res.json()
    doc_uri = staged["document_uri"]
    cand_id = staged["candidate_id"]
    assert staged["format"] == "pdf"
    assert len(staged["governed_chunks"]) >= 1

    # Step 18 (pre-publication check): Verify unapproved evidence is isolated from production search
    pre_search = client.post("/api/search", json={"query": "E2E_PHARMA_VERIFIED_2026_OMEGA", "top_k": 5}, headers=ADMIN_HEADERS).json()
    assert all(c["doc_uri"] != doc_uri for c in pre_search["scored_chunks"])

    # Step 7 & 8: Interactive Admin graph exploration & Candidate vs Trusted comparison
    exp_res = client.get(f"/api/candidates/graph/explorer?candidate_id={cand_id}&include_trusted_context=true", headers=ADMIN_HEADERS).json()
    assert exp_res["counts"]["total_nodes"] >= 4
    assert exp_res["integrated_preview"]["candidate_additions_count"] >= 5
    assert exp_res["integrated_preview"]["trusted_graph_readonly_verified"] is True

    # Step 9: Integrated SHACL validation
    shacl_res = client.get(f"/api/candidates/{cand_id}/shacl", headers=ADMIN_HEADERS).json()
    assert shacl_res["shacl_report"]["conforms"] is True

    # Step 10 & 11: HITL Review & Semantic Edit
    edit_res = client.post(
        f"/api/candidates/{cand_id}/edit",
        json={
            "add_triples": [
                {
                    "subject": "http://watson.pharma.org/entity/drug/pembrolizumab",
                    "predicate": "http://watson.pharma.org/ontology/manufacturedBy",
                    "object": "http://watson.pharma.org/entity/manufacturer/merck",
                    "object_type": "uri",
                }
            ],
            "reason": "Confirmed Pembrolizumab manufacturer Merck in HITL review",
        },
        headers=ADMIN_HEADERS,
    )
    assert edit_res.status_code == 200
    assert edit_res.json()["candidate"]["candidate_lifecycle_state"] == "VALIDATION_PENDING"

    # Step 12: Revalidation
    reval_res = client.post(f"/api/candidates/{cand_id}/validate", headers=ADMIN_HEADERS)
    assert reval_res.status_code == 200
    assert reval_res.json()["shacl_report"]["conforms"] is True
    assert reval_res.json()["candidate"]["candidate_lifecycle_state"] == "UNDER_REVIEW"

    # Step 13: Approval
    appr_res = client.post(
        f"/api/candidates/{cand_id}/approve",
        json={"expected_version": 2, "review_note": "Approved E2E pharmaceutical study", "pii_override": True},
        headers=ADMIN_HEADERS,
    )
    assert appr_res.status_code == 200
    assert appr_res.json()["candidate"]["candidate_lifecycle_state"] == "APPROVED"

    # Step 14: Controlled Publication
    pub_res = client.post(
        f"/api/candidates/{cand_id}/publish",
        json={"transaction_id": "tx_test21_e2e"},
        headers=ADMIN_HEADERS,
    )
    assert pub_res.status_code == 200, pub_res.text
    assert pub_res.json()["status"] == "PUBLISHED"

    # Step 15 & 16: Trusted Graph & SPARQL Verification
    sparql_check = client.post(
        "/api/graph/sparql",
        json={
            "query": f"""
            PREFIX watson: <http://watson.pharma.org/ontology/>
            SELECT ?doc ?fn ?state WHERE {{
                ?doc watson:documentUri "{doc_uri}" ;
                     watson:sourceFilename ?fn ;
                     watson:lifecycleState ?state .
            }}
            """
        },
        headers=ADMIN_HEADERS,
    ).json()
    assert sparql_check["row_count"] >= 1
    assert sparql_check["results"][0]["state"] == "ACTIVE"

    # Step 17: Approved Evidence Retrieval Verification
    post_search = client.post("/api/search", json={"query": "Keytruda oncology evidence E2E_PHARMA_VERIFIED_2026_OMEGA", "top_k": 20}, headers=ADMIN_HEADERS).json()
    assert any(u.startswith(doc_uri) for u in post_search["allowed_chunk_uris"])
    assert any(c["doc_uri"] == doc_uri for c in post_search["scored_chunks"]) or doc_uri in json.dumps(post_search)

    # Step 19 & 20: Audit, Provenance & Retrieval Regression Verification
    audit_check = client.get("/api/audit/logs", headers=ADMIN_HEADERS).json()
    assert any(e.get("document_uri") == doc_uri and e.get("event_type") == "PUBLICATION_COMPLETED" for e in audit_check)
    chat_check = client.post("/api/chat", json={"query": "What is the clinical evidence for Keytruda in NSCLC?"}, headers=ADMIN_HEADERS)
    assert chat_check.status_code == 200
    assert chat_check.json()["answer_grounding_status"] == "GROUNDED"
