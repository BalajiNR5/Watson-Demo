"""
58 Critical Acceptance Scenarios for Enterprise Workflow Separation, Governed Document HITL,
Knowledge Engineering Studio & Controlled Knowledge Publication (Prompt 3 Section 19).
"""

from __future__ import annotations

import json
import os
import shutil
import sys
import tempfile
from pathlib import Path

import pytest

PROJECT = Path(__file__).resolve().parents[1]
WORK = Path(tempfile.mkdtemp(prefix="watson-58-workflow-separation-"))
import atexit
atexit.register(lambda: shutil.rmtree(WORK, ignore_errors=True))

for folder in ["data", "ontology", "queries", "outputs", "reports"]:
    src = PROJECT / folder
    if src.exists():
        shutil.copytree(src, WORK / folder)

(WORK / "dedup_store.json").write_text(json.dumps({"exact_hashes": {}, "title_registry": []}))
os.environ.update(
    WATSON_BASE_DIR=str(WORK),
    HF_HUB_OFFLINE="1",
    TRANSFORMERS_OFFLINE="1",
    WATSON_ALLOW_CLOUD="0",
)
if (PROJECT / "approved_models/all-MiniLM-L6-v2").is_dir():
    os.environ["WATSON_EMBEDDING_MODEL"] = str(PROJECT / "approved_models/all-MiniLM-L6-v2")

sys.path[:0] = [str(PROJECT), str(PROJECT / "backend")]
from office_policy import disable_tokenizer_downloads
disable_tokenizer_downloads()

from fastapi.testclient import TestClient
from app import main as api_main
from watson.semantics.candidate_governance_service import CandidateGovernanceService
from watson.shared.config import SEED_VOCABULARIES_FILE, PHARMA_KG_FILE, FAISS_INDEX_FILE

ADMIN_HEADERS = {"x-user-id": "D4"}
SPOC_HEADERS = {"x-user-id": "D2"}
VIEWER_HEADERS = {"x-user-id": "D3"}


@pytest.fixture(scope="module")
def client() -> TestClient:
    return TestClient(api_main.app)


def _sample_study(tag: str, include_pii: bool = False) -> bytes:
    pii_line = "Patient SSN: 123-45-6789 and email patient.doe@clinical.org.\n" if include_pii else ""
    text = (
        f"Title: {tag} Clinical & Market Access Evaluation\n"
        f"Study Type: HCP Perception Survey\n"
        f"Therapeutic Area: Oncology\n"
        f"Geography: US\n"
        f"Sensitivity: INTERNAL\n\n"
        f"{pii_line}"
        f"Keytruda (Pembrolizumab) manufactured by Merck treats Non-Small Cell Lung Cancer (NSCLC) in Oncology.\n"
        f"Clinicians report positive uptake and strong clinical efficacy in US oncology centers.\n"
    )
    return text.encode("utf-8")


# ===========================================================================
# 1. Preservation Tests (Scenarios 1–8)
# ===========================================================================

def test_01_existing_ingestion_works(client: TestClient):
    """Scenario 1: Existing single and batch document ingestion works."""
    res = client.post(
        "/api/ingestion/upload",
        files={"file": ("scen01_study.txt", _sample_study("SCEN01"), "text/plain")},
        headers=ADMIN_HEADERS,
    )
    assert res.status_code == 200
    data = res.json()
    assert data["lifecycle_state"] == "UNDER_REVIEW"
    assert "candidate_id" in data


def test_02_original_document_governance_actions_work(client: TestClient):
    """Scenario 2: Original document governance queue and review actions work."""
    res = client.get("/api/hitl/documents", headers=ADMIN_HEADERS)
    assert res.status_code == 200
    assert len(res.json()["documents"]) >= 1


def test_03_current_graph_first_functionality_remains_operational(client: TestClient):
    """Scenario 3: Graph-first candidate explorer and queue navigator remain operational."""
    client.post("/api/candidates/dev-fixtures/seed", headers=ADMIN_HEADERS)
    nav = client.get("/api/candidates/queue/navigator", headers=ADMIN_HEADERS)
    assert nav.status_code == 200
    exp = client.get("/api/candidates/graph/explorer?candidate_id=cand_demo_a_edit", headers=ADMIN_HEADERS)
    assert exp.status_code == 200
    assert len(exp.json()["nodes"]) >= 3


def test_04_existing_shacl_results_remain_accessible(client: TestClient):
    """Scenario 4: Existing SHACL validation report endpoint and results remain accessible."""
    res = client.get("/api/candidates/cand_demo_a_edit/shacl", headers=ADMIN_HEADERS)
    assert res.status_code == 200
    assert res.json()["shacl_report"]["conforms"] is True


def test_05_existing_revisions_and_audit_history_remain_intact(client: TestClient):
    """Scenario 5: Existing candidate revisions and tamper-evident audit history remain intact."""
    cand = client.get("/api/candidates/cand_demo_a_edit", headers=ADMIN_HEADERS).json()["candidate"]
    assert len(cand["revision_history"]) >= 1
    logs = client.get("/api/audit/logs?limit=50", headers=ADMIN_HEADERS)
    assert logs.status_code == 200
    assert len(logs.json()) >= 1


def test_06_existing_databricks_integration_works(client: TestClient):
    """Scenario 6: Existing Databricks Product MVM catalog and mappings work."""
    cat = client.get("/api/graph/catalog", headers=ADMIN_HEADERS)
    assert cat.status_code == 200
    assert len(cat.json()["products"]) == 15
    maps = client.get("/api/graph/mappings", headers=ADMIN_HEADERS)
    assert maps.status_code == 200


def test_07_existing_faiss_rag_graphrag_and_llm_behavior_remains_intact(client: TestClient):
    """Scenario 7: Existing FAISS, RAG, GraphRAG, and Copilot synthesis remain intact."""
    res = client.post(
        "/api/chat",
        json={"query": "What is the clinical evidence for Keytruda in NSCLC?"},
        headers=ADMIN_HEADERS,
    )
    assert res.status_code == 200
    body = res.json()
    assert body["pipeline_execution_status"] == "COMPLETED"
    assert body["answer_grounding_status"] == "GROUNDED"
    assert len(body["citations"]) > 0


def test_08_existing_trusted_kg_explorer_and_sparql_querying_work(client: TestClient):
    """Scenario 8: Existing Trusted KG Explorer and SPARQL Studio querying work."""
    kg = client.get("/api/graph/explorer", headers=ADMIN_HEADERS)
    assert kg.status_code == 200
    assert kg.json()["counts"]["total_nodes"] > 50

    sp = client.post(
        "/api/graph/sparql",
        json={"query": "SELECT ?s ?p ?o WHERE { ?s ?p ?o } LIMIT 10"},
        headers=ADMIN_HEADERS,
    )
    assert sp.status_code == 200
    assert sp.json()["row_count"] == 10


# ===========================================================================
# 2. Document Governance Tests (Scenarios 9–14)
# ===========================================================================

def test_09_critical_pii_prevents_document_approval_without_policy_clearance(client: TestClient):
    """Scenario 9: Critical PII prevents document approval without explicit pii_override clearance."""
    up = client.post(
        "/api/ingestion/upload",
        files={"file": ("scen09_pii.txt", _sample_study("SCEN09_PII", include_pii=True), "text/plain")},
        headers=ADMIN_HEADERS,
    ).json()
    doc_uri = up["document_uri"]
    assert up["has_critical_pii"] is True

    # Attempt document approval without pii_override -> must fail with 400
    blocked = client.post(
        f"/api/hitl/documents/{doc_uri}/decision",
        json={"decision": "APPROVE_DOCUMENT", "pii_override": False, "review_note": "No override"},
        headers=ADMIN_HEADERS,
    )
    assert blocked.status_code == 400
    assert "CRITICAL_PII_CLEARANCE_REQUIRED" in blocked.json()["detail"]


def test_10_redaction_and_approved_exceptions_respect_access_controls(client: TestClient):
    """Scenario 10: Redaction and approved PII exceptions record audit event and respect access controls."""
    docs = client.get("/api/hitl/documents?status_filter=PII_REVIEW_REQUIRED", headers=ADMIN_HEADERS).json()["documents"]
    pii_doc = next(d for d in docs if d["has_critical_pii"])
    doc_uri = pii_doc["document_uri"]

    appr = client.post(
        f"/api/hitl/documents/{doc_uri}/decision",
        json={
            "decision": "APPROVE_DOCUMENT",
            "pii_override": True,
            "sensitivity_level": "RESTRICTED",
            "review_note": "Audited critical PII override with RESTRICTED sensitivity",
        },
        headers=ADMIN_HEADERS,
    )
    assert appr.status_code == 200
    assert appr.json()["document"]["document_governance_state"] == "APPROVED"
    assert appr.json()["document"]["sensitivity_level"] == "RESTRICTED"


def test_11_exact_duplicate_behavior_respects_existing_policy(client: TestClient):
    """Scenario 11: Exact duplicate upload reopens existing review and REJECT_DUPLICATE disposition blocks approval."""
    payload = _sample_study("SCEN11_DUP")
    first = client.post(
        "/api/ingestion/upload",
        files={"file": ("scen11_dup.txt", payload, "text/plain")},
        headers=ADMIN_HEADERS,
    ).json()
    second = client.post(
        "/api/ingestion/upload",
        files={"file": ("scen11_dup.txt", payload, "text/plain")},
        headers=ADMIN_HEADERS,
    ).json()
    assert second["document_uri"] == first["document_uri"]
    assert second["duplicate_upload"] is True

    # Attempting to approve with REJECT_DUPLICATE disposition is blocked
    blk = client.post(
        f"/api/hitl/documents/{first['document_uri']}/decision",
        json={"decision": "APPROVE_DOCUMENT", "dedup_disposition": "REJECT_DUPLICATE"},
        headers=ADMIN_HEADERS,
    )
    assert blk.status_code == 400


def test_12_document_quarantine_blocks_publication_eligibility(client: TestClient):
    """Scenario 12: Document quarantine blocks publication eligibility even when candidate RDF is approved."""
    up = client.post(
        "/api/ingestion/upload",
        files={"file": ("scen12_doc_quar.txt", _sample_study("SCEN12_DOC_QUAR"), "text/plain")},
        headers=ADMIN_HEADERS,
    ).json()
    doc_uri = up["document_uri"]
    cand_id = up["candidate_id"]

    # Quarantine the source document in HITL Workbench
    q_res = client.post(
        f"/api/hitl/documents/{doc_uri}/decision",
        json={"decision": "QUARANTINE_DOCUMENT", "review_note": "Source protocol signature missing"},
        headers=ADMIN_HEADERS,
    )
    assert q_res.status_code == 200
    assert q_res.json()["document"]["document_governance_state"] == "QUARANTINED"

    # Semantically approve the candidate RDF in Knowledge Engineering Studio
    client.post(f"/api/candidates/{cand_id}/validate", headers=ADMIN_HEADERS)
    client.post(f"/api/candidates/{cand_id}/approve", json={}, headers=ADMIN_HEADERS)

    # Publication must be blocked because source document is QUARANTINED
    pub_res = client.post(f"/api/candidates/{cand_id}/publish", json={}, headers=ADMIN_HEADERS)
    assert pub_res.status_code == 400
    assert "Document Governance Track" in pub_res.json()["detail"]


def test_13_document_approval_does_not_automatically_approve_candidate_rdf(client: TestClient):
    """Scenario 13: Document approval in HITL Workbench does NOT automatically approve candidate RDF."""
    up = client.post(
        "/api/ingestion/upload",
        files={"file": ("scen13_indep.txt", _sample_study("SCEN13_INDEP"), "text/plain")},
        headers=ADMIN_HEADERS,
    ).json()
    doc_uri = up["document_uri"]
    cand_id = up["candidate_id"]

    res = client.post(
        f"/api/hitl/documents/{doc_uri}/decision",
        json={"decision": "APPROVE_DOCUMENT", "review_note": "Source document approved"},
        headers=ADMIN_HEADERS,
    )
    assert res.status_code == 200
    body = res.json()
    assert body["document"]["document_governance_state"] == "APPROVED"
    assert body["candidate"]["candidate_lifecycle_state"] != "APPROVED"
    assert body["candidate"]["publication_lifecycle_state"] != "PUBLISHED"


def test_14_document_rejection_prevents_related_candidate_publication(client: TestClient):
    """Scenario 14: Document rejection prevents related candidate publication."""
    up = client.post(
        "/api/ingestion/upload",
        files={"file": ("scen14_rej.txt", _sample_study("SCEN14_REJ"), "text/plain")},
        headers=ADMIN_HEADERS,
    ).json()
    doc_uri = up["document_uri"]
    cand_id = up["candidate_id"]

    # Semantically approve candidate first, then reject source document
    client.post(f"/api/candidates/{cand_id}/validate", headers=ADMIN_HEADERS)
    client.post(f"/api/candidates/{cand_id}/approve", json={}, headers=ADMIN_HEADERS)
    client.post(
        f"/api/hitl/documents/{doc_uri}/decision",
        json={"decision": "REJECT_DOCUMENT", "review_note": "Source study retracted"},
        headers=ADMIN_HEADERS,
    )

    pub_res = client.post(f"/api/candidates/{cand_id}/publish", json={}, headers=ADMIN_HEADERS)
    assert pub_res.status_code == 400


# ===========================================================================
# 3. Semantic Engineering Tests (Scenarios 15–24)
# ===========================================================================

def test_15_graph_node_selection_displays_exact_rdf_identity(client: TestClient):
    """Scenario 15: Graph node selection displays exact RDF URI, class, namespace, and mapping status."""
    client.post("/api/candidates/dev-fixtures/seed", headers=ADMIN_HEADERS)
    exp = client.get("/api/candidates/graph/explorer?candidate_id=cand_demo_a_edit", headers=ADMIN_HEADERS).json()
    node = next(n for n in exp["nodes"] if n["uri"] == "http://watson.pharma.org/entity/brand/keytruda")
    assert node["uri"] == "http://watson.pharma.org/entity/brand/keytruda"
    assert "Brand" in node["rdf_class"]
    assert node["namespace"].startswith("http://watson.pharma.org/")


def test_16_graph_edge_selection_displays_exact_subject_predicate_object(client: TestClient):
    """Scenario 16: Graph edge selection displays exact subject, predicate, and object."""
    exp = client.get("/api/candidates/graph/explorer?candidate_id=cand_demo_a_edit", headers=ADMIN_HEADERS).json()
    edge = exp["edges"][0]
    assert edge["source"].startswith("http://")
    assert edge["predicate"].startswith("http://")
    assert edge["target"].startswith("http://")


def test_17_semantic_edit_persists_changed_rdf(client: TestClient):
    """Scenario 17: Semantic edit persists changed RDF statement."""
    client.post("/api/candidates/dev-fixtures/seed", headers=ADMIN_HEADERS)
    res = client.post(
        "/api/candidates/cand_demo_a_edit/edit",
        json={
            "replace_triples": [
                {
                    "old_triple": {
                        "subject": "http://watson.pharma.org/entity/brand/keytruda",
                        "predicate": "http://watson.pharma.org/ontology/hasIndication",
                        "object": "Provisional Non-Small Cell Lung Cancer",
                    },
                    "new_triple": {
                        "subject": "http://watson.pharma.org/entity/brand/keytruda",
                        "predicate": "http://watson.pharma.org/ontology/hasIndication",
                        "object": "Curated Metastatic NSCLC",
                        "object_type": "literal",
                    },
                }
            ],
            "reason": "Curated indication literal",
        },
        headers=ADMIN_HEADERS,
    )
    assert res.status_code == 200
    triples = res.json()["candidate"]["triples"]
    assert any(t["object"] == "Curated Metastatic NSCLC" for t in triples)


def test_18_edit_increments_candidate_version_and_invalidates_prior_shacl(client: TestClient):
    """Scenario 18: Edit increments candidate version and marks prior SHACL report stale."""
    cand = client.get("/api/candidates/cand_demo_a_edit", headers=ADMIN_HEADERS).json()["candidate"]
    assert cand["graph_version"] == 2
    assert cand["candidate_lifecycle_state"] == "VALIDATION_PENDING"
    assert cand["shacl_report"]["is_stale"] is True


def test_19_entity_merge_preserves_canonical_relationships_and_provenance(client: TestClient):
    """Scenario 19: Entity merge preserves canonical relationships and provenance."""
    client.post("/api/candidates/dev-fixtures/seed", headers=ADMIN_HEADERS)
    res = client.post(
        "/api/candidates/cand_demo_b_merge/merge",
        json={
            "source_entity_uri": "http://watson.pharma.org/entity/brand/keytruda_dup",
            "target_entity_uri": "http://watson.pharma.org/entity/brand/keytruda",
            "target_canonical_name": "Keytruda",
            "reason": "Reconciled duplicate brand mention",
        },
        headers=ADMIN_HEADERS,
    )
    assert res.status_code == 200
    cand = res.json()["candidate"]
    uris = {e["uri"] for e in cand["entities"]}
    assert "http://watson.pharma.org/entity/brand/keytruda_dup" not in uris
    assert "http://watson.pharma.org/entity/brand/keytruda" in uris


def test_20_shacl_violation_navigation_highlights_correct_resource(client: TestClient):
    """Scenario 20: SHACL violation issue carries exact focus_node URI for graph highlighting."""
    client.post("/api/candidates/dev-fixtures/seed", headers=ADMIN_HEADERS)
    # Add a conflicting second active substance (isBrandOf nivolumab) on Keytruda to trigger SHACL BrandShape maxCount=1 violation
    client.post(
        "/api/candidates/cand_demo_a_edit/edit",
        json={
            "add_triples": [
                {
                    "subject": "http://watson.pharma.org/entity/brand/keytruda",
                    "predicate": "http://watson.pharma.org/ontology/isBrandOf",
                    "object": "http://watson.pharma.org/entity/drug/nivolumab",
                    "object_type": "uri",
                }
            ],
            "reason": "Test SHACL violation focus_node",
        },
        headers=ADMIN_HEADERS,
    )
    val = client.post("/api/candidates/cand_demo_a_edit/validate", headers=ADMIN_HEADERS).json()["candidate"]
    shacl_issues = [i for i in val["issues"] if i["issue_type"] == "SHACL_VIOLATION"]
    assert len(shacl_issues) >= 1
    assert shacl_issues[0]["focus_node"] == "http://watson.pharma.org/entity/brand/keytruda"


def test_21_stale_validation_blocks_semantic_approval(client: TestClient):
    """Scenario 21: Stale validation blocks semantic approval."""
    client.post("/api/candidates/dev-fixtures/seed", headers=ADMIN_HEADERS)
    client.post(
        "/api/candidates/cand_demo_a_edit/edit",
        json={
            "add_triples": [
                {
                    "subject": "http://watson.pharma.org/entity/brand/keytruda",
                    "predicate": "http://watson.pharma.org/ontology/hasNote",
                    "object": "Stale test",
                }
            ]
        },
        headers=ADMIN_HEADERS,
    )
    appr = client.post("/api/candidates/cand_demo_a_edit/approve", json={}, headers=ADMIN_HEADERS)
    assert appr.status_code == 400


def test_22_conforming_shacl_with_missing_semantic_evidence_does_not_imply_complete_approval(client: TestClient):
    """Scenario 22: Conforming SHACL with missing semantic evidence blocks semantic approval."""
    client.post("/api/candidates/dev-fixtures/seed", headers=ADMIN_HEADERS)
    # cand_demo_c_quarantine has conforming SHACL triples but missing_evidence_flag=True / AWAITING_EVIDENCE
    appr = client.post("/api/candidates/cand_demo_c_quarantine/approve", json={}, headers=ADMIN_HEADERS)
    assert appr.status_code == 400


def test_23_trusted_rdf_remains_read_only(client: TestClient):
    """Scenario 23: Trusted RDF resource cannot be mutated directly as duplicate source."""
    res = client.post(
        "/api/candidates/cand_demo_a_edit/merge",
        json={
            "source_entity_uri": "http://watson.pharma.org/entity/manufacturer/merck",
            "target_entity_uri": "http://watson.pharma.org/entity/brand/keytruda",
        },
        headers=ADMIN_HEADERS,
    )
    assert res.status_code == 400
    assert "TRUSTED_RESOURCE_IMMUTABLE" in res.json()["detail"]


def test_24_concurrent_stale_candidate_changes_are_rejected_safely(client: TestClient):
    """Scenario 24: Concurrent stale candidate edits, merges, and approvals return HTTP 409."""
    res = client.post(
        "/api/candidates/cand_demo_a_edit/edit",
        json={"add_triples": [], "expected_version": 999},
        headers=ADMIN_HEADERS,
    )
    assert res.status_code == 409
    assert "STALE_CANDIDATE_VERSION" in res.json()["detail"]


# ===========================================================================
# 4. Cross-Workspace Lifecycle Tests (Scenarios 25–31)
# ===========================================================================

def test_25_document_approval_and_semantic_approval_remain_independent(client: TestClient):
    """Scenario 25: Document approval and semantic approval remain independent."""
    client.post("/api/candidates/dev-fixtures/seed", headers=ADMIN_HEADERS)
    doc_res = client.post(
        "/api/hitl/documents/watson:Doc_demo_edit_a/decision",
        json={"decision": "APPROVE_DOCUMENT", "review_note": "Doc approved first"},
        headers=ADMIN_HEADERS,
    ).json()
    assert doc_res["document"]["document_governance_state"] == "APPROVED"
    assert doc_res["candidate"]["candidate_lifecycle_state"] == "UNDER_REVIEW"


def test_26_approved_source_with_invalid_rdf_remains_unpublishable(client: TestClient):
    """Scenario 26: An approved source document with invalid RDF (SHACL violation) remains unpublishable."""
    client.post(
        "/api/candidates/cand_demo_a_edit/edit",
        json={
            "add_triples": [
                {
                    "subject": "http://watson.pharma.org/entity/brand/keytruda",
                    "predicate": "http://watson.pharma.org/ontology/isBrandOf",
                    "object": "http://watson.pharma.org/entity/drug/nivolumab",
                    "object_type": "uri",
                }
            ]
        },
        headers=ADMIN_HEADERS,
    )
    client.post("/api/candidates/cand_demo_a_edit/validate", headers=ADMIN_HEADERS)
    pub = client.post("/api/candidates/cand_demo_a_edit/publish", json={}, headers=ADMIN_HEADERS)
    assert pub.status_code == 400


def test_27_conforming_candidate_with_quarantined_source_remains_unpublishable(client: TestClient):
    """Scenario 27: A SHACL-conforming, semantically approved candidate with quarantined source remains unpublishable."""
    client.post("/api/candidates/dev-fixtures/seed", headers=ADMIN_HEADERS)
    client.post("/api/candidates/cand_demo_d_publish/approve", json={}, headers=ADMIN_HEADERS)
    client.post(
        "/api/hitl/documents/watson:Doc_demo_publish_d/decision",
        json={"decision": "QUARANTINE_DOCUMENT", "review_note": "Source hold"},
        headers=ADMIN_HEADERS,
    )
    tr = client.get("/api/publications/cand_demo_d_publish/readiness", headers=ADMIN_HEADERS).json()
    assert tr["derived_outcome"] == "Release Blocked"
    assert tr["can_stage"] is False
    assert tr["can_activate"] is False

    pub = client.post("/api/candidates/cand_demo_d_publish/publish", json={}, headers=ADMIN_HEADERS)
    assert pub.status_code == 400


def test_28_correct_ids_and_versions_propagate_across_navigation(client: TestClient):
    """Scenario 28: Exact document_uri, candidate_id, and graph_version propagate across HITL, Studio, and Publication APIs."""
    client.post("/api/candidates/dev-fixtures/seed", headers=ADMIN_HEADERS)
    hitl_doc = client.get("/api/hitl/documents/watson:Doc_demo_publish_d", headers=ADMIN_HEADERS).json()["document"]
    studio_cand = client.get(f"/api/candidates/{hitl_doc['candidate_id']}", headers=ADMIN_HEADERS).json()["candidate"]
    pub_ready = client.get(f"/api/publications/{hitl_doc['candidate_id']}/readiness", headers=ADMIN_HEADERS).json()

    assert hitl_doc["document_uri"] == studio_cand["document_uri"] == pub_ready["document_uri"]
    assert hitl_doc["candidate_id"] == studio_cand["candidate_id"] == pub_ready["candidate_id"]
    assert hitl_doc["graph_version"] == studio_cand["graph_version"] == pub_ready["graph_version"]


def test_29_audit_history_is_consistent_across_all_workspaces(client: TestClient):
    """Scenario 29: Audit history is consistent across Document HITL, Knowledge Engineering Studio, and Governance & Audit."""
    logs = client.get("/api/audit/logs?limit=200", headers=ADMIN_HEADERS).json()
    doc_events = [l for l in logs if l.get("document_uri") == "watson:Doc_demo_publish_d"]
    assert len(doc_events) >= 1


def test_30_approval_state_persists_after_refresh_or_restart(client: TestClient):
    """Scenario 30: Document approval and semantic approval states persist across service restart."""
    client.post(
        "/api/hitl/documents/watson:Doc_demo_publish_d/decision",
        json={"decision": "APPROVE_DOCUMENT", "review_note": "Cleared for restart test"},
        headers=ADMIN_HEADERS,
    )
    client.post("/api/candidates/cand_demo_d_publish/approve", json={}, headers=ADMIN_HEADERS)

    reloaded_svc = CandidateGovernanceService(coordinator=api_main.coordinator, assembler=api_main.assembler)
    cand = reloaded_svc.get_candidate("cand:demo_publish_d")
    assert cand["document_governance_state"] == "APPROVED"
    assert cand["candidate_lifecycle_state"] == "APPROVED"


def test_31_publication_requires_all_applicable_gates(client: TestClient):
    """Scenario 31: Publication requires Document Governance Track AND Semantic Governance Track."""
    tr = client.get("/api/publications/cand_demo_d_publish/readiness", headers=ADMIN_HEADERS).json()
    assert tr["tracks"]["document_governance"]["track_passed"] is True
    assert tr["tracks"]["semantic_governance"]["track_passed"] is True
    assert tr["can_stage"] is True


# ===========================================================================
# 5. Publication Tests (Scenarios 32–39)
# ===========================================================================

def test_32_rdf_and_faiss_are_staged_consistently(client: TestClient):
    """Scenario 32: Stage release creates a consistent release manifest with RDF triples and FAISS chunk counts."""
    stage_res = client.post("/api/candidates/cand_demo_d_publish/stage-release", json={}, headers=ADMIN_HEADERS)
    assert stage_res.status_code == 200
    manifest = stage_res.json()["release_manifest"]
    assert manifest["staged_rdf_triples_count"] >= 5
    assert manifest["staged_faiss_chunks_count"] >= 1
    assert manifest["production_visibility"] == "ISOLATED_STAGED_ONLY"

    ver_res = client.post("/api/candidates/cand_demo_d_publish/verify-release", headers=ADMIN_HEADERS)
    assert ver_res.status_code == 200
    assert ver_res.json()["status"] == "READY_TO_ACTIVATE"


def test_33_failed_staging_does_not_create_production_visibility(client: TestClient):
    """Scenario 33: Failed staging does not modify trusted RDF or FAISS production state."""
    client.post("/api/candidates/dev-fixtures/seed", headers=ADMIN_HEADERS)
    client.post(
        "/api/hitl/documents/watson:Doc_demo_edit_a/decision",
        json={"decision": "APPROVE_DOCUMENT"},
        headers=ADMIN_HEADERS,
    )
    client.post("/api/candidates/cand_demo_a_edit/approve", json={}, headers=ADMIN_HEADERS)

    before_ver = client.get("/api/governance/overview", headers=ADMIN_HEADERS).json()["metrics"]["trusted_graph_version"]
    fail_stage = client.post(
        "/api/candidates/cand_demo_a_edit/stage-release",
        json={"simulate_staging_failure": True},
        headers=ADMIN_HEADERS,
    )
    assert fail_stage.status_code == 400
    after_ver = client.get("/api/governance/overview", headers=ADMIN_HEADERS).json()["metrics"]["trusted_graph_version"]
    assert after_ver == before_ver


def test_34_activation_updates_actual_trusted_release(client: TestClient):
    """Scenario 34: Activating publication promotes candidate RDF and FAISS chunks into production."""
    client.post("/api/candidates/dev-fixtures/seed", headers=ADMIN_HEADERS)
    client.post(
        "/api/hitl/documents/watson:Doc_demo_publish_d/decision",
        json={"decision": "APPROVE_DOCUMENT"},
        headers=ADMIN_HEADERS,
    )
    client.post("/api/candidates/cand_demo_d_publish/approve", json={}, headers=ADMIN_HEADERS)
    client.post("/api/candidates/cand_demo_d_publish/stage-release", json={}, headers=ADMIN_HEADERS)
    client.post("/api/candidates/cand_demo_d_publish/verify-release", headers=ADMIN_HEADERS)

    pub = client.post(
        "/api/candidates/cand_demo_d_publish/publish",
        json={"transaction_id": "tx_scen_34"},
        headers=ADMIN_HEADERS,
    )
    assert pub.status_code == 200
    assert pub.json()["status"] == "PUBLISHED"


def test_35_published_rdf_is_available_in_authorized_sparql_queries(client: TestClient):
    """Scenario 35: Published RDF is immediately queryable in SPARQL Studio."""
    sp = client.post(
        "/api/graph/sparql",
        json={
            "query": "PREFIX watson: <http://watson.pharma.org/ontology/> SELECT ?s WHERE { ?s a watson:Brand } LIMIT 10"
        },
        headers=ADMIN_HEADERS,
    )
    assert sp.status_code == 200
    assert sp.json()["row_count"] >= 1


def test_36_published_evidence_is_available_in_authorized_research_copilot_queries(client: TestClient):
    """Scenario 36: Published evidence is discoverable in authorized Research Copilot queries."""
    chat = client.post(
        "/api/chat",
        json={"query": "What is the clinical evidence for Keytruda in NSCLC?"},
        headers=ADMIN_HEADERS,
    )
    assert chat.status_code == 200
    assert "Keytruda" in chat.json()["answer"]


def test_37_unapproved_evidence_remains_excluded(client: TestClient):
    """Scenario 37: Unapproved staged candidate evidence does not leak into production SPARQL or Copilot."""
    up = client.post(
        "/api/ingestion/upload",
        files={"file": ("scen37_unapproved.txt", _sample_study("UNAPPROVED_SECRET_MARKER_XYZ987"), "text/plain")},
        headers=ADMIN_HEADERS,
    ).json()
    assert up["lifecycle_state"] == "UNDER_REVIEW"

    sp = client.post(
        "/api/graph/sparql",
        json={"query": 'SELECT ?s ?p ?o WHERE { ?s ?p ?o FILTER(CONTAINS(STR(?o), "UNAPPROVED_SECRET_MARKER_XYZ987")) }'},
        headers=ADMIN_HEADERS,
    )
    assert sp.status_code == 200
    assert sp.json()["row_count"] == 0


def test_38_failed_publication_supports_safe_recovery(client: TestClient):
    """Scenario 38: Failed publication preserves active release and supports safe recovery retry."""
    client.post("/api/candidates/dev-fixtures/seed", headers=ADMIN_HEADERS)
    client.post(
        "/api/hitl/documents/watson:Doc_demo_edit_a/decision",
        json={"decision": "APPROVE_DOCUMENT"},
        headers=ADMIN_HEADERS,
    )
    client.post("/api/candidates/cand_demo_a_edit/approve", json={}, headers=ADMIN_HEADERS)

    fail = client.post(
        "/api/candidates/cand_demo_a_edit/publish",
        json={"transaction_id": "tx_scen_38_fail", "simulate_failure": True},
        headers=ADMIN_HEADERS,
    )
    assert fail.status_code == 400
    tr = client.get("/api/publications/cand_demo_a_edit/readiness", headers=ADMIN_HEADERS).json()
    assert tr["derived_outcome"] == "Recovery Required"

    # Recover publication cleanly
    rec = client.post(
        "/api/candidates/cand_demo_a_edit/publish",
        json={"transaction_id": "tx_scen_38_recover", "simulate_failure": False},
        headers=ADMIN_HEADERS,
    )
    assert rec.status_code == 200
    assert rec.json()["status"] == "PUBLISHED"


def test_39_revoked_or_superseded_releases_follow_withdrawal_rules(client: TestClient):
    """Scenario 39: Published release can be withdrawn or superseded via controlled withdrawal endpoint."""
    w_res = client.post(
        "/api/publications/tx_scen_38_recover/withdraw",
        json={"reason": "Superseded by updated clinical dossier", "mode": "SUPERSEDED"},
        headers=ADMIN_HEADERS,
    )
    assert w_res.status_code == 200
    assert w_res.json()["status"] == "SUPERSEDED"


# ===========================================================================
# 6. Authorization Tests (Scenarios 40–47)
# ===========================================================================

def test_40_admin_can_access_authorized_operational_workspaces(client: TestClient):
    """Scenario 40: Admin can access Ingestion Console, HITL Workbench, Knowledge Engineering Studio, and Knowledge Publication APIs."""
    assert client.get("/api/ingestion/console", headers=ADMIN_HEADERS).status_code == 200
    assert client.get("/api/hitl/documents", headers=ADMIN_HEADERS).status_code == 200
    assert client.get("/api/candidates/queue/navigator", headers=ADMIN_HEADERS).status_code == 200
    assert client.get("/api/publications/queue", headers=ADMIN_HEADERS).status_code == 200


def test_41_viewer_cannot_open_ingestion_console(client: TestClient):
    """Scenario 41: Viewer cannot access Ingestion Console (HTTP 403)."""
    assert client.get("/api/ingestion/console", headers=VIEWER_HEADERS).status_code == 403


def test_42_viewer_cannot_open_hitl_workbench(client: TestClient):
    """Scenario 42: Viewer cannot access HITL Workbench APIs (HTTP 403)."""
    assert client.get("/api/hitl/documents", headers=VIEWER_HEADERS).status_code == 403
    assert client.post("/api/hitl/documents/watson:Doc_001/decision", json={"decision": "APPROVE_DOCUMENT"}, headers=VIEWER_HEADERS).status_code == 403


def test_43_viewer_cannot_open_knowledge_engineering_studio(client: TestClient):
    """Scenario 43: Viewer cannot access Knowledge Engineering Studio APIs (HTTP 403)."""
    assert client.get("/api/candidates/queue/navigator", headers=VIEWER_HEADERS).status_code == 403
    assert client.get("/api/candidates/graph/explorer", headers=VIEWER_HEADERS).status_code == 403


def test_44_viewer_cannot_open_knowledge_publication(client: TestClient):
    """Scenario 44: Viewer cannot access Knowledge Publication APIs (HTTP 403)."""
    assert client.get("/api/publications/queue", headers=VIEWER_HEADERS).status_code == 403
    assert client.post("/api/candidates/cand_demo_d_publish/stage-release", json={}, headers=VIEWER_HEADERS).status_code == 403


def test_45_direct_unauthorized_api_requests_return_401_or_403(client: TestClient):
    """Scenario 45: Direct unauthorized API requests from Analyst, Commercial, External, and unknown users return 401/403."""
    for uid in ("U_ANALYST", "U_COMMERCIAL", "U_EXTERNAL", "D3"):
        h = {"x-user-id": uid}
        assert client.get("/api/hitl/documents", headers=h).status_code == 403
        assert client.get("/api/publications/queue", headers=h).status_code == 403
    assert client.get("/api/hitl/documents", headers={"x-user-id": "UNKNOWN_USER_999"}).status_code == 401


def test_46_persona_switching_immediately_updates_access(client: TestClient):
    """Scenario 46: Switching persona immediately updates current_user role and permissions."""
    sw_viewer = client.post("/api/auth/switch", json={"user_id": "D3"}).json()
    assert sw_viewer["current_user"]["role"] == "VIEWER"
    assert sw_viewer["current_user"]["can_ingest"] is False

    sw_admin = client.post("/api/auth/switch", json={"user_id": "D4"}).json()
    assert sw_admin["current_user"]["role"] == "ADMIN"
    assert sw_admin["current_user"]["can_ingest"] is True
    assert "knowledge:publish" in sw_admin["current_user"]["permissions"]


def test_47_existing_abac_behavior_remains_intact_in_research_and_exploration(client: TestClient):
    """Scenario 47: Viewer ABAC pre-filter restricts CONFIDENTIAL/RESTRICTED chunks while preserving research access."""
    v_search = client.post("/api/search", json={"query": "Spinraza SMA Japan", "top_k": 5}, headers=VIEWER_HEADERS).json()
    a_search = client.post("/api/search", json={"query": "Spinraza SMA Japan", "top_k": 5}, headers=ADMIN_HEADERS).json()
    assert len(v_search["allowed_chunk_uris"]) < len(a_search["allowed_chunk_uris"])


# ===========================================================================
# 7. Q10 Migration Tests (Scenarios 48–51)
# ===========================================================================

def test_48_existing_verification_results_remain_accessible_inside_governance_and_audit(client: TestClient):
    """Scenario 48: Q10 Cross-Layer Verification results are accessible via /api/governance/cross-layer-verification."""
    res = client.get("/api/governance/cross-layer-verification", headers=ADMIN_HEADERS)
    assert res.status_code == 200
    body = res.json()
    assert body["status"] == "PASS"
    assert "executed_at" in body
    assert "verification_scope" in body
    assert body["evaluated_principal"]["user_id"] == "D4"


def test_49_verification_numbers_originate_from_backend_data(client: TestClient):
    """Scenario 49: Q10 verification numbers originate from actual RDF graph and telemetry/audit stores."""
    body = client.get("/api/governance/cross-layer-verification", headers=ADMIN_HEADERS).json()
    assert body["restricted_chunks_in_graph"] >= 1
    assert body["restricted_documents_count"] >= 1
    assert body["cross_layer_join_status"] == "VERIFIED"


def test_50_restricted_documents_and_chunks_remain_protected(client: TestClient):
    """Scenario 50: Restricted chunk samples and telemetry details are redacted for non-admin Viewer persona."""
    viewer_q10 = client.get("/api/governance/cross-layer-verification", headers=VIEWER_HEADERS).json()
    assert viewer_q10["confidential_details_redacted"] is True
    assert viewer_q10["sample_restricted_chunks"] == []


def test_51_old_q10_route_does_not_become_unauthorized_disclosure_path(client: TestClient):
    """Scenario 51: Legacy /api/telemetry/q10-audit route also enforces confidential detail redaction for Viewer."""
    legacy_q10 = client.get("/api/telemetry/q10-audit", headers=VIEWER_HEADERS).json()
    assert legacy_q10["confidential_details_redacted"] is True
    assert legacy_q10["sample_restricted_chunks"] == []


# ===========================================================================
# 8. UI & Architecture Structure Tests (Scenarios 52–58)
# ===========================================================================

def test_52_professional_svg_navigation_replaces_emoji_icons():
    """Scenario 52: Sidebar navigation uses monochrome SVG icons (NavSvgIcon) with no emoji in sidebar buttons."""
    app_tsx = (PROJECT / "frontend/src/App.tsx").read_text(encoding="utf-8")
    assert "NavSvgIcon" in app_tsx
    nav_start = app_tsx.index('data-testid="enterprise-sidebar-nav"')
    nav_end = app_tsx.index("</nav>", nav_start)
    nav_block = app_tsx[nav_start:nav_end]
    for emoji in ("💬", "📥", "⚖️", "📚", "🕸️", "🪐", "🔍", "🛡️", "📊"):
        assert emoji not in nav_block, f"Found emoji {emoji} in sidebar navigation"


def test_53_no_feature_is_lost_because_of_navigation_refactoring():
    """Scenario 53: Sidebar includes all required workspaces in exact order and removes System Health & Q10 from primary nav."""
    app_tsx = (PROJECT / "frontend/src/App.tsx").read_text(encoding="utf-8")
    nav_start = app_tsx.index('data-testid="enterprise-sidebar-nav"')
    nav_end = app_tsx.index("</nav>", nav_start)
    nav_block = app_tsx[nav_start:nav_end]

    required_order = [
        "Research Copilot",
        "Ingestion Console",
        "HITL Workbench",
        "Knowledge Engineering Studio",
        "Knowledge Publication",
        "Document Library",
        "KG Explorer",
        "Knowledge Spaces",
        "SPARQL Studio",
        "Governance &amp; Audit",
    ]
    positions = [nav_block.index(label) for label in required_order]
    assert positions == sorted(positions), "Sidebar items are not in the required enterprise lifecycle order"
    assert "System Health &amp; Q10" not in nav_block


def test_54_no_redundant_approval_buttons_remain():
    """Scenario 54: HITL Workbench has no 'Approve & Activate' shortcut; Knowledge Engineering Studio has no document approval button."""
    rev_tsx = (PROJECT / "frontend/src/components/ReviewDocument.tsx").read_text(encoding="utf-8")
    kes_tsx = (PROJECT / "frontend/src/components/KnowledgeEngineeringStudio.tsx").read_text(encoding="utf-8")
    assert "Approve & Activate" not in rev_tsx
    assert "Approve &amp; Activate" not in rev_tsx
    assert "Approve & Activate" not in kes_tsx
    assert "Approve Semantic Candidate" in kes_tsx


def test_55_graph_canvas_supports_semantic_first_focus():
    """Scenario 55: CandidateGraphExplorer implements Semantic-First Focus default mode and Complete RDF Graph toggle."""
    cg_tsx = (PROJECT / "frontend/src/components/CandidateGraphExplorer.tsx").read_text(encoding="utf-8")
    assert "semanticFirstMode" in cg_tsx
    assert "Semantic-First Focus" in cg_tsx
    assert "Complete RDF Graph (Provenance Links)" in cg_tsx


def test_56_no_fake_success_messages_or_decorative_readiness_states():
    """Scenario 56: KnowledgePublicationWorkspace uses backend-derived outcomes instead of simplistic checklist scores."""
    pub_tsx = (PROJECT / "frontend/src/components/KnowledgePublicationWorkspace.tsx").read_text(encoding="utf-8")
    assert "derived_outcome" in pub_tsx
    assert "1. Document Governance" in pub_tsx
    assert "2. Semantic Governance" in pub_tsx
    assert "3. Release Integrity" in pub_tsx


def test_57_error_loading_blocked_and_empty_states_are_meaningful():
    """Scenario 57: Workspaces render explicit role='alert' error banners, blocker callouts, and Access Denied screens."""
    app_tsx = (PROJECT / "frontend/src/App.tsx").read_text(encoding="utf-8")
    pub_tsx = (PROJECT / "frontend/src/components/KnowledgePublicationWorkspace.tsx").read_text(encoding="utf-8")
    assert "Access Denied — Administrator Privileges Required (HTTP 403)" in app_tsx
    assert "publication-blocker-callout" in pub_tsx


def test_58_compiled_production_bundle_contains_all_five_lifecycle_workspaces(client: TestClient):
    """Scenario 58: Compiled production bundle includes all 5 lifecycle stages and serves cleanly over HTTP."""
    bundle_js = (PROJECT / "frontend/dist/assets/index-G7ZawakF.js").read_text(encoding="utf-8")
    for mod_id in (
        "./components/ReviewDocument",
        "./components/KnowledgeEngineeringStudio",
        "./components/KnowledgePublicationWorkspace",
        "./components/CandidateGraphExplorer",
        "./components/GraphExplorer",
    ):
        assert mod_id in bundle_js, f"Missing module {mod_id} in compiled production bundle"

    res = client.get("/")
    assert res.status_code == 200
    assert "index-G7ZawakF.js" in res.text
