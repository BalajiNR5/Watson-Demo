"""
36 Mandatory Functional & Regression Acceptance Tests for the Unified Graph-First
HITL Knowledge Engineering & Governance Workbench (Prompt 2 Section 17).
"""

import json
import os
import shutil
import tempfile
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

PROJECT_ROOT = Path(__file__).resolve().parents[1]

# Isolate runtime state in a temporary directory so tests are deterministic and repeatable
_TEMP_BASE = Path(tempfile.mkdtemp(prefix="watson_36_workbench_"))
for subdir in ("data", "ontology", "faiss_index", "storage"):
    src = PROJECT_ROOT / subdir
    dst = _TEMP_BASE / subdir
    if src.exists():
        shutil.copytree(src, dst, dirs_exist_ok=True)

os.environ["WATSON_BASE_DIR"] = str(_TEMP_BASE)

from app.main import app, candidate_governance  # noqa: E402


@pytest.fixture(scope="module")
def client() -> TestClient:
    return TestClient(app)


@pytest.fixture()
def admin_headers() -> dict:
    return {"x-user-id": "D4"}


@pytest.fixture()
def spoc_headers() -> dict:
    return {"x-user-id": "U_SPOC"}


# ===========================================================================
# Workbench & Navigation Tests (Tests 1–4)
# ===========================================================================

def test_01_unified_hitl_workbench_renders(client: TestClient, admin_headers: dict):
    """Test 1 — Unified HITL Workbench Renders: Queue/Issues Navigator, Graph Canvas, Contextual Inspector, Revision Timeline."""
    review_tsx = (PROJECT_ROOT / "frontend/src/components/ReviewDocument.tsx").read_text(encoding="utf-8")
    bundle_js = (PROJECT_ROOT / "frontend/dist/assets/index-G7ZawakF.js").read_text(encoding="utf-8")

    for testid in (
        "hitl-workbench-root",
        "derived-lifecycle-stepper",
        "region-c-navigator",
        "region-d-graph",
        "region-e-inspector",
        "region-f-timeline",
    ):
        assert testid in review_tsx, f"Missing {testid} in ReviewDocument.tsx"
        assert testid in bundle_js, f"Missing {testid} in compiled production bundle"

    res = client.get("/api/candidates/queue/navigator", headers=admin_headers)
    assert res.status_code == 200
    payload = res.json()
    assert payload["status"] == "SUCCESS"
    assert len(payload["candidates"]) >= 5


def test_02_review_queue_filtering(client: TestClient, admin_headers: dict):
    """Test 2 — Review Queue Filtering across all 11 categories."""
    client.post("/api/candidates/dev-fixtures/seed", headers=admin_headers)
    res = client.get("/api/candidates/queue/navigator", headers=admin_headers)
    assert res.status_code == 200
    counts = res.json()["counts"]

    expected_categories = [
        "ALL",
        "PENDING_REVIEW",
        "SHACL_VIOLATIONS",
        "SEMANTIC_CONFLICTS",
        "DUPLICATE_ENTITIES",
        "UNRESOLVED_MAPPINGS",
        "MISSING_EVIDENCE",
        "QUARANTINED",
        "AWAITING_EVIDENCE",
        "READY_FOR_APPROVAL",
        "APPROVED_AWAITING_PUBLICATION",
        "PUBLISHED",
    ]
    for cat in expected_categories:
        assert cat in counts, f"Missing queue category count: {cat}"
    assert counts["ALL"] >= 9
    assert counts["DUPLICATE_ENTITIES"] >= 1
    assert counts["QUARANTINED"] >= 1
    assert counts["READY_FOR_APPROVAL"] >= 1


def test_03_issue_selection_focuses_graph_element(client: TestClient, admin_headers: dict):
    """Test 3 — Issue Selection Focuses Graph Element: each synthesized issue carries focus_node/result_path mapped to graph nodes."""
    client.post("/api/candidates/dev-fixtures/seed", headers=admin_headers)
    res = client.get("/api/candidates/cand_demo_b_merge", headers=admin_headers)
    assert res.status_code == 200
    cand = res.json()["candidate"]
    issues = cand["issues"]
    dup_issues = [i for i in issues if i["issue_type"] == "POTENTIAL_DUPLICATE"]
    assert len(dup_issues) >= 1
    assert dup_issues[0]["focus_node"] == "http://watson.pharma.org/entity/brand/keytruda_dup"
    assert dup_issues[0]["suggested_target_uri"] == "http://watson.pharma.org/entity/brand/keytruda"

    graph_res = client.get(
        "/api/candidates/graph/explorer?candidate_id=cand_demo_b_merge",
        headers=admin_headers,
    )
    assert graph_res.status_code == 200
    node_uris = {n["uri"] for n in graph_res.json()["nodes"]}
    assert dup_issues[0]["focus_node"] in node_uris


def test_04_node_selection_opens_node_inspector(client: TestClient, admin_headers: dict):
    """Test 4 — Node Selection Opens Node Inspector: explorer nodes expose URI, class, origin, mapping status, SHACL status, properties, and evidence."""
    res = client.get(
        "/api/candidates/graph/explorer?candidate_id=cand_demo_a_edit",
        headers=admin_headers,
    )
    assert res.status_code == 200
    nodes = res.json()["nodes"]
    keytruda_node = next(n for n in nodes if n["uri"] == "http://watson.pharma.org/entity/brand/keytruda")
    assert keytruda_node["rdf_class"] in ("watson:Brand", "BrandDrug")
    assert keytruda_node["mapping_status"] in ("EXACT", "MATCHED_CANONICAL")
    assert keytruda_node["validation_status"] in ("CONFORMING", "VIOLATION", "STALE")
    assert isinstance(keytruda_node["evidence_snippets"], list)
    assert len(keytruda_node["evidence_snippets"]) >= 1


# ===========================================================================
# Graph-First Edit & Revalidation Tests (Tests 5–11)
# ===========================================================================

def test_05_edit_node_label_or_class_from_graph(client: TestClient, admin_headers: dict):
    """Test 5 — Edit Node Label or Class From Graph updates candidate graph and increments version."""
    client.post("/api/candidates/dev-fixtures/seed", headers=admin_headers)
    before = client.get("/api/candidates/cand_demo_a_edit", headers=admin_headers).json()["candidate"]
    v_before = before["graph_version"]

    res = client.post(
        "/api/candidates/cand_demo_a_edit/edit",
        json={
            "update_entities": [
                {
                    "entity_uri": "http://watson.pharma.org/entity/brand/keytruda",
                    "label": "Keytruda (Pembrolizumab IV)",
                    "rdf_class": "BrandDrug",
                    "mapping_status": "MATCHED_CANONICAL",
                }
            ],
            "reason": "Updated node label from Graph Inspector",
            "expected_version": v_before,
        },
        headers=admin_headers,
    )
    assert res.status_code == 200
    after = res.json()["candidate"]
    assert after["graph_version"] == v_before + 1
    assert after["content_hash"] != before["content_hash"]
    ent = next(e for e in after["entities"] if e["entity_uri"] == "http://watson.pharma.org/entity/brand/keytruda")
    assert ent["label"] == "Keytruda (Pembrolizumab IV)"


def test_06_edit_relationship_from_graph(client: TestClient, admin_headers: dict):
    """Test 6 — Edit Relationship From Graph via replace_triples removes old triple and adds new triple."""
    client.post("/api/candidates/dev-fixtures/seed", headers=admin_headers)
    before = client.get("/api/candidates/cand_demo_a_edit", headers=admin_headers).json()["candidate"]

    res = client.post(
        "/api/candidates/cand_demo_a_edit/edit",
        json={
            "replace_triples": [
                {
                    "old_triple": {
                        "subject": "http://watson.pharma.org/entity/brand/keytruda",
                        "predicate": "http://watson.pharma.org/ontology/hasIndication",
                        "object": "Provisional Non-Small Cell Lung Cancer",
                    },
                    "new_triple": {
                        "subject": "http://watson.pharma.org/entity/brand/keytruda",
                        "predicate": "http://watson.pharma.org/ontology/hasIndication",
                        "object": "Metastatic Non-Small Cell Lung Cancer (NSCLC)",
                        "object_type": "literal",
                    },
                }
            ],
            "reason": "Replaced provisional indication literal via graph edge inspector",
            "expected_version": before["graph_version"],
        },
        headers=admin_headers,
    )
    assert res.status_code == 200
    after = res.json()["candidate"]
    objs = [t["object"] for t in after["triples"] if t["predicate"].endswith("hasIndication")]
    assert "Provisional Non-Small Cell Lung Cancer" not in objs
    assert "Metastatic Non-Small Cell Lung Cancer (NSCLC)" in objs


def test_07_add_relationship_from_graph(client: TestClient, admin_headers: dict):
    """Test 7 — Add Relationship From Graph adds new triple to candidate graph."""
    res = client.post(
        "/api/candidates/cand_demo_a_edit/edit",
        json={
            "add_triples": [
                {
                    "subject": "http://watson.pharma.org/entity/brand/keytruda",
                    "predicate": "http://watson.pharma.org/ontology/hasSafetyNotice",
                    "object": "Immune-mediated pneumonitis monitoring required",
                    "object_type": "literal",
                }
            ],
            "reason": "Added safety notice triple from node inspector",
        },
        headers=admin_headers,
    )
    assert res.status_code == 200
    after = res.json()["candidate"]
    assert any(t["predicate"].endswith("hasSafetyNotice") for t in after["triples"])


def test_08_remove_invalid_triple_from_graph(client: TestClient, admin_headers: dict):
    """Test 8 — Remove Invalid Triple From Graph removes triple cleanly."""
    res = client.post(
        "/api/candidates/cand_demo_a_edit/edit",
        json={
            "remove_triples": [
                {
                    "subject": "http://watson.pharma.org/entity/brand/keytruda",
                    "predicate": "http://watson.pharma.org/ontology/hasSafetyNotice",
                    "object": "Immune-mediated pneumonitis monitoring required",
                }
            ],
            "reason": "Removed temporary safety notice triple",
        },
        headers=admin_headers,
    )
    assert res.status_code == 200
    after = res.json()["candidate"]
    assert not any(t["predicate"].endswith("hasSafetyNotice") for t in after["triples"])


def test_09_edit_diff_preview_works(client: TestClient, admin_headers: dict):
    """Test 9 — Edit Diff Preview shows exact added/removed triples before applying without mutating stored version."""
    client.post("/api/candidates/dev-fixtures/seed", headers=admin_headers)
    before = client.get("/api/candidates/cand_demo_a_edit", headers=admin_headers).json()["candidate"]

    prev_res = client.post(
        "/api/candidates/cand_demo_a_edit/edit/preview",
        json={
            "replace_triples": [
                {
                    "old_triple": {
                        "subject": "http://watson.pharma.org/entity/brand/keytruda",
                        "predicate": "http://watson.pharma.org/ontology/hasIndication",
                        "object": "Provisional Non-Small Cell Lung Cancer",
                    },
                    "new_triple": {
                        "subject": "http://watson.pharma.org/entity/brand/keytruda",
                        "predicate": "http://watson.pharma.org/ontology/hasIndication",
                        "object": "Curated First-Line NSCLC",
                    },
                }
            ]
        },
        headers=admin_headers,
    )
    assert prev_res.status_code == 200
    preview = prev_res.json()
    assert preview["diff"]["removed_count"] == 1
    assert preview["diff"]["added_count"] == 1
    assert preview["predicted_next_version"] == before["graph_version"] + 1
    assert preview["post_edit_state"] == "VALIDATION_PENDING"

    # Verify stored candidate was NOT mutated by preview
    after_check = client.get("/api/candidates/cand_demo_a_edit", headers=admin_headers).json()["candidate"]
    assert after_check["graph_version"] == before["graph_version"]


def test_10_edit_invalidates_prior_shacl_report(client: TestClient, admin_headers: dict):
    """Test 10 — Edit Invalidates Prior SHACL Report, sets VALIDATION_PENDING, and blocks approval."""
    client.post("/api/candidates/dev-fixtures/seed", headers=admin_headers)
    edit_res = client.post(
        "/api/candidates/cand_demo_a_edit/edit",
        json={
            "add_triples": [
                {
                    "subject": "http://watson.pharma.org/entity/brand/keytruda",
                    "predicate": "http://watson.pharma.org/ontology/hasDosingRegimen",
                    "object": "200 mg IV Q3W",
                    "object_type": "literal",
                }
            ],
            "reason": "Added dosing regimen",
        },
        headers=admin_headers,
    )
    assert edit_res.status_code == 200
    cand = edit_res.json()["candidate"]
    assert cand["candidate_lifecycle_state"] == "VALIDATION_PENDING"
    assert cand["shacl_report"]["is_stale"] is True

    # Attempt to approve while VALIDATION_PENDING must fail
    app_res = client.post(
        "/api/candidates/cand_demo_a_edit/approve",
        json={"expected_version": cand["graph_version"]},
        headers=admin_headers,
    )
    assert app_res.status_code == 400
    assert "VALIDATION_PENDING" in app_res.json()["detail"] or "stale" in app_res.json()["detail"].lower()


def test_11_revalidate_shacl_restores_conformance(client: TestClient, admin_headers: dict):
    """Test 11 — Revalidate SHACL Restores Conformance and binds report to latest version & hash."""
    val_res = client.post("/api/candidates/cand_demo_a_edit/validate", headers=admin_headers)
    assert val_res.status_code == 200
    cand = val_res.json()["candidate"]
    rep = val_res.json()["shacl_report"]
    assert rep["conforms"] is True
    assert rep["is_stale"] is False
    assert rep["candidate_version"] == cand["graph_version"]
    assert rep["candidate_content_hash"] == cand["content_hash"]
    assert cand["candidate_lifecycle_state"] == "UNDER_REVIEW"


# ===========================================================================
# Graph-First Entity Merge Tests (Tests 12–16)
# ===========================================================================

def test_12_duplicate_entity_highlighting(client: TestClient, admin_headers: dict):
    """Test 12 — Duplicate Entity Highlighting detects duplicate entities in graph explorer and duplicates endpoint."""
    client.post("/api/candidates/dev-fixtures/seed", headers=admin_headers)
    dup_res = client.get("/api/candidates/cand_demo_b_merge/duplicates", headers=admin_headers)
    assert dup_res.status_code == 200
    pairs = dup_res.json()["duplicate_pairs"]
    assert len(pairs) >= 1
    assert pairs[0]["source_entity"]["entity_uri"] == "http://watson.pharma.org/entity/brand/keytruda_dup"
    assert pairs[0]["target_entity"]["entity_uri"] == "http://watson.pharma.org/entity/brand/keytruda"

    exp_res = client.get("/api/candidates/graph/explorer?candidate_id=cand_demo_b_merge", headers=admin_headers)
    dup_nodes = [n for n in exp_res.json()["nodes"] if n["node_category"] == "DUPLICATE_CANDIDATE"]
    assert len(dup_nodes) >= 1


def test_13_side_by_side_entity_merge_preview(client: TestClient, admin_headers: dict):
    """Test 13 — Side-by-Side Entity Merge Preview shows source vs target comparison and affected triples."""
    prev_res = client.post(
        "/api/candidates/cand_demo_b_merge/merge/preview",
        json={
            "source_entity_uri": "http://watson.pharma.org/entity/brand/keytruda_dup",
            "target_entity_uri": "http://watson.pharma.org/entity/brand/keytruda",
            "target_canonical_name": "Keytruda",
        },
        headers=admin_headers,
    )
    assert prev_res.status_code == 200
    preview = prev_res.json()
    assert preview["source_entity"]["uri"] == "http://watson.pharma.org/entity/brand/keytruda_dup"
    assert preview["target_entity"]["uri"] == "http://watson.pharma.org/entity/brand/keytruda"
    assert preview["rewritten_triples_count"] >= 1
    assert preview["post_merge_state"] == "VALIDATION_PENDING"


def test_14_execute_entity_merge(client: TestClient, admin_headers: dict):
    """Test 14 — Execute Entity Merge redirects triples to canonical target and removes duplicate node."""
    merge_res = client.post(
        "/api/candidates/cand_demo_b_merge/merge",
        json={
            "source_entity_uri": "http://watson.pharma.org/entity/brand/keytruda_dup",
            "target_entity_uri": "http://watson.pharma.org/entity/brand/keytruda",
            "target_canonical_name": "Keytruda",
            "reason": "Merged duplicate Keytruda mention into canonical Keytruda entity",
        },
        headers=admin_headers,
    )
    assert merge_res.status_code == 200
    cand = merge_res.json()["candidate"]
    entity_uris = {e["entity_uri"] for e in cand["entities"]}
    assert "http://watson.pharma.org/entity/brand/keytruda_dup" not in entity_uris
    assert "http://watson.pharma.org/entity/brand/keytruda" in entity_uris
    assert not any(
        t["subject"] == "http://watson.pharma.org/entity/brand/keytruda_dup"
        or t["object"] == "http://watson.pharma.org/entity/brand/keytruda_dup"
        for t in cand["triples"]
    )


def test_15_merge_requires_revalidation(client: TestClient, admin_headers: dict):
    """Test 15 — Merge Requires Revalidation: merged candidate is VALIDATION_PENDING until revalidated."""
    cand = client.get("/api/candidates/cand_demo_b_merge", headers=admin_headers).json()["candidate"]
    assert cand["candidate_lifecycle_state"] == "VALIDATION_PENDING"
    assert cand["shacl_report"]["is_stale"] is True

    app_res = client.post("/api/candidates/cand_demo_b_merge/approve", json={}, headers=admin_headers)
    assert app_res.status_code == 400

    val_res = client.post("/api/candidates/cand_demo_b_merge/validate", headers=admin_headers)
    assert val_res.status_code == 200
    assert val_res.json()["candidate"]["candidate_lifecycle_state"] == "UNDER_REVIEW"


def test_16_trusted_resource_cannot_be_mutated_directly_as_duplicate_source(
    client: TestClient, admin_headers: dict
):
    """Test 16 — Trusted Resource Cannot Be Mutated Directly as Duplicate Source (TRUSTED_RESOURCE_IMMUTABLE)."""
    client.post("/api/candidates/dev-fixtures/seed", headers=admin_headers)
    # http://watson.pharma.org/entity/manufacturer/merck is in trusted graph and NOT a candidate entity in cand_demo_a_edit
    res = client.post(
        "/api/candidates/cand_demo_a_edit/merge",
        json={
            "source_entity_uri": "http://watson.pharma.org/entity/manufacturer/merck",
            "target_entity_uri": "http://watson.pharma.org/entity/brand/keytruda",
        },
        headers=admin_headers,
    )
    assert res.status_code == 400
    assert "TRUSTED_RESOURCE_IMMUTABLE" in res.json()["detail"]


# ===========================================================================
# Quarantine & Evidence Remediation Tests (Tests 17–23)
# ===========================================================================

def test_17_quarantine_candidate(client: TestClient, admin_headers: dict):
    """Test 17 — Quarantine Candidate transitions candidate to QUARANTINED and records quarantine metadata."""
    client.post("/api/candidates/dev-fixtures/seed", headers=admin_headers)
    q_res = client.post(
        "/api/candidates/cand_demo_a_edit/quarantine",
        json={
            "reason": "Missing canonical manufacturer provenance verification",
            "triggering_issue": "SHACL_OR_EVIDENCE_HOLD",
        },
        headers=admin_headers,
    )
    assert q_res.status_code == 200
    cand = q_res.json()["candidate"]
    assert cand["candidate_lifecycle_state"] == "QUARANTINED"
    assert cand["quarantine_record"]["reason"] == "Missing canonical manufacturer provenance verification"


def test_18_quarantined_candidate_cannot_be_approved_or_published(client: TestClient, admin_headers: dict):
    """Test 18 — Quarantined Candidate Cannot Be Approved or Published."""
    app_res = client.post("/api/candidates/cand_demo_a_edit/approve", json={}, headers=admin_headers)
    assert app_res.status_code == 400

    pub_res = client.post("/api/candidates/cand_demo_a_edit/publish", json={}, headers=admin_headers)
    assert pub_res.status_code == 400


def test_19_quarantine_path_a_edit_and_revalidate(client: TestClient, admin_headers: dict):
    """Test 19 — Quarantine Path A: Edit & Revalidate transitions QUARANTINED -> VALIDATION_PENDING -> UNDER_REVIEW."""
    edit_res = client.post(
        "/api/candidates/cand_demo_a_edit/edit",
        json={
            "add_triples": [
                {
                    "subject": "http://watson.pharma.org/entity/brand/keytruda",
                    "predicate": "http://watson.pharma.org/ontology/manufacturedBy",
                    "object": "http://watson.pharma.org/entity/manufacturer/merck",
                    "object_type": "uri",
                }
            ],
            "reason": "Path A remediation edit",
        },
        headers=admin_headers,
    )
    assert edit_res.status_code == 200
    assert edit_res.json()["candidate"]["candidate_lifecycle_state"] == "VALIDATION_PENDING"

    val_res = client.post("/api/candidates/cand_demo_a_edit/validate", headers=admin_headers)
    assert val_res.status_code == 200
    cand = val_res.json()["candidate"]
    assert cand["candidate_lifecycle_state"] == "UNDER_REVIEW"
    assert cand["quarantine_record"]["final_disposition"] in ("RETURNED_TO_UNDER_REVIEW", "REMEDIATED_RETURNED_TO_REVIEW")


def test_20_quarantine_path_b_request_evidence(client: TestClient, admin_headers: dict):
    """Test 20 — Quarantine Path B: Request Evidence transitions QUARANTINED -> AWAITING_EVIDENCE."""
    client.post("/api/candidates/dev-fixtures/seed", headers=admin_headers)
    req_res = client.post(
        "/api/candidates/cand_demo_c_quarantine/request-evidence",
        json={
            "request_note": "Attach Phase 3 NSCLC clinical dossier and Merck manufacturer provenance",
            "requested_fields": ["manufacturedBy", "clinicalEvidenceChunk"],
            "idempotency_key": "req_ev_demo_c_001",
        },
        headers=admin_headers,
    )
    assert req_res.status_code == 200
    cand = req_res.json()["candidate"]
    assert cand["candidate_lifecycle_state"] == "AWAITING_EVIDENCE"
    assert len(cand["quarantine_record"]["evidence_requests"]) >= 1


def test_21_quarantine_path_b_attach_supplemental_evidence_and_revalidate(
    client: TestClient, admin_headers: dict
):
    """Test 21 — Quarantine Path B: Attach Supplemental Evidence & Revalidate."""
    sub_res = client.post(
        "/api/candidates/cand_demo_c_quarantine/submit-evidence",
        json={
            "evidence_text": "Supplemental Clinical Dossier: Keytruda manufactured by Merck demonstrated OS benefit in NSCLC.",
            "source_reference": "Merck_NSCLC_Supplemental_Dossier_v2.pdf",
            "source_document_uri": "doc_demo_c_quarantine.pdf",
            "document_version": "v2.0",
            "chunk_or_page_ref": "page_4_chunk_2",
            "evidence_type": "CLINICAL_STUDY_REPORT",
            "sensitivity_level": "CONFIDENTIAL",
            "additional_triples": [
                {
                    "subject": "http://watson.pharma.org/entity/brand/keytruda",
                    "predicate": "http://watson.pharma.org/ontology/manufacturedBy",
                    "object": "http://watson.pharma.org/entity/manufacturer/merck",
                    "object_type": "uri",
                }
            ],
            "idempotency_key": "sub_ev_demo_c_001",
        },
        headers=admin_headers,
    )
    assert sub_res.status_code == 200
    cand = sub_res.json()["candidate"]
    assert cand["candidate_lifecycle_state"] == "VALIDATION_PENDING"
    assert len(cand["quarantine_record"]["evidence_submissions"]) == 1

    val_res = client.post("/api/candidates/cand_demo_c_quarantine/validate", headers=admin_headers)
    assert val_res.status_code == 200
    cand_val = val_res.json()["candidate"]
    assert cand_val["candidate_lifecycle_state"] == "UNDER_REVIEW"
    assert cand_val["shacl_report"]["conforms"] is True


def test_22_duplicate_evidence_request_or_submission_is_idempotent(client: TestClient, admin_headers: dict):
    """Test 22 — Duplicate Evidence Request or Submission with same idempotency_key does not create duplicate records."""
    cand_before = client.get("/api/candidates/cand_demo_c_quarantine", headers=admin_headers).json()["candidate"]
    v_before = cand_before["graph_version"]
    subs_before = len(cand_before["quarantine_record"]["evidence_submissions"])

    dup_sub = client.post(
        "/api/candidates/cand_demo_c_quarantine/submit-evidence",
        json={
            "evidence_text": "Supplemental Clinical Dossier: Keytruda manufactured by Merck demonstrated OS benefit in NSCLC.",
            "source_document_uri": "doc_demo_c_quarantine.pdf",
            "idempotency_key": "sub_ev_demo_c_001",
        },
        headers=admin_headers,
    )
    assert dup_sub.status_code == 200
    cand_after = dup_sub.json()["candidate"]
    assert cand_after["graph_version"] == v_before
    assert len(cand_after["quarantine_record"]["evidence_submissions"]) == subs_before


def test_23_unresolved_missing_evidence_blocks_approval(client: TestClient, admin_headers: dict):
    """Test 23 — Unresolved Missing Evidence Blocks Approval & Free-Text Without Source Binding Is Rejected."""
    # 1. Verify free-text evidence without source_document_uri or short text is rejected
    bad_ev = client.post(
        "/api/candidates/cand_demo_c_quarantine/submit-evidence",
        json={
            "evidence_text": "too short",
            "source_document_uri": "",
        },
        headers=admin_headers,
    )
    assert bad_ev.status_code == 400
    assert "ELIGIBLE_SOURCE_EVIDENCE_REQUIRED" in bad_ev.json()["detail"]

    # 2. Verify candidate with unresolved missing evidence (cand_demo_c_quarantine) blocks approval
    client.post("/api/candidates/dev-fixtures/seed", headers=admin_headers)
    app_res = client.post("/api/candidates/cand_demo_c_quarantine/approve", json={}, headers=admin_headers)
    assert app_res.status_code == 400
    assert "cannot approve" in app_res.json()["detail"].lower() or "evidence" in app_res.json()["detail"].lower()

    # Restore demo fixtures cleanly
    client.post("/api/candidates/dev-fixtures/seed", headers=admin_headers)


# ===========================================================================
# Approval, Publication & Enterprise Sync Tests (Tests 24–30)
# ===========================================================================

def test_24_quarantine_path_c_reject_candidate(client: TestClient, admin_headers: dict):
    """Test 24 — Quarantine Path C: Reject Candidate transitions to terminal REJECTED and blocks publication."""
    client.post("/api/candidates/dev-fixtures/seed", headers=admin_headers)
    rej_res = client.post(
        "/api/candidates/cand_demo_c_quarantine/reject",
        json={"reason": "Path C terminal rejection due to unverified off-label claim"},
        headers=admin_headers,
    )
    assert rej_res.status_code == 200
    cand = rej_res.json()["candidate"]
    assert cand["candidate_lifecycle_state"] == "REJECTED"
    assert cand["quarantine_record"]["final_disposition"] == "REJECTED_TERMINAL"

    pub_res = client.post("/api/candidates/cand_demo_c_quarantine/publish", json={}, headers=admin_headers)
    assert pub_res.status_code == 400


def test_25_publication_readiness_panel_accuracy(client: TestClient, admin_headers: dict):
    """Test 25 — Publication Readiness Panel Accuracy evaluates all 10 required checks."""
    client.post("/api/candidates/dev-fixtures/seed", headers=admin_headers)
    r_res = client.get("/api/candidates/cand_demo_d_publish/readiness", headers=admin_headers)
    assert r_res.status_code == 200
    readiness = r_res.json()
    assert readiness["total_checks"] == 10
    assert len(readiness["checks"]) == 10
    assert readiness["ready_for_approval"] is True


def test_26_stale_version_approval_protection(client: TestClient, admin_headers: dict):
    """Test 26 — Stale Version Approval Protection returns HTTP 409 STALE_CANDIDATE_VERSION."""
    client.post("/api/candidates/dev-fixtures/seed", headers=admin_headers)
    res = client.post(
        "/api/candidates/cand_demo_d_publish/approve",
        json={"expected_version": 999},
        headers=admin_headers,
    )
    assert res.status_code == 409
    assert "STALE_CANDIDATE_VERSION" in res.json()["detail"]


def test_27_stale_version_edit_or_merge_protection(client: TestClient, admin_headers: dict):
    """Test 27 — Stale Version Edit or Merge Protection returns HTTP 409 STALE_CANDIDATE_VERSION."""
    edit_res = client.post(
        "/api/candidates/cand_demo_a_edit/edit",
        json={
            "add_triples": [
                {
                    "subject": "http://watson.pharma.org/entity/brand/keytruda",
                    "predicate": "http://watson.pharma.org/ontology/hasIndication",
                    "object": "NSCLC",
                }
            ],
            "expected_version": 999,
        },
        headers=admin_headers,
    )
    assert edit_res.status_code == 409
    assert "STALE_CANDIDATE_VERSION" in edit_res.json()["detail"]

    merge_res = client.post(
        "/api/candidates/cand_demo_b_merge/merge",
        json={
            "source_entity_uri": "http://watson.pharma.org/entity/brand/keytruda_dup",
            "target_entity_uri": "http://watson.pharma.org/entity/brand/keytruda",
            "expected_version": 999,
        },
        headers=admin_headers,
    )
    assert merge_res.status_code == 409
    assert "STALE_CANDIDATE_VERSION" in merge_res.json()["detail"]


def test_28_controlled_publication_succeeds(client: TestClient, admin_headers: dict):
    """Test 28 — Controlled Publication Succeeds after approval and updates Trusted RDF + FAISS."""
    client.post("/api/candidates/dev-fixtures/seed", headers=admin_headers)
    cand = client.get("/api/candidates/cand_demo_d_publish", headers=admin_headers).json()["candidate"]

    app_res = client.post(
        "/api/candidates/cand_demo_d_publish/approve",
        json={"expected_version": cand["graph_version"], "review_note": "Approved for controlled publication"},
        headers=admin_headers,
    )
    assert app_res.status_code == 200
    assert app_res.json()["candidate"]["candidate_lifecycle_state"] == "APPROVED"

    pub_res = client.post(
        "/api/candidates/cand_demo_d_publish/publish",
        json={"transaction_id": "tx_workbench_test_28"},
        headers=admin_headers,
    )
    assert pub_res.status_code == 200
    pub_data = pub_res.json()
    assert pub_data["status"] == "PUBLISHED"
    assert pub_data["candidate"]["publication_lifecycle_state"] == "PUBLISHED"
    assert pub_data["transaction"]["status"] == "PUBLISHED"


def test_29_publication_failure_does_not_corrupt_trusted_knowledge(client: TestClient, admin_headers: dict):
    """Test 29 — Publication Failure Does Not Corrupt Trusted Knowledge (atomic rollback)."""
    client.post("/api/candidates/dev-fixtures/seed", headers=admin_headers)
    cand = client.get("/api/candidates/cand_demo_a_edit", headers=admin_headers).json()["candidate"]
    client.post(
        "/api/candidates/cand_demo_a_edit/approve",
        json={"expected_version": cand["graph_version"]},
        headers=admin_headers,
    )
    overview_before = client.get("/api/governance/overview", headers=admin_headers).json()
    v_before = overview_before["metrics"]["trusted_graph_version"]

    fail_res = client.post(
        "/api/candidates/cand_demo_a_edit/publish",
        json={"simulate_failure": True},
        headers=admin_headers,
    )
    assert fail_res.status_code == 400

    overview_after = client.get("/api/governance/overview", headers=admin_headers).json()
    assert overview_after["metrics"]["trusted_graph_version"] == v_before
    cand_after = client.get("/api/candidates/cand_demo_a_edit", headers=admin_headers).json()["candidate"]
    assert cand_after["publication_lifecycle_state"] == "PUBLICATION_FAILED"


def test_30_published_knowledge_appears_across_platform_views(client: TestClient, admin_headers: dict):
    """Test 30 — Published Knowledge Appears Across Platform Views (Document Library, KG Explorer, SPARQL Studio, Copilot)."""
    docs_res = client.get("/api/documents", headers=admin_headers)
    assert docs_res.status_code == 200
    docs_payload = docs_res.json()
    docs_list = docs_payload["documents"] if isinstance(docs_payload, dict) and "documents" in docs_payload else docs_payload
    assert len(docs_list) >= 5

    kg_res = client.get("/api/graph/explorer", headers=admin_headers)
    assert kg_res.status_code == 200
    assert len(kg_res.json()["nodes"]) >= 10

    sparql_res = client.post(
        "/api/graph/sparql",
        json={"query": "SELECT ?s ?p ?o WHERE { ?s ?p ?o } LIMIT 15"},
        headers=admin_headers,
    )
    assert sparql_res.status_code == 200
    assert sparql_res.json()["row_count"] >= 5

    chat_res = client.post(
        "/api/chat",
        json={"query": "What is the clinical evidence for Keytruda in NSCLC?"},
        headers=admin_headers,
    )
    assert chat_res.status_code == 200
    assert len(chat_res.json()["answer"]) > 20


# ===========================================================================
# Security, Audit & Regression Tests (Tests 31–36)
# ===========================================================================

def test_31_unauthorized_staged_candidate_access_blocked(client: TestClient):
    """Test 31 — Unauthorized Staged Candidate Access Blocked (HTTP 403 for Viewer/Analyst/External)."""
    for uid in ("U_ANALYST", "U_COMMERCIAL", "U_EXTERNAL", "D3"):
        headers = {"x-user-id": uid}
        assert client.get("/api/candidates", headers=headers).status_code == 403
        assert client.get("/api/candidates/queue/navigator", headers=headers).status_code == 403
        assert client.get("/api/candidates/cand_demo_a_edit", headers=headers).status_code == 403
        assert client.post("/api/candidates/cand_demo_a_edit/edit", json={}, headers=headers).status_code == 403


def test_32_tamper_evident_audit_trail_records_all_hitl_actions(client: TestClient, admin_headers: dict):
    """Test 32 — Tamper-Evident Audit Trail Records All HITL Actions and blocks modification/deletion."""
    for method in (client.delete, client.put, client.patch):
        res = method("/api/audit/logs", headers=admin_headers)
        assert res.status_code == 403

    logs_res = client.get("/api/audit/logs?limit=500", headers=admin_headers)
    assert logs_res.status_code == 200
    logs_payload = logs_res.json()
    logs_list = logs_payload["logs"] if isinstance(logs_payload, dict) and "logs" in logs_payload else logs_payload
    events = {e["event_type"] for e in logs_list}
    for required_evt in (
        "CANDIDATE_EDITED",
        "CANDIDATE_MERGED",
        "CANDIDATE_QUARANTINED",
        "QUARANTINE_EVIDENCE_REQUESTED",
        "QUARANTINE_EVIDENCE_RECEIVED",
        "SHACL_VALIDATION_EXECUTED",
        "CANDIDATE_APPROVED",
        "PUBLICATION_COMPLETED",
    ):
        assert required_evt in events, f"Expected audit event {required_evt} in audit trail"


def test_33_revision_snapshot_diff_works(client: TestClient, admin_headers: dict):
    """Test 33 — Revision Snapshot Diff Works: revision_history entries record diff_snapshot with added/removed triples."""
    client.post("/api/candidates/dev-fixtures/seed", headers=admin_headers)
    client.post(
        "/api/candidates/cand_demo_a_edit/edit",
        json={
            "replace_triples": [
                {
                    "old_triple": {
                        "subject": "http://watson.pharma.org/entity/brand/keytruda",
                        "predicate": "http://watson.pharma.org/ontology/hasIndication",
                        "object": "Provisional Non-Small Cell Lung Cancer",
                    },
                    "new_triple": {
                        "subject": "http://watson.pharma.org/entity/brand/keytruda",
                        "predicate": "http://watson.pharma.org/ontology/hasIndication",
                        "object": "Snapshot Diff Tested NSCLC Indication",
                    },
                }
            ],
            "reason": "Testing revision diff snapshot",
        },
        headers=admin_headers,
    )
    cand = client.get("/api/candidates/cand_demo_a_edit", headers=admin_headers).json()["candidate"]
    latest_rev = cand["revision_history"][-1]
    assert latest_rev["action"] in ("EDIT", "EDIT_CANDIDATE")
    assert "diff_snapshot" in latest_rev
    assert len(latest_rev["diff_snapshot"]["added_triples"]) == 1
    assert len(latest_rev["diff_snapshot"]["removed_triples"]) == 1


def test_34_demo_walkthrough_mode_is_isolated_and_resettable(client: TestClient, admin_headers: dict):
    """Test 34 — Demo Walkthrough Mode Is Isolated and Resettable without affecting real ingested candidates."""
    seed_res = client.post("/api/candidates/dev-fixtures/seed", headers=admin_headers)
    assert seed_res.status_code == 200
    assert len(seed_res.json()["demo_candidates"]) == 4

    reset_res = client.post("/api/candidates/dev-fixtures/reset", headers=admin_headers)
    assert reset_res.status_code == 200
    assert reset_res.json()["removed_count"] == 4

    cands_after = client.get("/api/candidates", headers=admin_headers).json()["candidates"]
    remaining_ids = {c["candidate_id"] for c in cands_after}
    assert "cand_demo_a_edit" not in remaining_ids
    assert len(remaining_ids) >= 5 and all(not c.get("is_synthetic_candidate") for c in cands_after)


def test_35_frontend_production_build_and_bundle_verification(client: TestClient):
    """Test 35 — Frontend Production Build & Bundle Verification."""
    dist_index = PROJECT_ROOT / "frontend/dist/index.html"
    dist_bundle = PROJECT_ROOT / "frontend/dist/assets/index-G7ZawakF.js"
    assert dist_index.exists()
    assert dist_bundle.exists()
    bundle_text = dist_bundle.read_text(encoding="utf-8")
    assert "Graph-First Knowledge Engineering" in bundle_text
    assert "Preview Before/After RDF Diff" in bundle_text
    assert "Visual Entity Merge" in bundle_text
    assert "10-Point Publication Readiness" in bundle_text

    res = client.get("/")
    assert res.status_code == 200
    assert "<div id=\"root\"></div>" in res.text


def test_36_full_existing_platform_regression_invariants():
    """Test 36 — Full Existing Platform Regression Invariants: seed_vocabularies.json and core ontology files intact."""
    from watson.shared.config import SEED_VOCABULARIES_FILE, PHARMA_KG_FILE, FAISS_INDEX_FILE
    assert SEED_VOCABULARIES_FILE.exists()
    vocab_data = json.loads(SEED_VOCABULARIES_FILE.read_text(encoding="utf-8"))
    assert len(vocab_data) > 0
    assert PHARMA_KG_FILE.exists()
    assert (PROJECT_ROOT / "ontology/pharma_shapes.ttl").exists()
    assert FAISS_INDEX_FILE.exists()
