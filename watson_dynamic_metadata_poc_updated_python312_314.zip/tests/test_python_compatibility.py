"""Real-library compatibility smoke tests; no model downloads or store writes.

Run: python -m pytest tests/test_python_compatibility.py -q
Optional: set WATSON_EMBEDDING_MODEL to a local MiniLM directory to test encoding.
"""
from __future__ import annotations

import importlib
import os
from pathlib import Path
import sys

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "backend"))
os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"

from watson.shared.models import QueryIntent


def test_real_dependencies_import_without_bundled_shims():
    import office_launcher
    for name in office_launcher.REQUIRED:
        module = importlib.import_module(name)
        path = Path(module.__file__).resolve()
        assert (ROOT / "backend" / "_compat_shims") not in path.parents, name


def test_existing_faiss_index_and_tensor_numpy_interop():
    import faiss
    import numpy as np
    import torch
    index = faiss.read_index(str(ROOT / "data/indexes/Watson.faiss"))
    assert index.d == 384
    assert index.ntotal > 0
    vector = torch.from_numpy(index.reconstruct(0).copy()).unsqueeze(0).numpy()
    assert vector.dtype == np.float32
    scores, ids = index.search(vector, 1)
    assert ids[0, 0] >= 0
    assert np.isfinite(scores).all()


def test_rdf_sparql_against_existing_graph():
    from rdflib import Graph
    graph = Graph().parse(str(ROOT / "ontology/pharma_kg.ttl"), format="turtle")
    count = list(graph.query("SELECT (COUNT(*) AS ?n) WHERE { ?s ?p ?o }"))[0][0]
    assert int(count) == len(graph) > 0


def test_fastapi_and_application_pydantic_models():
    from fastapi import FastAPI
    from fastapi.testclient import TestClient
    app = FastAPI()

    @app.post("/intent")
    def intent(body: QueryIntent):
        return body.model_dump(mode="json")

    with TestClient(app, base_url="http://localhost") as client:
        response = client.post("/intent", json={"raw_query": "Keytruda evidence"})
        assert response.status_code == 200
        assert response.json()["raw_query"] == "Keytruda evidence"
        assert client.post("/intent", json={}).status_code == 422
        assert client.get("/openapi.json").status_code == 200


def test_spacy_entity_ruler():
    import spacy
    nlp = spacy.blank("en")
    ruler = nlp.add_pipe("entity_ruler")
    ruler.add_patterns([{"label": "Brand", "pattern": "Keytruda"}])
    assert [(ent.text, ent.label_) for ent in nlp("Keytruda evidence").ents] == [("Keytruda", "Brand")]


def test_local_embedding_model_uses_same_vector_space():
    model_path = os.environ.get("WATSON_EMBEDDING_MODEL", "")
    if not model_path or not Path(model_path).is_dir():
        pytest.skip("Set WATSON_EMBEDDING_MODEL to a local all-MiniLM-L6-v2 directory")
    import numpy as np
    from sentence_transformers import SentenceTransformer
    from watson.retrieval.vector_index import VectorIndexManager
    index = VectorIndexManager()
    text = ["Keytruda treats non-small cell lung cancer"]
    query_vectors = index.encode(text)
    ingest_vectors = SentenceTransformer(model_path, local_files_only=True).encode(text, normalize_embeddings=True)
    assert query_vectors.shape == (1, 384)
    assert np.isfinite(query_vectors).all()
    assert np.allclose(np.linalg.norm(query_vectors, axis=1), 1.0, atol=1e-5)
    assert np.allclose(query_vectors, ingest_vectors, atol=1e-5)
    allowed = {entry["chunk_uri"] for entry in index.chunk_uri_map.values()}
    hits = index.search_with_prefilter(text[0], allowed, top_k=3)
    assert hits and all(uri in allowed for uri, score in hits)
    assert index.search_with_prefilter(text[0], set(), top_k=3) == []
