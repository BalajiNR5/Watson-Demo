import fs from 'fs';
import path from 'path';
import { createRequire } from 'module';

const require = createRequire('/usr/share/nodejs/');
const babel = require('@babel/core');

const ROOT = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const SRC_DIR = path.join(ROOT, 'frontend', 'src');
const BUNDLE_PATH = path.join(ROOT, 'frontend', 'dist', 'assets', 'index-G7ZawakF.js');

const existingBundle = fs.readFileSync(BUNDLE_PATH, 'utf-8');
const splitMarker = '(function(){\nconst __modules = {};';
const markerIdx = existingBundle.indexOf(splitMarker);
if (markerIdx === -1) {
  throw new Error('Could not locate __modules marker in existing bundle');
}
const reactRuntimePrefix = existingBundle.slice(0, markerIdx);

const modulesToCompile = [
  { id: './services/api', file: path.join(SRC_DIR, 'services', 'api.ts') },
  { id: './components/SafeMarkdownRenderer', file: path.join(SRC_DIR, 'components', 'SafeMarkdownRenderer.tsx') },
  { id: './components/ErrorBoundary', file: path.join(SRC_DIR, 'components', 'ErrorBoundary.tsx') },
  { id: './components/CandidateGraphExplorer', file: path.join(SRC_DIR, 'components', 'CandidateGraphExplorer.tsx') },
  { id: './components/ReviewDocument', file: path.join(SRC_DIR, 'components', 'ReviewDocument.tsx') },
  { id: './components/KnowledgeEngineeringStudio', file: path.join(SRC_DIR, 'components', 'KnowledgeEngineeringStudio.tsx') },
  { id: './components/KnowledgePublicationWorkspace', file: path.join(SRC_DIR, 'components', 'KnowledgePublicationWorkspace.tsx') },
  { id: './components/GraphExplorer', file: path.join(SRC_DIR, 'components', 'GraphExplorer.tsx') },
  { id: './App', file: path.join(SRC_DIR, 'App.tsx') },
];

let out = reactRuntimePrefix + '(function(){\nconst __modules = {};\nconst __cache = {};\n';

for (const mod of modulesToCompile) {
  const code = fs.readFileSync(mod.file, 'utf-8');
  const transformed = babel.transformSync(code, {
    filename: mod.file,
    presets: [
      [require('@babel/preset-env'), { modules: 'commonjs', targets: { esmodules: true } }],
      [require('@babel/preset-react'), { runtime: 'classic' }],
      [require('@babel/preset-typescript'), { isTSX: true, allExtensions: true }],
    ],
    compact: false,
    comments: false,
  });
  out += `__modules[${JSON.stringify(mod.id)}] = function(module, exports, require) {\n${transformed.code}\n};\n`;
}

out += `
function __require(id) {
  if (id === "react") return uu;
  if (id === "react-dom/client") return mi;
  let normId = id;
  if (id === "../services/api") normId = "./services/api";
  if (id === "./CandidateGraphExplorer") normId = "./components/CandidateGraphExplorer";
  if (id === "./ReviewDocument") normId = "./components/ReviewDocument";
  if (id === "./KnowledgeEngineeringStudio") normId = "./components/KnowledgeEngineeringStudio";
  if (id === "./KnowledgePublicationWorkspace") normId = "./components/KnowledgePublicationWorkspace";
  if (__cache[normId]) return __cache[normId].exports;
  const fn = __modules[normId];
  if (!fn) throw new Error("Module not found: " + normId + " (raw: " + id + ")");
  const mod = { exports: {} };
  __cache[normId] = mod;
  fn(mod, mod.exports, __require);
  return mod.exports;
}
const AppMod = __require("./App");
const App = AppMod.default || AppMod;
const { ErrorBoundary } = __require("./components/ErrorBoundary");
mi.createRoot(document.getElementById("root")).render(
  uu.createElement(uu.StrictMode, null, uu.createElement(ErrorBoundary, null, uu.createElement(App, null)))
);
})();
`;

fs.writeFileSync(BUNDLE_PATH, out, 'utf-8');
console.log(`Frontend bundle compiled successfully: ${BUNDLE_PATH} (${out.length} bytes)`);
