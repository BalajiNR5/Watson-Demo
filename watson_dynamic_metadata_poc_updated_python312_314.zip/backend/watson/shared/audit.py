from __future__ import annotations

import json
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from watson.shared.config import AUDIT_LOG_FILE

_LOCK = threading.Lock()

VALID_EVENT_TYPES = {
    "INGEST",
    "PARSE_WARNING",
    "PII_FLAG",
    "PII_OVERRIDE",
    "DEDUP_HIT",
    "STATE_TRANSITION",
    "ENTITY_RESOLUTION",
    "ENRICHMENT_START",
    "ENRICHMENT_COMPLETE",
    "ENRICHMENT_FAILED",
    "ABAC_DENIED",
    "EXPIRY_TRIGGERED",
    "HALLUCINATION_RISK",
    "TAXONOMY_UPDATE",
    "QUERY",
    "RETRIEVAL_STAGE",
    "FEEDBACK_RECORDED",
}


def log_audit_event(
    event_type: str,
    user_id: str,
    message: str,
    document_uri: Optional[str] = None,
    chunk_uri: Optional[str] = None,
    old_state: Optional[str] = None,
    new_state: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
    correlation_id: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Append-only audit logger writing to audit_log.jsonl with thread safety.
    """
    if event_type not in VALID_EVENT_TYPES:
        event_type = "GENERAL_AUDIT"

    timestamp = datetime.now(timezone.utc).isoformat()
    cid = correlation_id or str(uuid.uuid4())

    event = {
        "event_id": str(uuid.uuid4()),
        "timestamp": timestamp,
        "event_type": event_type,
        "user_id": user_id,
        "document_uri": document_uri,
        "chunk_uri": chunk_uri,
        "old_state": old_state,
        "new_state": new_state,
        "message": message,
        "metadata": metadata or {},
        "correlation_id": cid,
    }

    AUDIT_LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with _LOCK:
        with open(AUDIT_LOG_FILE, "a", encoding="utf-8") as f:
            f.write(json.dumps(event) + "\n")

    return event


def query_audit_logs(
    event_type: Optional[str] = None,
    user_id: Optional[str] = None,
    document_uri: Optional[str] = None,
    correlation_id: Optional[str] = None,
    limit: int = 100,
) -> List[Dict[str, Any]]:
    """
    Query audit events matching specific criteria.
    """
    if not AUDIT_LOG_FILE.exists():
        return []

    results = []
    with _LOCK:
        with open(AUDIT_LOG_FILE, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    event = json.loads(line)
                    event.setdefault("event_id", f"evt_{abs(hash(line)) % 10**10:010d}")
                    event.setdefault("user_id", (event.get("details") or {}).get("actor_id", "SYSTEM"))
                    event.setdefault("correlation_id", (event.get("details") or {}).get("correlation_id", event["event_id"]))
                    event.setdefault("message", f"{event.get('event_type', 'AUDIT')} on {event.get('document_uri', 'resource')}")
                    if event_type and event.get("event_type") != event_type:
                        continue
                    if user_id and event.get("user_id") != user_id:
                        continue
                    if document_uri and event.get("document_uri") != document_uri:
                        continue
                    if correlation_id and event.get("correlation_id") != correlation_id:
                        continue
                    results.append(event)
                except Exception:
                    continue

    return results[-limit:]
