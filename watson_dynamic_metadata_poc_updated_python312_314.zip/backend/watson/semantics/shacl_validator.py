"""
Watson Platform — Standards-Based SHACL Validation Engine (Phase 5)
===================================================================
Validates Candidate RDF Knowledge Graphs using standards-based SHACL shapes
(`ontology/pharma_shapes.ttl`) over a controlled, read-only Integrated
Knowledge Preview context:

    INTEGRATED_PREVIEW =
        CANDIDATE_GRAPH
      + APPROVED_MAPPINGS
      + SCOPED_TRUSTED_GRAPH_CONTEXT

Key Guarantees:
1. Trusted graph access is strictly read-only (zero mutation of trusted RDF).
2. Preserves named-graph provenance between candidate triples and trusted context.
3. Unapproved mappings (PROPOSED, CONFLICT, UNRESOLVED) are never treated as trusted.
4. Valid references from candidate entities (e.g., a candidate Drug referencing an
   existing trusted Manufacturer, Indication, or TherapeuticArea) resolve cleanly
   via SCOPED_TRUSTED_GRAPH_CONTEXT without false missing-reference violations.
5. Genuine SHACL violations (missing required properties, invalid datatypes,
   cardinality breaches, out-of-range values, unresolved/untyped target references,
   or cross-graph functional conflicts) are detected and reported with full
   provenance and human-readable explanations.
6. Every report is cryptographically bound to `candidate_version`,
   `candidate_content_hash`, `shacl_shapes_version`, and `trusted_graph_version`.
"""
from __future__ import annotations

import datetime
import hashlib
import json
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

import rdflib
from rdflib import Graph, Literal, Namespace, OWL, RDF, RDFS, URIRef, XSD

from watson.shared.config import (
    ONTOLOGY_DIR,
    PHARMA_KG_FILE,
    PHARMA_KG_INFERRED_FILE,
    PHARMA_ONTOLOGY_FILE,
    SEED_VOCABULARIES_FILE,
)

WATSON = Namespace("http://watson.pharma.org/ontology/")
ENTITY = Namespace("http://watson.pharma.org/entity/")
SH = Namespace("http://www.w3.org/ns/shacl#")

SHACL_SHAPES_FILE = ONTOLOGY_DIR / "pharma_shapes.ttl"

# Authoritative trusted pharmaceutical manufacturers in reference context
TRUSTED_MANUFACTURERS: List[Dict[str, Any]] = [
    {
        "uri": "http://watson.pharma.org/entity/manufacturer/merck",
        "id": "manufacturer:merck",
        "canonical_name": "Merck & Co. (MSD)",
        "country": "US",
        "brands": ["brand:keytruda"],
        "drugs": ["drug:pembrolizumab"],
    },
    {
        "uri": "http://watson.pharma.org/entity/manufacturer/bms",
        "id": "manufacturer:bms",
        "canonical_name": "Bristol Myers Squibb",
        "country": "US",
        "brands": ["brand:opdivo"],
        "drugs": ["drug:nivolumab"],
    },
    {
        "uri": "http://watson.pharma.org/entity/manufacturer/sanofi_regeneron",
        "id": "manufacturer:sanofi_regeneron",
        "canonical_name": "Sanofi & Regeneron Pharmaceuticals",
        "country": "Global",
        "brands": ["brand:dupixent"],
        "drugs": ["drug:dupilumab"],
    },
    {
        "uri": "http://watson.pharma.org/entity/manufacturer/astrazeneca",
        "id": "manufacturer:astrazeneca",
        "canonical_name": "AstraZeneca PLC",
        "country": "UK",
        "brands": ["brand:farxiga"],
        "drugs": ["drug:dapagliflozin"],
    },
    {
        "uri": "http://watson.pharma.org/entity/manufacturer/boehringer_ingelheim",
        "id": "manufacturer:boehringer_ingelheim",
        "canonical_name": "Boehringer Ingelheim & Eli Lilly",
        "country": "Germany",
        "brands": ["brand:jardiance"],
        "drugs": ["drug:empagliflozin"],
    },
    {
        "uri": "http://watson.pharma.org/entity/manufacturer/novartis",
        "id": "manufacturer:novartis",
        "canonical_name": "Novartis AG",
        "country": "EU",
        "brands": ["brand:entresto", "brand:xolair"],
        "drugs": ["drug:sacubitril_valsartan", "drug:omalizumab"],
    },
    {
        "uri": "http://watson.pharma.org/entity/manufacturer/biogen",
        "id": "manufacturer:biogen",
        "canonical_name": "Biogen Inc.",
        "country": "US",
        "brands": ["brand:spinraza", "brand:tecfidera"],
        "drugs": ["drug:nusinersen", "drug:dimethyl_fumarate"],
    },
    {
        "uri": "http://watson.pharma.org/entity/manufacturer/vertex",
        "id": "manufacturer:vertex",
        "canonical_name": "Vertex Pharmaceuticals",
        "country": "US",
        "brands": ["brand:trikafta"],
        "drugs": ["drug:elexacaftor_tezacaftor_ivacaftor"],
    },
]

# OWL Subclass closure map for Watson ontology classes
SUBCLASS_CLOSURE: Dict[str, Set[str]] = {
    str(WATSON.BiologicDrug): {str(WATSON.BiologicDrug), str(WATSON.Drug), str(WATSON.PharmaEntity)},
    str(WATSON.SmallMoleculeDrug): {str(WATSON.SmallMoleculeDrug), str(WATSON.Drug), str(WATSON.PharmaEntity)},
    str(WATSON.Drug): {str(WATSON.Drug), str(WATSON.PharmaEntity)},
    str(WATSON.Brand): {str(WATSON.Brand), str(WATSON.PharmaEntity)},
    str(WATSON.Indication): {str(WATSON.Indication), str(WATSON.PharmaEntity)},
    str(WATSON.TherapeuticArea): {str(WATSON.TherapeuticArea), str(WATSON.PharmaEntity)},
    str(WATSON.Geography): {str(WATSON.Geography), str(WATSON.PharmaEntity)},
    str(WATSON.StudyType): {str(WATSON.StudyType), str(WATSON.PharmaEntity)},
    str(WATSON.Manufacturer): {str(WATSON.Manufacturer), str(WATSON.PharmaEntity)},
    str(WATSON.KeyOpinionLeader): {str(WATSON.KeyOpinionLeader), str(WATSON.HCP), str(WATSON.PharmaEntity)},
    str(WATSON.HCP): {str(WATSON.HCP), str(WATSON.PharmaEntity)},
    str(WATSON.HCPSentimentStudy): {
        str(WATSON.HCPSentimentStudy),
        str(WATSON.MarketResearchDocument),
        str(WATSON.Document),
    },
    str(WATSON.MarketResearchDocument): {str(WATSON.MarketResearchDocument), str(WATSON.Document)},
    str(WATSON.Document): {str(WATSON.Document)},
    str(WATSON.DocumentChunk): {str(WATSON.DocumentChunk)},
    str(WATSON.SentimentAssertion): {str(WATSON.SentimentAssertion)},
    str(WATSON.KnowledgeSpace): {str(WATSON.KnowledgeSpace)},
    str(WATSON.LineageRecord): {str(WATSON.LineageRecord)},
}


def _utc_now() -> str:
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


class SHACLValidator:
    """
    Standards-based SHACL Validation Engine operating over:
    INTEGRATED_PREVIEW = CANDIDATE_GRAPH + APPROVED_MAPPINGS + SCOPED_TRUSTED_GRAPH_CONTEXT
    """

    def __init__(
        self,
        shapes_path: Optional[Path] = None,
        ontology_path: Optional[Path] = None,
        kg_path: Optional[Path] = None,
        vocab_path: Optional[Path] = None,
    ):
        self.shapes_path = Path(shapes_path) if shapes_path else SHACL_SHAPES_FILE
        self.ontology_path = Path(ontology_path) if ontology_path else PHARMA_ONTOLOGY_FILE
        self.kg_path = Path(kg_path) if kg_path else (
            PHARMA_KG_INFERRED_FILE if PHARMA_KG_INFERRED_FILE.exists() else PHARMA_KG_FILE
        )
        self.vocab_path = Path(vocab_path) if vocab_path else SEED_VOCABULARIES_FILE

    def get_shapes_version_info(self) -> Dict[str, str]:
        """Returns the current SHACL shapes version and SHA-256 fingerprint."""
        if self.shapes_path.exists():
            raw = self.shapes_path.read_bytes()
            sha = hashlib.sha256(raw).hexdigest()[:16]
            return {"version": f"1.0.0+{sha}", "sha256": sha, "source": str(self.shapes_path.name)}
        return {"version": "1.0.0+builtin", "sha256": "builtin_v1_0_0", "source": "builtin_pharma_shapes"}

    def get_trusted_graph_version_info(self, trusted_graph: Optional[Graph] = None) -> Dict[str, Any]:
        """Computes a deterministic version identifier for the current trusted RDF graph."""
        if trusted_graph is not None and len(trusted_graph) > 0:
            triple_count = len(trusted_graph)
            sample = sorted(f"{s}|{p}|{o}" for s, p, o in trusted_graph)
            digest = hashlib.sha256("\n".join(sample).encode("utf-8")).hexdigest()[:16]
            return {
                "version": f"kg-v2.1+{digest}",
                "triple_count": triple_count,
                "sha256": digest,
            }
        kg_file = PHARMA_KG_FILE if PHARMA_KG_FILE.exists() else self.kg_path
        if kg_file.exists():
            raw = kg_file.read_bytes()
            digest = hashlib.sha256(raw).hexdigest()[:16]
            return {
                "version": f"kg-v2.1+{digest}",
                "triple_count": raw.count(b"\n"),
                "sha256": digest,
            }
        return {"version": "kg-v2.1+empty", "triple_count": 0, "sha256": "empty"}

    def build_scoped_trusted_context(
        self,
        candidate_triples: List[Dict[str, Any]],
        trusted_graph: Optional[Graph] = None,
        approved_mappings: Optional[List[Dict[str, Any]]] = None,
    ) -> Tuple[Graph, Dict[str, Any]]:
        """
        Builds a strictly read-only SCOPED_TRUSTED_GRAPH_CONTEXT containing:
        1. All trusted entities referenced as subjects or objects in `candidate_triples`.
        2. Their 1-hop class declarations (`rdf:type`), `canonicalName`, `isBrandOf`,
           `hasBrand`, `treatsIndication`, `inTherapeuticArea`, `manufacturedBy`.
        3. Trusted reference Manufacturers (`watson:Manufacturer`) and Seed Vocabulary entities.
        4. Approved semantic mappings (`EXACT` or explicitly approved `APPROVED`).
        Never mutates `trusted_graph`.
        """
        scoped = Graph()

        # 1. Load read-only source graph if not passed
        source_g = trusted_graph
        if source_g is None or len(source_g) == 0:
            source_g = Graph()
            if self.ontology_path.exists():
                source_g.parse(str(self.ontology_path), format="turtle")
            if PHARMA_KG_FILE.exists():
                source_g.parse(str(PHARMA_KG_FILE), format="turtle")

        # 2. Collect URIs referenced by candidate triples
        referenced_uris: Set[str] = set()
        for t in candidate_triples:
            s = str(t.get("subject", ""))
            p = str(t.get("predicate", ""))
            o = str(t.get("object", ""))
            if s.startswith("http://"):
                referenced_uris.add(s)
            if p.startswith("http://"):
                referenced_uris.add(p)
            if o.startswith("http://"):
                referenced_uris.add(o)

        # 3. Seed trusted Manufacturers into scoped context (read-only reference data)
        for mfg in TRUSTED_MANUFACTURERS:
            m_uri = URIRef(mfg["uri"])
            scoped.add((m_uri, RDF.type, WATSON.Manufacturer))
            scoped.add((m_uri, RDF.type, WATSON.PharmaEntity))
            scoped.add((m_uri, WATSON.canonicalName, Literal(mfg["canonical_name"], datatype=XSD.string)))
            scoped.add((m_uri, RDFS.label, Literal(mfg["canonical_name"], datatype=XSD.string)))
            for b_id in mfg.get("brands", []):
                b_local = b_id.split(":")[-1]
                b_uri = ENTITY[f"brand/{b_local}"]
                scoped.add((b_uri, WATSON.manufacturedBy, m_uri))
            for d_id in mfg.get("drugs", []):
                d_local = d_id.split(":")[-1]
                d_uri = ENTITY[f"drug/{d_local}"]
                scoped.add((d_uri, WATSON.manufacturedBy, m_uri))

        # 4. Seed canonical entities from seed_vocabularies.json into scoped context
        if self.vocab_path.exists():
            try:
                vdata = json.loads(self.vocab_path.read_text(encoding="utf-8")).get("vocabularies", {})
                for b in vdata.get("brands", []):
                    b_local = b["id"].split(":")[-1]
                    b_uri = ENTITY[f"brand/{b_local}"]
                    scoped.add((b_uri, RDF.type, WATSON.Brand))
                    scoped.add((b_uri, WATSON.canonicalName, Literal(b["canonical_name"], datatype=XSD.string)))
                    if b.get("drug_id"):
                        d_local = b["drug_id"].split(":")[-1]
                        d_uri = ENTITY[f"drug/{d_local}"]
                        scoped.add((b_uri, WATSON.isBrandOf, d_uri))
                        scoped.add((d_uri, WATSON.hasBrand, b_uri))
                    for ind_id in b.get("indication_ids", []):
                        i_local = ind_id.split(":")[-1]
                        scoped.add((b_uri, WATSON.treatsIndication, ENTITY[f"indication/{i_local}"]))
                for d in vdata.get("drugs", []):
                    d_local = d["id"].split(":")[-1]
                    d_uri = ENTITY[f"drug/{d_local}"]
                    scoped.add((d_uri, RDF.type, WATSON.Drug))
                    if d.get("drug_class") == "Biologic":
                        scoped.add((d_uri, RDF.type, WATSON.BiologicDrug))
                    elif d.get("drug_class") == "SmallMolecule":
                        scoped.add((d_uri, RDF.type, WATSON.SmallMoleculeDrug))
                    scoped.add((d_uri, WATSON.canonicalName, Literal(d["canonical_name"], datatype=XSD.string)))
                for ind in vdata.get("indications", []):
                    i_local = ind["id"].split(":")[-1]
                    i_uri = ENTITY[f"indication/{i_local}"]
                    scoped.add((i_uri, RDF.type, WATSON.Indication))
                    scoped.add((i_uri, WATSON.canonicalName, Literal(ind["canonical_name"], datatype=XSD.string)))
                    if ind.get("therapeutic_area_id"):
                        ta_local = ind["therapeutic_area_id"].split(":")[-1]
                        scoped.add((i_uri, WATSON.inTherapeuticArea, ENTITY[f"ta/{ta_local}"]))
                for ta in vdata.get("therapeutic_areas", []):
                    t_local = ta["id"].split(":")[-1]
                    t_uri = ENTITY[f"ta/{t_local}"]
                    scoped.add((t_uri, RDF.type, WATSON.TherapeuticArea))
                    scoped.add((t_uri, WATSON.canonicalName, Literal(ta["canonical_name"], datatype=XSD.string)))
                for geo in vdata.get("geographies", []):
                    g_local = geo["id"].split(":")[-1]
                    g_uri = ENTITY[f"geo/{g_local}"]
                    scoped.add((g_uri, RDF.type, WATSON.Geography))
                    scoped.add((g_uri, WATSON.canonicalName, Literal(geo["canonical_name"], datatype=XSD.string)))
                for st in vdata.get("study_templates", []):
                    s_local = st["id"].split(":")[-1]
                    s_uri = ENTITY[f"study/{s_local}"]
                    scoped.add((s_uri, RDF.type, WATSON.StudyType))
                    scoped.add((s_uri, WATSON.canonicalName, Literal(st["canonical_name"], datatype=XSD.string)))
            except Exception:
                pass

        # 5. Copy 1-hop triples for referenced URIs from source_g into scoped graph
        scoped_from_kg = 0
        for ref_str in list(referenced_uris):
            u = URIRef(ref_str)
            for s, p, o in source_g.triples((u, None, None)):
                scoped.add((s, p, o))
                scoped_from_kg += 1
                if isinstance(o, URIRef):
                    for s2, p2, o2 in source_g.triples((o, RDF.type, None)):
                        scoped.add((s2, p2, o2))
                    for s2, p2, o2 in source_g.triples((o, WATSON.canonicalName, None)):
                        scoped.add((s2, p2, o2))
            for s, p, o in source_g.triples((None, None, u)):
                scoped.add((s, p, o))
                scoped_from_kg += 1

        # 6. Apply only AUTHORIZED mappings (EXACT or explicitly APPROVED)
        approved_count = 0
        unapproved_skipped = 0
        for m in approved_mappings or []:
            status = m.get("mapping_status") or m.get("status", "UNRESOLVED")
            if status in ("EXACT", "APPROVED"):
                approved_count += 1
                src_uri = m.get("source_uri")
                tgt_uri = m.get("target_uri")
                if src_uri and tgt_uri and src_uri.startswith("http://") and tgt_uri.startswith("http://"):
                    u_src = URIRef(src_uri)
                    u_tgt = URIRef(tgt_uri)
                    for _, _, o_type in list(scoped.triples((u_tgt, RDF.type, None))):
                        scoped.add((u_src, RDF.type, o_type))
                    for _, p_rel, o_val in list(scoped.triples((u_tgt, None, None))):
                        if p_rel in (WATSON.canonicalName, WATSON.isBrandOf, WATSON.inTherapeuticArea, WATSON.manufacturedBy):
                            scoped.add((u_src, p_rel, o_val))
            else:
                unapproved_skipped += 1

        context_meta = {
            "referenced_uris_count": len(referenced_uris),
            "scoped_trusted_triples_count": len(scoped),
            "scoped_from_kg_count": scoped_from_kg,
            "approved_mappings_applied": approved_count,
            "unapproved_mappings_excluded": unapproved_skipped,
            "trusted_manufacturers_loaded": len(TRUSTED_MANUFACTURERS),
        }
        return scoped, context_meta

    @staticmethod
    def _term_from_dict(val: Any, obj_type: str = "uri", datatype: Optional[str] = None) -> rdflib.Identifier:
        s_val = str(val)
        if obj_type == "uri" or s_val.startswith("http://") or s_val.startswith("https://"):
            return URIRef(s_val)
        if datatype:
            return Literal(val, datatype=URIRef(datatype))
        if isinstance(val, bool):
            return Literal(val, datatype=XSD.boolean)
        if isinstance(val, int):
            return Literal(val, datatype=XSD.integer)
        if isinstance(val, float):
            return Literal(val, datatype=XSD.float)
        return Literal(s_val, datatype=XSD.string)

    @staticmethod
    def _expanded_types(g: Graph, node: rdflib.Identifier) -> Set[str]:
        direct = {str(o) for _, _, o in g.triples((node, RDF.type, None))}
        expanded = set(direct)
        for t in direct:
            expanded.update(SUBCLASS_CLOSURE.get(t, {t}))
        return expanded

    def validate_candidate(
        self,
        candidate_record: Dict[str, Any],
        trusted_graph: Optional[Graph] = None,
    ) -> Dict[str, Any]:
        """
        Executes standards-based SHACL validation over INTEGRATED_PREVIEW:
            CANDIDATE_GRAPH + APPROVED_MAPPINGS + SCOPED_TRUSTED_GRAPH_CONTEXT
        and returns a version-bound SHACL Validation Report.
        """
        candidate_id = candidate_record.get("candidate_id", "cand:unknown")
        candidate_version = int(candidate_record.get("graph_version", 1))
        candidate_hash = candidate_record.get("content_hash", "")
        candidate_triples = candidate_record.get("triples", [])
        candidate_entities = candidate_record.get("entities", [])
        candidate_mappings = candidate_record.get("mappings", [])

        shapes_info = self.get_shapes_version_info()
        trusted_info = self.get_trusted_graph_version_info(trusted_graph)

        # 1. Build Candidate RDF Graph
        cand_g = Graph()
        for t in candidate_triples:
            s = URIRef(str(t["subject"]))
            p = URIRef(str(t["predicate"]))
            o = self._term_from_dict(
                t["object"],
                obj_type=t.get("object_type", "uri" if str(t["object"]).startswith("http://") else "literal"),
                datatype=t.get("datatype"),
            )
            cand_g.add((s, p, o))

        # 2. Build Read-Only Scoped Trusted Graph Context
        scoped_trusted_g, context_meta = self.build_scoped_trusted_context(
            candidate_triples=candidate_triples,
            trusted_graph=trusted_graph,
            approved_mappings=candidate_mappings,
        )

        # 3. Construct Integrated Knowledge Preview Graph (Read-Only Union)
        integrated_g = Graph()
        for triple in scoped_trusted_g:
            integrated_g.add(triple)
        for triple in cand_g:
            integrated_g.add(triple)

        # Track which focus nodes are touched or defined in the candidate graph
        candidate_subjects: Set[rdflib.Identifier] = {s for s, _, _ in cand_g}
        candidate_objects: Set[rdflib.Identifier] = {o for _, _, o in cand_g if isinstance(o, URIRef)}

        violations: List[Dict[str, Any]] = []
        warnings: List[Dict[str, Any]] = []
        cross_graph_resolved: List[Dict[str, str]] = []

        def add_violation(
            focus_node: str,
            result_path: str,
            source_shape: str,
            constraint_component: str,
            message: str,
            explanation: str,
            value: Optional[str] = None,
        ) -> None:
            violations.append({
                "violation_id": f"shv_{uuid.uuid4().hex[:8]}",
                "severity": "sh:Violation",
                "focus_node": str(focus_node),
                "result_path": str(result_path),
                "value": str(value) if value is not None else None,
                "source_shape": str(source_shape),
                "constraint_component": str(constraint_component),
                "message": message,
                "explanation": explanation,
            })

        def add_warning(
            focus_node: str,
            result_path: str,
            source_shape: str,
            constraint_component: str,
            message: str,
            explanation: str,
            value: Optional[str] = None,
        ) -> None:
            warnings.append({
                "warning_id": f"shw_{uuid.uuid4().hex[:8]}",
                "severity": "sh:Warning",
                "focus_node": str(focus_node),
                "result_path": str(result_path),
                "value": str(value) if value is not None else None,
                "source_shape": str(source_shape),
                "constraint_component": str(constraint_component),
                "message": message,
                "explanation": explanation,
            })

        # Helper to check target class in integrated graph and record cross-graph resolution
        def check_target_class(
            subj: rdflib.Identifier,
            pred_uri: URIRef,
            expected_class_uri: URIRef,
            shape_name: str,
            msg: str,
        ) -> None:
            for _, _, obj in cand_g.triples((subj, pred_uri, None)):
                if not isinstance(obj, URIRef):
                    add_violation(
                        focus_node=str(subj),
                        result_path=str(pred_uri),
                        source_shape=shape_name,
                        constraint_component="sh:NodeKindConstraintComponent",
                        value=str(obj),
                        message=msg,
                        explanation=f"Property '{pred_uri}' on '{subj}' must reference an IRI resource, found literal '{obj}'.",
                    )
                    continue
                obj_types = self._expanded_types(integrated_g, obj)
                if str(expected_class_uri) not in obj_types:
                    add_violation(
                        focus_node=str(subj),
                        result_path=str(pred_uri),
                        source_shape=shape_name,
                        constraint_component="sh:ClassConstraintComponent",
                        value=str(obj),
                        message=msg,
                        explanation=(
                            f"Referenced entity '{obj}' on '{subj}' via '{pred_uri.split('/')[-1]}' is not typed as "
                            f"'{expected_class_uri.split('/')[-1]}' in either the Candidate Graph or the Scoped Trusted Graph Context."
                        ),
                    )
                else:
                    in_cand = any(True for _ in cand_g.triples((obj, RDF.type, None)))
                    in_trusted = any(True for _ in scoped_trusted_g.triples((obj, RDF.type, None)))
                    if in_trusted:
                        cross_graph_resolved.append({
                            "focus_node": str(subj),
                            "property": str(pred_uri),
                            "target_node": str(obj),
                            "resolved_class": str(expected_class_uri),
                            "resolved_via": "SCOPED_TRUSTED_GRAPH_CONTEXT",
                        })

        # ---------------------------------------------------------------------
        # Evaluate Shape 1: watson:MarketResearchDocumentShape
        # ---------------------------------------------------------------------
        for node in candidate_subjects:
            n_types = self._expanded_types(integrated_g, node)
            if str(WATSON.Document) in n_types:
                shape_uri = str(WATSON.MarketResearchDocumentShape)
                doc_uris = list(integrated_g.objects(node, WATSON.documentUri))
                if len(doc_uris) != 1:
                    add_violation(
                        focus_node=str(node),
                        result_path=str(WATSON.documentUri),
                        source_shape=shape_uri,
                        constraint_component="sh:MinCountConstraintComponent" if len(doc_uris) == 0 else "sh:MaxCountConstraintComponent",
                        message="Every governed document must have exactly one xsd:string watson:documentUri.",
                        explanation=f"Document '{node}' has {len(doc_uris)} watson:documentUri values (expected 1).",
                    )
                fns = list(integrated_g.objects(node, WATSON.sourceFilename))
                if not fns or not str(fns[0]).strip():
                    add_violation(
                        focus_node=str(node),
                        result_path=str(WATSON.sourceFilename),
                        source_shape=shape_uri,
                        constraint_component="sh:MinCountConstraintComponent",
                        message="Every governed document must specify a non-empty xsd:string watson:sourceFilename.",
                        explanation=f"Document '{node}' is missing required property watson:sourceFilename.",
                    )
                states = [str(x) for x in integrated_g.objects(node, WATSON.lifecycleState)]
                valid_states = {"DRAFT", "UNDER_REVIEW", "ACTIVE", "ARCHIVED", "REJECTED", "QUARANTINED"}
                if not states or states[0] not in valid_states:
                    add_violation(
                        focus_node=str(node),
                        result_path=str(WATSON.lifecycleState),
                        source_shape=shape_uri,
                        constraint_component="sh:InConstraintComponent",
                        value=states[0] if states else None,
                        message="Document watson:lifecycleState must be one of DRAFT, UNDER_REVIEW, ACTIVE, ARCHIVED, REJECTED, or QUARANTINED.",
                        explanation=f"Document '{node}' has invalid or missing lifecycleState '{states[0] if states else None}'.",
                    )
                sens = [str(x) for x in integrated_g.objects(node, WATSON.sensitivityLevel)]
                valid_sens = {"PUBLIC", "INTERNAL", "RESTRICTED", "HIGHLY_RESTRICTED", "CONFIDENTIAL"}
                if not sens or sens[0] not in valid_sens:
                    add_violation(
                        focus_node=str(node),
                        result_path=str(WATSON.sensitivityLevel),
                        source_shape=shape_uri,
                        constraint_component="sh:InConstraintComponent",
                        value=sens[0] if sens else None,
                        message="Document watson:sensitivityLevel must be one of PUBLIC, INTERNAL, RESTRICTED, HIGHLY_RESTRICTED, or CONFIDENTIAL.",
                        explanation=f"Document '{node}' has invalid or missing sensitivityLevel '{sens[0] if sens else None}'.",
                    )
                q_scores = list(integrated_g.objects(node, WATSON.qualityScore))
                if not q_scores:
                    add_violation(
                        focus_node=str(node),
                        result_path=str(WATSON.qualityScore),
                        source_shape=shape_uri,
                        constraint_component="sh:MinCountConstraintComponent",
                        message="Document watson:qualityScore must be an xsd:float between 0.0 and 1.0.",
                        explanation=f"Document '{node}' is missing watson:qualityScore.",
                    )
                else:
                    try:
                        qf = float(str(q_scores[0]))
                        if qf < 0.0 or qf > 1.0:
                            add_violation(
                                focus_node=str(node),
                                result_path=str(WATSON.qualityScore),
                                source_shape=shape_uri,
                                constraint_component="sh:MinInclusiveConstraintComponent",
                                value=str(q_scores[0]),
                                message="Document watson:qualityScore must be an xsd:float between 0.0 and 1.0.",
                                explanation=f"Document '{node}' has out-of-range qualityScore {qf} (must be in [0.0, 1.0]).",
                            )
                    except ValueError:
                        add_violation(
                            focus_node=str(node),
                            result_path=str(WATSON.qualityScore),
                            source_shape=shape_uri,
                            constraint_component="sh:DatatypeConstraintComponent",
                            value=str(q_scores[0]),
                            message="Document watson:qualityScore must be an xsd:float between 0.0 and 1.0.",
                            explanation=f"Document '{node}' has non-numeric qualityScore '{q_scores[0]}'.",
                        )
                chunks = list(integrated_g.objects(node, WATSON.containsChunk))
                if not chunks:
                    add_violation(
                        focus_node=str(node),
                        result_path=str(WATSON.containsChunk),
                        source_shape=shape_uri,
                        constraint_component="sh:MinCountConstraintComponent",
                        message="Every governed document must contain at least one valid watson:DocumentChunk.",
                        explanation=f"Document '{node}' has no linked watson:DocumentChunk via watson:containsChunk.",
                    )
                check_target_class(
                    node,
                    WATSON.inTherapeuticArea,
                    WATSON.TherapeuticArea,
                    shape_uri,
                    "Document watson:inTherapeuticArea must reference a valid watson:TherapeuticArea.",
                )
                check_target_class(
                    node,
                    WATSON.coversGeography,
                    WATSON.Geography,
                    shape_uri,
                    "Document watson:coversGeography must reference a valid watson:Geography.",
                )

            # -----------------------------------------------------------------
            # Evaluate Shape 2: watson:DocumentChunkShape
            # -----------------------------------------------------------------
            if str(WATSON.DocumentChunk) in n_types:
                shape_uri = str(WATSON.DocumentChunkShape)
                c_uris = list(integrated_g.objects(node, WATSON.chunkUri))
                if len(c_uris) != 1:
                    add_violation(
                        focus_node=str(node),
                        result_path=str(WATSON.chunkUri),
                        source_shape=shape_uri,
                        constraint_component="sh:MinCountConstraintComponent",
                        message="Every watson:DocumentChunk must have a unique xsd:string watson:chunkUri.",
                        explanation=f"Chunk '{node}' has {len(c_uris)} watson:chunkUri values.",
                    )
                c_texts = list(integrated_g.objects(node, WATSON.chunkText))
                if not c_texts or len(str(c_texts[0]).strip()) < 5:
                    add_violation(
                        focus_node=str(node),
                        result_path=str(WATSON.chunkText),
                        source_shape=shape_uri,
                        constraint_component="sh:MinLengthConstraintComponent",
                        value=str(c_texts[0]) if c_texts else None,
                        message="Every watson:DocumentChunk must contain non-empty watson:chunkText (minLength 5).",
                        explanation=f"Chunk '{node}' has empty or too-short watson:chunkText.",
                    )
                c_parents = list(integrated_g.objects(node, WATSON.chunkOf))
                if not c_parents:
                    add_violation(
                        focus_node=str(node),
                        result_path=str(WATSON.chunkOf),
                        source_shape=shape_uri,
                        constraint_component="sh:MinCountConstraintComponent",
                        message="Every watson:DocumentChunk must link to its parent watson:Document via watson:chunkOf.",
                        explanation=f"Chunk '{node}' is missing watson:chunkOf link to parent document.",
                    )
                check_target_class(
                    node,
                    WATSON.mentionsBrand,
                    WATSON.Brand,
                    shape_uri,
                    "Chunk watson:mentionsBrand must reference a valid watson:Brand.",
                )
                check_target_class(
                    node,
                    WATSON.mentionsDrug,
                    WATSON.Drug,
                    shape_uri,
                    "Chunk watson:mentionsDrug must reference a valid watson:Drug.",
                )
                check_target_class(
                    node,
                    WATSON.mentionsIndication,
                    WATSON.Indication,
                    shape_uri,
                    "Chunk watson:mentionsIndication must reference a valid watson:Indication.",
                )

            # -----------------------------------------------------------------
            # Evaluate Shape 3: watson:BrandShape
            # -----------------------------------------------------------------
            if str(WATSON.Brand) in n_types:
                shape_uri = str(WATSON.BrandShape)
                cnames = [str(x) for x in cand_g.objects(node, WATSON.canonicalName)] or [
                    str(x) for x in integrated_g.objects(node, WATSON.canonicalName)
                ]
                if len(cnames) == 0 or not cnames[0].strip():
                    add_violation(
                        focus_node=str(node),
                        result_path=str(WATSON.canonicalName),
                        source_shape=shape_uri,
                        constraint_component="sh:MinCountConstraintComponent",
                        message="Every watson:Brand must have exactly one xsd:string watson:canonicalName.",
                        explanation=f"Brand '{node}' is missing required watson:canonicalName.",
                    )
                elif len(set(cnames)) > 1:
                    add_violation(
                        focus_node=str(node),
                        result_path=str(WATSON.canonicalName),
                        source_shape=shape_uri,
                        constraint_component="sh:MaxCountConstraintComponent",
                        value=", ".join(cnames),
                        message="Every watson:Brand must have at most one watson:canonicalName.",
                        explanation=f"Brand '{node}' has multiple conflicting canonicalName literals: {cnames}.",
                    )

                drugs = list(integrated_g.objects(node, WATSON.isBrandOf))
                if not drugs:
                    add_violation(
                        focus_node=str(node),
                        result_path=str(WATSON.isBrandOf),
                        source_shape=shape_uri,
                        constraint_component="sh:MinCountConstraintComponent",
                        message="Every watson:Brand must be linked via watson:isBrandOf to a valid watson:Drug in the candidate or trusted graph.",
                        explanation=f"Brand '{node}' has no watson:isBrandOf link in either the candidate graph or the scoped trusted graph.",
                    )
                else:
                    check_target_class(
                        node,
                        WATSON.isBrandOf,
                        WATSON.Drug,
                        shape_uri,
                        "Every watson:isBrandOf target on a watson:Brand must be a valid watson:Drug.",
                    )
                    # Check functional consistency with trusted graph
                    trusted_drugs = {str(o) for o in scoped_trusted_g.objects(node, WATSON.isBrandOf)}
                    cand_drugs = {str(o) for o in cand_g.objects(node, WATSON.isBrandOf)}
                    if trusted_drugs and cand_drugs and not cand_drugs.issubset(trusted_drugs):
                        add_violation(
                            focus_node=str(node),
                            result_path=str(WATSON.isBrandOf),
                            source_shape=shape_uri,
                            constraint_component="sh:EqualsConstraintComponent",
                            value=", ".join(sorted(cand_drugs)),
                            message="Candidate watson:isBrandOf conflicts with authoritative trusted graph drug assignment.",
                            explanation=(
                                f"Brand '{node}' is linked to drug {sorted(cand_drugs)} in the candidate graph, "
                                f"which conflicts with trusted graph assignment {sorted(trusted_drugs)}."
                            ),
                        )

                check_target_class(
                    node,
                    WATSON.treatsIndication,
                    WATSON.Indication,
                    shape_uri,
                    "Every watson:treatsIndication target on a watson:Brand must be a valid watson:Indication.",
                )
                check_target_class(
                    node,
                    WATSON.manufacturedBy,
                    WATSON.Manufacturer,
                    shape_uri,
                    "Every watson:manufacturedBy target on a watson:Brand must resolve to a valid watson:Manufacturer in the candidate or trusted graph.",
                )

            # -----------------------------------------------------------------
            # Evaluate Shape 4: watson:DrugShape
            # -----------------------------------------------------------------
            if str(WATSON.Drug) in n_types:
                shape_uri = str(WATSON.DrugShape)
                cnames = [str(x) for x in cand_g.objects(node, WATSON.canonicalName)] or [
                    str(x) for x in integrated_g.objects(node, WATSON.canonicalName)
                ]
                if len(cnames) == 0 or not cnames[0].strip():
                    add_violation(
                        focus_node=str(node),
                        result_path=str(WATSON.canonicalName),
                        source_shape=shape_uri,
                        constraint_component="sh:MinCountConstraintComponent",
                        message="Every watson:Drug must have a single xsd:string watson:canonicalName.",
                        explanation=f"Drug '{node}' is missing required watson:canonicalName.",
                    )
                elif len(set(cnames)) > 1:
                    add_violation(
                        focus_node=str(node),
                        result_path=str(WATSON.canonicalName),
                        source_shape=shape_uri,
                        constraint_component="sh:MaxCountConstraintComponent",
                        value=", ".join(cnames),
                        message="Every watson:Drug must have a single xsd:string watson:canonicalName.",
                        explanation=f"Drug '{node}' has multiple conflicting canonicalName values: {cnames}.",
                    )

                check_target_class(
                    node,
                    WATSON.targetsIndication,
                    WATSON.Indication,
                    shape_uri,
                    "Every watson:targetsIndication target on a watson:Drug must resolve to a valid watson:Indication.",
                )
                check_target_class(
                    node,
                    WATSON.manufacturedBy,
                    WATSON.Manufacturer,
                    shape_uri,
                    "Every watson:manufacturedBy target on a watson:Drug must resolve to a valid watson:Manufacturer in the candidate or trusted graph.",
                )

            # -----------------------------------------------------------------
            # Evaluate Shape 5: watson:IndicationShape
            # -----------------------------------------------------------------
            if str(WATSON.Indication) in n_types:
                shape_uri = str(WATSON.IndicationShape)
                cnames = [str(x) for x in cand_g.objects(node, WATSON.canonicalName)] or [
                    str(x) for x in integrated_g.objects(node, WATSON.canonicalName)
                ]
                if not cnames or not cnames[0].strip():
                    add_violation(
                        focus_node=str(node),
                        result_path=str(WATSON.canonicalName),
                        source_shape=shape_uri,
                        constraint_component="sh:MinCountConstraintComponent",
                        message="Every watson:Indication must have a single xsd:string watson:canonicalName.",
                        explanation=f"Indication '{node}' is missing required watson:canonicalName.",
                    )
                tas = list(integrated_g.objects(node, WATSON.inTherapeuticArea))
                if not tas:
                    add_violation(
                        focus_node=str(node),
                        result_path=str(WATSON.inTherapeuticArea),
                        source_shape=shape_uri,
                        constraint_component="sh:MinCountConstraintComponent",
                        message="Every watson:Indication must belong to at least one valid watson:TherapeuticArea via watson:inTherapeuticArea.",
                        explanation=f"Indication '{node}' is missing required watson:inTherapeuticArea link in candidate and trusted graphs.",
                    )
                else:
                    check_target_class(
                        node,
                        WATSON.inTherapeuticArea,
                        WATSON.TherapeuticArea,
                        shape_uri,
                        "Every watson:inTherapeuticArea target on a watson:Indication must be a valid watson:TherapeuticArea.",
                    )

            # -----------------------------------------------------------------
            # Evaluate Shape 6: watson:SentimentAssertionShape
            # -----------------------------------------------------------------
            if str(WATSON.SentimentAssertion) in n_types:
                shape_uri = str(WATSON.SentimentAssertionShape)
                brands = list(integrated_g.objects(node, WATSON.sentimentAboutBrand))
                if not brands:
                    add_violation(
                        focus_node=str(node),
                        result_path=str(WATSON.sentimentAboutBrand),
                        source_shape=shape_uri,
                        constraint_component="sh:MinCountConstraintComponent",
                        message="Every watson:SentimentAssertion must reference a valid watson:Brand via watson:sentimentAboutBrand.",
                        explanation=f"SentimentAssertion '{node}' is missing watson:sentimentAboutBrand.",
                    )
                else:
                    check_target_class(
                        node,
                        WATSON.sentimentAboutBrand,
                        WATSON.Brand,
                        shape_uri,
                        "Every watson:SentimentAssertion must reference a valid watson:Brand.",
                    )
                scores = list(integrated_g.objects(node, WATSON.sentimentScore))
                if not scores:
                    add_violation(
                        focus_node=str(node),
                        result_path=str(WATSON.sentimentScore),
                        source_shape=shape_uri,
                        constraint_component="sh:MinCountConstraintComponent",
                        message="Every watson:SentimentAssertion must have an xsd:float watson:sentimentScore in [0.0, 1.0].",
                        explanation=f"SentimentAssertion '{node}' is missing watson:sentimentScore.",
                    )
                else:
                    try:
                        sf = float(str(scores[0]))
                        if sf < 0.0 or sf > 1.0:
                            add_violation(
                                focus_node=str(node),
                                result_path=str(WATSON.sentimentScore),
                                source_shape=shape_uri,
                                constraint_component="sh:MaxInclusiveConstraintComponent",
                                value=str(scores[0]),
                                message="Every watson:SentimentAssertion must have an xsd:float watson:sentimentScore in [0.0, 1.0].",
                                explanation=f"SentimentAssertion '{node}' has sentimentScore {sf} outside [0.0, 1.0].",
                            )
                    except ValueError:
                        add_violation(
                            focus_node=str(node),
                            result_path=str(WATSON.sentimentScore),
                            source_shape=shape_uri,
                            constraint_component="sh:DatatypeConstraintComponent",
                            value=str(scores[0]),
                            message="Every watson:SentimentAssertion must have an xsd:float watson:sentimentScore in [0.0, 1.0].",
                            explanation=f"SentimentAssertion '{node}' has non-float sentimentScore '{scores[0]}'.",
                        )

        # ---------------------------------------------------------------------
        # Evaluate Semantic Reconciliation & Mapping Governance Constraints
        # ---------------------------------------------------------------------
        for ent in candidate_entities:
            m_status = ent.get("mapping_status") or ent.get("resolution_status")
            ent_uri = ent.get("uri") or ent.get("canonical_uri") or f"urn:unresolved:{ent.get('mention', 'entity')}"
            if m_status == "CONFLICT":
                add_violation(
                    focus_node=str(ent_uri),
                    result_path=str(WATSON.mappingStatus),
                    source_shape=str(WATSON.SemanticMappingGovernanceShape),
                    constraint_component="sh:HasValueConstraintComponent",
                    value="CONFLICT",
                    message=f"Entity '{ent.get('mention') or ent.get('canonical_name')}' has a CONFLICT mapping state and cannot be approved without reconciliation.",
                    explanation=ent.get("conflict_notes") or f"Semantic mapping conflict detected on '{ent_uri}'. Resolve or merge before approval.",
                )
            elif m_status == "UNRESOLVED" and ent.get("required_resolution", False):
                add_violation(
                    focus_node=str(ent_uri),
                    result_path=str(WATSON.mappingStatus),
                    source_shape=str(WATSON.SemanticMappingGovernanceShape),
                    constraint_component="sh:MinCountConstraintComponent",
                    value="UNRESOLVED",
                    message=f"Required entity '{ent.get('mention')}' is UNRESOLVED and lacks an authorized canonical URI.",
                    explanation=f"Entity mention '{ent.get('mention')}' ({ent.get('entity_type')}) could not be resolved to an ontology concept or approved mapping.",
                )
            elif m_status in ("PROPOSED", "UNRESOLVED"):
                add_warning(
                    focus_node=str(ent_uri),
                    result_path=str(WATSON.mappingStatus),
                    source_shape=str(WATSON.SemanticMappingGovernanceShape),
                    constraint_component="sh:InfoConstraintComponent",
                    value=str(m_status),
                    message=f"Entity '{ent.get('mention') or ent.get('canonical_name')}' has mapping status '{m_status}'.",
                    explanation="Proposed or provisional mappings require human review confirmation before treated as authoritative.",
                )

        affected_resources = sorted({v["focus_node"] for v in violations})
        violated_shapes = sorted({v["source_shape"] for v in violations})
        explanations = [v["explanation"] for v in violations]
        conforms = len(violations) == 0

        return {
            "report_id": f"shacl_rep_{uuid.uuid4().hex[:10]}",
            "candidate_id": candidate_id,
            "candidate_version": candidate_version,
            "candidate_content_hash": candidate_hash,
            "shacl_shapes_version": shapes_info["version"],
            "shacl_shapes_hash": shapes_info["sha256"],
            "trusted_graph_version": trusted_info["version"],
            "trusted_graph_hash": trusted_info["sha256"],
            "validation_timestamp": _utc_now(),
            "conforms": conforms,
            "status": "CONFORMING" if conforms else "NON_CONFORMING",
            "is_stale": False,
            "violation_count": len(violations),
            "warning_count": len(warnings),
            "violations": violations,
            "warnings": warnings,
            "affected_resources": affected_resources,
            "violated_shapes": violated_shapes,
            "explanations": explanations,
            "cross_graph_references_resolved": cross_graph_resolved,
            "integrated_context_summary": {
                "candidate_triples_count": len(cand_g),
                **context_meta,
                "cross_graph_references_resolved_count": len(cross_graph_resolved),
            },
        }
