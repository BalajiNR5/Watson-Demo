from __future__ import annotations

import json
import logging
import os
import re
import shutil
import sys
import tempfile
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

_BACKEND_DIR = Path(__file__).resolve().parent.parent
if str(_BACKEND_DIR) not in sys.path:
    sys.path.insert(0, str(_BACKEND_DIR))
_ROOT_DIR = _BACKEND_DIR.parent
if str(_ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(_ROOT_DIR))
for _sub in (
    _BACKEND_DIR / "watson" / "semantics",
    _BACKEND_DIR / "watson" / "ingestion",
    _BACKEND_DIR / "watson" / "governance",
    _BACKEND_DIR / "_compat_shims",
):
    if _sub.is_dir() and str(_sub) not in sys.path:
        sys.path.append(str(_sub))

from fastapi import Cookie, Depends, FastAPI, File, Header, HTTPException, Query, Request, Response, UploadFile
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from starlette.middleware.trustedhost import TrustedHostMiddleware

from app.security.auth import (
    MAX_UPLOAD_BYTES,
    create_session_token,
    extract_authenticated_user,
    get_effective_permissions,
    is_authorized_ingestion_admin,
    require_ingestion_admin,
    resolve_user_from_registry,
    validate_and_sanitize_upload,
    verify_password_pbkdf2,
)
from watson.governance.abac_engine import evaluate_access, load_lifecycle_store, load_user_registry
from watson.ingestion.databricks_metadata_ingestor import (
    DEFAULT_FIXTURE_PATH,
    DatabricksProductMetadataIngestor,
    MetadataIngestionError,
)
from watson.ingestion.ingestion_coordinator import IngestionCoordinator
from watson.retrieval.graphrag_assembler import GraphRAGAssembler
from watson.retrieval.guardrails import WatsonGuardrails
from watson.retrieval.qwen_interface import QwenInterface
from watson.semantics.candidate_governance_service import CandidateGovernanceService
from watson.semantics.graph_explorer_service import GraphExplorerService
from watson.semantics.metadata_compatibility import SemanticCompatibilityEngine
from watson.shared.audit import log_audit_event, query_audit_logs
from watson.shared.config import (
    CHUNK_URI_MAP_FILE,
    FIXTURES_DATA_DIR,
    LIFECYCLE_STORE_FILE,
    PHARMA_KG_FILE,
    PHARMA_KG_INFERRED_FILE,
    RAW_DATA_DIR,
    STORES_DATA_DIR,
    USER_REGISTRY_FILE,
)
from watson.shared.exceptions import ABACAccessDeniedError, DedupError, LifecycleViolationError, ParsingError
from watson.spaces.knowledge_space import KnowledgeSpaceManager

logger = logging.getLogger("watson.api")

app = FastAPI(
    title="Watson Pharma Knowledge Intelligence Platform API",
    version="2.1.0",
    description="PRD-aligned governed ingestion, Databricks MVM dynamic metadata, semantic ontology, and GraphRAG API",
)

# Production UI and API share one loopback origin; allow testserver for in-process FastAPI TestClient.
app.add_middleware(
    TrustedHostMiddleware,
    allowed_hosts=["127.0.0.1", "localhost", "[::1]", "testserver", "watson.local"],
)

# Global services
coordinator = IngestionCoordinator()
assembler = GraphRAGAssembler()
qwen = QwenInterface()
guardrails = WatsonGuardrails()
space_manager = KnowledgeSpaceManager()
metadata_ingestor = DatabricksProductMetadataIngestor()
compatibility_engine = SemanticCompatibilityEngine()
graph_explorer_service = GraphExplorerService()
candidate_governance = CandidateGovernanceService(coordinator=coordinator, assembler=assembler)

# Initialize Databricks Product MVM catalog, compatibility report, and Layer 2 overlay at startup
try:
    graph_explorer_service.ensure_artifacts_exist()
    compatibility_engine.sync_layer2_graph_overlay(assembler.graph)
except Exception as _init_exc:
    logger.warning("Initial Databricks metadata bootstrap warning: %s", _init_exc)

# Active persona state for non-ingestion UI read sessions
CURRENT_USER_ID = "D4"


# ---------------------------------------------------------------------------
# Request & Response Schemas
# ---------------------------------------------------------------------------

class SwitchPersonaRequest(BaseModel):
    user_id: str


class LoginRequest(BaseModel):
    user_id: str
    password: Optional[str] = None
    bootstrap_token: Optional[str] = None


class FileImportRequest(BaseModel):
    filename: Optional[str] = None
    source_filename: Optional[str] = None


class RetryIngestionRequest(BaseModel):
    document_uri: str


class DatabricksIngestRequest(BaseModel):
    source_url: Optional[str] = None
    fixture_name: Optional[str] = None
    fixture_path: Optional[str] = None
    prefer_remote: bool = False
    allow_fixture_fallback: bool = True


class SearchRequest(BaseModel):
    query: str
    top_k: int = 5
    therapeutic_area: Optional[str] = None


class ChatRequest(BaseModel):
    query: str
    top_k: int = 5


class ReviewRequest(BaseModel):
    document_uri: str
    decision: str  # APPROVE or REJECT
    review_note: str = ""
    pii_override: bool = False
    sensitivity_level: Optional[str] = None
    allowed_therapeutic_areas: Optional[List[str]] = None
    allowed_geographies: Optional[List[str]] = None
    expiry_date: Optional[str] = None
    expected_version: Optional[int] = None


class SparqlRequest(BaseModel):
    query: str


class FeedbackRequest(BaseModel):
    correlation_id: str
    rating: int
    comment: str = ""


class CandidateEditRequest(BaseModel):
    add_triples: Optional[List[Dict[str, Any]]] = None
    remove_triples: Optional[List[Dict[str, Any]]] = None
    replace_triples: Optional[List[Dict[str, Any]]] = None
    update_entities: Optional[List[Dict[str, Any]]] = None
    reason: str = "Semantic edit during HITL governance review"
    expected_version: Optional[int] = None
    idempotency_key: Optional[str] = None


class CandidateMergeRequest(BaseModel):
    source_entity_uri: str
    target_entity_uri: str
    target_canonical_name: Optional[str] = None
    reason: str = "Entity merge during HITL reconciliation"
    expected_version: Optional[int] = None
    idempotency_key: Optional[str] = None


class CandidateQuarantineRequest(BaseModel):
    reason: str
    triggering_issue: str = "VALIDATION_OR_GOVERNANCE_POLICY"
    expected_version: Optional[int] = None


class CandidateRequestEvidenceRequest(BaseModel):
    request_note: str
    requested_fields: Optional[List[str]] = None
    expected_version: Optional[int] = None
    idempotency_key: Optional[str] = None


class CandidateSubmitEvidenceRequest(BaseModel):
    evidence_text: str
    source_reference: str = "Supplemental Clinical Dossier"
    source_document_uri: Optional[str] = None
    document_version: Optional[str] = None
    chunk_or_page_ref: Optional[str] = None
    evidence_type: Optional[str] = None
    sensitivity_level: Optional[str] = None
    additional_triples: Optional[List[Dict[str, Any]]] = None
    expected_version: Optional[int] = None
    idempotency_key: Optional[str] = None


class CandidateDecisionRequest(BaseModel):
    reason: str = ""
    expected_version: Optional[int] = None
    review_note: str = "Approved during HITL governance review"
    pii_override: bool = False
    sensitivity_level: Optional[str] = None
    allowed_therapeutic_areas: Optional[List[str]] = None
    allowed_geographies: Optional[List[str]] = None
    expiry_date: Optional[str] = None


class CandidatePublishRequest(BaseModel):
    transaction_id: Optional[str] = None
    simulate_failure: bool = False


class PublicationRollbackRequest(BaseModel):
    reason: str = "Controlled rollback by administrator"


class HitlDocumentDecisionRequest(BaseModel):
    decision: str
    review_note: str = ""
    pii_override: bool = False
    dedup_disposition: Optional[str] = None
    sensitivity_level: Optional[str] = None
    allowed_therapeutic_areas: Optional[List[str]] = None
    allowed_geographies: Optional[List[str]] = None
    expiry_date: Optional[str] = None
    requested_evidence_fields: Optional[List[str]] = None
    evidence_text: Optional[str] = None
    source_reference: Optional[str] = None


class StageReleaseRequest(BaseModel):
    simulate_staging_failure: bool = False


class WithdrawPublicationRequest(BaseModel):
    reason: str = "Controlled release withdrawal by administrator"
    mode: str = "WITHDRAWN"



# ---------------------------------------------------------------------------
# Security & Auth Helpers
# ---------------------------------------------------------------------------

def get_current_user(
    request: Request,
    authorization: Optional[str] = Header(None),
    x_watson_session: Optional[str] = Header(None),
    x_user_id: Optional[str] = Header(None),
    x_csrf_token: Optional[str] = Header(None),
    watson_session: Optional[str] = Cookie(None),
) -> Dict[str, Any]:
    """
    Resolves user identity for general platform features (Copilot, Library,
    SPARQL Studio, KG Explorer). Never escalates an unknown user ID to Admin.
    Protected ingestion routes do NOT use this fallback—they require
    `Depends(require_ingestion_admin)`.
    """
    return extract_authenticated_user(
        request=request,
        authorization=authorization,
        x_watson_session=x_watson_session,
        x_user_id=x_user_id,
        x_csrf_token=x_csrf_token,
        watson_session=watson_session,
        require_explicit_auth=False,
        fallback_user_id=CURRENT_USER_ID,
    )


# ---------------------------------------------------------------------------
# Health & Authentication Endpoints
# ---------------------------------------------------------------------------

@app.get("/api/health")
def health():
    return {
        "status": "healthy",
        "platform": "Watson Pharma Knowledge Intelligence Platform",
        "version": "2.1.0",
        "qwen_status": "ONLINE" if qwen.is_loaded else "BLOCKED",
        "primary_llm": qwen.model_name,
        "llm_transport": "OLLAMA",
        "ollama_url": qwen.ollama_url,
        "easy_setup_root": str(_ROOT_DIR),
        "blocked_reason": qwen.blocked_reason if not qwen.is_loaded else None,
        "current_active_user": CURRENT_USER_ID,
        "ingestion_access_policy": "ADMIN_ONLY",
    }


@app.get("/api/auth/current")
def current_user(user: Dict[str, Any] = Depends(get_current_user)):
    session_bundle = create_session_token(
        user_id=user["user_id"],
        role=user["role"],
        permissions=user.get("permissions", []),
    )
    out = dict(user)
    out["session_token"] = session_bundle["access_token"]
    out["csrf_token"] = session_bundle["csrf_token"]
    return out


@app.get("/api/auth/personas")
def list_personas():
    reg = load_user_registry(USER_REGISTRY_FILE)
    users = reg.get("users", {})
    roles = reg.get("roles", {})
    result = []
    for uid, uinfo in users.items():
        perms = get_effective_permissions(uid, uinfo, roles)
        item = dict(uinfo)
        item["permissions"] = perms
        item["can_ingest"] = uinfo.get("role") == "ADMIN" or "documents:ingest" in perms
        result.append(item)
    return result


@app.post("/api/auth/login")
def login(req: LoginRequest, response: Response):
    """
    Authenticates a user or administrator session and issues a cryptographically
    signed HMAC-SHA256 Bearer token and CSRF-protected HTTP-only cookie.
    """
    uid = (req.user_id or "").strip()
    reg = load_user_registry(USER_REGISTRY_FILE)
    users = reg.get("users", {})
    if uid not in users:
        log_audit_event(
            event_type="AUTH_LOGIN_FAILURE",
            user_id=uid or "UNKNOWN",
            message=f"Login failed: unknown user '{uid}'",
        )
        raise HTTPException(status_code=401, detail="Invalid credentials.")

    user_obj = resolve_user_from_registry(uid, authenticated=True, auth_method="login")

    # If WATSON_ADMIN_PASSWORD_HASH or WATSON_ADMIN_BOOTSTRAP_TOKEN is configured in env,
    # require password/token verification when authenticating as an administrator.
    admin_pw_hash = os.environ.get("WATSON_ADMIN_PASSWORD_HASH", "").strip()
    admin_bootstrap = os.environ.get("WATSON_ADMIN_BOOTSTRAP_TOKEN", "").strip()
    if user_obj["can_ingest"] and (admin_pw_hash or admin_bootstrap):
        pw_ok = bool(admin_pw_hash and req.password and verify_password_pbkdf2(req.password, admin_pw_hash))
        tok_ok = bool(admin_bootstrap and req.bootstrap_token and req.bootstrap_token == admin_bootstrap)
        if not (pw_ok or tok_ok):
            log_audit_event(
                event_type="AUTH_LOGIN_FAILURE",
                user_id=uid,
                message=f"Administrator login rejected for '{uid}': invalid password or bootstrap token.",
            )
            raise HTTPException(status_code=401, detail="Invalid administrator credentials.")

    session_bundle = create_session_token(
        user_id=uid,
        role=user_obj["role"],
        permissions=user_obj["permissions"],
    )
    response.set_cookie(
        key="watson_session",
        value=session_bundle["access_token"],
        httponly=True,
        samesite="strict",
        max_age=DEFAULT_SESSION_TTL_SECONDS if "DEFAULT_SESSION_TTL_SECONDS" in globals() else 28800,
    )
    log_audit_event(
        event_type="AUTH_LOGIN_SUCCESS",
        user_id=uid,
        message=f"User '{uid}' ({user_obj['role']}) authenticated via /api/auth/login.",
        metadata={"role": user_obj["role"], "can_ingest": user_obj["can_ingest"]},
    )
    user_out = dict(user_obj)
    user_out["session_token"] = session_bundle["access_token"]
    user_out["csrf_token"] = session_bundle["csrf_token"]
    return {
        "status": "authenticated",
        "access_token": session_bundle["access_token"],
        "token_type": "Bearer",
        "csrf_token": session_bundle["csrf_token"],
        "expires_at": session_bundle["expires_at"],
        "current_user": user_out,
    }


@app.post("/api/auth/logout")
def logout(response: Response, user: Dict[str, Any] = Depends(get_current_user)):
    response.delete_cookie("watson_session")
    log_audit_event(
        event_type="AUTH_LOGOUT",
        user_id=user["user_id"],
        message=f"User '{user['user_id']}' logged out.",
    )
    return {"status": "logged_out"}


@app.post("/api/auth/switch")
def switch_persona(req: SwitchPersonaRequest, response: Response):
    global CURRENT_USER_ID
    reg = load_user_registry(USER_REGISTRY_FILE)
    if req.user_id not in reg.get("users", {}):
        raise HTTPException(status_code=400, detail=f"Unknown persona: {req.user_id}")
    CURRENT_USER_ID = req.user_id
    user_obj = resolve_user_from_registry(CURRENT_USER_ID, authenticated=True, auth_method="persona_switch")
    session_bundle = create_session_token(
        user_id=CURRENT_USER_ID,
        role=user_obj["role"],
        permissions=user_obj["permissions"],
    )
    user_out = dict(user_obj)
    user_out["session_token"] = session_bundle["access_token"]
    user_out["csrf_token"] = session_bundle["csrf_token"]
    return {
        "status": "switched",
        "access_token": session_bundle["access_token"],
        "csrf_token": session_bundle["csrf_token"],
        "current_user": user_out,
    }


# ---------------------------------------------------------------------------
# Document Library Endpoints (Accessible per ABAC Permissions)
# ---------------------------------------------------------------------------

@app.get("/api/documents")
def list_documents(user: Dict[str, Any] = Depends(get_current_user)):
    """Lists all documents filtered by user's ABAC permissions."""
    store = load_lifecycle_store(LIFECYCLE_STORE_FILE)
    accessible = []
    for doc_uri, record in store.items():
        allowed, _, _ = evaluate_access(
            user_id=user["user_id"],
            document_uri=doc_uri,
            user_registry_path=USER_REGISTRY_FILE,
            lifecycle_store_path=LIFECYCLE_STORE_FILE,
        )
        if allowed:
            accessible.append(record)
    return accessible


# ---------------------------------------------------------------------------
# Protected Administrator-Only Ingestion Console & Document Upload Endpoints
# ---------------------------------------------------------------------------

@app.get("/api/ingestion/console")
def get_ingestion_console_status(admin_user: Dict[str, Any] = Depends(require_ingestion_admin)):
    """
    Protected backend endpoint backing the Ingestion Console view.
    Only authenticated administrators (role=ADMIN / permission=documents:ingest)
    may access this endpoint.
    """
    pending = coordinator.pending_documents(admin_user)
    recent_uploads = query_audit_logs(event_type="INGESTION_UPLOAD_SUCCESS", limit=15)
    databricks_summary = None
    if metadata_ingestor.summary_path.exists():
        try:
            databricks_summary = json.loads(metadata_ingestor.summary_path.read_text(encoding="utf-8"))
        except Exception:
            databricks_summary = None

    return {
        "status": "AUTHORIZED",
        "authorized": True,
        "role": admin_user["role"],
        "max_upload_mb": MAX_UPLOAD_BYTES // (1024 * 1024),
        "console": "Watson Governed Document & Metadata Ingestion Console",
        "authorized_admin": {
            "user_id": admin_user["user_id"],
            "name": admin_user["name"],
            "role": admin_user["role"],
            "permissions": admin_user.get("permissions", []),
            "auth_method": admin_user.get("auth_method"),
        },
        "upload_policy": {
            "allowed_extensions": [".pdf", ".docx", ".pptx", ".txt"],
            "max_upload_bytes": MAX_UPLOAD_BYTES,
            "deduplication": "SHA-256 3-tier content & title deduplication",
            "pii_scanning": "Automated regex + NLP PII redaction and HITL gate",
        },
        "pending_review_count": len(pending),
        "databricks_metadata_summary": databricks_summary,
        "databricks_ingestion_summary": databricks_summary,
        "recent_upload_events": recent_uploads,
        "operational_metrics": candidate_governance.get_operational_metrics(),
        "candidates": candidate_governance.list_candidates(),
    }


def _stage_uploaded_bytes(
    raw_filename: Optional[str],
    file_bytes: bytes,
    admin_user: Dict[str, Any],
    operation_name: str = "UPLOAD_DOCUMENT",
) -> Dict[str, Any]:
    """Internal helper executing upload safeguards, staging, and audit logging."""
    actor_id = admin_user["user_id"]
    log_audit_event(
        event_type="INGESTION_UPLOAD_ATTEMPT",
        user_id=actor_id,
        message=f"Administrator '{actor_id}' initiated {operation_name} for '{raw_filename}'",
        metadata={
            "actor_id": actor_id,
            "operation": operation_name,
            "raw_filename": raw_filename,
            "size_bytes": len(file_bytes),
        },
    )
    try:
        safe_filename, _ = validate_and_sanitize_upload(raw_filename, file_bytes, max_bytes=MAX_UPLOAD_BYTES)
        with tempfile.TemporaryDirectory(prefix="watson-upload-") as incoming:
            incoming_dir = Path(incoming).resolve()
            target = (incoming_dir / safe_filename).resolve()
            if not target.is_relative_to(incoming_dir):
                raise HTTPException(status_code=400, detail="Invalid upload storage path.")
            target.write_bytes(file_bytes)
            staged = coordinator.stage_file(target, actor_id=actor_id)
            try:
                if isinstance(staged, dict) and staged.get("document_uri") and staged.get("governed_chunks"):
                    cand_info = candidate_governance.get_candidate(staged["document_uri"])
                    staged["candidate_id"] = cand_info["candidate_id"]
                    staged["batch_id"] = cand_info["batch_id"]
                    staged["graph_version"] = cand_info["graph_version"]
                    staged["content_hash"] = cand_info["content_hash"]
                    staged["candidate_lifecycle_state"] = cand_info["candidate_lifecycle_state"]
                    staged["publication_lifecycle_state"] = cand_info["publication_lifecycle_state"]
                    staged["shacl_report"] = cand_info["shacl_report"]
                    staged["pipeline_stages"] = cand_info["pipeline_stages"]
            except Exception:
                pass
            log_audit_event(
                event_type="INGESTION_UPLOAD_SUCCESS",
                user_id=actor_id,
                document_uri=staged.get("document_uri"),
                message=f"Administrator '{actor_id}' staged document '{safe_filename}' ({staged.get('document_uri')})",
                metadata={
                    "actor_id": actor_id,
                    "operation": operation_name,
                    "outcome": "SUCCESS",
                    "document_uri": staged.get("document_uri"),
                    "doc_id": staged.get("doc_id"),
                    "source_filename": safe_filename,
                    "duplicate_upload": bool(staged.get("duplicate_upload")),
                },
            )
            return staged
    except HTTPException as http_exc:
        log_audit_event(
            event_type="INGESTION_UPLOAD_FAILURE",
            user_id=actor_id,
            message=f"Upload rejected ({http_exc.status_code}): {http_exc.detail}",
            metadata={
                "actor_id": actor_id,
                "operation": operation_name,
                "outcome": f"REJECTED_{http_exc.status_code}",
                "reason": str(http_exc.detail),
            },
        )
        raise
    except DedupError as exc:
        log_audit_event(
            event_type="INGESTION_UPLOAD_FAILURE",
            user_id=actor_id,
            message=f"Upload rejected (409 Duplicate): {exc}",
            metadata={
                "actor_id": actor_id,
                "operation": operation_name,
                "outcome": "REJECTED_409_DUPLICATE",
                "reason": str(exc),
            },
        )
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except (ParsingError, ValueError) as exc:
        log_audit_event(
            event_type="INGESTION_UPLOAD_FAILURE",
            user_id=actor_id,
            message=f"Upload rejected (400 Parse/Validation): {exc}",
            metadata={
                "actor_id": actor_id,
                "operation": operation_name,
                "outcome": "REJECTED_400_PARSE",
                "reason": str(exc),
            },
        )
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        logger.exception("Document staging failed")
        log_audit_event(
            event_type="INGESTION_UPLOAD_FAILURE",
            user_id=actor_id,
            message="Upload failed due to internal staging error.",
            metadata={
                "actor_id": actor_id,
                "operation": operation_name,
                "outcome": "FAILED_500",
            },
        )
        raise HTTPException(
            status_code=500,
            detail="Staging failed. Retry to reopen an existing pending review or try the upload again.",
        ) from exc


@app.post("/api/ingestion/upload")
def upload_document(
    file: UploadFile = File(...),
    admin_user: Dict[str, Any] = Depends(require_ingestion_admin),
):
    """
    Administrator-only single document upload endpoint.
    Enforces server-side authentication, ADMIN / documents:ingest authorization,
    filename & path traversal validation, size limits, and audit logging.
    """
    chunks: List[bytes] = []
    size = 0
    while block := file.file.read(1024 * 1024):
        size += len(block)
        if size > MAX_UPLOAD_BYTES:
            log_audit_event(
                event_type="INGESTION_UPLOAD_FAILURE",
                user_id=admin_user["user_id"],
                message=f"Upload rejected (413): exceeded {MAX_UPLOAD_BYTES} bytes limit.",
                metadata={"actor_id": admin_user["user_id"], "operation": "UPLOAD_DOCUMENT", "outcome": "REJECTED_413"},
            )
            raise HTTPException(status_code=413, detail="Upload limit is 50 MB.")
        chunks.append(block)
    file_bytes = b"".join(chunks)
    return _stage_uploaded_bytes(file.filename, file_bytes, admin_user, operation_name="UPLOAD_DOCUMENT")


@app.post("/api/ingestion/upload/batch")
def upload_documents_batch(
    files: List[UploadFile] = File(...),
    admin_user: Dict[str, Any] = Depends(require_ingestion_admin),
):
    """
    Administrator-only batch document upload endpoint.
    """
    if not files:
        raise HTTPException(status_code=400, detail="No files provided for batch upload.")
    if len(files) > 20:
        raise HTTPException(status_code=400, detail="Batch upload is limited to 20 files per request.")

    results = []
    for f in files:
        data = f.file.read(MAX_UPLOAD_BYTES + 1)
        if len(data) > MAX_UPLOAD_BYTES:
            raise HTTPException(status_code=413, detail=f"File '{f.filename}' exceeds 50 MB limit.")
        staged = _stage_uploaded_bytes(f.filename, data, admin_user, operation_name="BATCH_UPLOAD_DOCUMENT")
        results.append(staged)
    return {"status": "BATCH_STAGED", "count": len(results), "succeeded": len(results), "failed": 0, "staged_documents": results}


@app.post("/api/ingestion/import")
def import_corpus_file(
    req: FileImportRequest,
    admin_user: Dict[str, Any] = Depends(require_ingestion_admin),
):
    """
    Administrator-only local corpus import endpoint.
    Strictly confines file lookup to `data/raw` and rejects path traversal.
    """
    raw_name = (req.filename or req.source_filename or "").strip()
    if not raw_name or "/" in raw_name or "\\" in raw_name or ".." in raw_name:
        raise HTTPException(status_code=400, detail="Invalid filename for corpus import.")
    candidate = (RAW_DATA_DIR / raw_name).resolve()
    if not candidate.is_relative_to(RAW_DATA_DIR.resolve()) or not candidate.is_file():
        raise HTTPException(status_code=404, detail=f"Approved source file '{raw_name}' not found in raw corpus directory.")
    file_bytes = candidate.read_bytes()
    return _stage_uploaded_bytes(candidate.name, file_bytes, admin_user, operation_name="IMPORT_CORPUS_DOCUMENT")


@app.post("/api/ingestion/retry")
def retry_staged_ingestion(
    req: RetryIngestionRequest,
    admin_user: Dict[str, Any] = Depends(require_ingestion_admin),
):
    """
    Administrator-only endpoint to retry/reprocess a staged document.
    """
    pending = coordinator.pending_documents(admin_user)
    match = next((d for d in pending if d.get("document_uri") == req.document_uri), None)
    if not match:
        raise HTTPException(status_code=404, detail=f"Pending staged document '{req.document_uri}' not found.")
    log_audit_event(
        event_type="INGESTION_UPLOAD_SUCCESS",
        user_id=admin_user["user_id"],
        document_uri=req.document_uri,
        message=f"Administrator '{admin_user['user_id']}' reopened staged document '{req.document_uri}' for review.",
        metadata={"actor_id": admin_user["user_id"], "operation": "RETRY_INGESTION", "outcome": "SUCCESS"},
    )
    return match


@app.post("/api/ingestion/databricks/ingest")
def trigger_databricks_metadata_ingestion(
    req: Optional[DatabricksIngestRequest] = None,
    admin_user: Dict[str, Any] = Depends(require_ingestion_admin),
):
    """
    Administrator-only endpoint to trigger dynamic ingestion of the Databricks
    Pharmaceuticals Product MVM model, regenerate semantic compatibility mappings,
    and incrementally sync the Layer 2 RDF graph overlay.
    """
    req_data = req or DatabricksIngestRequest()
    fixture_path: Optional[Path] = None
    raw_fname = req_data.fixture_name or req_data.fixture_path
    if raw_fname:
        fname = raw_fname.strip()
        if fname in {"v1", "default", "databricks_pharmaceuticals_v1_mvm_model.json"}:
            fixture_path = DEFAULT_FIXTURE_PATH
        elif fname in {"v1.1", "v1.1-fixture", "databricks_pharmaceuticals_v1_1_mvm_fixture.json"}:
            fixture_path = FIXTURES_DATA_DIR / "databricks_pharmaceuticals_v1_1_mvm_fixture.json"
        else:
            cand = (FIXTURES_DATA_DIR / Path(fname).name).resolve()
            if not cand.is_relative_to(FIXTURES_DATA_DIR.resolve()) or not cand.is_file():
                raise HTTPException(status_code=400, detail=f"Unknown or invalid fixture name: {fname}")
            fixture_path = cand

    try:
        summary = metadata_ingestor.ingest(
            source_url=req_data.source_url,
            fixture_path=fixture_path,
            allow_fixture_fallback=req_data.allow_fixture_fallback,
            actor_id=admin_user["user_id"],
        )
        mapping_rep = compatibility_engine.generate_mappings(actor_id=admin_user["user_id"])
        layer2_sync = compatibility_engine.sync_layer2_graph_overlay(assembler.graph)
        explorer_payload = graph_explorer_service.build_explorer_payload(assembler.graph)
        return {
            "status": "SUCCESS",
            "ingestion_summary": summary,
            "mapping_summary": mapping_rep["summary_counts"],
            "layer2_sync": layer2_sync,
            "explorer_counts": explorer_payload["counts"],
        }
    except MetadataIngestionError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.get("/api/ingestion/pending")
def pending_documents(user: Dict[str, Any] = Depends(get_current_user)):
    return coordinator.pending_documents(user)


@app.post("/api/ingestion/review")
def review_document(req: ReviewRequest, user: Dict[str, Any] = Depends(get_current_user)):
    """Reviews a staged document and activates it upon approval."""
    try:
        gov_store = candidate_governance._load_gov_store()
        cand_id = f"cand:{req.document_uri.replace('watson:', '')}"
        tracked_cand = gov_store.get("candidates", {}).get(cand_id)
        if tracked_cand is not None or req.expected_version is not None:
            if req.decision == "APPROVE":
                candidate_governance.approve_candidate(
                    candidate_id=req.document_uri,
                    user=user,
                    expected_version=req.expected_version,
                    review_note=req.review_note,
                    pii_override=req.pii_override,
                    sensitivity_level=req.sensitivity_level,
                    allowed_ta=req.allowed_therapeutic_areas,
                    allowed_geo=req.allowed_geographies,
                    expiry_date=req.expiry_date,
                )
        result = coordinator.review_and_activate(
            doc_uri=req.document_uri,
            reviewer_id=user["user_id"],
            reviewer_role=user["role"],
            decision=req.decision,
            review_note=req.review_note,
            pii_override=req.pii_override,
            sensitivity_level=req.sensitivity_level,
            allowed_ta=req.allowed_therapeutic_areas,
            allowed_geo=req.allowed_geographies,
            expiry_date=req.expiry_date,
        )
        if result.get("status") == "ACTIVE":
            assembler.index_manager._load_index_and_map()
            assembler._load_graph()
            compatibility_engine.sync_layer2_graph_overlay(assembler.graph)
            try:
                candidate_governance.sync_all_staged_candidates()
            except Exception:
                pass
        elif result.get("status") == "REJECTED" and tracked_cand is not None:
            try:
                candidate_governance.reject_candidate(req.document_uri, reason=req.review_note, user=user)
            except Exception:
                pass
        return result
    except ABACAccessDeniedError as e:
        raise HTTPException(status_code=403, detail=str(e))
    except (LifecycleViolationError, ValueError) as e:
        msg = str(e)
        if "STALE_CANDIDATE_VERSION" in msg:
            raise HTTPException(status_code=409, detail=msg)
        raise HTTPException(status_code=400, detail=msg)


@app.post("/api/documents/{doc_id}/archive")
def archive_document(doc_id: str, user: Dict[str, Any] = Depends(get_current_user)):
    if user.get("role") not in ("ADMIN", "SPOC", "COMPLIANCE_OFFICER"):
        raise HTTPException(status_code=403, detail="Only ADMIN, SPOC, or COMPLIANCE_OFFICER roles may archive documents.")
    doc_uri = f"watson:Doc_{doc_id}" if not doc_id.startswith("watson:") else doc_id
    try:
        res = coordinator.archive_document(doc_uri, user_id=user["user_id"])
        return res
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/api/documents/{doc_id}/reinstate")
def reinstate_document(doc_id: str, user: Dict[str, Any] = Depends(get_current_user)):
    if user.get("role") not in ("ADMIN", "SPOC", "COMPLIANCE_OFFICER"):
        raise HTTPException(status_code=403, detail="Only ADMIN, SPOC, or COMPLIANCE_OFFICER roles may reinstate documents.")
    doc_uri = f"watson:Doc_{doc_id}" if not doc_id.startswith("watson:") else doc_id
    try:
        res = coordinator.reinstate_document(doc_uri, user_id=user["user_id"])
        return res
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


# ---------------------------------------------------------------------------
# Visual Graph Explorer, Data Catalog & Semantic Mapping Endpoints
# ---------------------------------------------------------------------------

@app.get("/api/graph/explorer")
def get_graph_explorer_data(user: Dict[str, Any] = Depends(get_current_user)):
    """
    Returns the unified Visual Graph Explorer, Data Catalog, and Semantic Mapping
    payload driven by actual generated Databricks Product MVM artifacts and
    Watson's Layer 2 Semantic Graph. Accessible to all authenticated users.
    """
    return graph_explorer_service.build_explorer_payload(assembler.graph)


@app.post("/api/graph/explorer/refresh")
def refresh_graph_explorer_data(
    req: Optional[DatabricksIngestRequest] = None,
    user: Dict[str, Any] = Depends(get_current_user),
):
    """
    Reloads the Visual Graph Explorer from generated artifacts.
    If `fixture_name` or `source_url` is provided to trigger a re-ingestion,
    verifies that the caller is an authorized administrator (`can_ingest`).
    Preserves the last-known-good graph view if refresh fails.
    """
    raw_ref_fname = (req.fixture_name or req.fixture_path) if req else None
    if not raw_ref_fname and req is not None and not req.source_url and is_authorized_ingestion_admin(user):
        raw_ref_fname = "v1"
    if req and (raw_ref_fname or req.source_url):
        if not is_authorized_ingestion_admin(user):
            raise HTTPException(
                status_code=403,
                detail="Only administrators may trigger a new model ingestion during graph refresh.",
            )
        fname = raw_ref_fname.strip() if raw_ref_fname else None
        fpath = None
        if fname in {"v1", "default", "databricks_pharmaceuticals_v1_mvm_model.json"}:
            fpath = DEFAULT_FIXTURE_PATH
        elif fname in {"v1.1", "v1.1-fixture", "databricks_pharmaceuticals_v1_1_mvm_fixture.json"}:
            fpath = FIXTURES_DATA_DIR / "databricks_pharmaceuticals_v1_1_mvm_fixture.json"
        elif fname:
            cand = (FIXTURES_DATA_DIR / Path(fname).name).resolve()
            if not cand.is_relative_to(FIXTURES_DATA_DIR.resolve()) or not cand.is_file():
                # Preserve LKG view and return error detail
                lkg = graph_explorer_service._last_known_good_payload
                raise HTTPException(
                    status_code=400,
                    detail=f"Refresh failed: fixture '{fname}' not found. Last-known-good graph preserved ({lkg['counts']['total_nodes'] if lkg else 0} nodes).",
                )
            fpath = cand

        try:
            metadata_ingestor.ingest(
                source_url=req.source_url,
                fixture_path=fpath,
                allow_fixture_fallback=req.allow_fixture_fallback,
                actor_id=user["user_id"],
            )
            compatibility_engine.generate_mappings(actor_id=user["user_id"])
            compatibility_engine.sync_layer2_graph_overlay(assembler.graph)
        except Exception as exc:
            raise HTTPException(
                status_code=400,
                detail=f"Refresh failed ({exc}). Last-known-good graph view preserved.",
            ) from exc

    payload = graph_explorer_service.build_explorer_payload(assembler.graph)
    log_audit_event(
        event_type="GRAPH_EXPLORER_REFRESH",
        user_id=user["user_id"],
        message=f"Graph Explorer refreshed (version={payload['model_identity'].get('version')}, nodes={payload['counts']['total_nodes']}).",
        metadata=payload["counts"],
    )
    ref_state = payload.get("refresh_state", {})
    out = dict(payload)
    out["explorer"] = payload
    out["last_successful_refresh"] = ref_state.get("last_successful_refresh")
    out["source_version"] = ref_state.get("source_version")
    out["diff_summary"] = ref_state.get("diff_summary")
    out["used_last_known_good"] = ref_state.get("used_last_known_good", False)
    return out


@app.get("/api/graph/catalog")
def get_databricks_catalog(user: Dict[str, Any] = Depends(get_current_user)):
    """Returns the generated Databricks Pharmaceuticals Product MVM catalog and ingestion summary."""
    graph_explorer_service.ensure_artifacts_exist()
    catalog = json.loads(metadata_ingestor.catalog_path.read_text(encoding="utf-8"))
    summary = json.loads(metadata_ingestor.summary_path.read_text(encoding="utf-8"))
    all_fks = catalog.get("relationships", {}).get("foreign_keys", [])
    products = []
    for p in catalog.get("products", []):
        p_copy = dict(p)
        p_copy.setdefault("canonical_id", p.get("id"))
        p_fks = []
        for fk in all_fks:
            if fk.get("source_product") == p.get("name"):
                p_fks.append({
                    "source_columns": [fk.get("source_column")],
                    "target_product": fk.get("target_product") if fk.get("is_intra_domain") else f"{fk.get('target_domain')}.{fk.get('target_product')}",
                    "target_columns": [fk.get("target_column")],
                    "is_in_scope_target": bool(fk.get("is_intra_domain")),
                })
        p_copy["foreign_keys"] = p_fks
        products.append(p_copy)
    return {"catalog": catalog, "summary": summary, "products": products}


@app.get("/api/graph/mappings")
def get_semantic_mappings(user: Dict[str, Any] = Depends(get_current_user)):
    """Returns the generated semantic compatibility & mapping report."""
    payload = graph_explorer_service.build_explorer_payload(assembler.graph)
    raw_rep = json.loads(compatibility_engine.mapping_output_path.read_text(encoding="utf-8"))
    raw_rep["product_mappings"] = payload.get("product_mappings", raw_rep.get("product_mappings", []))
    raw_rep["attribute_mappings"] = payload.get("attribute_mappings", raw_rep.get("attribute_mappings", []))
    return raw_rep


# ---------------------------------------------------------------------------
# Search & Copilot Endpoints
# ---------------------------------------------------------------------------

@app.post("/api/search")
def search(req: SearchRequest, user: Dict[str, Any] = Depends(get_current_user)):
    """Executes 6-stage monitored retrieval pipeline."""
    res = assembler.retrieve(query=req.query, user_id=user["user_id"], top_k=req.top_k)
    return res.dict()


@app.post("/api/chat")
def chat(req: ChatRequest, user: Dict[str, Any] = Depends(get_current_user)):
    """Executes full GraphRAG answer synthesis with guardrails, citations, and lineage."""
    is_safe, msg = guardrails.check_prompt_injection(req.query)
    if not is_safe:
        log_audit_event(
            event_type="HALLUCINATION_RISK",
            user_id=user["user_id"],
            message=f"Prompt injection blocked: {req.query}",
        )
        raise HTTPException(status_code=400, detail=f"Security violation: {msg}")

    ans = assembler.retrieve_and_synthesize(
        query=req.query,
        user_id=user["user_id"],
        top_k=req.top_k,
    )

    from watson.observability.telemetry import log_telemetry_event
    log_telemetry_event(
        user_id=user["user_id"],
        user_role=user["role"],
        query=req.query,
        route=ans.route.value,
        retrieved_count=len(ans.scored_chunks),
        latency_ms=ans.latency_ms,
        guardrail_status=ans.guardrail_status,
        document_uris_accessed=[c.doc_uri for c in ans.scored_chunks if c.doc_uri],
        correlation_id=ans.correlation_id,
    )

    return {
        "answer_id": ans.answer_id,
        "correlation_id": ans.correlation_id,
        "query": ans.query,
        "route": ans.route.value,
        "answer": ans.answer,
        "citations": [c.dict() for c in ans.citations],
        "scored_chunks": [c.dict() for c in ans.scored_chunks],
        "kg_facts": [f.dict() for f in ans.kg_facts],
        "lineage_records": [l.dict() for l in ans.lineage_records],
        "live_stages": [s.dict() for s in ans.live_stages],
        "guardrail_status": ans.guardrail_status,
        "model_status": ans.model_status,
        "active_provider": ans.active_provider,
        "latency_ms": ans.latency_ms,
        "user_role": user["role"],
        "pipeline_execution_status": ans.pipeline_execution_status,
        "answer_grounding_status": ans.answer_grounding_status,
        "answer_relevance_status": ans.answer_relevance_status,
        "quality_diagnostics": ans.quality_diagnostics,
        "evidence_gap_detected": ans.evidence_gap_detected,
        "evidence_coverage_matrix": ans.evidence_coverage_matrix if isinstance(ans.evidence_coverage_matrix, dict) else (ans.evidence_coverage_matrix.dict() if ans.evidence_coverage_matrix else None),
        "claims": [c.dict() for c in ans.claims],
        "clinical_claim_verified": ans.clinical_claim_verified,
        "conversation_intent": ans.conversation_intent,
    }


@app.get("/api/chat/stream")
def chat_stream(
    query: str = Query(..., description="User question"),
    top_k: int = Query(5, description="Number of chunks"),
    user: Dict[str, Any] = Depends(get_current_user),
):
    """Server-Sent Events (SSE) streaming endpoint for live execution trace."""
    def event_generator():
        ans = assembler.retrieve_and_synthesize(query=query, user_id=user["user_id"], top_k=top_k)
        for stage in ans.live_stages:
            payload = json.dumps({"event": "stage", "stage": stage.dict()})
            yield f"data: {payload}\n\n"
        complete_payload = json.dumps({
            "event": "complete",
            "answer": ans.answer,
            "citations": [c.dict() for c in ans.citations],
            "kg_facts": [f.dict() for f in ans.kg_facts],
            "lineage_records": [l.dict() for l in ans.lineage_records],
            "route": ans.route.value,
            "model_status": ans.model_status,
            "active_provider": ans.active_provider,
            "latency_ms": ans.latency_ms,
            "quality_diagnostics": ans.quality_diagnostics,
            "evidence_coverage_matrix": ans.evidence_coverage_matrix if isinstance(ans.evidence_coverage_matrix, dict) else (ans.evidence_coverage_matrix.dict() if ans.evidence_coverage_matrix else None),
            "claims": [c.dict() for c in ans.claims],
            "clinical_claim_verified": ans.clinical_claim_verified,
            "conversation_intent": ans.conversation_intent,
        })
        yield f"data: {complete_payload}\n\n"

    return StreamingResponse(event_generator(), media_type="text/event-stream")


@app.get("/api/spaces")
def list_spaces():
    return space_manager.list_spaces()


@app.get("/api/spaces/{space_id}/health")
def space_health(space_id: str, user: Dict[str, Any] = Depends(get_current_user)):
    return space_manager.get_space_health(space_id, user_id=user["user_id"])


@app.get("/api/audit/logs")
def audit_logs(event_type: Optional[str] = Query(None), user_id: Optional[str] = Query(None), limit: int = Query(250)):
    return query_audit_logs(event_type=event_type, user_id=user_id, limit=limit)


@app.get("/api/telemetry/stats")
def telemetry_stats():
    from watson.observability.telemetry import get_telemetry_stats
    return get_telemetry_stats()


@app.get("/api/telemetry/q10-audit")
@app.get("/api/governance/cross-layer-verification")
def q10_audit(user: Dict[str, Any] = Depends(get_current_user)):
    from watson.observability.telemetry_query import run_q10_cross_layer_audit
    report = run_q10_cross_layer_audit()
    role = str(user.get("role", "VIEWER")).upper()
    report["evaluated_principal"] = {
        "user_id": user.get("user_id"),
        "name": user.get("name"),
        "role": role,
    }
    # Redact confidential chunk URIs and restricted document telemetry for non-admin/non-compliance personas (Tests 50 & 51)
    if role not in ("ADMIN", "COMPLIANCE_OFFICER", "SPOC"):
        report["sample_restricted_chunks"] = []
        report["telemetry_access_details"] = []
        report["abac_denials_observed"] = []
        report["confidential_details_redacted"] = True
    else:
        report["confidential_details_redacted"] = False
    return report


@app.post("/api/feedback")
def submit_feedback(req: FeedbackRequest, user: Dict[str, Any] = Depends(get_current_user)):
    from watson.observability.feedback_store import record_feedback
    res = record_feedback(
        correlation_id=req.correlation_id,
        user_id=user["user_id"],
        rating=req.rating,
        comment=req.comment,
    )
    return res


# ---------------------------------------------------------------------------
# Interactive SPARQL Query Studio Endpoints
# ---------------------------------------------------------------------------

_BUILTIN_SPARQL_TEMPLATES = [
    {
        "id": "Q01",
        "name": "Shared Target / Indication Discovery",
        "category": "Target Discovery",
        "description": "Identifies distinct brands sharing an indication with a selected target brand (e.g. Keytruda). Returns Brand, Drug, and Indication.",
        "sparql": """PREFIX watson: <http://watson.pharma.org/ontology/>
PREFIX entity: <http://watson.pharma.org/entity/>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>

SELECT DISTINCT ?brand ?brandName ?drug ?drugName ?indication ?indicationName
WHERE {
    VALUES ?targetBrand { <http://watson.pharma.org/entity/brand/keytruda> }
    ?targetBrand watson:treatsIndication ?indication .
    ?brand watson:treatsIndication ?indication ;
           watson:isBrandOf ?drug ;
           watson:canonicalName ?brandName .
    ?drug watson:canonicalName ?drugName .
    ?indication watson:canonicalName ?indicationName .
    FILTER(?brand != ?targetBrand)
}
ORDER BY ?brandName ?indicationName""",
    },
    {
        "id": "Q02",
        "name": "Negative Sentiment Surface",
        "category": "Sentiment Analytics",
        "description": "Brands whose average HCP sentiment is below 0.4 grouped by therapeutic area. Demonstrates GROUP BY, AVG, HAVING.",
        "sparql": """PREFIX watson: <http://watson.pharma.org/ontology/>

SELECT ?taName ?brandName (AVG(?score) AS ?avgSentiment) (COUNT(?sa) AS ?assertionCount)
WHERE {
    ?sa a watson:SentimentAssertion ;
        watson:sentimentAboutBrand ?brand ;
        watson:sentimentScore ?score .
    ?brand watson:canonicalName ?brandName ;
           watson:treatsIndication ?ind .
    ?ind watson:inTherapeuticArea ?ta .
    ?ta watson:canonicalName ?taName .
}
GROUP BY ?taName ?brandName
HAVING (AVG(?score) < 0.4)
ORDER BY ?taName ?avgSentiment""",
    },
    {
        "id": "Q03",
        "name": "Sentiment Trajectory",
        "category": "Sentiment Analytics",
        "description": "Temporal condition: sentiment > 0.6 before 2023 AND sentiment < 0.4 in 2023 or later. Multi-assertion temporal trajectory analysis.",
        "sparql": """PREFIX watson: <http://watson.pharma.org/ontology/>

SELECT DISTINCT ?brandName ?priorScore ?priorDate ?recentScore ?recentDate
WHERE {
    ?sa1 a watson:SentimentAssertion ;
         watson:sentimentAboutBrand ?brand ;
         watson:sentimentScore ?priorScore ;
         watson:assertionDate ?priorDate .
    FILTER(?priorScore > 0.6 && STR(?priorDate) < "2023-01-01")

    ?sa2 a watson:SentimentAssertion ;
         watson:sentimentAboutBrand ?brand ;
         watson:sentimentScore ?recentScore ;
         watson:assertionDate ?recentDate .
    FILTER(?recentScore < 0.4 && STR(?recentDate) >= "2023-01-01")

    ?brand watson:canonicalName ?brandName .
}
ORDER BY ?brandName""",
    },
    {
        "id": "Q04",
        "name": "Competitive Snapshot",
        "category": "Competitive Intelligence",
        "description": "Oncology competitive snapshot: brands, indication coverage, and average sentiment descending.",
        "sparql": """PREFIX watson: <http://watson.pharma.org/ontology/>

SELECT ?brandName (COUNT(DISTINCT ?ind) AS ?indicationCount) (AVG(?score) AS ?avgSentiment)
WHERE {
    ?brand a watson:Brand ;
           watson:canonicalName ?brandName ;
           watson:treatsIndication ?ind .
    ?ind watson:inTherapeuticArea ?ta .
    ?ta watson:canonicalName ?taName .
    FILTER(STR(?taName) = "Oncology")
    OPTIONAL {
        ?sa a watson:SentimentAssertion ;
            watson:sentimentAboutBrand ?brand ;
            watson:sentimentScore ?score .
    }
}
GROUP BY ?brandName
ORDER BY DESC(?avgSentiment) DESC(?indicationCount)""",
    },
    {
        "id": "Q05",
        "name": "Coverage Gap",
        "category": "Gap Analysis",
        "description": "Indications with < 2 market-research documents AND at least one brand targeting the indication.",
        "sparql": """PREFIX watson: <http://watson.pharma.org/ontology/>

SELECT ?indicationName (COUNT(DISTINCT ?doc) AS ?docCount) (COUNT(DISTINCT ?brand) AS ?brandCount)
WHERE {
    ?ind a watson:Indication ;
         watson:canonicalName ?indicationName .
    ?brand watson:treatsIndication ?ind .
    OPTIONAL {
        ?doc a watson:MarketResearchDocument ;
             watson:mentionsIndication ?ind .
    }
}
GROUP BY ?indicationName
HAVING (COUNT(DISTINCT ?doc) < 2 && COUNT(DISTINCT ?brand) >= 1)
ORDER BY ?docCount ?indicationName""",
    },
    {
        "id": "Q06",
        "name": "OWL Inference Test",
        "category": "Semantic Inference",
        "description": "Demonstrates polymorphic retrieval of HCPSentimentStudy when querying watson:Document due to subclass reasoning.",
        "sparql": """PREFIX watson: <http://watson.pharma.org/ontology/>

SELECT ?doc ?docType ?title ?sourceFilename
WHERE {
    ?doc a watson:Document ;
         watson:sourceFilename ?sourceFilename .
    OPTIONAL { ?doc watson:documentTitle ?title }
    OPTIONAL { ?doc a ?docType . FILTER(?docType = watson:HCPSentimentStudy) }
}
ORDER BY ?sourceFilename""",
    },
    {
        "id": "Q07",
        "name": "Complex Pharma Research Synthesis",
        "category": "Competitive Intelligence",
        "description": "Analyzes competitor brand co-occurrences in evidence chunks along with indication context and active document status.",
        "sparql": """PREFIX watson: <http://watson.pharma.org/ontology/>

SELECT ?brand1Name ?brand2Name ?indicationName (COUNT(DISTINCT ?chunk) AS ?coOccurrenceChunks) (AVG(?score) AS ?avgSentiment)
WHERE {
    ?b1 a watson:Brand ;
        watson:canonicalName ?brand1Name ;
        watson:competesWith ?b2 ;
        watson:treatsIndication ?ind .
    ?b2 a watson:Brand ;
        watson:canonicalName ?brand2Name ;
        watson:treatsIndication ?ind .
    ?ind watson:canonicalName ?indicationName .
    ?chunk a watson:DocumentChunk ;
           watson:mentionsBrand ?b1 ;
           watson:mentionsBrand ?b2 ;
           watson:chunkOf ?doc .
    ?doc watson:lifecycleState ?state .
    FILTER(STR(?state) = "ACTIVE")
    OPTIONAL {
        ?chunk watson:hasSentimentAssertion ?sa .
        ?sa watson:sentimentScore ?score .
    }
    FILTER(STR(?b1) < STR(?b2))
}
GROUP BY ?brand1Name ?brand2Name ?indicationName
ORDER BY DESC(?coOccurrenceChunks) ?brand1Name""",
    },
    {
        "id": "Q08",
        "name": "Expiry Surface",
        "category": "Governance & Compliance",
        "description": "ACTIVE documents expiring within time window -> document, study type, expiry date, owning TA.",
        "sparql": """PREFIX watson: <http://watson.pharma.org/ontology/>

SELECT ?docUri ?sourceFilename ?studyTypeName ?expiryDate ?taName
WHERE {
    ?doc a watson:MarketResearchDocument ;
         watson:documentUri ?docUri ;
         watson:sourceFilename ?sourceFilename ;
         watson:lifecycleState ?state ;
         watson:expiryDate ?expiryDate ;
         watson:hasStudyType ?st ;
         watson:inTherapeuticArea ?ta .
    ?st watson:canonicalName ?studyTypeName .
    ?ta watson:canonicalName ?taName .
    FILTER(STR(?state) = "ACTIVE")
    FILTER(STR(?expiryDate) >= "2026-01-01" && STR(?expiryDate) <= "2027-12-31")
}
ORDER BY ?expiryDate ?sourceFilename""",
    },
    {
        "id": "Q09",
        "name": "Lineage Trace",
        "category": "Lineage & Provenance",
        "description": "Given chunk URI, reconstructs parent document, title, enrichment model, timestamp, chunks produced, and reviewer.",
        "sparql": """PREFIX watson: <http://watson.pharma.org/ontology/>

SELECT ?chunkUri ?docUri ?sourceFilename ?enrichmentModel ?timestamp ?chunksProduced ?reviewedBy
WHERE {
    ?chunk a watson:DocumentChunk ;
           watson:chunkUri ?chunkUri ;
           watson:chunkOf ?doc .
    ?doc watson:documentUri ?docUri ;
         watson:sourceFilename ?sourceFilename ;
         watson:hasLineage ?lineage .
    ?lineage watson:actorOrSystem ?enrichmentModel ;
             watson:executionTimestamp ?timestamp .
    OPTIONAL { ?doc watson:reviewedBy ?reviewedBy }
    OPTIONAL { ?doc watson:chunksProduced ?chunksProduced }
}
ORDER BY ?chunkUri
LIMIT 15""",
    },
    {
        "id": "Q10",
        "name": "ABAC Governance Audit",
        "category": "Governance & Compliance",
        "description": "Identifies restricted and confidential chunks across therapy areas for user/session policy enforcement audit.",
        "sparql": """PREFIX watson: <http://watson.pharma.org/ontology/>

SELECT ?chunkUri ?docUri ?sensitivityLevel ?taName
WHERE {
    ?chunk a watson:DocumentChunk ;
           watson:chunkUri ?chunkUri ;
           watson:chunkOf ?doc .
    ?doc watson:documentUri ?docUri ;
         watson:sensitivityLevel ?sensitivityLevel ;
         watson:inTherapeuticArea ?ta .
    ?ta watson:canonicalName ?taName .
    FILTER(STR(?sensitivityLevel) IN ("RESTRICTED", "HIGHLY_RESTRICTED", "CONFIDENTIAL"))
}
ORDER BY ?sensitivityLevel ?chunkUri""",
    },
    {
        "id": "Q11",
        "name": "Knowledge Space Health",
        "category": "Health & Operations",
        "description": "Document count, avg quality score, latest ingest timestamp, and archived document count for each KnowledgeSpace.",
        "sparql": """PREFIX watson: <http://watson.pharma.org/ontology/>

SELECT ?spaceName ?owner (COUNT(DISTINCT ?doc) AS ?documentCount) (AVG(?qualityScore) AS ?avgQualityScore) (MAX(?ingestTime) AS ?latestIngestTimestamp) (SUM(IF(STR(?lifecycleState) = "ARCHIVED", 1, 0)) AS ?archivedCount)
WHERE {
    ?ks a watson:KnowledgeSpace ;
        watson:spaceName ?spaceName ;
        watson:spaceOwner ?owner .
    OPTIONAL {
        ?ks watson:containsDocument ?doc .
        ?doc watson:qualityScore ?qualityScore ;
             watson:ingestTimestamp ?ingestTime ;
             watson:lifecycleState ?lifecycleState .
    }
}
GROUP BY ?spaceName ?owner
ORDER BY DESC(?documentCount) ?spaceName""",
    },
    {
        "id": "EXP_BRANDS",
        "name": "Explore All Brands & Indications",
        "category": "Graph Exploration",
        "description": "Lists all pharmaceutical brands, active ingredients, and indications registered in the Knowledge Graph.",
        "sparql": """PREFIX watson: <http://watson.pharma.org/ontology/>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>

SELECT DISTINCT ?brandName ?drugName ?indicationName ?taName
WHERE {
    ?brand a watson:Brand ;
           watson:canonicalName ?brandName .
    OPTIONAL {
        ?brand watson:isBrandOf ?drug .
        ?drug watson:canonicalName ?drugName .
    }
    OPTIONAL {
        ?brand watson:treatsIndication ?ind .
        ?ind watson:canonicalName ?indicationName .
        OPTIONAL {
            ?ind watson:inTherapeuticArea ?ta .
            ?ta watson:canonicalName ?taName .
        }
    }
}
ORDER BY ?brandName ?indicationName
LIMIT 50""",
    },
    {
        "id": "EXP_CLASSES",
        "name": "Ontology Class Hierarchy & Counts",
        "category": "Graph Exploration",
        "description": "Lists OWL classes and instance counts currently asserted or inferred in the Knowledge Graph.",
        "sparql": """PREFIX owl: <http://www.w3.org/2002/07/owl#>
PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>

SELECT ?class (COUNT(?instance) AS ?instanceCount)
WHERE {
    ?instance rdf:type ?class .
    FILTER(STRSTARTS(STR(?class), "http://watson.pharma.org/ontology/"))
}
GROUP BY ?class
ORDER BY DESC(?instanceCount)""",
    },
    {
        "id": "EXP_DBX_MAPPINGS",
        "name": "Databricks Product MVM Schema & Mappings",
        "category": "Graph Exploration",
        "description": "Queries imported Databricks Pharmaceuticals Product MVM tables and their semantic mapping status in the Layer 2 overlay.",
        "sparql": """PREFIX dbx: <http://databricks.pharma.org/mvm/v1/>
PREFIX dbxmap: <http://watson.pharma.org/mapping/databricks/>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>

SELECT ?productName ?subdomain ?mappingStatus ?targetConcept
WHERE {
    ?m a dbxmap:SemanticMapping ;
       dbxmap:sourceConcept ?prod ;
       dbxmap:mappingStatus ?mappingStatus .
    ?prod rdfs:label ?productName ;
          dbx:subdomain ?subdomain .
    OPTIONAL { ?m dbxmap:targetConcept ?targetConcept }
}
ORDER BY ?mappingStatus ?productName""",
    },
]


@app.get("/api/graph/sparql/templates")
def get_sparql_templates():
    """Returns PRD Section 13 authoritative SPARQL query templates and exploration suites."""
    return {"templates": _BUILTIN_SPARQL_TEMPLATES}


@app.post("/api/graph/sparql")
def execute_sparql(req: SparqlRequest, user: Dict[str, Any] = Depends(get_current_user)):
    """Executes an interactive SPARQL query against the in-memory semantic Knowledge Graph."""
    if not req.query or not req.query.strip():
        raise HTTPException(status_code=400, detail="Query cannot be empty.")

    q_upper = req.query.upper()
    prohibited = ["DROP", "DELETE", "INSERT", "CLEAR", "LOAD", "CREATE"]
    for keyword in prohibited:
        if re.search(rf"\b{keyword}\b", q_upper):
            raise HTTPException(
                status_code=403,
                detail=f"SPARQL mutation keyword '{keyword}' is prohibited. Read-only queries only.",
            )

    t0 = time.time()
    try:
        graph = assembler.graph
        if graph is None or len(graph) == 0:
            import rdflib
            graph = rdflib.Graph()
            kg_path = PHARMA_KG_INFERRED_FILE if PHARMA_KG_INFERRED_FILE.exists() else PHARMA_KG_FILE
            graph.parse(str(kg_path), format="turtle")

        res = graph.query(req.query)
        elapsed_ms = round((time.time() - t0) * 1000, 2)

        vars_list = [str(v) for v in res.vars] if res.vars else []
        rows = []
        for r in res:
            row_dict = {}
            for idx, var in enumerate(vars_list):
                val = r[idx]
                row_dict[var] = str(val) if val is not None else ""
            rows.append(row_dict)

        log_audit_event(
            event_type="SPARQL_QUERY",
            user_id=user["user_id"],
            message=f"SPARQL Query executed: {len(rows)} rows returned in {elapsed_ms}ms",
            metadata={"row_count": len(rows), "latency_ms": elapsed_ms, "columns": vars_list},
        )

        return {
            "status": "SUCCESS",
            "query": req.query,
            "latency_ms": elapsed_ms,
            "triple_count": len(graph),
            "columns": vars_list,
            "row_count": len(rows),
            "results": rows,
            "user_id": user["user_id"],
            "user_role": user["role"],
        }
    except Exception as e:
        elapsed_ms = round((time.time() - t0) * 1000, 2)
        err_msg = str(e)
        logger.warning("SPARQL Execution Error: %s", err_msg)
        raise HTTPException(
            status_code=400,
            detail=f"SPARQL Syntax / Execution Error: {err_msg}",
        )


# ---------------------------------------------------------------------------
# Governed Knowledge Engineering: Candidate Graph, SHACL, HITL & Publication APIs
# ---------------------------------------------------------------------------

def _require_staged_evidence_access(user: Dict[str, Any]) -> Dict[str, Any]:
    """Enforces RBAC/ABAC on staged candidate knowledge and evidence (TEST 08 & TEST 16)."""
    role = str(user.get("role", "")).upper()
    if role not in ("ADMIN", "SPOC", "COMPLIANCE_OFFICER"):
        log_audit_event(
            event_type="STAGED_EVIDENCE_DENIED",
            user_id=user.get("user_id", "UNKNOWN"),
            message=f"Unauthorized staged candidate access blocked for user '{user.get('user_id')}' ({role}).",
            metadata={"role": role, "outcome": "DENIED_403"},
        )
        raise HTTPException(
            status_code=403,
            detail=f"Access denied: Role '{role}' is not authorized to access staged candidate knowledge or unapproved evidence.",
        )
    return user


@app.get("/api/candidates")
def list_candidates_api(
    batch_id: Optional[str] = Query(None),
    document_uri: Optional[str] = Query(None),
    lifecycle_state: Optional[str] = Query(None),
    validation_status: Optional[str] = Query(None),
    user: Dict[str, Any] = Depends(get_current_user),
):
    _require_staged_evidence_access(user)
    cands = candidate_governance.list_candidates(
        batch_id=batch_id,
        document_uri=document_uri,
        lifecycle_state=lifecycle_state,
        validation_status=validation_status,
    )
    return {
        "status": "SUCCESS",
        "count": len(cands),
        "operational_metrics": candidate_governance.get_operational_metrics(),
        "candidates": cands,
    }


@app.get("/api/candidates/queue/navigator")
def get_candidates_queue_navigator_api(
    user: Dict[str, Any] = Depends(get_current_user),
):
    _require_staged_evidence_access(user)
    return candidate_governance.get_review_queue_navigator()


@app.post("/api/candidates/dev-fixtures/seed")
def seed_candidate_demo_fixtures_api(
    user: Dict[str, Any] = Depends(get_current_user),
):
    _require_staged_evidence_access(user)
    return candidate_governance.seed_demo_fixtures(user=user)


@app.post("/api/candidates/dev-fixtures/reset")
def reset_candidate_demo_fixtures_api(
    user: Dict[str, Any] = Depends(get_current_user),
):
    _require_staged_evidence_access(user)
    return candidate_governance.reset_demo_fixtures(user=user)


@app.get("/api/candidates/graph/explorer")
def get_candidate_graph_explorer_api(
    candidate_id: Optional[str] = Query(None),
    document_uri: Optional[str] = Query(None),
    batch_id: Optional[str] = Query(None),
    include_trusted_context: bool = Query(True),
    user: Dict[str, Any] = Depends(get_current_user),
):
    _require_staged_evidence_access(user)
    return candidate_governance.build_candidate_explorer_payload(
        candidate_id=candidate_id,
        document_uri=document_uri,
        batch_id=batch_id,
        include_trusted_context=include_trusted_context,
    )


@app.get("/api/candidates/{candidate_id:path}/readiness")
def get_candidate_readiness_api(
    candidate_id: str,
    user: Dict[str, Any] = Depends(get_current_user),
):
    _require_staged_evidence_access(user)
    try:
        return candidate_governance.evaluate_publication_readiness(candidate_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@app.get("/api/candidates/{candidate_id:path}/duplicates")
def get_candidate_duplicates_api(
    candidate_id: str,
    entity_uri: Optional[str] = Query(None),
    user: Dict[str, Any] = Depends(get_current_user),
):
    _require_staged_evidence_access(user)
    try:
        return candidate_governance.find_potential_duplicates(
            candidate_id=candidate_id,
            entity_uri=entity_uri,
        )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@app.post("/api/candidates/{candidate_id:path}/edit/preview")
def preview_edit_candidate_api(
    candidate_id: str,
    req: CandidateEditRequest,
    user: Dict[str, Any] = Depends(get_current_user),
):
    _require_staged_evidence_access(user)
    try:
        return candidate_governance.preview_edit_candidate(
            candidate_id=candidate_id,
            edits={
                "add_triples": req.add_triples or [],
                "remove_triples": req.remove_triples or [],
                "replace_triples": req.replace_triples or [],
                "update_entities": req.update_entities or [],
            },
            user=user,
        )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except (LifecycleViolationError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.post("/api/candidates/{candidate_id:path}/merge/preview")
def preview_merge_candidate_entities_api(
    candidate_id: str,
    req: CandidateMergeRequest,
    user: Dict[str, Any] = Depends(get_current_user),
):
    _require_staged_evidence_access(user)
    try:
        return candidate_governance.preview_merge_entities(
            candidate_id=candidate_id,
            source_entity_uri=req.source_entity_uri,
            target_entity_uri=req.target_entity_uri,
            target_canonical_name=req.target_canonical_name,
            user=user,
        )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except (LifecycleViolationError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.get("/api/candidates/{candidate_id:path}/shacl")
def get_candidate_shacl_report_api(
    candidate_id: str,
    user: Dict[str, Any] = Depends(get_current_user),
):
    _require_staged_evidence_access(user)
    try:
        cand = candidate_governance.get_candidate(candidate_id)
        return {
            "status": "SUCCESS",
            "candidate_id": cand["candidate_id"],
            "graph_version": cand["graph_version"],
            "content_hash": cand["content_hash"],
            "candidate_lifecycle_state": cand["candidate_lifecycle_state"],
            "shacl_report": cand.get("shacl_report"),
            "validation_history": cand.get("validation_history", []),
        }
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@app.post("/api/candidates/{candidate_id:path}/validate")
def validate_candidate_shacl_api(
    candidate_id: str,
    user: Dict[str, Any] = Depends(get_current_user),
):
    _require_staged_evidence_access(user)
    try:
        cand = candidate_governance.revalidate_candidate(candidate_id, user=user)
        return {
            "status": "SUCCESS",
            "candidate": cand,
            "shacl_report": cand["shacl_report"],
        }
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except (LifecycleViolationError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.post("/api/candidates/{candidate_id:path}/edit")
def edit_candidate_api(
    candidate_id: str,
    req: CandidateEditRequest,
    user: Dict[str, Any] = Depends(get_current_user),
):
    _require_staged_evidence_access(user)
    try:
        cand = candidate_governance.edit_candidate(
            candidate_id=candidate_id,
            edits={
                "add_triples": req.add_triples or [],
                "remove_triples": req.remove_triples or [],
                "replace_triples": req.replace_triples or [],
                "update_entities": req.update_entities or [],
            },
            user=user,
            reason=req.reason,
            expected_version=req.expected_version,
            idempotency_key=req.idempotency_key,
        )
        return {"status": "SUCCESS", "candidate": cand}
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except (LifecycleViolationError, ValueError) as exc:
        msg = str(exc)
        if "STALE_CANDIDATE_VERSION" in msg:
            raise HTTPException(status_code=409, detail=msg) from exc
        raise HTTPException(status_code=400, detail=msg) from exc


@app.post("/api/candidates/{candidate_id:path}/merge")
def merge_candidate_entities_api(
    candidate_id: str,
    req: CandidateMergeRequest,
    user: Dict[str, Any] = Depends(get_current_user),
):
    _require_staged_evidence_access(user)
    try:
        cand = candidate_governance.merge_candidate_entities(
            candidate_id=candidate_id,
            source_entity_uri=req.source_entity_uri,
            target_entity_uri=req.target_entity_uri,
            target_canonical_name=req.target_canonical_name,
            user=user,
            reason=req.reason,
            expected_version=req.expected_version,
            idempotency_key=req.idempotency_key,
        )
        return {"status": "SUCCESS", "candidate": cand}
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except (LifecycleViolationError, ValueError) as exc:
        msg = str(exc)
        if "STALE_CANDIDATE_VERSION" in msg:
            raise HTTPException(status_code=409, detail=msg) from exc
        raise HTTPException(status_code=400, detail=msg) from exc


@app.post("/api/candidates/{candidate_id:path}/quarantine")
def quarantine_candidate_api(
    candidate_id: str,
    req: CandidateQuarantineRequest,
    user: Dict[str, Any] = Depends(get_current_user),
):
    _require_staged_evidence_access(user)
    try:
        cand = candidate_governance.quarantine_candidate(
            candidate_id=candidate_id,
            reason=req.reason,
            triggering_issue=req.triggering_issue,
            user=user,
        )
        return {"status": "SUCCESS", "candidate": cand}
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except (LifecycleViolationError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.post("/api/candidates/{candidate_id:path}/request-evidence")
def request_evidence_candidate_api(
    candidate_id: str,
    req: CandidateRequestEvidenceRequest,
    user: Dict[str, Any] = Depends(get_current_user),
):
    _require_staged_evidence_access(user)
    try:
        cand = candidate_governance.request_evidence(
            candidate_id=candidate_id,
            request_note=req.request_note,
            requested_fields=req.requested_fields,
            user=user,
            expected_version=req.expected_version,
            idempotency_key=req.idempotency_key,
        )
        return {"status": "SUCCESS", "candidate": cand}
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except (LifecycleViolationError, ValueError) as exc:
        msg = str(exc)
        if "STALE_CANDIDATE_VERSION" in msg:
            raise HTTPException(status_code=409, detail=msg) from exc
        raise HTTPException(status_code=400, detail=msg) from exc


@app.post("/api/candidates/{candidate_id:path}/submit-evidence")
def submit_evidence_candidate_api(
    candidate_id: str,
    req: CandidateSubmitEvidenceRequest,
    user: Dict[str, Any] = Depends(get_current_user),
):
    _require_staged_evidence_access(user)
    try:
        cand = candidate_governance.submit_evidence(
            candidate_id=candidate_id,
            evidence_text=req.evidence_text,
            source_reference=req.source_reference,
            source_document_uri=req.source_document_uri,
            document_version=req.document_version,
            chunk_or_page_ref=req.chunk_or_page_ref,
            evidence_type=req.evidence_type,
            sensitivity_level=req.sensitivity_level,
            additional_triples=req.additional_triples,
            user=user,
            expected_version=req.expected_version,
            idempotency_key=req.idempotency_key,
        )
        return {"status": "SUCCESS", "candidate": cand}
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except (LifecycleViolationError, ValueError) as exc:
        msg = str(exc)
        if "STALE_CANDIDATE_VERSION" in msg:
            raise HTTPException(status_code=409, detail=msg) from exc
        raise HTTPException(status_code=400, detail=msg) from exc


@app.post("/api/candidates/{candidate_id:path}/defer")
def defer_candidate_api(
    candidate_id: str,
    req: CandidateDecisionRequest,
    user: Dict[str, Any] = Depends(get_current_user),
):
    _require_staged_evidence_access(user)
    try:
        cand = candidate_governance.defer_candidate(
            candidate_id=candidate_id,
            reason=req.reason or req.review_note or "Deferred for subsequent governance review",
            user=user,
        )
        return {"status": "SUCCESS", "candidate": cand}
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except (LifecycleViolationError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.post("/api/candidates/{candidate_id:path}/reject")
def reject_candidate_api(
    candidate_id: str,
    req: CandidateDecisionRequest,
    user: Dict[str, Any] = Depends(get_current_user),
):
    _require_staged_evidence_access(user)
    try:
        cand = candidate_governance.reject_candidate(
            candidate_id=candidate_id,
            reason=req.reason or req.review_note or "Rejected during HITL governance review",
            user=user,
        )
        return {"status": "SUCCESS", "candidate": cand}
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except (LifecycleViolationError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.post("/api/candidates/{candidate_id:path}/approve")
def approve_candidate_api(
    candidate_id: str,
    req: CandidateDecisionRequest,
    user: Dict[str, Any] = Depends(get_current_user),
):
    _require_staged_evidence_access(user)
    try:
        cand = candidate_governance.approve_candidate(
            candidate_id=candidate_id,
            user=user,
            expected_version=req.expected_version,
            review_note=req.review_note or req.reason or "Approved during HITL review",
            pii_override=req.pii_override,
            sensitivity_level=req.sensitivity_level,
            allowed_ta=req.allowed_therapeutic_areas,
            allowed_geo=req.allowed_geographies,
            expiry_date=req.expiry_date,
        )
        return {"status": "SUCCESS", "candidate": cand}
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except (LifecycleViolationError, ValueError) as exc:
        msg = str(exc)
        if "STALE_CANDIDATE_VERSION" in msg:
            raise HTTPException(status_code=409, detail=msg) from exc
        raise HTTPException(status_code=400, detail=msg) from exc


@app.post("/api/candidates/{candidate_id:path}/publish")
def publish_candidate_api(
    candidate_id: str,
    req: Optional[CandidatePublishRequest] = None,
    user: Dict[str, Any] = Depends(get_current_user),
):
    _require_staged_evidence_access(user)
    req_data = req or CandidatePublishRequest()
    try:
        res = candidate_governance.publish_candidate(
            candidate_id=candidate_id,
            user=user,
            transaction_id=req_data.transaction_id,
            simulate_failure=req_data.simulate_failure,
        )
        compatibility_engine.sync_layer2_graph_overlay(assembler.graph)
        return res
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except (LifecycleViolationError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.get("/api/candidates/{candidate_id:path}")
def get_candidate_detail_api(
    candidate_id: str,
    user: Dict[str, Any] = Depends(get_current_user),
):
    _require_staged_evidence_access(user)
    try:
        cand = candidate_governance.get_candidate(candidate_id)
        log_audit_event(
            event_type="STAGED_EVIDENCE_ACCESSED",
            user_id=user["user_id"],
            document_uri=cand["document_uri"],
            message=f"Authorized user '{user['user_id']}' ({user['role']}) inspected staged candidate '{cand['candidate_id']}'.",
            metadata={"candidate_id": cand["candidate_id"], "graph_version": cand["graph_version"]},
        )
        return {"status": "SUCCESS", "candidate": cand}
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@app.post("/api/publications/{transaction_id}/rollback")
def rollback_publication_api(
    transaction_id: str,
    req: Optional[PublicationRollbackRequest] = None,
    user: Dict[str, Any] = Depends(get_current_user),
):
    _require_staged_evidence_access(user)
    req_data = req or PublicationRollbackRequest()
    try:
        res = candidate_governance.rollback_publication(
            transaction_id=transaction_id,
            reason=req_data.reason,
            user=user,
        )
        compatibility_engine.sync_layer2_graph_overlay(assembler.graph)
        return res
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


# ---------------------------------------------------------------------------
# Workspace 2: Document-Level HITL Governance Endpoints
# ---------------------------------------------------------------------------

@app.get("/api/hitl/documents")
def list_hitl_documents_api(
    status_filter: Optional[str] = Query(None),
    user: Dict[str, Any] = Depends(get_current_user),
):
    _require_staged_evidence_access(user)
    return candidate_governance.list_hitl_documents(status_filter=status_filter, user=user)


@app.get("/api/hitl/documents/{document_uri:path}")
def get_hitl_document_detail_api(
    document_uri: str,
    user: Dict[str, Any] = Depends(get_current_user),
):
    _require_staged_evidence_access(user)
    try:
        return candidate_governance.get_hitl_document_detail(document_uri, user=user)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@app.post("/api/hitl/documents/{document_uri:path}/decision")
def execute_hitl_document_decision_api(
    document_uri: str,
    req: HitlDocumentDecisionRequest,
    user: Dict[str, Any] = Depends(get_current_user),
):
    _require_staged_evidence_access(user)
    try:
        return candidate_governance.execute_hitl_document_decision(
            document_uri_or_id=document_uri,
            decision=req.decision,
            user=user,
            review_note=req.review_note,
            pii_override=req.pii_override,
            dedup_disposition=req.dedup_disposition,
            sensitivity_level=req.sensitivity_level,
            allowed_ta=req.allowed_therapeutic_areas,
            allowed_geo=req.allowed_geographies,
            expiry_date=req.expiry_date,
            requested_evidence_fields=req.requested_evidence_fields,
            evidence_text=req.evidence_text,
            source_reference=req.source_reference,
        )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except (LifecycleViolationError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


# ---------------------------------------------------------------------------
# Workspace 4: Knowledge Publication Staging, Verification & Release Endpoints
# ---------------------------------------------------------------------------

@app.get("/api/publications/queue")
def get_publications_queue_api(user: Dict[str, Any] = Depends(get_current_user)):
    _require_staged_evidence_access(user)
    return candidate_governance.get_publication_workspace_queue()


@app.get("/api/publications/{candidate_id:path}/readiness")
def get_three_track_publication_readiness_api(
    candidate_id: str,
    user: Dict[str, Any] = Depends(get_current_user),
):
    _require_staged_evidence_access(user)
    try:
        return candidate_governance.evaluate_three_track_publication_readiness(candidate_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@app.post("/api/candidates/{candidate_id:path}/stage-release")
def stage_candidate_release_api(
    candidate_id: str,
    req: Optional[StageReleaseRequest] = None,
    user: Dict[str, Any] = Depends(get_current_user),
):
    _require_staged_evidence_access(user)
    req_data = req or StageReleaseRequest()
    try:
        return candidate_governance.stage_candidate_release(
            candidate_id=candidate_id,
            user=user,
            simulate_staging_failure=req_data.simulate_staging_failure,
        )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except (LifecycleViolationError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.post("/api/candidates/{candidate_id:path}/verify-release")
def verify_staged_release_api(
    candidate_id: str,
    user: Dict[str, Any] = Depends(get_current_user),
):
    _require_staged_evidence_access(user)
    try:
        return candidate_governance.verify_staged_release(candidate_id=candidate_id, user=user)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except (LifecycleViolationError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.post("/api/publications/{transaction_id:path}/withdraw")
def withdraw_publication_api(
    transaction_id: str,
    req: Optional[WithdrawPublicationRequest] = None,
    user: Dict[str, Any] = Depends(get_current_user),
):
    _require_staged_evidence_access(user)
    req_data = req or WithdrawPublicationRequest()
    try:
        res = candidate_governance.withdraw_publication(
            transaction_id_or_candidate_id=transaction_id,
            reason=req_data.reason,
            mode=req_data.mode,
            user=user,
        )
        compatibility_engine.sync_layer2_graph_overlay(assembler.graph)
        return res
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except (LifecycleViolationError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.get("/api/governance/overview")
def get_governance_overview_api(user: Dict[str, Any] = Depends(get_current_user)):
    return candidate_governance.get_governance_overview()


@app.delete("/api/audit/logs")
@app.put("/api/audit/logs")
@app.patch("/api/audit/logs")
def block_audit_log_modification(user: Dict[str, Any] = Depends(get_current_user)):
    """Tamper-evident audit protection: blocks any attempt to modify or delete audit logs (TEST 14)."""
    log_audit_event(
        event_type="AUDIT_MODIFICATION_BLOCKED",
        user_id=user.get("user_id", "UNKNOWN"),
        message=f"Tamper-evident guard blocked unauthorized audit modification attempt by '{user.get('user_id')}'.",
        metadata={"role": user.get("role"), "outcome": "BLOCKED_403"},
    )
    raise HTTPException(
        status_code=403,
        detail="Audit trail is append-only and tamper-evident. Modification or deletion of audit records is strictly prohibited.",
    )


# Mount React Production Frontend
from fastapi.staticfiles import StaticFiles

_FRONTEND_DIST = _ROOT_DIR / "frontend" / "dist"
if _FRONTEND_DIST.exists():
    app.mount("/", StaticFiles(directory=str(_FRONTEND_DIST), html=True), name="static")
