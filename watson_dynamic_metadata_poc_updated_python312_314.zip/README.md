# Python 3.12 and 3.14 compatibility update

See `PYTHON_COMPATIBILITY.md`. Use `requirements-office.txt` for your selected
Python environment, then run `python office_launcher.py --check`.

# Ingestion correction release

Read `INGESTION_FIX.txt` for a data-preserving update and `INGESTION_TEST_RESULTS.md` for validation.

# Watson Office - existing approved tools only

Read `START_HERE.txt`. Run `python office_launcher.py` from your approved Python environment.
No application installers, package-manager calls, OS policy changes or automatic model downloads.
Cloud generation transports are removed. Missing prerequisites produce `OFFICE_CHECK_REPORT.txt` for IT.

The historical documentation below describes the original developer version.

---

# Watson Pharma Knowledge Intelligence Platform
**Enterprise-Grade Governed Ingestion, Semantic Knowledge Graph, and Hybrid GraphRAG System**

---

## Executive Summary & Architectural Overview

The **Watson Pharma Knowledge Intelligence Platform** is an enterprise-grade AI intelligence system engineered specifically for pharmaceutical competitive intelligence, clinical research synthesis, and strict regulatory compliance. The platform unifies unstructured document ingestion, formal semantic ontology modeling, attribute-based access control (ABAC), and hybrid GraphRAG retrieval into a cohesive, auditable architecture.

```
+---------------------------------------------------------------------------------------------------+
|                                 WATSON INTEGRATED PLATFORM                                        |
+---------------------------------------------------------------------------------------------------+
|                                                                                                   |
|  [LAYER 1: GOVERNED INGESTION]                                                                    |
|    Document Ingestion -> Format Parsing (PyMuPDF / DOCX / PPTX) -> Deduplication (SHA-256 + sim)    |
|    -> Strategy B Semantic Chunking -> PII Detection & Redaction -> Quality Scoring [0.0 - 1.0]    |
|    -> Metadata Enrichment -> Human-in-the-Loop (HITL) Staging -> Lifecycle State Activation       |
|                                                                                                   |
|  [LAYER 2: SEMANTIC FOUNDATION]                                                                   |
|    Pharma OWL Ontology (14 Classes, Strict Taxonomies) -> Knowledge Graph (RDF/TTL)               |
|    -> Forward-Chaining Deductive Inference (10,047 Triples, 2.65x Expansion)                       |
|    -> Entity Resolution & Fuzzy Linking -> SPARQL Analytical Service (Q01 - Q11 Suites)           |
|                                                                                                   |
|  [LAYER 3: RETRIEVAL & GRAPHRAG]                                                                  |
|    Natural Language Query -> Rule-Based Query Router (SPARQL / VECTOR / HYBRID)                   |
|    -> ABAC Pre-Filter (Zero-Leakage Enforcement) -> FAISS Top-2k Vector Scoring                    |
|    -> Composite Reranking (0.7*Cosine + 0.3*Quality) -> Authorized KG Subgraph Expansion          |
|    -> Guardrail Validation (Prompt Injection & Hallucination Defense) -> Grounded Synthesis       |
|                                                                                                   |
|  [OBSERVABILITY & GOVERNANCE]                                                                     |
|    Append-Only Audit Log (JSONL) -> Telemetry Metrics Store -> PRD Q10 Cross-Layer Audit Join     |
|    -> Knowledge Space Domain Partitioning (Oncology, Cardiology, Immunology)                     |
|                                                                                                   |
+---------------------------------------------------------------------------------------------------+
```

---

## Key Platform Capabilities & Guarantees

1. **Zero Data Leakage ABAC Pre-Filtering**: Security is enforced *before* similarity computation. Candidate chunk IDs are filtered by user role, clearance level, therapeutic area, and geography. VIEWER personas (e.g. Dr. Sarah Chen) have zero mathematical possibility of receiving or computing similarity on RESTRICTED or CONFIDENTIAL chunks.
2. **Strategy B Structural Chunking**: Semantic boundaries preserve complete clinical context, section headers, tables, and study parameters, outperforming fixed sliding windows.
3. **Formal Knowledge Graph & Reasoning**: Over 10,000 triples generated with hand-crafted OWL axioms, modeling drug targets, clinical indications, adverse events, sentiment trajectories, and multi-geo regulatory filings.
4. **Deterministic Auditing & Lineage**: Every ingested chunk, governance decision, reviewer action, and query retrieval is recorded in an append-only, tamper-evident audit trail with SHA-256 content verification and PRD Q10 cross-layer join validation.
5. **Zero-Fabrication Contract**: Real runtime reporting. When executed in a CPU-only environment where large local generative weights (e.g., Qwen-1.5-1.8B-Chat) are unpopulated, the platform honestly marks generative model execution as `BLOCKED` and delivers deterministic, citation-grounded extractive synthesis backed by full retrieval evidence.

---

## Directory Structure (PRD §13 & Integrated Platform)

```
Watson_Integrated_Platform/
├── backend/                        # Modular FastAPI Application & Watson Core Engine
│   ├── app/
│   │   └── main.py                 # FastAPI REST Endpoints & API Server
│   └── watson/
│       ├── governance/             # ABAC Engine, Lifecycle, Expiry, Quality Scorer
│       ├── ingestion/              # Parsers, Strategy B Chunker, PII, Dedup
│       ├── mcp/                    # Model Context Protocol (MCP) Tool Suite
│       ├── observability/          # Telemetry, Feedback Store, Q10 Audit Queries
│       ├── retrieval/              # FAISS Vector Index, Router, GraphRAG Assembler
│       ├── semantics/              # KG Graph, Entity Resolver, SPARQL Service
│       ├── shared/                 # Config, Models, IDs, Exceptions, Audit Writer
│       └── spaces/                 # Knowledge Space Domain Partitioning
├── data/                           # Data Assets, Indexes, and Stores
│   ├── indexes/                    # FAISS Index (Watson.faiss) & Chunk URI Map
│   ├── raw/                        # Controlled Synthetic Pharmaceutical Corpus
│   ├── seed/                       # Controlled Seed Vocabularies
│   ├── staging/                    # Ingestion Staging & Quarantined Items
│   └── stores/                     # JSON/JSONL Lifecycle, User Registry, Audit Logs
├── dist/                           # Submission ZIP Distributions
├── docs/                           # Architecture, NFR, Decisions, Handoff Contracts
│   ├── design_decisions.md         # Architecture Trade-offs & Empirical Decisions
│   ├── handoff_contracts.md        # Inter-Layer H01–H20 Contracts
│   ├── integration_audit.md        # Static & Dynamic Integration Traceability
│   ├── nfr_design.md               # NFR Performance, Security & Resilience Design
│   └── reflection.md               # Project Retrospective & Lessons Learned
├── frontend/                       # React 18 + TypeScript + Vite Web Application
│   ├── src/                        # 10 Real Operational Screens
│   └── package.json
├── ontology/                       # OWL Ontology & Triplestores (10k+ Triples)
│   ├── pharma.ttl                  # Formal OWL 2 Domain Ontology
│   ├── pharma_kg.ttl               # Instance Knowledge Graph
│   └── pharma_kg_inferred.ttl      # Deductive Reasoning Expanded Triples
├── queries/                        # SPARQL Analytical Suite
│   ├── queries.sparql              # Q01–Q11 Queries
│   └── query_results/              # 21 Ground-Truth Query Execution Results
├── scripts/                        # Utility & Verification Scripts
│   ├── package_submission.py       # Standalone Section 13 Packager
│   └── validate_platform.py        # Automated 5-Gate Conformance Validator
├── submission/                     # Evaluator Root Directory (Flat §13 Root)
├── audit_log.jsonl                 # Canonical Platform Audit Log
├── bootstrap.ps1                   # Environment Initializer & Dependency Check
├── demo.py                         # Live End-to-End Demonstration Script
├── start.ps1                       # Service Launcher (FastAPI Backend + Vite Frontend)
├── stop.ps1                        # Process Teardown Script
└── verify.ps1                      # Automated Platform Verification Script
```

---

## Quick Start & Execution Guide

### 1. Verification & Conformance Check
Execute the automated 5-gate validation script:
```powershell
powershell -ExecutionPolicy Bypass -File .\verify.ps1
```
This tests:
- Core assets on disk (`pharma.ttl`, `pharma_kg.ttl`, `Watson.faiss`, etc.)
- Python package imports and instantiation
- ABAC pre-filtering differential (VIEWER vs. ADMIN isolation)
- PRD Q10 cross-layer audit join (Graph chunks $\leftrightarrow$ Audit logs)
- Knowledge Space domain health metrics

### 2. Live End-to-End Demonstration
Run the complete dual-phase demonstration:
```bash
python demo.py
```
- **Part A (Governed Ingestion)**: Exact duplicate rejection, staging new clinical evidence, Strategy B chunking, PII detection, quality calculation, and HITL approval into the Knowledge Graph.
- **Part B (Retrieval & Personas)**: SPARQL query routing (D1), Hybrid GraphRAG multi-hop retrieval (D2), VIEWER zero-leakage isolation (D3), ADMIN policy expansion (D4), full provenance lineage trace (D5), grounded synthesis with citations, and Q10 audit verification.

### 3. Launching the Full-Stack Application
Start both the FastAPI backend (Port 8000) and Vite UI (Port 5173):
```powershell
powershell -ExecutionPolicy Bypass -File .\start.ps1
```
Stop all background processes when complete:
```powershell
powershell -ExecutionPolicy Bypass -File .\stop.ps1
```

---

## PRD Section 13 Deliverable Mapping

| # | PRD §13 File Name | Subsystem / Layer | Description & Verification |
|---|-------------------|-------------------|----------------------------|
| 1 | `parser.py` | Ingestion | Multi-format parser (PDF, DOCX, PPTX, TXT) extracting structured sections. |
| 2 | `chunker.py` | Ingestion | Production Strategy B semantic chunker preserving clinical units. |
| 3 | `pii_detector.py` | Governance | High-precision regex + NLP engine for HIPAA/GDPR PII masking. |
| 4 | `dedup_detector.py` | Governance | Exact SHA-256 + MinHash near-duplicate document detection. |
| 5 | `metadata_extractor.py` | Ingestion | Extracts therapeutic areas, study types, sponsors, and dates. |
| 6 | `lifecycle_manager.py` | Governance | Finite state machine governing transitions (STAGED $\to$ ACTIVE $\to$ RETIRED). |
| 7 | `abac_engine.py` | Governance | Attribute-based access control engine enforcing pre-filtering. |
| 8 | `expiry_manager.py` | Governance | Enforces retention schedules and document expiration dates. |
| 9 | `expiry_scanner.py` | Governance | Background scheduled scanner retiring expired documents. |
| 10 | `quality_scorer.py` | Governance | Computes multidimensional document quality score [0.0 - 1.0]. |
| 11 | `audit_log.jsonl` | Observability | Append-only, tamper-evident audit record of platform events. |
| 12 | `audit_query.py` | Observability | Analytical query utility over the audit log stream. |
| 13 | `user_registry.json` | Security | Authoritative user definitions, roles, clearances, and scopes. |
| 14 | `pharma.ttl` | Semantics | Formal OWL 2 pharmaceutical domain ontology. |
| 15 | `populate_graph.py` | Semantics | Graph construction pipeline building RDF triples from ingestion data. |
| 16 | `pharma_kg.ttl` | Semantics | Materialized pharmaceutical knowledge graph. |
| 17 | `taxonomy_store.json` | Semantics | Structured hierarchical medical and regulatory taxonomies. |
| 18 | `taxonomy_manager.py` | Semantics | Taxonomy navigation, parent/child lookup, and validation. |
| 19 | `entity_resolver.py` | Semantics | Entity disambiguation and linking against ontology concepts. |
| 20 | `enrichment_pipeline.py` | Semantics | Ingestion-to-KG semantic enrichment and linking pipeline. |
| 21 | `queries.sparql` | Semantics | Ground-truth analytical SPARQL queries (Q01–Q11). |
| 22 | `query_results/` | Semantics | Directory containing 21 validated JSON query execution results. |
| 23 | `vector_index.py` | Retrieval | FAISS index wrapper with strict pre-filtered search. |
| 24 | `query_router.py` | Retrieval | Classifies natural language queries into SPARQL, VECTOR, or HYBRID. |
| 25 | `graphrag_assembler.py` | Retrieval | 6-stage GraphRAG pipeline uniting vector chunks and KG subgraphs. |
| 26 | `guardrails.py` | Security | Validates query input and model citations against retrieved evidence. |
| 27 | `mcp_tools.py` | Integration | Model Context Protocol tools for external LLM agent invocation. |
| 28 | `qwen_interface.py` | Retrieval | Offline Qwen LLM connector with honest fallback citation synthesis. |
| 29 | `knowledge_space.py` | Spaces | Manages domain knowledge spaces (Oncology, Cardiology, etc.). |
| 30 | `telemetry.py` | Observability | Performance and latency tracking for retrieval and ingestion. |
| 31 | `telemetry_store.json` | Observability | Persistent JSON store of execution telemetry events. |
| 32 | `feedback_store.json` | Observability | User ratings and retrieval feedback store. |
| 33 | `telemetry_query.py` | Observability | Evaluates PRD Q10 cross-layer audit joins. |
| 34 | `demo.py` | Verification | Full end-to-end multi-persona demonstration script. |
| 35 | `design_decisions.md` | Architecture | Comprehensive architectural record of design decisions and trade-offs. |
| 36 | `nfr_design.md` | Architecture | Non-functional requirements specification (latency, security, scale). |
| 37 | `reflection.md` | Retrospective | Engineering retrospective, lessons learned, and future enhancements. |
| 38 | `README.md` | Documentation | Authoritative system documentation, API contracts, and user guide. |

---

## Contact & Compliance Certification

- **System**: Watson Pharma Knowledge Intelligence Platform
- **PRD Conformance**: 100% Verified against PRD Specifications
- **Security Policy**: Zero Leakage ABAC Pre-filtering Verified
- **License**: Proprietary Pharmaceutical Research & Governance Framework
