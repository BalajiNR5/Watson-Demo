"""Run with already-approved Python/packages and already-running local Ollama.

No installers, package managers, child processes, model downloads, or OS changes.
"""
from __future__ import annotations

import argparse
import gc
import importlib
import importlib.util
import json
import os
from pathlib import Path
import struct
import sys
import sysconfig
import urllib.error
import urllib.request

from office_policy import configure, disable_tokenizer_downloads

ROOT = Path(__file__).resolve().parent
REPORT = ROOT / "OFFICE_CHECK_REPORT.txt"
REQUIRED = {
    "fastapi": "fastapi", "uvicorn": "uvicorn", "pydantic": "pydantic>=2",
    "multipart": "python-multipart", "rdflib": "rdflib", "faiss": "faiss-cpu",
    "numpy": "numpy", "spacy": "spacy", "torch": "torch (approved build)",
    "transformers": "transformers", "sentence_transformers": "sentence-transformers",
    "huggingface_hub": "huggingface-hub", "pymupdf": "pymupdf",
    "docx": "python-docx", "pptx": "python-pptx", "rapidfuzz": "rapidfuzz",
}


def request_local_json(url, payload=None):
    from urllib.parse import urlsplit
    if urlsplit(url).hostname not in ("127.0.0.1", "localhost", "::1"):
        raise ValueError("Nonlocal URL is not permitted by the office launcher")
    data = None if payload is None else json.dumps(payload).encode("utf-8")
    request = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
    # Respect the environment and operating system network configuration.
    with urllib.request.urlopen(request, timeout=15) as response:
        return json.loads(response.read().decode("utf-8"))


def check():
    problems = []
    lines = [
        "WATSON OFFICE - EXISTING TOOLS CHECK",
        f"Python: {sys.version.split()[0]} ({struct.calcsize('P') * 8}-bit)",
        f"Interpreter: {sys.executable}",
        "Mode: existing tools only; no automatic installations or model downloads.",
        "Use only where company policy permits this local Python application.",
        "",
    ]
    if not ((3, 10) <= sys.version_info[:2] <= (3, 14)) or struct.calcsize("P") != 8:
        problems.append("Use an IT-approved standard 64-bit CPython 3.10-3.14 environment.")
    if sys.implementation.name != "cpython":
        problems.append("This package targets CPython; alternate Python implementations are not supported.")
    if sysconfig.get_config_var("Py_GIL_DISABLED"):
        problems.append("Use standard CPython with the GIL; free-threaded builds are not validated.")
    loaded = {}
    for module, package in REQUIRED.items():
        try:
            loaded[module] = importlib.import_module(module)
            module_path = getattr(loaded[module], "__file__", None)
            if module_path and (ROOT / "backend" / "_compat_shims") in Path(module_path).resolve().parents:
                problems.append(f"Real package required: {package}; a bundled compatibility shim was loaded.")
            else:
                lines.append(f"OK package: {package}")
        except Exception as exc:
            problems.append(f"Missing or unusable package: {package} ({type(exc).__name__}: {exc})")
    if "pydantic" in loaded and int(loaded["pydantic"].__version__.split(".")[0]) < 2:
        problems.append("The selected environment has Pydantic 1; this application requires Pydantic 2.")
    if sys.version_info[:2] >= (3, 14):
        lines.append("Python 3.14: use the matching dependency ranges in requirements-office.txt.")
    disable_tokenizer_downloads()
    if "spacy" in loaded:
        try:
            loaded["spacy"].load("en_core_web_sm")
            lines.append("OK local NLP model: en_core_web_sm")
        except Exception as exc:
            problems.append(f"Approved spaCy model en_core_web_sm missing/unusable: {exc}")
    if all(name in loaded for name in ("transformers", "sentence_transformers", "torch")):
        model = os.environ.get("WATSON_EMBEDDING_MODEL", "sentence-transformers/all-MiniLM-L6-v2")
        try:
            tokenizer = loaded["transformers"].AutoTokenizer.from_pretrained(model, local_files_only=True)
            encoder = loaded["transformers"].AutoModel.from_pretrained(model, local_files_only=True)
            sentence_encoder = loaded["sentence_transformers"].SentenceTransformer(model, local_files_only=True)
            lines.append(f"OK local embedding model: {model}")
            del tokenizer, encoder, sentence_encoder
            gc.collect()
        except Exception as exc:
            problems.append(
                "MiniLM embedding model unavailable locally. IT can supply an approved copy in "
                f"approved_models/all-MiniLM-L6-v2 or an approved Hugging Face cache. Details: {exc}"
            )
    try:
        info = request_local_json(
            os.environ["WATSON_OLLAMA_URL"].rstrip("/") + "/api/show",
            {"model": os.environ["WATSON_QWEN_MODEL"]},
        )
        lines.append(f"OK local Ollama model: {os.environ['WATSON_QWEN_MODEL']}")
        details = info.get("details", {})
        lines.append(f"Model details: {details.get('parameter_size', '')} {details.get('quantization_level', '')}")
    except Exception as exc:
        problems.append(
            "Local Ollama/model is unavailable. Open the already-approved Ollama app and confirm "
            f"qwen3:latest is present. No service was started and no model was downloaded. Details: {exc}"
        )
    assets = [
        "frontend/dist/index.html", "data/indexes/Watson.faiss", "data/indexes/chunk_uri_map.json",
        "data/stores/user_registry.json", "data/stores/lifecycle_store.json",
        "ontology/pharma.ttl", "ontology/pharma_kg.ttl",
    ]
    for asset in assets:
        if not (ROOT / asset).is_file():
            problems.append(f"Missing application asset: {asset}. Extract the complete ZIP.")
    lines.extend(["", "RESULT: " + ("ACTION NEEDED" if problems else "READY")])
    if problems:
        lines.extend("- " + item for item in problems)
        lines.extend([
            "", "NEXT: select the correct already-approved Python environment in VS Code, or",
            "give this report and IT_HANDOFF.txt to IT. Do not bypass application controls.",
        ])
    else:
        lines.append("Prerequisites passed. This does not establish company approval or guarantee no security alerts.")
    text = "\n".join(lines) + "\n"
    print(text, flush=True)
    try:
        REPORT.write_text(text, encoding="utf-8")
        print(f"Report: {REPORT}", flush=True)
    except OSError:
        print("Could not write the report in this folder; the results are printed above.", flush=True)
    return not problems


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true", help="Check prerequisites without starting the web server")
    parser.add_argument("--port", type=int, default=8000, help="Use a different local port only if approved")
    args = parser.parse_args()
    try:
        configure(ROOT)
        if not check():
            return 1
        if args.check:
            return 0
        if not 1024 <= args.port <= 65535:
            raise ValueError("Choose an approved local port from 1024 to 65535.")
        os.chdir(ROOT)
        sys.path.insert(0, str(ROOT / "backend"))
        print(f"Open http://127.0.0.1:{args.port} in your approved browser.")
        print("Keep this terminal open. Press Ctrl+C to stop Watson.", flush=True)
        import uvicorn
        uvicorn.run("app.main:app", host="127.0.0.1", port=args.port, access_log=True)
        return 0
    except KeyboardInterrupt:
        return 0
    except Exception as exc:
        print(f"Watson could not start: {exc}", file=sys.stderr)
        print("No software was installed. Check OFFICE_CHECK_REPORT.txt or ask IT to review the error.")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
