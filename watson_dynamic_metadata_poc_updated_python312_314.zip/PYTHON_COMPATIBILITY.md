# Python 3.12 and 3.14 compatibility

This update adds standard 64-bit CPython 3.14 support while retaining CPython
3.10-3.13 acceptance. Python 3.12 and 3.14 were directly tested. Free-threaded
Python builds and alternate interpreters are not validated and the launcher
rejects them. No Python interpreter, dependency wheels or model weights are
bundled in this project ZIP.

## What changed

- `office_launcher.py` accepts CPython 3.10 through 3.14. Package messages no
  longer incorrectly demand Transformers 4 and Sentence Transformers 3 on 3.14.
  Preflight also rejects bundled compatibility shims in place of real packages.
- `requirements-office.txt` uses Python environment markers: 3.10-3.13 keep
  the original model-library major ranges; 3.14 selects newer compatible ranges
  for PyTorch, Transformers, Sentence Transformers, Hugging Face Hub, spaCy,
  NumPy, FAISS, PyMuPDF, Pydantic, FastAPI, tiktoken and pytest.
- PyTorch is now an explicit requirement. HTTPX is included for the existing
  FastAPI acceptance tests.
- Startup and IT handoff instructions reflect the supported runtimes.
- `tests/test_python_compatibility.py` adds real-dependency smoke checks.

The application's retrieval implementation, embedding model and 384-dimensional
vector space are unchanged. All original documents, stores, ontology files,
indexes, frontend files and other application source files are preserved byte
for byte. No deterministic embedding substitute was introduced.

## Provisioning a Python 3.14 environment

Use a **new** environment for each Python minor version. Do not copy an existing
3.12 virtual environment or its `site-packages` into a 3.14 installation.
Dependency provisioning remains manual or IT-owned. The application launcher
never installs software or downloads model weights.

Example Windows commands for an approved workstation:

```powershell
py -3.14 -m venv .venv314
.\.venv314\Scripts\python.exe -m pip install --upgrade pip
.\.venv314\Scripts\python.exe -m pip install -r requirements-office.txt
.\.venv314\Scripts\python.exe office_launcher.py --check
.\.venv314\Scripts\python.exe office_launcher.py
```

For Python 3.12 use `py -3.12` and a separate `.venv312` directory. On Linux or
macOS use `python3.14 -m venv .venv314` and `.venv314/bin/python` for the remaining
commands. CPU/GPU PyTorch provisioning must match the host; an approved CPU
build may be installed first from the official PyTorch CPU wheel index.
An internal approved wheelhouse can be used in place of public package indexes.

The following prerequisites are still required separately:

1. The spaCy `en_core_web_sm` model compatible with spaCy 3.8 (3.8.0 was tested).
2. A complete `sentence-transformers/all-MiniLM-L6-v2` model in the existing
   local cache, or `approved_models/all-MiniLM-L6-v2` under the extracted project.
   An absolute local path can also be supplied via `WATSON_EMBEDDING_MODEL`.
3. The existing Ollama application running locally with `qwen3:latest` available.

Keep the same MiniLM model for the existing FAISS index. Switching to a different
embedding model requires a separately planned reindex, even if its dimension
is also 384. Normal startup stays `python office_launcher.py`.

## Validation

| Check | Python 3.12.14 | Python 3.14.8 |
| --- | --- | --- |
| Install dependency ranges in separate environment | Passed | Passed |
| Installed dependency consistency (`uv pip check`) | Passed | Passed |
| Real package imports (no bundled shims) | Passed | Passed |
| Existing FAISS index, PyTorch/NumPy interoperability | Passed | Passed |
| Existing RDF graph and SPARQL query | Passed | Passed |
| FastAPI/Pydantic request validation and OpenAPI | Passed | Passed |
| spaCy entity ruler | Passed | Passed |
| Real MiniLM query/ingestion embedding agreement | Passed | Passed |
| Authorized FAISS retrieval and empty-allowlist denial | Passed | Passed |
| Existing 58 enterprise workflow acceptance tests | 58 passed | 58 passed |
| Combined compatibility and acceptance checks | **64 passed** | **64 passed** |

Direct runtime testing used Linux x86-64 with actual dependencies and local
MiniLM and spaCy model files. No shim-backed results are counted above.
Windows x86-64 Python 3.14 dependency resolution also passed; Windows runtime
execution was not tested. Python 3.10, 3.11 and 3.13 retain their previous
acceptance and were not directly tested in this update.

Python 3.14 launcher preflight passed the interpreter, all required packages,
spaCy model, MiniLM model and bundled asset checks. It stopped as expected on
the unavailable local Ollama service. Live Qwen3 generation and browser-based
end-to-end execution were not tested. Existing Pydantic `.dict()` deprecation
warnings and multipart/TestClient dependency warnings are non-fatal; the
requirements continue to exclude Pydantic 3.

Main dependency versions used for runtime validation:

| Package | Python 3.12 | Python 3.14 |
| --- | --- | --- |
| PyTorch CPU | 2.15.0+cpu | 2.15.0+cpu |
| Transformers | 4.57.6 | 5.22.1 |
| Sentence Transformers | 3.4.1 | 6.2.0 |
| Hugging Face Hub | 0.36.2 | 2.4.0 |
| spaCy | 3.8.18 | 3.8.18 |
| FAISS CPU | 1.15.1 | 1.15.1 |
| NumPy | 2.5.4 | 2.5.4 |
| FastAPI | 0.162.0 | 0.162.0 |
| Pydantic | 2.14.2 | 2.14.2 |
| RDFLib | 7.6.0 | 7.6.0 |
| PyMuPDF | 1.28.2 | 1.28.2 |

These are tested versions, not a universal platform lockfile. The requirements
file defines compatible ranges and the selected interpreter chooses its branch.
The lower bounds of every permitted range have not been individually tested.

To repeat the checks after provisioning:

```text
python -m pytest tests/test_python_compatibility.py tests/test_58_enterprise_workflow_separation.py -q
```

Set `WATSON_EMBEDDING_MODEL` to the absolute local MiniLM directory first for
the embedding smoke test; otherwise that one test skips explicitly. The existing
acceptance suite uses temporary data copies. No models are downloaded by the
new smoke tests. Tests and provisioning can take longer than normal startup.

Dependency references:
- https://pypi.org/project/sentence-transformers/6.2.0/
- https://pypi.org/project/transformers/
- https://pypi.org/project/spacy/3.8.10/
- https://pypi.org/project/torch/
- https://pypi.org/project/faiss-cpu/
- https://pypi.org/project/numpy/2.3.3/
- https://pypi.org/project/pydantic/2.12.0/
