# Watson Cross-Layer Executable Handoff Contracts (H01–H20)

| ID | Producer -> Consumer | Invariant & Data Schema | Failure & Evidence Behavior | Verification Test |
|---|---|---|---|---|
| **H01** | File Upload -> Parser | Raw file path, SHA-256 hash, MIME/extension, actor, UTC timestamp. | Reject invalid/corrupted files; emit `PARSE_WARNING` or `INGEST` failure. | `test_h01_upload_parse` |
| **H02** | Parser -> Dedup + Chunker | `ParsedDocument` with text, structural sections, character offsets, geometry (page/slide). | Parser warning on scan/degraded format without crashing. | `test_h02_parser_chunker` |
| **H03** | Dedup -> Review | Exact hash match or near-dedup (>0.85 text similarity within TA/DocType). | Identical SHA256 rejected; near duplicates held with match URI. | `test_h03_dedup_review` |
| **H04** | Chunker -> PII + Metadata | Strategy B semantic chunks with doc_id, chunk_uri, tokens, page/slide boundaries. | Untraceable chunks rejected; page boundaries strictly preserved. | `test_h04_chunker_pii` |
| **H05** | PII + Metadata -> Lifecycle | 15 PRD metadata fields + PII scan findings; hold if critical PII unmasked. | Unredacted PII routes doc to `UNDER_REVIEW` with `PII_FLAG`. | `test_h05_pii_metadata` |
| **H06** | HITL Review -> ACTIVE State + ACL | Reviewer ID, decision note, sensitivity level, allowed TAs, allowed geos, expiry date. | Non-admin/unauthorized review rejected; ACL persisted atomically. | `test_h06_hitl_activation` |
| **H07** | ACTIVE Event -> Enrichment Job | Approved document snapshot with immutable content hash and job ID. | Inactive documents cannot be scheduled for semantic enrichment. | `test_h07_active_enrichment` |
| **H08** | Entity Extraction -> Resolver | spaCy NER spans, chunk URIs, term class, match confidence. | Low confidence (<0.5) discarded; exact/fuzzy matches logged. | `test_h08_entity_resolution` |
| **H09** | Resolver -> Taxonomy / RDF | Canonical entity URI or provisional term (`watson:Provisional_...`). | Unmapped terms stored in `provisional_entities.json` without failing. | `test_h09_resolver_taxonomy` |
| **H10** | RDF + Lineage -> Vector Index | DocumentChunk triples, `LineageRecord`, and FAISS 384-d normalized vector. | Atomic commit; no orphan FAISS vector without graph chunk URI. | `test_h10_rdf_faiss_sync` |
| **H11** | Graph / FAISS -> Retrieval | UserContext (role, assigned TA, assigned geo, clearance). | Strict default-deny pre-filtering before vector distance calculation. | `test_h11_abac_prefilter` |
| **H12** | Query Router -> 6-Stage Pipeline | Intent classification: `SPARQL`, `VECTOR`, or `HYBRID`. | Policy validation; no raw client role spoofing; audit log emitted. | `test_h12_query_routing` |
| **H13** | 6-Stage Pipeline -> GraphRAG | Safe ranked chunks + authorized 1-hop and 2-hop KG facts. | Zero restricted facts returned to unauthorized roles. | `test_h13_graphrag_assembly` |
| **H14** | GraphRAG -> Local Qwen | Context string with strict source URI headers; prompt template. | If weights/compute unavailable, return status `BLOCKED` honestly. | `test_h14_qwen_context` |
| **H15** | Qwen -> Guardrails -> API | Sentence-level citations mapped to source URIs; hallucination checks. | Fabricated citations or injection payloads rejected/flagged. | `test_h15_guardrails_citation` |
| **H16** | API -> Frontend UI | Role-safe DTO with answer, citations, confidence, latency, route. | Identical ABAC enforcement across REST, CLI, and MCP interfaces. | `test_h16_api_ui_contract` |
| **H17** | API -> Feedback & Telemetry | Request metrics, route, latency, user role, user rating/comment. | Zero plain-text restricted document content in telemetry stores. | `test_h17_telemetry_feedback` |
| **H18** | Expiry / Archive -> KG + FAISS | Tombstone transition (`ARCHIVED`/`UNDER_REVIEW`); immediate index removal. | Expired or archived documents revoked immediately from search. | `test_h18_expiry_revocation` |
| **H19** | Knowledge Space -> Graph / Q11 | Space URI, member documents, SPOC owner permissions, health stats. | Aggregate metrics do not leak unauthorized member documents. | `test_h19_knowledge_space` |
| **H20** | CLI / MCP / UI -> Shared Service | Universal invocation of identical underlying governance/search code. | No mock shortcuts, parallel bypass paths, or divergent logic. | `test_h20_unified_services` |
