# Watson Answer Validation & Guardrail Conformance Report

## 1. 6-Axis Multi-Status Real-Time Validation

Every answer synthesized by the Watson Semantic GraphRAG pipeline is validated against six independent multi-status dimensions before delivery to the frontend:

```mermaid
graph LR
    A[Synthesized Answer] --> V1[Intent Match Status]
    A --> V2[Entity Coverage Status]
    A --> V3[Geography Alignment Status]
    A --> V4[Answer Completeness Status]
    A --> V5[Claim Grounding Status]
    A --> V6[Citation Validity Status]
    
    V1 --> R{Trustworthiness Evaluation}
    V2 --> R
    V3 --> R
    V4 --> R
    V5 --> R
    V6 --> R
```

### 1.1 Intent Match Status (`intent_match_status`)
- **MATCHED:** The execution strategy directly addresses the user's research query (e.g. `QUANTITATIVE_CLINICAL_EVIDENCE`, `TEMPORAL_SENTIMENT_ANALYSIS`, `MARKET_ACCESS_COMPARISON`).
- **UNMATCHED:** Query intent was misclassified or defaulted to a generic overview.

### 1.2 Entity Coverage Status (`entity_coverage_status`)
- **COVERED:** $100\%$ of requested pharmaceutical brand entities have verified evidence in the answer plan ($CoverageRatio = 1.0$).
- **PARTIAL_COVERAGE:** Some requested entities lack evidence.
- **NO_COVERAGE:** No requested entities located.

### 1.3 Geography Alignment Status (`geography_alignment_status`)
- **ALIGNED:** The cited evidence is scoped strictly to the requested jurisdictional territories (e.g., US study Doc_005 for US query; EU study Doc_007 for EU query).
- **MISALIGNED:** Evidence from unrequested regions leaked into the answer.

### 1.4 Answer Completeness Status (`answer_completeness_status`)
- **COMPLETE:** All requested structured sections (e.g., Common Factors, Established Differences, Reimbursement, HCP Concerns, Recommendations) are synthesized.
- **PARTIAL:** Some requested sections could not be populated.

### 1.5 Claim Grounding Status (`claim_grounding_status`)
- **GROUNDED:** Every factual claim has an explicit passage citation $[watson:Doc\_XXX:chunk:b:YYYY]$ verified against the retrieved text.
- **PARTIALLY_GROUNDED:** Minor assertions lack explicit passage citations.
- **UNGROUNDED:** Contains hallucinatory assertions.

### 1.6 Citation Validity Status (`citation_validity_status`)
- **VALID:** Zero hallucinated or malformed citation brackets. All cited chunk URIs exist in the ABAC-permitted vector sub-index.
- **INVALID_CITATIONS:** Citations reference nonexistent chunks or unauthorized documents.

---

## 2. Guardrails & Non-Hallucination Constraints

1. **Prompt Injection Guardrail:** Evaluates query inputs against adversarial patterns before retrieval.
2. **Missing Endpoint Guardrail:** If numerical endpoints (hazard ratios, OS, PFS) are not present in the source report, the system explicitly reports `Not Reported` rather than generating simulated numbers.
3. **Clinical Superiority Guardrail:** Unvalidated claims of clinical superiority without head-to-head randomized trials are rejected with an explicit evidence limitation disclosure.
4. **ABAC Guardrail:** Clearances are verified server-side before similarity ranking, guaranteeing that viewers cannot leak restricted documents.
