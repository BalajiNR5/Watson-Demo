# ROOT CAUSE ANALYSIS — WATSON SEMANTIC GRAPHRAG PLATFORM
**Component:** Systematic Semantic GraphRAG Architecture  
**Audit Date:** 2026-10-16  
**Status:** Defect Catalogued & Corrected  

---

## 1. Executive Summary
An exhaustive audit of the 15-stage execution pipeline connecting the FastAPI chat controller, Query Router, Entity Resolver, Taxonomy Manager, RDF/SPARQL Engine, FAISS Vector Index, GraphRAG Assembler, and Answer Synthesizer was conducted. 

While the 15 execution stages routinely reported "COMPLETED", systemic discrepancies existed between pipeline execution metrics and actual semantic correctness. This document details the 10 core architectural root causes, affected modules, reproduction mechanisms, and verified remediation proofs.

---

## 2. Identified Root Causes & Defect Catalogue

### Defect 1: Intent Precedence & Keyword Masking
- **Actual Cause:** In `query_router.py`, conversational gating and intent classification evaluated broad substring matches rather than strict word boundaries. For example, the query `"Which drugs had declining HCP sentiment before 2023 versus 2023 onward?"` matched `"us"` inside `"versus"` (`"us" in "versus"` evaluated to `True`), mistakenly re-classifying an independent cross-brand temporal research question into a contextual `FOLLOW_UP_RESEARCH` question. This caused stale session context (e.g. `Keytruda` in `NSCLC`) to be forcibly appended.
- **Affected Functions:** `QueryRouter.classify_conversational_gate()`, `QueryRouter.analyze_intent()`
- **Reproduction:** Issue a question containing `"versus"` or `"status"` following an earlier session turn.
- **Remediation:** Enforce regex word boundaries (`\b(united states|india|europe|eu|us)\b`) and establish strict priority ordering: `TEMPORAL_SENTIMENT_ANALYSIS` -> `ONTOLOGY_RELATIONSHIP_TRACE` -> `CLINICAL_CLAIM_VERIFICATION` -> `PROVENANCE_TRACE` -> `MARKET_ACCESS_COMPARISON` -> `DIRECT_RESEARCH_SYNTHESIS`.

---

### Defect 2: Session Context Cross-Contamination
- **Actual Cause:** Single-session dictionary (`self.sessions`) retained the latest brand, indication, and geography globally per user ID without isolating by conversation or verifying topic shift. When subsequent unrelated questions lacked explicit brand names, the router blindly substituted the previous brand's evidence tuple.
- **Affected Functions:** `QueryRouter.analyze_intent()`, `GraphRAGAssembler.retrieve_and_synthesize()`
- **Reproduction:** Ask a question about Keytruda, then ask `"Which drugs had declining HCP sentiment before 2023 versus 2023 onward?"`
- **Remediation:** Check explicit query indicators before inspecting session memory; clear session topic bindings on explicit research queries or intent shifts.

---

### Defect 3: Indication Aliasing & Multi-Brand Cross-Pollination
- **Actual Cause:** The alias mapping for `"asthma"` contained `"respiratory care"`. When a multi-brand query like `"Keytruda in EU oncology, Dupixent in US immunology, and Xolair in Indian respiratory care"` was analyzed, global search matched `"respiratory care"` to `"asthma"`. Because Keytruda's explicit indication was omitted in its specific clause, the router defaulted to the globally matched indication (`Asthma`), contaminating Keytruda with Asthma.
- **Affected Functions:** `QueryRouter._resolve_entities_in_query()`, `INDICATION_ALIASES`
- **Remediation:** Move `"respiratory care"` to therapeutic area aliases (`Respiratory`); enforce per-clause entity binding and validate indication candidates against brand-allowed indications (`allowed_indications`).

---

### Defect 4: RDF Chunk URI Normalization Discrepancies
- **Actual Cause:** In `graphrag_assembler.py`, RDF `SentimentAssertion` instances store `derivedChunk` as `<http://watson.pharma.org/chunk/watson_Doc_015_chunk_b_0000>`. String splitting `c_val.split("_")` produced 6 parts (`['watson', 'Doc', '015', 'chunk', 'b', '0000']`). Naive parsing generated `doc_uri = "watson:Doc"` and `chunk_uri = "watson:Doc:015:chunk:b"`, which failed ABAC document filtering (`user_allowed_docs`) and failed index chunk lookup. Consequently, direct graph-discovered chunks were dropped from candidate sets.
- **Affected Functions:** `GraphRAGAssembler._query_semantic_graph_facts()`
- **Reproduction:** Execute any temporal SPARQL query requesting assertion source provenance.
- **Remediation:** Enforce canonical chunk URI formatting: `f"{p[0]}:{p[1]}_{p[2]}:{p[3]}:{p[4]}:{p[5]}"` yielding `watson:Doc_015:chunk:b:0000`.

---

### Defect 5: Metric Hallucination on Missing Quantitative Evidence
- **Actual Cause:** Direct synthesis templates for clinical evidence attempted to provide comprehensive trial outcome summaries even when specific numerical endpoints (e.g. hazard ratio, progression-free survival) were absent from the authorized document.
- **Affected Functions:** `QwenInterface._synthesize_clinical_evidence()`
- **Reproduction:** Ask for hazard ratio and overall survival in `Doc_007`.
- **Remediation:** Introduce `QUANTITATIVE_CLINICAL_EVIDENCE` intent that verifies explicit numerical metrics in the retrieved passage; if not present, explicitly classify the metric as `NOT_REPORTED` in accordance with PRD non-hallucination rules.

---

### Defect 6: Clinical Superiority Over-Assertion
- **Actual Cause:** Comparative synthesis templates treated competitive brand co-occurrence as clinical equivalence or mild superiority when analyzing comparator claims, failing to distinguish between actual head-to-head clinical trial evidence and market access competitor landscape commentary.
- **Affected Functions:** `QwenInterface._synthesize_comparative()`
- **Reproduction:** Ask `"Can we conclude that Farxiga is clinically superior to Jardiance in CKD based only on the indexed reports?"`
- **Remediation:** Implement `CLINICAL_CLAIM_VERIFICATION` route that explicitly inspects for head-to-head trial endpoints, rejecting superiority conclusions when evidence contains only landscape comparisons.

---

### Defect 7: Inadequate Citation Support Validation
- **Actual Cause:** `WatsonGuardrails.validate_citations()` verified that cited chunk URIs existed within `retrieved_uris`, but did not verify whether the cited chunk text actually contained the claimed entities, indications, or numerical tokens.
- **Affected Functions:** `WatsonGuardrails.validate_citations()`, `WatsonGuardrails.validate_answer_quality()`
- **Reproduction:** Cite a valid chunk from an unrelated section of the document.
- **Remediation:** Implement substantive claim extraction (`ClaimRecord`) mapping claims to chunk text, classifying support into `SUPPORTED`, `PARTIALLY_SUPPORTED`, `UNSUPPORTED`, and `CONTRADICTED`.

---

### Defect 8: Lack of Canonical Evidence Tuple Enforcement
- **Actual Cause:** Information extracted from vector chunks and graph triples was maintained in disjoint data structures (`scored_chunks`, `kg_facts`), allowing synthesizers to combine attributes from different entities into single synthetic statements.
- **Affected Functions:** `GraphRAGAssembler`, `QwenInterface`
- **Reproduction:** Multi-subject queries comparing 3 or more brands across multiple geographies.
- **Remediation:** Introduce `EvidenceSet` and `SubjectEntityQuery` with immutable evidence tuples: `(brand_uri, drug_uri, indication_uri, therapeutic_area_uri, geography_uri, document_uri, chunk_uri)`.

---

### Defect 9: Pipeline Completion Mistaken for Answer Correctness
- **Actual Cause:** Diagnostic traces recorded stage status `COMPLETED` based purely on whether Python functions executed without raising exceptions, masking semantic mismatches under an apparent 100% success rate.
- **Affected Functions:** `GraphRAGAssembler.retrieve_and_synthesize()`, `SafeMarkdownRenderer.tsx`
- **Reproduction:** Observe frontend trace badges showing green checkmarks even when answers reported insufficient evidence.
- **Remediation:** Separate execution status (`PIPELINE_EXECUTION`) from semantic statuses (`INTENT_MATCH`, `EVIDENCE_RELEVANCE`, `ENTITY_COVERAGE`, `CLAIM_GROUNDING`).

---

### Defect 10: Conversational Gate Leaking Research Pipelines
- **Actual Cause:** Greetings like `"hi"` or small talk queries did not short-circuit all 15 stages, resulting in empty vector index queries and synthetic latency delays.
- **Affected Functions:** `QueryRouter.classify_conversational_gate()`, `GraphRAGAssembler`
- **Reproduction:** Submit `"hi"` in Chatbot UI.
- **Remediation:** Immediate short-circuit return of conversational response with stages 4-15 marked `SKIPPED`.

---

## 3. Verification & Acceptance
All 10 defects have been catalogued with automated regression tests in `tests/test_semantic_invariants_and_routing.py` and `tests/test_targeted_qa_and_conversation.py`.
