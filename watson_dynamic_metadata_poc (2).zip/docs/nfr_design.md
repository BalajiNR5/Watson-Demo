# Watson Platform — Non-Functional Requirements (NFR) Architecture & Design

This document details the architectural strategies, benchmarks, and verification procedures for the 7 core Non-Functional Requirements mandated by the Watson PRD (Section 14).

---

## 1. Security & Attribute-Based Access Control (ABAC)
- **Requirement**: Default-deny security model. Strict attribute filtering on role, clearance level, therapeutic area, and geography. Zero leakage of RESTRICTED documents or titles to unauthorized roles (e.g., VIEWER).
- **Architecture**:
  - Two-stage enforcement: ACL written to document and chunk RDF triples during HITL activation.
  - Pre-filtering before vector scoring: candidate FAISS vector IDs are strictly restricted to authorized chunks *before* similarity is computed. Unauthorized vectors are never scored or retrieved.
  - Fail-closed SPARQL enforcement: direct SPARQL queries from VIEWER roles are denied; query execution filters triples by sensitivity.
- **Verification**: Evaluated via D3 (Dr. Sarah Chen, VIEWER) vs D4 (Elena Rostova, ADMIN) comparison. D3 receives exactly 20 permitted chunks with 0 restricted items; D4 accesses all 70 chunks.

---

## 2. Retrieval Performance & Latency
- **Requirement**: Fast end-to-end response times (< 250ms for hybrid retrieval; < 50ms for FAISS vector search on permitted subsets).
- **Architecture**:
  - `IndexFlatIP` using normalized 384-dimensional dense vectors (`all-MiniLM-L6-v2`).
  - Temporary sub-index construction on permitted vectors executes in < 5ms.
  - In-memory RDFLib graph querying executes SPARQL benchmarks Q01–Q11 in 10ms–80ms.
- **Verification**: Monitored via `StageTraceItem` timestamps recorded in `telemetry_store.json` on every request.

---

## 3. Auditability, Provenance & Lineage
- **Requirement**: Complete, immutable traceability from synthesized claims back to source paragraphs, reviewer notes, and ingestion runs.
- **Architecture**:
  - Append-only `audit_log.jsonl` recording events: `INGEST`, `PARSE_WARNING`, `PII_FLAG`, `DEDUP_HIT`, `STATE_TRANSITION`, `ENTITY_RESOLUTION`, `ENRICHMENT_COMPLETE`, `ABAC_DENIED`, `QUERY`.
  - First-class RDF individual `watson:LineageRecord` created per document activation, linking `DocumentChunk` via `watson:derivedFrom` to reviewer identity and model versions.
- **Verification**: Tested in PRD Q09 lineage trace and UI evidence drill-down modal.

---

## 4. Data Integrity & Idempotency
- **Requirement**: Strict deduplication, collision-free identity generation, and atomic lifecycle transitions.
- **Architecture**:
  - Exact duplicates rejected via SHA-256 hash match (`DEDUP_HIT`).
  - Near-duplicates (>0.85 sequence similarity within therapeutic area) flagged and held for human review (`UNDER_REVIEW`).
  - Deterministic URI schemas: `watson:Doc_{id}`, `watson:Chunk_{id}_{idx}`, `watson:Lineage_{id}`.
  - State machine transitions enforced: only `ACTIVE` documents can be indexed in FAISS or queried in GraphRAG.
- **Verification**: Automated test suite (`test_layer1_e2e.py`) asserts rejection of non-ACTIVE states and exact hash collisions.

---

## 5. Explainability & Quality Reranking
- **Requirement**: Transparent composite scoring combining semantic relevance and document clinical quality.
- **Architecture**:
  - Composite scoring formula:
    $$\text{final\_score} = 0.7 \times \text{similarity} + 0.3 \times \text{quality\_score}$$
  - Quality score is explainable and composed of 4 auditable signals:
    - 30% Metadata Completeness
    - 30% Text Richness (clinical vocabulary density)
    - 20% HCP Sample Size (interpolated between 20 and 300+)
    - 20% Freshness ($1 - \frac{\text{days since ingest}}{730}$)
- **Verification**: Ablation testing demonstrates that higher-quality clinical studies outrank low-quality mentions even when semantic cosine similarity is comparable.

---

## 6. Safety, Guardrails & Anti-Hallucination
- **Requirement**: Zero unverified citations, prompt injection defense, and honest abstention.
- **Architecture**:
  - Regex-based injection defense scanning for adversarial jailbreaks (`ignore previous instructions`, `DAN mode`).
  - Strict citation audit: regex extracts `[watson:Chunk_...]` tokens from LLM answers and verifies 100% inclusion in the retrieved context set. Any hallucinated citation raises a guardrail warning.
  - Context sufficiency check: if zero authorized evidence exists, platform abstains honestly instead of speculating.
- **Verification**: Unit tests verify citation validation failure when an unretrieved chunk URI is injected.

---

## 7. Extensibility & Portability
- **Requirement**: Self-contained runtime, no hardcoded developer paths, pluggable ontology and storage backends.
- **Architecture**:
  - Dynamic path resolution via `watson.shared.config.BASE_DIR` relative to file roots or `WATSON_BASE_DIR` environment variables.
  - Zero absolute paths (no hardcoded `C:\Users\HP` paths in deliverable code).
  - Standalone packaging into flat evaluator root `submission/Watson/` with lightweight compatibility wrappers.
