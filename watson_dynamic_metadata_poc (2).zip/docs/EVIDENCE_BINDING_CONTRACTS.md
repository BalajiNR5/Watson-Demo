# Canonical Evidence Binding & Non-Contamination Contracts

## 1. The Immutable 7-Tuple Invariant

To guarantee zero cross-entity or cross-indication contamination, Watson mandates that every retrieved chunk and knowledge graph assertion preserves an immutable association across 7 canonical dimensions:

$$\text{EvidenceTuple} = \langle \text{brand\_uri}, \text{drug\_uri}, \text{indication\_uri}, \text{therapeutic\_area\_uri}, \text{geography\_uri}, \text{document\_uri}, \text{chunk\_uri} \rangle$$

```python
class EvidenceItem(BaseModel):
    document_uri: str
    chunk_uri: str
    original_source_location: str
    brand: Optional[str] = None
    drug: Optional[str] = None
    indication: Optional[str] = None
    therapeutic_area: Optional[str] = None
    geography: Optional[str] = None
    graph_relationships: List[str]
    sparql_bindings: List[Dict[str, Any]]
    exact_supporting_passage: str
    retrieval_score: float
    quality_score: float
    authorization_result: str
    lifecycle_status: str
    provenance: Dict[str, Any]
    evidence_type: str
    evidence_relevance: str
    requested_dimension_coverage: List[str]

class EvidenceSet(BaseModel):
    request_id: str
    items: List[EvidenceItem]
    evidence_tuples: List[Dict[str, Optional[str]]]
    graph_facts: List[KGFact]
    missing_evidence: List[str]
    coverage_ratio: float
```

---

## 2. Mandatory Canonical Mappings

The table below defines the authoritative ground truth mappings enforced across Layer 2 and Layer 3:

| Brand | Active Drug (API) | Canonical Indication | Therapeutic Area | Target Geography | Primary Document |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Keytruda** | Pembrolizumab | Non-Small Cell Lung Cancer (NSCLC) | Oncology | European Union (EU) | `watson:Doc_007` |
| **Dupixent** | Dupilumab | Atopic Dermatitis (AD) | Immunology | United States (US) | `watson:Doc_005` |
| **Xolair** | Omalizumab | Persistent Asthma | Respiratory | India | `watson:Doc_008` |
| **Farxiga** | Dapagliflozin | Chronic Kidney Disease (CKD) | Metabolic / Renal | European Union (EU) | `watson:Doc_004` |
| **Jardiance** | Empagliflozin | Chronic Kidney Disease (CKD) | Metabolic / Renal | Germany / EU | `watson:Doc_011` |
| **Opdivo** | Nivolumab | Advanced Melanoma | Oncology | Canada | `watson:Doc_015` |
| **Spinraza** | Nusinersen | Spinal Muscular Atrophy (SMA) | Rare Disease | Japan | `watson:Doc_002` |
| **Trikafta** | Elexacaftor/Tezacaftor/Ivacaftor | Cystic Fibrosis | Rare Disease | Global | `watson:Doc_003` |
| **Tecfidera** | Dimethyl Fumarate | Multiple Sclerosis | Neurology | United Kingdom | `watson:Doc_001` |

---

## 3. Strict Non-Contamination Invariants

1. **Clause-Level Disambiguation:** In multi-brand queries (e.g. comparing Keytruda, Dupixent, and Xolair), geographic and indication terms in the prompt are parsed into distinct sub-clause spans. Keytruda never inherits Asthma or India from adjacent clauses.
2. **Pre-Filtering Isolation:** Each brand in a comparative matrix independently queries the ABAC pre-filtered vector index using its dedicated query vector and scope constraints.
3. **Synthesis Partitioning:** In comparative responses, each brand receives its own verified row in the structured matrix. Zero fields from unrelated graph nodes are combined into synthetic tuples.
4. **Non-Substitution:** If evidence for a brand in a requested indication is missing, Watson explicitly declares an **Evidence Gap** rather than substituting an unrequested entity (e.g. Farxiga).
