# Watson Query Contracts & Precedence Hierarchy

## 1. Typed QueryPlan Contract

Watson implements a single, strongly-typed contract (`QueryPlan`, inheriting/superseding `QueryIntent`) for structured query representation across all 15 stages of the Semantic GraphRAG pipeline.

```python
class QueryPlan(BaseModel):
    request_id: str
    authenticated_user_id: str
    conversation_id: str
    original_question: str
    conversational_intent: ConversationIntent
    research_intent: QuestionType
    requested_entities: List[str]
    canonical_entity_uris: List[str]
    required_brand_drug_indication_bindings: List[SubjectEntityQuery]
    requested_geographies: List[str]
    requested_therapeutic_areas: List[str]
    requested_document_ids: List[str]
    requested_metrics: List[str]
    temporal_constraints: Optional[Dict[str, Any]]
    comparison_dimensions: List[str]
    expected_answer_structure: str
    required_evidence_types: List[str]
    evidence_scope: str
    authorization_context: Dict[str, Any]
    
    # Interoperability fields
    raw_query: str
    effective_query: str
    question_type: QuestionType
    conversation_intent: ConversationIntent
    route: QueryRoute
    route_reason: str
    is_conversational: bool
    clinical_superiority_claim: bool
    conversational_response: Optional[str]
    requested_subjects: List[SubjectEntityQuery]
    requested_indications: List[str]
    requested_evidence_categories: List[str]
    requested_comparison_dimensions: List[str]
    required_answer_sections: List[str]
    minimum_evidence_coverage: float
```

---

## 2. Deterministic Intent Precedence Hierarchy

Query intent classification is strictly deterministic, evaluating request semantics according to this formal precedence hierarchy:

```mermaid
flowchart TD
    Q[User Query Text] --> G[Step 0: Conversational Gating Check]
    G -->|Greeting / Small Talk / Help / Out of Scope| CG[CONVERSATIONAL_GATE - Early Return]
    G -->|Research Query| F[Step 1: Multi-Turn Follow-Up Resolution]
    F --> P1{Rule 1: Temporal / Sentiment?}
    P1 -->|Yes| T1[TEMPORAL_SENTIMENT_ANALYSIS - SPARQL Route]
    P1 -->|No| P2{Rule 2: Knowledge Graph Multi-Brand Aggregation?}
    P2 -->|Yes| T2[KNOWLEDGE_GRAPH_AGGREGATION - HYBRID Route]
    P2 -->|No| P3{Rule 3: Ontology Relationship Trace?}
    P3 -->|Yes| T3[ONTOLOGY_RELATIONSHIP_TRACE - SPARQL Route]
    P3 -->|No| P4{Rule 4: Clinical Superiority Verification?}
    P4 -->|Yes| T4[CLINICAL_CLAIM_VERIFICATION - HYBRID Route]
    P4 -->|No| P5{Rule 5: Quantitative Metric Extraction?}
    P5 -->|Yes| T5[QUANTITATIVE_CLINICAL_EVIDENCE - HYBRID Route]
    P5 -->|No| P6{Rule 6: Lineage / Provenance Audit?}
    P6 -->|Yes| T6[PROVENANCE_TRACE - SPARQL Route]
    P6 -->|No| P7{Rule 7: Comparative Analysis?}
    P7 -->|Yes| T7[MARKET_ACCESS_COMPARISON - HYBRID Route]
    P7 -->|No| T8[DIRECT_RESEARCH_SYNTHESIS - HYBRID Route]
```

### Precedence Explanation

1. **Conversational Gating (Step 0):** Evaluated strictly before invoking FAISS or SPARQL. Filters non-research greetings, out-of-scope banter, and ambiguous requests in $< 20\text{ ms}$.
2. **Temporal Sentiment Analysis (Rule 1):** Triggered when explicit longitudinal trajectory comparisons (e.g., pre-2023 vs. 2023+) are detected. Requires SPARQL execution across RDF `SentimentAssertion` individuals.
3. **Knowledge Graph Multi-Brand Aggregation (Rule 2):** Triggered when multiple brands are queried for their approved names, APIs, indications, and TAs according to the knowledge graph. Preserves independent tuples without Farxiga substitution.
4. **Ontology Relationship Trace (Rule 3):** Triggered by explicit requests to explore semantic ontology predicates (e.g. `isBrandOf`, `treatsIndication`, `competesWith`) surrounding a focal brand entity (e.g. Farxiga).
5. **Clinical Claim Verification (Rule 4):** Triggered by claims of clinical superiority. Strictly rejects positive superiority conclusions when head-to-head randomized trials are absent.
6. **Quantitative Clinical Evidence (Rule 4B):** Triggered when specific numerical trial metrics (hazard ratios, overall survival, PFS) are requested. Enforces non-hallucination: absent endpoints are explicitly reported as `Not Reported`.
7. **Provenance & Lineage Trace (Rule 4C):** Traverses the document-to-chunk-to-reviewer chain of custody.
8. **Comparative Synthesis (Rule 5):** Evaluates multi-product or cross-market questions with independent brand evidence tuples and regional boundary isolation.
9. **Direct Synthesis (Rule 6):** Standard evidence retrieval for single-brand questions (e.g., Dupixent US HCP concerns).
