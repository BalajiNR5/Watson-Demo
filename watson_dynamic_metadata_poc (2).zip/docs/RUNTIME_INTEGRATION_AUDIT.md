# Watson Platform — Live Runtime Integration & Discrepancy Audit

**Audit Date:** 2026-10-16  
**Subject:** Live Browser Runtime vs. Automated Test Discrepancy Analysis  
**Working Directory:** `C:\Users\HP\Desktop\Watson_Project\Watson_Integrated_Platform`  

---

## 1. Executive Summary

Live browser testing revealed that conversational greetings (e.g. `"Hi Watson!"`) and capability inquiries (e.g. `"What kind of pharmaceutical research questions can you help me answer?"`) triggered full research retrieval (`HYBRID` route), returning unrelated governance and Jardiance/Spinraza excerpts. However, automated regression suites (`test_t01`, `test_c1`–`test_c3`) had previously reported passing.

This audit determined the exact technical root cause of this runtime divergence, inspected the active processes and network flow, and verified the implementation parity across the frontend, FastAPI backend, and test suites.

---

## 2. Process & Network Flow Inspection

| Dimension | Active Runtime Value | Verification Method |
| :--- | :--- | :--- |
| **Active Port** | `8000` (FastAPI Backend) | `Get-NetTCPConnection -LocalPort 8000` |
| **Process ID (PID)** | `11536` | `Get-Process -Id 11536` |
| **Executable** | `C:\Users\HP\AppData\Local\Programs\Python\Python312\python.exe` | Win32_Process WMI Query |
| **Command Line** | `python -m uvicorn backend.app.main:app --host 0.0.0.0 --port 8000` | Win32_Process WMI Query |
| **Working Directory** | `C:\Users\HP\Desktop\Watson_Project\Watson_Integrated_Platform` | Win32_Process WMI Query |
| **Frontend Endpoint** | `/api/chat` (HTTP POST) | `frontend/src/services/api.ts` line 253 |
| **Vite Proxy** | Proxies `/api` $\rightarrow$ `http://localhost:8000` | `frontend/vite.config.ts` line 9 |
| **Loaded Modules** | Canonical `backend/watson/retrieval/query_router.py` | Python `sys.modules` inspection |

---

## 3. Root Cause Analysis: The Automated Test Illusion

### 3.1 The Regex Pattern Flaw
The conversational gating function `classify_conversational_gate` in `backend/watson/retrieval/query_router.py` previously defined greetings as:
```python
if re.search(r"^\s*(hi|hello|hey|good\s+morning|good\s+afternoon|good\s+evening|greetings|howdy)\b[!\.\?]*$", q_lower):
```
and capability questions as:
```python
if re.search(r"^\s*(what\s+can\s+you\s+do|help|who\s+are\s+you|what\s+are\s+your\s+capabilities|how\s+does\s+watson\s+work)\b[!\.\?]*$", q_lower):
```

### 3.2 Why Automated Tests Passed
The automated unit tests only asserted exact minimal tokens:
- `test_t01_conversational_query`: query = `"hi"` $\rightarrow$ matched `^hi$` $\rightarrow$ **PASS**
- `test_c1_greeting_no_retrieval`: query = `"hi"` $\rightarrow$ matched `^hi$` $\rightarrow$ **PASS**
- `test_c2_small_talk_acknowledgement`: query = `"thanks!"` $\rightarrow$ matched `^thanks!$` $\rightarrow$ **PASS**
- `test_c3_capability_help`: query = `"what can you do"` $\rightarrow$ matched `^what can you do$` $\rightarrow$ **PASS**

### 3.3 Why Real Browser Interactions Failed
When a live researcher in the web UI typed:
1. `"Hi Watson!"`:
   - `q_lower` was `"hi watson!"`.
   - The regex required the word `"hi"` to be followed immediately by end-of-string or punctuation. Because `"watson"` followed `"hi"`, the regex returned `None`.
2. `"What kind of pharmaceutical research questions can you help me answer?"`:
   - Did not match the rigid 5-option pattern in line 204.
3. **The Fall-Through Cascade:**
   - Both failed queries fell through to `return ConversationIntent.RESEARCH_QUESTION, None`.
   - As a `RESEARCH_QUESTION`, they were passed to FAISS vector search, retrieved 5 top cosine chunks from `Doc_011` (Jardiance/Spinraza), and generated full 15-stage research answers with citations!

---

## 4. Phase 2 HTTP Reproduction Evidence

Raw HTTP POST requests sent directly to `http://localhost:8000/api/chat`:

```text
=== QUERY: Hi Watson! ===
Route: HYBRID
Conversation Intent: RESEARCH_QUESTION (INCORRECT)
Scored chunks count: 5 (INCORRECT - FAISS INVOCATION LEAK)
Citations count: 5 (INCORRECT)
Answer: Governance and Traceability. Designed to support chunk-level source traceability in Watson Layer 2/3... [watson:Doc_011:chunk:b:0004]

=== QUERY: What kind of pharmaceutical research questions can you help me answer? ===
Route: HYBRID
Conversation Intent: RESEARCH_QUESTION (INCORRECT)
Scored chunks count: 5 (INCORRECT - FAISS INVOCATION LEAK)
Answer: This synthetic Market Access Insight evaluates Jardiance (Empagliflozin) in Chronic Kidney Disease within the Metabolic therapeutic area for Germany. [watson:Doc_011:chunk:b:0000]

=== QUERY: Summarize the HCP concerns about Dupixent in US atopic dermatitis. ===
Route: HYBRID
Conversation Intent: RESEARCH_QUESTION (CORRECT)
Scored chunks count: 1 (CORRECT)
Answer: ### Healthcare Professional (HCP) Concerns and Perceptions. HCP feedback indicates that clinicians want clearer evidence summaries, safety differentiation, and patient-selection guidance for Dupixent in Atopic Dermatitis. [watson:Doc_005:chunk:b:0000]
```

---

## 5. Architectural Corrective Actions

1. **Broaden Conversational Recognition:**
   - Expand `classify_conversational_gate` with robust multi-word and punctuation-tolerant regex patterns.
   - Support `"Hi Watson!"`, `"Hello Watson"`, `"hey there"`, `"good morning watson"`.
   - Support capability questions like `"What kind of pharmaceutical research questions can you help me answer?"` and `"How can Watson help with market research?"`.
2. **Dedicated `CONVERSATIONAL` Route:**
   - Add `QueryRoute.CONVERSATIONAL = "CONVERSATIONAL"` to `models.py`.
   - Ensure the live route is explicitly reported as `CONVERSATIONAL`, not `HYBRID`.
3. **Execution Trace Skips:**
   - In `graphrag_assembler.py`, mark stages 4–15 as `SKIPPED` with explanation `"Skipped: Conversational gate satisfied request without document retrieval."`.
4. **Suppress Factual Grounding Badges on Social Answers:**
   - Set `answer_grounding_status="NOT_APPLICABLE"` and `claim_grounding_status="NOT_APPLICABLE"`.
   - Update `frontend/src/App.tsx` to hide grounding badges when `route === 'CONVERSATIONAL'` or `active_provider === 'CONVERSATIONAL_GATE'`.
5. **Real HTTP Regression Tests:**
   - Add end-to-end HTTP integration tests sending exact browser strings to the running FastAPI server.

---

## 6. Verification & Parity Confirmation

All corrective actions have been applied, compiled, and verified at live runtime:

1. **Uvicorn Backend Process Parity:**
   - Reloaded `backend.app.main:app` under Python 3.12 on port 8000.
   - Endpoint `/api/health` confirmed operational.

2. **Frontend Production Build:**
   - `npm run build` completed with zero TypeScript errors and zero Vite bundle warnings (`dist/` generated).

3. **Live HTTP Verification Results:**
   - Query: `"Hi Watson!"`
     - Route: `CONVERSATIONAL`
     - Intent: `GREETING`
     - Active Provider: `CONVERSATIONAL_GATE`
     - Retrieved Chunks: 0 | Citations: 0
     - Live Stages: 15 total (Stages 1–3 `COMPLETED`, Stages 4–15 `SKIPPED`)
     - Answer: Natural greeting without document leakage or spurious citations.
   - Query: `"What kind of pharmaceutical research questions can you help me answer?"`
     - Route: `CONVERSATIONAL`
     - Intent: `CAPABILITY_HELP`
     - Active Provider: `CONVERSATIONAL_GATE`
     - Retrieved Chunks: 0 | Citations: 0
     - Answer: Structured breakdown across Layer 1, Layer 2, Layer 3 and concrete research question archetypes.
   - Query: `"Summarize the HCP concerns about Dupixent in US atopic dermatitis"`
     - Route: `HYBRID`
     - Intent: `RESEARCH_QUESTION`
     - Active Provider: `DETERMINISTIC_GROUNDED_SYNTHESIS`
     - Retrieved Chunks: 1 (`Doc_005`) | Citations: 1
     - Answer: Grounded synthesis covering HCP perception, safety differentiation, and clinical evidence.

4. **Automated Test Suite Parity:**
   - Executed complete suite across 6 files:
     - `tests/test_targeted_qa_and_conversation.py` (22/22 passed)
     - `tests/test_semantic_invariants_and_routing.py` (14/14 passed)
     - `tests/test_systemic_architecture_repair.py` (9/9 passed)
     - `tests/test_question_answering_regression.py` (8/8 passed)
     - `tests/test_semantic_graphrag.py` (2/2 passed)
     - `tests/test_live_conversational_http.py` (4/4 passed)
   - **Total: 59 passed, 0 failed in 65.67s.**

5. **Submission Packaging:**
   - Ran `scripts/package_submission.py`.
   - Verified 38 deliverables in `SECTION_13_DELIVERABLES_MANIFEST.json`.
   - Generated `dist/Watson_Submission.zip` (SHA-256: `ca03b82c101baedd321c574526d44427da843e431d3aa6f3d896d145f240ad29`).

