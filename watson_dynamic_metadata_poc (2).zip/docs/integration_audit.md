# Watson Integration Audit & Asset Inventory

## 1. Inventory of Baseline Assets in Parent Workspace

The canonical implementation builds upon existing, rigorously tested baseline modules in `C:\Users\HP\Desktop\Watson_Project`:

- **Layer 1 Governed Ingestion**:
  - `parser.py`: Multi-format parsing (PDF via PyMuPDF, DOCX via python-docx, PPTX via python-pptx, TXT). Preserves layout, slide boundaries, speaker notes, and emits parse warnings.
  - `updated_chunker.py`: Implements empirical Strategy B semantic/structural chunking (page-bounded PDF, H1/H2 bounded DOCX, slide-bounded PPTX).
  - `chunker.py`: Multi-strategy chunker supporting both Strategy A (fixed 256/512 with 20% overlap) and Strategy B for empirical comparison.
  - `dedup_detector.py`: Exact SHA-256 hash match + near-dedup token similarity (>0.85 within TA).
  - `pii_detector.py`: High-precision pattern detector for patient names, phone numbers, emails, MRNs/SSNs.
  - `metadata_extractor.py`: Extracts 15 mandatory PRD fields against seed vocabularies.
  - `lifecycle_manager.py`: Implements lifecycle state transitions (DRAFT -> UNDER_REVIEW -> ACTIVE -> ARCHIVED / REJECTED) and blocks non-ACTIVE assets.
  - `abac_engine.py`: Role-based and attribute-based security enforcement (VIEWER, ANALYST, SPOC, ADMIN).
  - `quality_scorer.py`: Explainable composite quality score ($0.3 \times \text{completeness} + 0.3 \times \text{richness} + 0.2 \times \text{sample} + 0.2 \times \text{freshness}$).
  - `expiry_manager.py` & `expiry_scanner.py`: Enforces study retention policies and triggers UNDER_REVIEW state for expired docs.
  - `audit_query.py`: Queries append-only `audit_log.jsonl`.

- **Layer 2 Semantic Foundation**:
  - `pharma.ttl`: Hand-crafted OWL/RDFS/SKOS ontology with 12+ classes, object properties, transitive properties (`isSubIndicationOf`), and external alignments (ChEBI, DOID, MeSH).
  - `populate_graph.py`: Builds the pristine seed graph with $\ge 700$ triples.
  - `entity_resolver.py`: Resolves mentions via exact dictionary matching, rapidfuzz fuzzy matching (>0.85), or provisional entity quarantine.
  - `enrichment_pipeline.py`: spaCy NER + entity resolution, building triples for documents, chunks, sentiment assertions, and lineage records.
  - `taxonomy_manager.py`: Manages `taxonomy_store.json`.
  - `execute_sparql_queries.py`: Automated execution of SPARQL benchmark suite Q01–Q11.

- **Baseline Test Suite**:
  - 237 passing tests executed in parent directory (`237 passed in 298.52s`).

## 2. Porting & Refactoring Strategy

1. **Modular Organization**: All business logic is organized into clean, coherent subpackages under `backend/watson/`:
   - `watson.shared`: models, ids, config, exceptions, audit
   - `watson.ingestion`: parser, chunker, dedup, pii, metadata, coordinator
   - `watson.governance`: lifecycle, abac, quality, expiry, audit_query
   - `watson.semantics`: ontology, seed, resolver, enrichment, taxonomy, sparql
   - `watson.retrieval`: vector_index, router, graphrag, qwen, guardrails
   - `watson.spaces`: knowledge_space
   - `watson.mcp`: mcp_tools
   - `watson.observability`: telemetry, feedback, telemetry_query

2. **Section 13 Evaluator Compatibility**:
   Flat root scripts in `submission/Watson/` act as thin delegating wrappers into `backend/watson/`, guaranteeing:
   - 100% adherence to PRD Section 13 file naming
   - Full backward compatibility for standalone CLI calls
   - Zero hardcoded developer-specific absolute paths
