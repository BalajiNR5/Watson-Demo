import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
BACKEND = ROOT / "backend"
sys.path.insert(0, str(BACKEND))

from watson.retrieval.graphrag_assembler import GraphRAGAssembler


def test_semantic_graphrag_pipeline():
    print("=" * 60)
    print("TESTING 15-STAGE SEMANTIC GRAPHRAG PIPELINE")
    print("=" * 60)

    assembler = GraphRAGAssembler()

    # Query 1: Clinical multi-hop query
    q1 = "What is the clinical trial evidence and target mechanism for Keytruda in NSCLC?"
    print(f"\n[TEST 1] Executing query: '{q1}' (User: D4 Admin)")
    res1 = assembler.retrieve_and_synthesize(q1, user_id="D4")

    print(f" -> Route: {res1.route.value}")
    print(f" -> Active Provider: {res1.active_provider}")
    print(f" -> Latency: {res1.latency_ms} ms")
    print(f" -> Live Stages: {len(res1.live_stages)} stages executed")
    assert len(res1.live_stages) == 15, f"Expected 15 stages, got {len(res1.live_stages)}"
    print(f" -> Knowledge Graph Facts: {len(res1.kg_facts)} facts")
    assert len(res1.kg_facts) > 0, "Expected non-zero KG facts for Keytruda in NSCLC"
    print(f" -> Citations: {len(res1.citations)}")
    assert len(res1.citations) > 0, "Expected non-zero citations"
    print(f" -> Lineage Records: {len(res1.lineage_records)}")
    assert len(res1.lineage_records) > 0, "Expected non-zero lineage records"
    print(f" -> Synthesized Answer:\n    {res1.answer[:250]}...")

    # Query 2: Temporal Sentiment Query
    q2 = "Show declining sentiment trends for Farxiga over time"
    print(f"\n[TEST 2] Executing query: '{q2}' (User: D4 Admin)")
    res2 = assembler.retrieve_and_synthesize(q2, user_id="D4")
    print(f" -> Route: {res2.route.value}")
    print(f" -> Live Stages: {len(res2.live_stages)}")
    print(f" -> Temporal Facts Found: {len(res2.kg_facts)}")

    # Query 3: ABAC Security Isolation (D3 Viewer vs D4 Admin)
    print("\n[TEST 3] ABAC Pre-Filter Security Isolation Check")
    res_d3 = assembler.retrieve_and_synthesize("Keytruda oncology clinical data", user_id="D3")
    res_d4 = assembler.retrieve_and_synthesize("Keytruda oncology clinical data", user_id="D4")
    d3_chunks = len(assembler.get_allowed_chunk_uris("D3"))
    d4_chunks = len(assembler.get_allowed_chunk_uris("D4"))
    print(f" -> D3 (Viewer) allowed chunk space: {d3_chunks}")
    print(f" -> D4 (Admin) allowed chunk space: {d4_chunks}")
    assert d3_chunks < d4_chunks, "Admin must have broader clearance than Viewer"
    restricted_in_d3 = sum(1 for c in res_d3.scored_chunks if "CONFIDENTIAL" in str(c) or "RESTRICTED" in str(c))
    assert restricted_in_d3 == 0, "Zero-leakage violated: restricted chunks present in Viewer result"
    print(f" -> Strict Zero Data Leakage: Verified ({restricted_in_d3} restricted items leaked)")

    print("\n" + "=" * 60)
    print("ALL SEMANTIC GRAPHRAG TESTS PASSED (EXIT CODE 0)")
    print("=" * 60)


if __name__ == "__main__":
    test_semantic_graphrag_pipeline()
