# tests/test_question_answering_regression.py
"""
End-to-End Regression Test Suite for Watson Semantic GraphRAG Question Answering.
Validates all 8 Priority 8 question types:
A. Clinical evidence for a drug and specific indication
B. Competitive comparison between two drugs
C. HCP sentiment trends over time
D. Document provenance and reviewer lineage
E. Multi-hop ontology relationship queries
F. Questions outside the available knowledge base (insufficient context detection)
G. Questions with relevant documents but irrelevant graph neighbors
H. Unauthorized clinical evidence requests (ABAC isolation)
"""

import sys
import unittest
from pathlib import Path

BACKEND_DIR = Path(__file__).resolve().parent.parent / "backend"
if str(BACKEND_DIR) not in sys.path:
    sys.path.insert(0, str(BACKEND_DIR))
ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from watson.retrieval.graphrag_assembler import GraphRAGAssembler


class TestQuestionAnsweringRegression(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.assembler = GraphRAGAssembler()

    def test_question_a_clinical_evidence_keytruda_nsclc(self):
        """Type A: Clinical evidence for Keytruda in NSCLC."""
        print("\n" + "=" * 60)
        print("TEST A: Clinical Evidence for Keytruda in NSCLC")
        print("=" * 60)
        res = self.assembler.retrieve_and_synthesize(
            query="What is the clinical evidence for Keytruda in NSCLC?",
            user_id="D4",
        )
        print("Answer:\n", res.answer)
        print(f"Relevance: {res.answer_relevance_status} | Grounding: {res.answer_grounding_status}")

        self.assertEqual(res.pipeline_execution_status, "COMPLETED")
        self.assertEqual(res.answer_relevance_status, "RELEVANT")
        self.assertEqual(res.answer_grounding_status, "GROUNDED")
        self.assertGreater(len(res.citations), 0)
        # Must address NSCLC and not substitute melanoma
        self.assertIn("nsclc", res.answer.lower())
        self.assertNotIn("knowledge graph relations confirm: keytruda label", res.answer.lower())
        self.assertTrue(any(h in res.answer for h in ["Clinical Evidence Overview", "Relevant Clinical Studies", "Efficacy Findings"]))

    def test_question_b_competitive_comparison(self):
        """Type B: Competitive comparison between two drugs (Farxiga vs Jardiance in CKD)."""
        print("\n" + "=" * 60)
        print("TEST B: Competitive Comparison between Farxiga and Jardiance in CKD")
        print("=" * 60)
        res = self.assembler.retrieve_and_synthesize(
            query="Compare Farxiga versus Jardiance in Chronic Kidney Disease",
            user_id="D4",
        )
        print("Answer:\n", res.answer[:300] + "...")
        print(f"Relevance: {res.answer_relevance_status} | Grounding: {res.answer_grounding_status}")

        self.assertEqual(res.pipeline_execution_status, "COMPLETED")
        self.assertEqual(res.answer_grounding_status, "GROUNDED")
        self.assertIn("farxiga", res.answer.lower())

    def test_question_c_temporal_sentiment_trends(self):
        """Type C: HCP sentiment trends over time."""
        print("\n" + "=" * 60)
        print("TEST C: HCP Sentiment Trends over Time")
        print("=" * 60)
        res = self.assembler.retrieve_and_synthesize(
            query="Show declining sentiment trends for Farxiga over time",
            user_id="D4",
        )
        print("Answer:\n", res.answer[:300] + "...")
        print(f"Relevance: {res.answer_relevance_status} | Facts: {len(res.kg_facts)}")

        self.assertEqual(res.pipeline_execution_status, "COMPLETED")
        self.assertGreater(len(res.kg_facts), 0)

    def test_question_d_document_provenance_and_lineage(self):
        """Type D: Document provenance and reviewer lineage."""
        print("\n" + "=" * 60)
        print("TEST D: Document Provenance & Reviewer Lineage")
        print("=" * 60)
        res = self.assembler.retrieve_and_synthesize(
            query="What is the lineage, reviewer, and approval history for Keytruda NSCLC documents?",
            user_id="D4",
        )
        print(f"Lineage Records Created: {len(res.lineage_records)}")
        for rec in res.lineage_records[:2]:
            print(f"  - Chunk: {rec.chunk_uri} | Reviewer: {rec.reviewer_id} | State: {rec.lifecycle_state}")

        self.assertGreater(len(res.lineage_records), 0)
        self.assertEqual(res.lineage_records[0].lifecycle_state, "ACTIVE")

    def test_question_e_multi_hop_ontology_query(self):
        """Type E: Multi-hop ontology relationship queries."""
        print("\n" + "=" * 60)
        print("TEST E: Multi-hop Ontology Relationship Query")
        print("=" * 60)
        res = self.assembler.retrieve_and_synthesize(
            query="What active brands compete with Opdivo and what indications do they treat?",
            user_id="D4",
        )
        print("Answer:\n", res.answer[:300] + "...")
        print(f"KG Facts count: {len(res.kg_facts)}")

        self.assertEqual(res.pipeline_execution_status, "COMPLETED")
        self.assertGreater(len(res.kg_facts), 0)

    def test_question_f_outside_knowledge_base(self):
        """Type F: Questions outside the available knowledge base (insufficient context detection)."""
        print("\n" + "=" * 60)
        print("TEST F: Outside Knowledge Base (Keytruda in Alzheimer's)")
        print("=" * 60)
        res = self.assembler.retrieve_and_synthesize(
            query="What is the clinical evidence for Keytruda in Alzheimer's disease?",
            user_id="D4",
        )
        print("Answer:\n", res.answer)
        print(f"Relevance: {res.answer_relevance_status} | Gap Detected: {res.evidence_gap_detected}")

        self.assertEqual(res.pipeline_execution_status, "COMPLETED")
        self.assertEqual(res.answer_relevance_status, "INSUFFICIENT_EVIDENCE")
        self.assertTrue(
            "insufficient context" in res.answer.lower()
            or "cannot answer from available evidence" in res.answer.lower()
        )
        # Must NOT hallucinate or substitute melanoma
        self.assertNotIn("treatsindication melanoma", res.answer.lower())

    def test_question_g_relevant_documents_irrelevant_graph_neighbors(self):
        """Type G: Questions with relevant documents but irrelevant graph neighbors."""
        print("\n" + "=" * 60)
        print("TEST G: Relevant Documents with Irrelevant Graph Neighbors")
        print("=" * 60)
        res = self.assembler.retrieve_and_synthesize(
            query="What are the market access barriers for Dupixent in India?",
            user_id="D4",
        )
        print("Answer:\n", res.answer[:300] + "...")
        print(f"Relevance: {res.answer_relevance_status} | Citations: {len(res.citations)}")

        self.assertEqual(res.pipeline_execution_status, "COMPLETED")
        self.assertIn("dupixent", res.answer.lower())

    def test_question_h_unauthorized_clinical_evidence_abac(self):
        """Type H: Unauthorized clinical evidence requests (ABAC security isolation)."""
        print("\n" + "=" * 60)
        print("TEST H: ABAC Security Isolation (D3 Viewer vs D4 Admin)")
        print("=" * 60)
        viewer_allowed = self.assembler.get_allowed_chunk_uris("D3")
        admin_allowed = self.assembler.get_allowed_chunk_uris("D4")

        print(f"Viewer (D3) Allowed Chunks: {len(viewer_allowed)}")
        print(f"Admin (D4) Allowed Chunks: {len(admin_allowed)}")

        self.assertEqual(len(viewer_allowed), 20)
        self.assertEqual(len(admin_allowed), 70)
        # Zero restricted chunks in viewer set
        restricted_in_viewer = [c for c in viewer_allowed if "Doc_012" in c or "Doc_014" in c]
        self.assertEqual(len(restricted_in_viewer), 0)

    def test_cross_query_test_a_eu_market_access_keytruda(self):
        """Cross-Query Remediation TEST A: Keytruda in EU NSCLC Market Access."""
        print("\n" + "=" * 60)
        print("CROSS-QUERY TEST A: Keytruda in EU NSCLC Market Access")
        print("=" * 60)
        query = "According to the EU market access report, what are the main reimbursement, treatment pathway, and HCP concerns surrounding Keytruda for non-small-cell lung cancer?"
        res = self.assembler.retrieve_and_synthesize(query=query, user_id="D4")
        print("Answer:\n", res.answer)
        print("Quality Diagnostics:\n", res.quality_diagnostics)

        self.assertEqual(res.pipeline_execution_status, "COMPLETED")
        self.assertEqual(res.quality_diagnostics.get("geographic_alignment"), "ALIGNED")
        self.assertEqual(res.quality_diagnostics.get("user_facing_readability"), "HIGH")
        # Must cite Doc_007 (EU report) and NOT cite US Doc_009 as sole source
        doc_007_cited = any(":Doc_007:" in c.source_uri for c in res.citations)
        self.assertTrue(doc_007_cited)
        # Must NOT contain raw metadata leaks
        self.assertNotIn("synthetic id: syn-", res.answer.lower())
        self.assertNotIn("study type market access insight", res.answer.lower())
        # Must cover reimbursement, pathway, and HCP concerns
        self.assertTrue(any(w in res.answer.lower() for w in ["reimbursement", "prior authorization", "budget impact"]))
        self.assertTrue(any(w in res.answer.lower() for w in ["treatment pathway", "sequencing", "pathway"]))
        self.assertTrue(any(w in res.answer.lower() for w in ["hcp", "clinician", "physician", "patient-selection", "safety differentiation"]))

    def test_cross_query_test_b_us_hcp_dupixent(self):
        """Cross-Query Remediation TEST B: Dupixent in US Atopic Dermatitis."""
        print("\n" + "=" * 60)
        print("CROSS-QUERY TEST B: Dupixent in US Atopic Dermatitis")
        print("=" * 60)
        query = "What concerns do healthcare professionals express about Dupixent for atopic dermatitis in the United States, and what improvements do they recommend?"
        res = self.assembler.retrieve_and_synthesize(query=query, user_id="D4")
        print("Answer:\n", res.answer)
        print("Quality Diagnostics:\n", res.quality_diagnostics)

        self.assertEqual(res.pipeline_execution_status, "COMPLETED")
        self.assertEqual(res.quality_diagnostics.get("geographic_alignment"), "ALIGNED")
        self.assertEqual(res.quality_diagnostics.get("user_facing_readability"), "HIGH")
        # Must cite Doc_005 (US survey) and NEVER cite India Doc_014
        doc_005_cited = any(":Doc_005:" in c.source_uri for c in res.citations)
        doc_014_cited = any(":Doc_014:" in c.source_uri for c in res.citations)
        self.assertTrue(doc_005_cited)
        self.assertFalse(doc_014_cited)
        # Must NOT leak metadata
        self.assertNotIn("synthetic id: syn-", res.answer.lower())
        # Must cover concerns and recommendations
        self.assertTrue(any(w in res.answer.lower() for w in ["concern", "safety differentiation", "patient-selection", "clearer evidence"]))
        self.assertTrue(any(w in res.answer.lower() for w in ["recommend", "concise comparison", "implementation guidance"]))

    def test_cross_query_test_c_comparative_three_market(self):
        """Cross-Query Remediation TEST C: Multi-Product Comparison (Keytruda EU, Dupixent US, Xolair India)."""
        print("\n" + "=" * 60)
        print("CROSS-QUERY TEST C: Three-Market Comparison (Keytruda EU, Dupixent US, Xolair India)")
        print("=" * 60)
        query = "Compare the market access considerations for Keytruda in EU oncology, Dupixent in US immunology, and Xolair in Indian respiratory care. What factors are common, and what differences can the available evidence establish?"
        res = self.assembler.retrieve_and_synthesize(query=query, user_id="D4")
        print("Answer:\n", res.answer)
        print("Coverage Matrix:\n", res.evidence_coverage_matrix)
        print("Quality Diagnostics:\n", res.quality_diagnostics)

        self.assertEqual(res.pipeline_execution_status, "COMPLETED")
        self.assertEqual(res.quality_diagnostics.get("entity_coverage"), "FULL_COVERAGE")
        self.assertEqual(res.quality_diagnostics.get("answer_completeness"), "COMPLETE")
        # All three products must be cited
        all_cited = " ".join(c.source_uri for c in res.citations)
        self.assertTrue(any(":Doc_007:" in all_cited or "Keytruda" in res.answer for _ in [1]))
        self.assertTrue(any(":Doc_005:" in all_cited or "Dupixent" in res.answer for _ in [1]))
        self.assertTrue(any(":Doc_008:" in all_cited or "Xolair" in res.answer for _ in [1]))
        # Must feature Markdown table
        self.assertIn("|", res.answer)
        self.assertIn("Drug / Brand", res.answer)
        # Must feature Common Factors and Established Differences
        self.assertIn("Common", res.answer)
        self.assertIn("Differences", res.answer)


if __name__ == "__main__":
    unittest.main()
