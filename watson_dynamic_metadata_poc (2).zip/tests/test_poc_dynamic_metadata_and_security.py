"""
Comprehensive Automated Test Suite for the Watson Dynamic Metadata & Access Control POC
=======================================================================================
Covers:
1. Phase 2: Administrator-Only Ingestion Console & Upload Access Control (10+ scenarios)
2. Phase 3: Databricks Pharmaceuticals Product MVM Dynamic Ingestion & LKG Fallback
3. Phase 4: Vocabulary Compatibility, Layer 2 RDF Overlay & Layer 3 Non-Destructive Integration
4. Phase 5: Interactive Visual Graph Explorer (Views A, B, C, Catalog, Mappings, Refresh Diff)
5. Phase 6: End-to-End SPARQL Studio & Research Copilot Non-Regression
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import sys
import tempfile
import time
from pathlib import Path

import pytest

PROJECT = Path(__file__).resolve().parents[1]
WORK = Path(tempfile.mkdtemp(prefix="watson-poc-tests-"))
import atexit
atexit.register(lambda: shutil.rmtree(WORK, ignore_errors=True))

for folder in ["data", "ontology", "queries", "outputs", "reports"]:
    src = PROJECT / folder
    if src.exists():
        shutil.copytree(src, WORK / folder)

(WORK / "dedup_store.json").write_text(json.dumps({"exact_hashes": {}, "title_registry": []}))
os.environ.update(
    WATSON_BASE_DIR=str(WORK),
    HF_HUB_OFFLINE="1",
    TRANSFORMERS_OFFLINE="1",
    WATSON_ALLOW_CLOUD="0",
)
if (PROJECT / "approved_models/all-MiniLM-L6-v2").is_dir():
    os.environ["WATSON_EMBEDDING_MODEL"] = str(PROJECT / "approved_models/all-MiniLM-L6-v2")

sys.path[:0] = [str(PROJECT), str(PROJECT / "backend")]
from office_policy import disable_tokenizer_downloads
disable_tokenizer_downloads()

from fastapi.testclient import TestClient
from app import main as api_main
from app.security.auth import (
    assign_admin_role,
    create_session_token,
    hash_password_pbkdf2,
    verify_password_pbkdf2,
)
from watson.ingestion.databricks_metadata_ingestor import (
    DatabricksProductMetadataIngestor,
    MetadataIngestionError,
)
from watson.semantics.metadata_compatibility import SemanticCompatibilityEngine
from watson.semantics.graph_explorer_service import GraphExplorerService
from watson.shared.config import (
    AUDIT_LOG_FILE,
    CHUNK_URI_MAP_FILE,
    FAISS_INDEX_FILE,
    LIFECYCLE_STORE_FILE,
    PHARMA_KG_FILE,
    RAW_DATA_DIR,
    SEED_VOCABULARIES_FILE,
    STAGING_DATA_DIR,
    USER_REGISTRY_FILE,
)

BASELINE_SEED_SHA256 = hashlib.sha256((PROJECT / "data/seed/seed_vocabularies.json").read_bytes()).hexdigest()
SAMPLE_DOC_TEXT = (
    "HCP Perception Survey\n"
    "Therapeutic Area: Oncology\n"
    "Keytruda pembrolizumab treats NSCLC in US clinical practice.\n"
    "Evidence shows strong biomarker adoption and PD-L1 testing rates.\n"
)


@pytest.fixture
def client():
    with TestClient(api_main.app, base_url="http://localhost") as c:
        yield c


# ============================================================================
# 1. PHASE 2: ADMINISTRATOR-ONLY INGESTION CONSOLE & UPLOAD ACCESS CONTROL
# ============================================================================

def test_01_unauthenticated_users_cannot_access_ingestion_console_or_upload(client):
    """Requirement 1: Unauthenticated requests to Ingestion Console and upload endpoints are rejected with 401."""
    res_console = client.get("/api/ingestion/console")
    assert res_console.status_code == 401, res_console.text

    res_upload = client.post(
        "/api/ingestion/upload",
        files={"file": ("unauth.txt", SAMPLE_DOC_TEXT.encode(), "text/plain")},
    )
    assert res_upload.status_code == 401, res_upload.text

    res_batch = client.post(
        "/api/ingestion/upload/batch",
        files=[("files", ("unauth1.txt", SAMPLE_DOC_TEXT.encode(), "text/plain"))],
    )
    assert res_batch.status_code == 401, res_batch.text

    res_import = client.post("/api/ingestion/import", json={"source_filename": "doc.txt"})
    assert res_import.status_code == 401, res_import.text

    res_retry = client.post("/api/ingestion/retry", json={"document_uri": "watson:Doc_001"})
    assert res_retry.status_code == 401, res_retry.text

    res_dbx = client.post("/api/ingestion/databricks/ingest", json={})
    assert res_dbx.status_code == 401, res_dbx.text


def test_02_non_admin_users_cannot_access_ingestion_console(client):
    """Requirement 2: Authenticated non-admin personas receive 403 Forbidden on the Ingestion Console endpoint."""
    non_admin_ids = ["D3", "U_ANALYST", "U_SPOC", "U_COMPLIANCE", "U_COMMERCIAL", "U_EXTERNAL"]
    for uid in non_admin_ids:
        res = client.get("/api/ingestion/console", headers={"x-user-id": uid})
        assert res.status_code == 403, f"Expected 403 for {uid}, got {res.status_code}: {res.text}"
        assert "not authorized" in res.json()["detail"].lower()


def test_03_frontend_ui_hides_and_guards_ingestion_console_for_non_admins():
    """Requirement 3: Frontend UI hides Ingestion Console nav for non-admins and renders Access Denied screen without upload inputs."""
    app_tsx = (PROJECT / "frontend/src/App.tsx").read_text(encoding="utf-8")
    assert "isAdminUser" in app_tsx
    assert "currentUser.role === 'ADMIN'" in app_tsx
    assert "documents:ingest" in app_tsx
    assert "Access Denied — Administrator Privileges Required (HTTP 403)" in app_tsx
    assert "{isAdminUser && (" in app_tsx


def test_04_non_admin_users_cannot_bypass_ui_via_direct_upload_api(client):
    """Requirement 4: Non-admin users cannot upload documents via direct API calls, even when spoofing role headers."""
    non_admin_ids = ["D3", "U_ANALYST", "U_SPOC", "U_COMPLIANCE", "U_COMMERCIAL", "U_EXTERNAL"]
    for uid in non_admin_ids:
        res = client.post(
            "/api/ingestion/upload?role=ADMIN&is_admin=true",
            files={"file": ("bypass.txt", SAMPLE_DOC_TEXT.encode(), "text/plain")},
            headers={
                "x-user-id": uid,
                "X-User-Role": "ADMIN",
                "X-Permissions": "documents:ingest",
            },
        )
        assert res.status_code == 403, f"Expected 403 for {uid}, got {res.status_code}"

        login_res = client.post("/api/auth/login", json={"user_id": uid})
        assert login_res.status_code == 200
        token = login_res.json()["access_token"]
        res_bearer = client.post(
            "/api/ingestion/upload",
            files={"file": ("bypass_bearer.txt", SAMPLE_DOC_TEXT.encode(), "text/plain")},
            headers={"Authorization": f"Bearer {token}", "X-User-Role": "ADMIN"},
        )
        assert res_bearer.status_code == 403


def test_05_non_admin_users_cannot_trigger_alternate_ingestion_endpoints(client):
    """Requirement 5: Non-admin users are blocked (403) on batch upload, file import, retry, and Databricks metadata ingest."""
    for uid in ["D3", "U_ANALYST", "U_SPOC", "U_COMPLIANCE"]:
        headers = {"x-user-id": uid}
        assert client.post(
            "/api/ingestion/upload/batch",
            files=[("files", ("b1.txt", SAMPLE_DOC_TEXT.encode(), "text/plain"))],
            headers=headers,
        ).status_code == 403
        assert client.post(
            "/api/ingestion/import",
            json={"source_filename": "some_doc.txt"},
            headers=headers,
        ).status_code == 403
        assert client.post(
            "/api/ingestion/retry",
            json={"document_uri": "watson:Doc_001"},
            headers=headers,
        ).status_code == 403
        assert client.post(
            "/api/ingestion/databricks/ingest",
            json={},
            headers=headers,
        ).status_code == 403


def test_06_administrators_can_access_console_and_perform_valid_uploads(client):
    """Requirement 6: Authenticated administrators (D4) can access the console and perform single, batch, and metadata uploads."""
    login = client.post("/api/auth/login", json={"user_id": "D4"})
    assert login.status_code == 200
    token = login.json()["access_token"]
    auth_headers = {"Authorization": f"Bearer {token}"}

    console = client.get("/api/ingestion/console", headers=auth_headers)
    assert console.status_code == 200, console.text
    assert console.json()["authorized"] is True
    assert console.json()["role"] == "ADMIN"

    unique_text = SAMPLE_DOC_TEXT + f"\nUnique admin upload timestamp: {time.time()}\n"
    up_res = client.post(
        "/api/ingestion/upload",
        files={"file": ("admin-study.txt", unique_text.encode(), "text/plain")},
        headers=auth_headers,
    )
    assert up_res.status_code == 200, up_res.text
    staged = up_res.json()
    assert staged["lifecycle_state"] == "UNDER_REVIEW"
    assert staged["staged_by"] == "D4"


def test_07_invalid_expired_and_csrf_missing_authentication_rejected(client):
    """Requirement 7: Invalid, tampered, or expired tokens return 401; cookie sessions without CSRF token return 403."""
    bad_token = "eyJleHAiOjk5OTk5OTk5OTksInN1YiI6IkQ0In0.invalidsignature"
    res_tampered = client.post(
        "/api/ingestion/upload",
        files={"file": ("tampered.txt", SAMPLE_DOC_TEXT.encode(), "text/plain")},
        headers={"Authorization": f"Bearer {bad_token}"},
    )
    assert res_tampered.status_code == 401

    expired_bundle = create_session_token("D4", "ADMIN", ["documents:ingest"], ttl_seconds=-10)
    res_expired = client.post(
        "/api/ingestion/upload",
        files={"file": ("expired.txt", SAMPLE_DOC_TEXT.encode(), "text/plain")},
        headers={"Authorization": f"Bearer {expired_bundle['access_token']}"},
    )
    assert res_expired.status_code == 401
    assert "expired" in res_expired.json()["detail"].lower()

    res_unknown = client.post(
        "/api/ingestion/upload",
        files={"file": ("unknown.txt", SAMPLE_DOC_TEXT.encode(), "text/plain")},
        headers={"x-user-id": "NON_EXISTENT_USER_999"},
    )
    assert res_unknown.status_code == 401

    valid_bundle = create_session_token("D4", "ADMIN", ["documents:ingest"], ttl_seconds=3600)
    client.cookies.set("watson_session", valid_bundle["access_token"])
    try:
        res_no_csrf = client.post(
            "/api/ingestion/upload",
            files={"file": ("csrf_test.txt", SAMPLE_DOC_TEXT.encode(), "text/plain")},
        )
        assert res_no_csrf.status_code == 403
        assert "csrf" in res_no_csrf.json()["detail"].lower()

        unique_csrf_text = SAMPLE_DOC_TEXT + f"\nCSRF verified admin upload: {time.time()}\n"
        res_with_csrf = client.post(
            "/api/ingestion/upload",
            files={"file": ("csrf_ok.txt", unique_csrf_text.encode(), "text/plain")},
            headers={"X-CSRF-Token": valid_bundle["csrf_token"]},
        )
        assert res_with_csrf.status_code == 200
    finally:
        client.cookies.clear()


def test_08_unauthorized_requests_do_not_mutate_files_corpus_or_graph(client):
    """Requirement 8: Rejected 401/403 requests leave zero side effects on disk, stores, or RDF graph."""
    before_staging = set(STAGING_DATA_DIR.glob("*"))
    before_raw = set(RAW_DATA_DIR.rglob("*"))
    before_lifecycle = LIFECYCLE_STORE_FILE.read_bytes()
    before_triples = len(api_main.assembler.graph)

    client.post(
        "/api/ingestion/upload",
        files={"file": ("should_not_exist.txt", b"Unauthorized content", "text/plain")},
    )
    client.post(
        "/api/ingestion/upload",
        files={"file": ("should_not_exist_2.txt", b"Viewer content", "text/plain")},
        headers={"x-user-id": "D3"},
    )

    assert set(STAGING_DATA_DIR.glob("*")) == before_staging
    assert set(RAW_DATA_DIR.rglob("*")) == before_raw
    assert LIFECYCLE_STORE_FILE.read_bytes() == before_lifecycle
    assert len(api_main.assembler.graph) == before_triples


def test_09_existing_non_ingestion_features_remain_accessible_to_ordinary_users(client):
    """Requirement 9: Ordinary users retain full access to Document Library, Copilot, Search, SPARQL Studio, and KG Explorer."""
    for uid in ["D3", "U_ANALYST", "U_SPOC"]:
        headers = {"x-user-id": uid}
        assert client.get("/api/documents", headers=headers).status_code == 200
        assert client.post("/api/search", json={"query": "Keytruda NSCLC", "top_k": 3}, headers=headers).status_code == 200
        assert client.post("/api/chat", json={"query": "What is the clinical evidence for Keytruda in NSCLC?"}, headers=headers).status_code == 200
        assert client.get("/api/graph/sparql/templates", headers=headers).status_code == 200
        assert client.post(
            "/api/graph/sparql",
            json={"query": "SELECT ?s ?p ?o WHERE { ?s ?p ?o } LIMIT 5"},
            headers=headers,
        ).status_code == 200
        assert client.get("/api/graph/explorer", headers=headers).status_code == 200
        assert client.get("/api/graph/catalog", headers=headers).status_code == 200
        assert client.get("/api/graph/mappings", headers=headers).status_code == 200


def test_10_audit_events_recorded_without_sensitive_leaks(client):
    """Requirement 10: Audit logs record actor ID, timestamp, operation, and outcome without leaking document contents or tokens."""
    secret_marker = "TOP_SECRET_CLINICAL_BODY_DO_NOT_LOG_987654"
    login = client.post("/api/auth/login", json={"user_id": "D4"})
    token = login.json()["access_token"]

    client.post(
        "/api/ingestion/upload",
        files={"file": ("denied_audit.txt", secret_marker.encode(), "text/plain")},
        headers={"x-user-id": "D3"},
    )
    client.post(
        "/api/ingestion/upload",
        files={"file": ("allowed_audit.txt", (SAMPLE_DOC_TEXT + secret_marker).encode(), "text/plain")},
        headers={"Authorization": f"Bearer {token}"},
    )

    audit_raw = AUDIT_LOG_FILE.read_text(encoding="utf-8")
    assert secret_marker not in audit_raw, "Document content must never appear in audit logs!"
    assert token not in audit_raw, "Session token must never appear in audit logs!"

    logs = client.get("/api/audit/logs", headers={"x-user-id": "D4"}).json()
    event_types = {entry["event_type"] for entry in logs}
    assert "INGESTION_ACCESS_DENIED" in event_types
    assert "INGESTION_ACCESS_GRANTED" in event_types
    assert "INGESTION_UPLOAD_ATTEMPT" in event_types
    assert "INGESTION_UPLOAD_SUCCESS" in event_types


def test_11_upload_safeguards_and_admin_assignment_utility(client, tmp_path):
    """Verifies executable blocking, double-extension blocking, and server-side assign_admin_role utility."""
    headers = {"x-user-id": "D4"}
    res_double = client.post(
        "/api/ingestion/upload",
        files={"file": ("exploit.exe.txt", SAMPLE_DOC_TEXT.encode(), "text/plain")},
        headers=headers,
    )
    assert res_double.status_code == 400

    res_mz = client.post(
        "/api/ingestion/upload",
        files={"file": ("binary.txt", b"MZ\x90\x00ExecutablePayload", "text/plain")},
        headers=headers,
    )
    assert res_mz.status_code == 400

    pw_hash = hash_password_pbkdf2("StrongAdminPass!2026")
    assert verify_password_pbkdf2("StrongAdminPass!2026", pw_hash) is True
    assert verify_password_pbkdf2("WrongPass", pw_hash) is False

    reg_copy = tmp_path / "user_registry.json"
    reg_copy.write_bytes(USER_REGISTRY_FILE.read_bytes())
    updated = assign_admin_role("U_SPOC", registry_path=reg_copy, actor_id="D4")
    assert updated["role"] == "ADMIN"
    assert "documents:ingest" in updated["permissions"]


# ============================================================================
# 2. PHASE 3: DATABRICKS PHARMACEUTICALS PRODUCT MVM INGESTION TESTS
# ============================================================================

def test_12_databricks_product_mvm_ingestion_and_validation(tmp_path):
    """Verifies authoritative Databricks Pharmaceuticals v1 MVM ingestion, counts, FK validation, and idempotency."""
    catalog_out = tmp_path / "outputs/databricks_pharma_product_catalog.json"
    summary_out = tmp_path / "outputs/ingestion_summary.json"
    report_out = tmp_path / "reports/ingestion_report.md"

    ingestor = DatabricksProductMetadataIngestor(
        catalog_path=catalog_out,
        summary_path=summary_out,
        report_path=report_out,
        default_fixture_path=PROJECT / "data/fixtures/databricks_pharmaceuticals_v1_mvm_model.json",
    )
    summary1 = ingestor.ingest(
        fixture_path=PROJECT / "data/fixtures/databricks_pharmaceuticals_v1_mvm_model.json",
        actor_id="D4",
    )
    assert summary1["status"] == "SUCCESS"
    counts = summary1["counts"]
    assert counts["subdomains_count"] == 2
    assert counts["products_count"] == 15
    assert counts["attributes_count"] == 594
    assert counts["primary_keys_count"] == 15
    assert counts["foreign_keys_total"] == 83
    assert counts["intra_domain_foreign_keys"] == 37
    assert counts["cross_domain_foreign_keys"] == 46
    assert summary1["validation"]["valid"] is True

    cat1 = json.loads(catalog_out.read_text(encoding="utf-8"))
    assert len(cat1["products"]) == 15

    # Verify repeatable idempotent second run produces identical catalog without duplicates
    summary2 = ingestor.ingest(
        fixture_path=PROJECT / "data/fixtures/databricks_pharmaceuticals_v1_mvm_model.json",
        actor_id="D4",
    )
    cat2 = json.loads(catalog_out.read_text(encoding="utf-8"))
    assert len(cat2["products"]) == 15
    assert [p["id"] for p in cat1["products"]] == [p["id"] for p in cat2["products"]]
    assert summary2["diff"]["catalog_changed"] is False
    assert summary2["diff"]["products"]["unchanged_count"] == 15

    # Verify failure handling preserves last-known-good catalog on disk
    bad_fixture = tmp_path / "corrupt_model.json"
    bad_fixture.write_text("{malformed json", encoding="utf-8")
    with pytest.raises(MetadataIngestionError):
        ingestor.ingest(fixture_path=bad_fixture, actor_id="D4")

    preserved_catalog = json.loads(catalog_out.read_text(encoding="utf-8"))
    assert len(preserved_catalog["products"]) == 15
    assert preserved_catalog["catalog_fingerprint_sha256"] == cat1["catalog_fingerprint_sha256"]


# ============================================================================
# 3. PHASE 4: VOCABULARY COMPATIBILITY & LAYER 2/3 INTEGRATION TESTS
# ============================================================================

def test_13_vocabulary_compatibility_and_seed_vocabularies_invariance(tmp_path):
    """Verifies seed_vocabularies.json byte-for-byte preservation and accurate EXACT/PROPOSED/CONFLICT/UNRESOLVED mappings."""
    current_sha = hashlib.sha256(SEED_VOCABULARIES_FILE.read_bytes()).hexdigest()
    assert current_sha == BASELINE_SEED_SHA256, "seed_vocabularies.json must NEVER be modified or replaced!"

    engine = SemanticCompatibilityEngine(
        seed_vocab_path=SEED_VOCABULARIES_FILE,
        catalog_path=PROJECT / "outputs/databricks_pharma_product_catalog.json",
        mapping_output_path=tmp_path / "outputs/semantic_mapping_report.json",
        compatibility_md_path=tmp_path / "reports/compatibility_report.md",
        overlay_ttl_path=tmp_path / "databricks_overlay.ttl",
    )
    report = engine.generate_mappings(actor_id="D4")
    status_counts = report["summary_counts"]["total_mapping_status_breakdown"]

    assert status_counts["EXACT"] == 3
    assert status_counts["PROPOSED"] == 4
    assert status_counts["CONFLICT"] == 3
    assert status_counts["UNRESOLVED"] == 9
    assert report["seed_vocabulary_verification"]["preserved"] is True

    # Ensure medicinal_product is mapped to watson:Brand with CONFLICT status and NEVER equated to Keytruda
    mp_record = next(r for r in report["product_mappings"] if r["source_concept_name"] == "medicinal_product")
    assert mp_record["mapping_status"] == "CONFLICT"
    assert mp_record["target_concept_id"] == "watson:Brand"
    assert "Keytruda" in mp_record["rationale"] or "keytruda" in mp_record["rationale"].lower()


def test_14_layer2_rdf_overlay_and_layer3_faiss_preservation(client):
    """Verifies that Databricks MVM triples are queryable in SPARQL Studio while Layer 3 FAISS index is untouched."""
    faiss_before = FAISS_INDEX_FILE.read_bytes()
    chunk_map_before = CHUNK_URI_MAP_FILE.read_bytes()

    sparql_query = """
    PREFIX dbx: <http://databricks.pharma.org/mvm/v1/>
    PREFIX dbxmap: <http://watson.pharma.org/mapping/databricks/>
    PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
    SELECT ?table ?label ?subdomain
    WHERE {
        ?table a dbx:DataProduct ;
               rdfs:label ?label ;
               dbx:subdomain ?subdomain .
    }
    ORDER BY ?label
    """
    res = client.post("/api/graph/sparql", json={"query": sparql_query}, headers={"x-user-id": "D4"})
    assert res.status_code == 200, res.text
    data = res.json()
    assert data["row_count"] == 15

    assert FAISS_INDEX_FILE.read_bytes() == faiss_before
    assert CHUNK_URI_MAP_FILE.read_bytes() == chunk_map_before


# ============================================================================
# 4. PHASE 5: INTERACTIVE VISUAL GRAPH EXPLORER & REFRESH DIFF TESTS
# ============================================================================

def test_15_graph_explorer_views_catalog_mappings_and_live_refresh_diff(client):
    """Verifies View A, View B, View C, Catalog endpoint, Mappings endpoint, and v1 -> v1.1 refresh diff."""
    explorer = client.get("/api/graph/explorer", headers={"x-user-id": "D4"}).json()
    assert explorer["default_view"] == "integrated"
    assert "databricks" in explorer["views"]
    assert "watson" in explorer["views"]
    assert "integrated" in explorer["views"]

    view_a = explorer["views"]["databricks"]
    view_b = explorer["views"]["watson"]
    view_c = explorer["views"]["integrated"]

    assert len([n for n in view_a["nodes"] if n["node_type"] == "DATABRICKS_PRODUCT"]) == 15
    assert any(e["relationship_type"] == "FOREIGN_KEY_TO" for e in view_a["edges"])
    assert any(e["relationship_type"] == "CONTAINS_ATTRIBUTE" for e in view_a["edges"])

    assert any(n["node_type"] == "WATSON_CLASS" for n in view_b["nodes"])
    assert any(n["node_type"] == "WATSON_ENTITY" for n in view_b["nodes"])
    assert any(e["relationship_type"] == "TREATS_INDICATION" for e in view_b["edges"])

    assert any(e["relationship_type"] == "MAPPED_TO" for e in view_c["edges"])

    # Trigger live refresh with v1.1 evolution fixture and verify diff calculation
    refresh_res = client.post(
        "/api/graph/explorer/refresh",
        json={"fixture_path": "data/fixtures/databricks_pharmaceuticals_v1_1_mvm_fixture.json"},
        headers={"x-user-id": "D4"},
    )
    assert refresh_res.status_code == 200, refresh_res.text
    ref_data = refresh_res.json()
    assert ref_data["source_version"] == "v1.1-fixture"
    diff = ref_data["diff_summary"]
    assert any(
        c["product"] == "indication" and "real_world_evidence_score" in c["added_attributes"]
        for c in diff["changed_products"]
    )

    # Restore v1 baseline via refresh
    restore_res = client.post(
        "/api/graph/explorer/refresh",
        json={"fixture_path": "data/fixtures/databricks_pharmaceuticals_v1_mvm_model.json"},
        headers={"x-user-id": "D4"},
    )
    assert restore_res.status_code == 200
    assert restore_res.json()["source_version"] == "v1"
