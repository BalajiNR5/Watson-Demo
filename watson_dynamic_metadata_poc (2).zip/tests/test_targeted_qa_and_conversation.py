# tests/test_targeted_qa_and_conversation.py
"""
Targeted QA Intent & Conversational Routing Regression Suite for Watson Platform.
Validates all requirements from:
Part 1 (G1-G10):
  1. Dupixent US HCP synthesis preservation
  2. Farxiga vs Jardiance clinical superiority rejection
  3. Farxiga ontology relationship trace
  4. Keytruda EU market access
  5. Dupixent US vs India comparison
  6. Three-brand market access comparison
  7. Numerical clinical outcome gap acknowledgement
  8. Lineage & provenance trace
  9. VIEWER vs ADMIN source access isolation
  10. False/unsupported graph relationship rejection
Part 2 (C1-C12):
  1. 'hi' greeting (zero retrieval, minimal trace)
  2. 'thanks' small talk
  3. 'what can you do?' capability help
  4. 'Tell me about Dupixent in atopic dermatitis' research retrieval
  5. 'What about the United States?' contextual follow-up
  6. 'Compare that with India' contextual cross-geography comparison
  7. 'Show me the source' citation & lineage from preceding turn
  8. 'What is the weather today?' out-of-domain handling
  9. Random nonsensical input clarification
  10. Relevant research question with no indexed evidence (insufficient context)
  11. Multi-turn topic change (clears stale context)
  12. VIEWER vs ADMIN follow-up authorization rechecked
"""

import sys
import unittest
from pathlib import Path

BACKEND_DIR = Path(__file__).resolve().parent.parent / "backend"
if str(BACKEND_DIR) not in sys.path:
    sys.path.insert(0, str(BACKEND_DIR))
ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from watson.retrieval.graphrag_assembler import GraphRAGAssembler


class TestTargetedQAAndConversation(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.assembler = GraphRAGAssembler()

    # -------------------------------------------------------------------------
    # PART 1: TARGETED QA TESTS (G1 - G10)
    # -------------------------------------------------------------------------

    def test_g1_dupixent_us_hcp_synthesis_preserved(self):
        """G1: Preserves successful Dupixent US HCP concerns and recommendations."""
        res = self.assembler.retrieve_and_synthesize(
            query="What concerns do healthcare professionals express about Dupixent for atopic dermatitis in the United States, and what improvements do they recommend?",
            user_id="D4",
        )
        self.assertEqual(res.pipeline_execution_status, "COMPLETED")
        self.assertEqual(res.answer_grounding_status, "GROUNDED")
        self.assertEqual(res.quality_diagnostics.get("geographic_alignment"), "ALIGNED")
        doc_005_cited = any(":Doc_005:" in c.source_uri for c in res.citations)
        doc_014_cited = any(":Doc_014:" in c.source_uri for c in res.citations)
        self.assertTrue(doc_005_cited)
        self.assertFalse(doc_014_cited)
        self.assertTrue(any(w in res.answer.lower() for w in ["concern", "safety differentiation", "patient-selection"]))

    def test_g2_farxiga_superiority_claim_rejection(self):
        """G2: Farxiga vs Jardiance superiority question must reject unsupported superiority."""
        query = "can we conclude clinical superiority of Farxiga over Jardiance in CKD?"
        res = self.assembler.retrieve_and_synthesize(query=query, user_id="D4")

        self.assertEqual(res.pipeline_execution_status, "COMPLETED")
        self.assertEqual(res.answer_grounding_status, "GROUNDED")
        self.assertEqual(res.clinical_claim_verified, "NOT_ESTABLISHED")
        # Must contain the mandatory evidence-grounded boundary statement
        self.assertIn("The available indexed evidence does not establish that Farxiga is clinically superior to Jardiance in chronic kidney disease", res.answer)
        self.assertIn("The documents mention Jardiance as a comparator but do not provide head-to-head efficacy results sufficient to support that conclusion", res.answer)
        # Must NOT assert positive clinical superiority outcomes
        self.assertNotIn("clinical utility supported by trial endpoints", res.answer.lower())
        self.assertNotIn("demonstrates consistent clinical activity", res.answer.lower())
        # Claims must reflect the evidence boundary
        self.assertGreater(len(res.claims), 0)
        self.assertEqual(res.claims[0].support_status.value, "SUPPORTED")

    def test_g3_farxiga_ontology_relationship_trace(self):
        """G3: Farxiga ontology trace must produce actual graph path and RDF predicates."""
        query = "Using the semantic knowledge graph, explain the relationships surrounding Farxiga, its active ingredient, treated indications, therapeutic area, and supporting EU study document."
        res = self.assembler.retrieve_and_synthesize(query=query, user_id="D4")

        self.assertEqual(res.pipeline_execution_status, "COMPLETED")
        self.assertEqual(res.quality_diagnostics.get("semantic_contribution"), "INTEGRATED")
        # Must trace actual RDF predicates
        self.assertIn("isBrandOf", res.answer)
        self.assertIn("treatsIndication", res.answer)
        self.assertIn("hasTherapeuticArea", res.answer)
        self.assertIn("dapagliflozin", res.answer.lower())
        self.assertIn("ckd", res.answer.lower())
        self.assertIn("metabolic", res.answer.lower())
        # Must cite or document Doc_011 / Market Access EU
        self.assertTrue(any(w in res.answer for w in ["Doc_011", "Market_Access_Metabolic_Farxiga_CKD_EU"]))
        # Must distinguish Asserted, Inferred, Documented, Seed
        self.assertIn("Asserted RDF Triples", res.answer)
        self.assertIn("Inferred Relationships", res.answer)
        self.assertIn("Documented Research Evidence", res.answer)
        # Must NOT produce multi-market table
        self.assertNotIn("Comparative Evaluation Matrix", res.answer)

    def test_g4_keytruda_eu_market_access(self):
        """G4: Keytruda EU market access report concise geographically aligned answer."""
        query = "According to the EU market access report, what are the main reimbursement, treatment pathway, and HCP concerns surrounding Keytruda for non-small-cell lung cancer?"
        res = self.assembler.retrieve_and_synthesize(query=query, user_id="D4")

        self.assertEqual(res.pipeline_execution_status, "COMPLETED")
        self.assertEqual(res.quality_diagnostics.get("geographic_alignment"), "ALIGNED")
        doc_007_cited = any(":Doc_007:" in c.source_uri for c in res.citations)
        self.assertTrue(doc_007_cited)
        self.assertNotIn("synthetic id: syn-", res.answer.lower())
        self.assertIn("Reimbursement", res.answer)
        self.assertIn("Treatment Pathway", res.answer)
        self.assertIn("HCP", res.answer)

    def test_g5_dupixent_us_versus_india(self):
        """G5: Dupixent US versus India two-geography comparison."""
        query = "Compare the market access and HCP perceptions for Dupixent in the United States versus India."
        res = self.assembler.retrieve_and_synthesize(query=query, user_id="D4")

        self.assertEqual(res.pipeline_execution_status, "COMPLETED")
        self.assertIn("Dupixent", res.answer)
        # Must cover both US and India
        all_text = res.answer.lower()
        self.assertTrue("united states" in all_text or "us" in all_text)
        self.assertIn("india", all_text)

    def test_g6_three_brand_market_comparison(self):
        """G6: Three-brand market comparison covering Keytruda EU, Dupixent US, Xolair India."""
        query = "Compare the market access considerations for Keytruda in EU oncology, Dupixent in US immunology, and Xolair in Indian respiratory care. What factors are common, and what differences can the available evidence establish?"
        res = self.assembler.retrieve_and_synthesize(query=query, user_id="D4")

        self.assertEqual(res.pipeline_execution_status, "COMPLETED")
        self.assertEqual(res.quality_diagnostics.get("entity_coverage"), "FULL_COVERAGE")
        self.assertIn("|", res.answer)
        self.assertIn("Drug / Brand", res.answer)
        self.assertIn("Keytruda", res.answer)
        self.assertIn("Dupixent", res.answer)
        self.assertIn("Xolair", res.answer)

    def test_g7_numerical_clinical_outcomes_gap(self):
        """G7: Numerical clinical outcome question explicitly acknowledges absent statistics."""
        query = "What are the exact numerical overall survival percentages and statistical hazard ratios for Farxiga in CKD?"
        res = self.assembler.retrieve_and_synthesize(query=query, user_id="D4")

        self.assertEqual(res.pipeline_execution_status, "COMPLETED")
        # Must not fabricate numerical trial endpoints
        self.assertTrue(
            "hazard ratio" not in res.answer.lower()
            or "not provide" in res.answer.lower()
            or "does not establish" in res.answer.lower()
            or "limitations" in res.answer.lower()
        )

    def test_g8_q9_lineage_trace(self):
        """G8: Provenance trace covering source, chunk, reviewer, and lifecycle state."""
        query = "What is the lineage, reviewer, and approval history for Keytruda NSCLC documents?"
        res = self.assembler.retrieve_and_synthesize(query=query, user_id="D4")

        self.assertGreater(len(res.lineage_records), 0)
        self.assertEqual(res.lineage_records[0].lifecycle_state, "ACTIVE")
        self.assertTrue(res.lineage_records[0].reviewer_id in ["D4", "D1", "D2"])

    def test_g9_viewer_vs_admin_isolation(self):
        """G9: Strict source access isolation between VIEWER (D3) and ADMIN (D4)."""
        viewer_chunks = self.assembler.get_allowed_chunk_uris("D3")
        admin_chunks = self.assembler.get_allowed_chunk_uris("D4")

        # Viewer cannot access RESTRICTED documents
        self.assertLess(len(viewer_chunks), len(admin_chunks))
        self.assertFalse(any(":Doc_002:" in c for c in viewer_chunks))
        self.assertTrue(any(":Doc_002:" in c for c in admin_chunks))

    def test_g10_unsupported_graph_relationship_rejection(self):
        """G10: False/unsupported graph relationship (Keytruda in Alzheimer's) rejected."""
        query = "What is the clinical evidence for Keytruda in Alzheimer's disease?"
        res = self.assembler.retrieve_and_synthesize(query=query, user_id="D4")

        self.assertEqual(res.answer_relevance_status, "INSUFFICIENT_EVIDENCE")
        self.assertTrue(res.evidence_gap_detected)
        self.assertIn("Insufficient Context", res.answer)

    # -------------------------------------------------------------------------
    # PART 2: CONVERSATIONAL INTENT & MULTI-TURN TESTS (C1 - C12)
    # -------------------------------------------------------------------------

    def test_c1_greeting_no_retrieval(self):
        """C1: 'hi' returns greeting with zero retrieval, minimal trace, NOT_APPLICABLE grounding."""
        res = self.assembler.retrieve_and_synthesize(query="hi", user_id="D4")

        self.assertEqual(res.pipeline_execution_status, "COMPLETED")
        self.assertEqual(res.answer_relevance_status, "CONVERSATIONAL")
        self.assertEqual(res.answer_grounding_status, "NOT_APPLICABLE")
        self.assertEqual(res.quality_diagnostics.get("clinical_claim_verified"), "NOT_APPLICABLE")
        self.assertEqual(len(res.citations), 0)
        self.assertEqual(len(res.scored_chunks), 0)
        self.assertTrue(len(res.live_stages) in (3, 15))
        if len(res.live_stages) == 15:
            self.assertTrue(all(s.status == "SKIPPED" for s in res.live_stages[3:]))
        self.assertIn("Watson", res.answer)
        self.assertNotIn("Opdivo", res.answer)
        self.assertNotIn("melanoma", res.answer.lower())

    def test_c2_small_talk_acknowledgement(self):
        """C2: 'thanks' returns acknowledgement with zero retrieval."""
        res = self.assembler.retrieve_and_synthesize(query="thanks", user_id="D4")

        self.assertEqual(res.answer_relevance_status, "CONVERSATIONAL")
        self.assertEqual(len(res.citations), 0)
        self.assertIn("welcome", res.answer.lower())

    def test_c3_capability_help(self):
        """C3: 'what can you do?' returns capabilities description."""
        res = self.assembler.retrieve_and_synthesize(query="what can you do?", user_id="D4")

        self.assertEqual(res.answer_relevance_status, "CONVERSATIONAL")
        self.assertIn("Layer 1", res.answer)
        self.assertIn("Layer 2", res.answer)
        self.assertIn("Layer 3", res.answer)

    def test_c4_research_question_retrieval(self):
        """C4: 'Tell me about Dupixent in atopic dermatitis' executes full research retrieval."""
        res = self.assembler.retrieve_and_synthesize(query="Tell me about Dupixent in atopic dermatitis", user_id="D4")

        self.assertEqual(res.pipeline_execution_status, "COMPLETED")
        self.assertEqual(res.answer_relevance_status, "RELEVANT")
        self.assertGreater(len(res.citations), 0)
        self.assertIn("dupixent", res.answer.lower())

    def test_c5_contextual_followup_us(self):
        """C5: 'What about the United States?' resolves session context (Dupixent, AD)."""
        # Turn 1
        self.assembler.retrieve_and_synthesize(query="Tell me about Dupixent in atopic dermatitis", user_id="D4")
        # Turn 2
        res2 = self.assembler.retrieve_and_synthesize(query="What about the United States?", user_id="D4")

        self.assertEqual(res2.pipeline_execution_status, "COMPLETED")
        self.assertIn("dupixent", res2.answer.lower())
        # Must focus on US study Doc_005
        doc_005_cited = any(":Doc_005:" in c.source_uri for c in res2.citations)
        self.assertTrue(doc_005_cited)

    def test_c6_contextual_cross_geography_comparison(self):
        """C6: 'Compare that with India' executes cross-geography comparison from session context."""
        # Turn 1 & 2 establish Dupixent in US
        self.assembler.retrieve_and_synthesize(query="Tell me about Dupixent in atopic dermatitis in the United States", user_id="D4")
        # Turn 2: compare with India
        res2 = self.assembler.retrieve_and_synthesize(query="Compare that with India", user_id="D4")

        self.assertEqual(res2.pipeline_execution_status, "COMPLETED")
        self.assertIn("dupixent", res2.answer.lower())
        self.assertIn("india", res2.answer.lower())

    def test_c7_show_me_the_source_provenance(self):
        """C7: 'Show me the source' retrieves lineage from preceding turn."""
        # Turn 1: Research query
        self.assembler.retrieve_and_synthesize(query="What are the HCP concerns for Dupixent in the United States?", user_id="D4")
        # Turn 2: Source lineage request
        res2 = self.assembler.retrieve_and_synthesize(query="Show me the source", user_id="D4")

        self.assertEqual(res2.pipeline_execution_status, "COMPLETED")
        self.assertIn("Source Provenance", res2.answer)
        self.assertIn("Doc_005", res2.answer)
        self.assertGreater(len(res2.lineage_records), 0)

    def test_c8_out_of_domain_weather(self):
        """C8: 'What is the weather today?' returns out-of-domain explanation."""
        res = self.assembler.retrieve_and_synthesize(query="What is the weather today?", user_id="D4")

        self.assertEqual(res.answer_relevance_status, "CONVERSATIONAL")
        self.assertEqual(len(res.citations), 0)
        self.assertIn("outside my operational domain", res.answer.lower())

    def test_c9_random_nonsensical_input(self):
        """C9: Nonsensical input requests clarification without document retrieval."""
        res = self.assembler.retrieve_and_synthesize(query="asdfghjkl qwertyuiop", user_id="D4")

        self.assertEqual(res.answer_relevance_status, "CONVERSATIONAL")
        self.assertEqual(len(res.citations), 0)
        self.assertIn("ambiguous", res.answer.lower())

    def test_c10_relevant_research_with_no_evidence(self):
        """C10: Relevant question with no indexed evidence returns insufficient context."""
        res = self.assembler.retrieve_and_synthesize(query="What is the clinical evidence for Keytruda in Parkinson's disease?", user_id="D4")

        self.assertEqual(res.answer_relevance_status, "INSUFFICIENT_EVIDENCE")
        self.assertIn("Insufficient Context", res.answer)

    def test_c11_multi_turn_topic_change(self):
        """C11: Multi-turn topic change clears stale context and does not reuse old evidence."""
        # Turn 1: Dupixent
        self.assembler.retrieve_and_synthesize(query="Tell me about Dupixent in atopic dermatitis", user_id="D4")
        # Turn 2: Topic change to Keytruda
        res2 = self.assembler.retrieve_and_synthesize(query="Tell me about Keytruda in melanoma", user_id="D4")

        self.assertEqual(res2.pipeline_execution_status, "COMPLETED")
        self.assertIn("keytruda", res2.answer.lower())
        self.assertNotIn("dupixent", res2.answer.lower())
        # Session context must now be Keytruda, not Dupixent
        sess = self.assembler.sessions.get("D4", {})
        self.assertEqual(sess.get("last_brand"), "Keytruda")

    def test_c12_viewer_vs_admin_followup_rechecked(self):
        """C12: Follow-up queries re-check ABAC permissions anew."""
        # D3 (Viewer) attempts to ask follow-up on restricted content
        res = self.assembler.retrieve_and_synthesize(
            query="Show clinical trial endpoints for restricted oncology studies",
            user_id="D3",
        )
        # Viewer must NEVER receive Doc_002 citations
        for cite in res.citations:
            self.assertNotIn(":Doc_002:", cite.source_uri)


if __name__ == "__main__":
    unittest.main()
