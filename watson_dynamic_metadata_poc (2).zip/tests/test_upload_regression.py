"""Actual parsers, local MiniLM/spaCy, FastAPI, FAISS and file transactions.
All state is copied into an isolated temporary directory, never the deliverable.
"""
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
from concurrent.futures import ThreadPoolExecutor
from unittest.mock import patch

import pytest

PROJECT=Path(__file__).resolve().parents[1]
WORK=Path(tempfile.mkdtemp(prefix='watson-ingestion-tests-'))
import atexit
atexit.register(lambda: shutil.rmtree(WORK,ignore_errors=True))
for folder in ['data','ontology','queries']:
    shutil.copytree(PROJECT/folder,WORK/folder)
(WORK/'dedup_store.json').write_text(json.dumps({'exact_hashes':{},'title_registry':[]}))
(WORK/'data/stores/lifecycle_store.json').write_text('{}')
os.environ.update(WATSON_BASE_DIR=str(WORK),HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',WATSON_ALLOW_CLOUD='0')
if (PROJECT/'approved_models/all-MiniLM-L6-v2').is_dir():
    os.environ['WATSON_EMBEDDING_MODEL']=str(PROJECT/'approved_models/all-MiniLM-L6-v2')
sys.path[:0]=[str(PROJECT),str(PROJECT/'backend')]
from office_policy import disable_tokenizer_downloads
disable_tokenizer_downloads()
from fastapi.testclient import TestClient
from app import main as api
from watson.ingestion import ingestion_coordinator as ingestion
from watson.ingestion import staging_state as state
from watson.ingestion.dedup_detector import check_deduplication,compute_sha256
from watson.shared.config import STAGING_DATA_DIR,LIFECYCLE_STORE_FILE,PHARMA_KG_FILE,FAISS_INDEX_FILE,CHUNK_URI_MAP_FILE
import rdflib

BASELINE={p:p.read_bytes() for folder in ['data','ontology'] for p in (WORK/folder).rglob('*') if p.is_file()}
BASELINE[WORK/'dedup_store.json']=(WORK/'dedup_store.json').read_bytes()
TEXT='HCP Perception Survey\nTherapeutic Area: Oncology\nKeytruda pembrolizumab treats NSCLC.\nGeography: US\nClinical research discusses efficacy and safety evidence in oncology.\nValidation study alpha.'

@pytest.fixture(autouse=True)
def clean_state():
    for folder in ['data','ontology']:
        shutil.rmtree(WORK/folder)
    for path,content in BASELINE.items():
        path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(content)
    pipeline=api.coordinator.enrichment_pipeline
    pipeline.graph=rdflib.Graph();pipeline.graph.parse(str(PHARMA_KG_FILE),format='turtle');pipeline._init_vector_store()
    api.assembler.index_manager._load_index_and_map();api.assembler._load_graph()
    yield

@pytest.fixture
def client():
    with TestClient(api.app,base_url='http://localhost') as value:yield value

def upload(client,text=TEXT,name='validation-study.txt',content=None):
    return client.post('/api/ingestion/upload',files={'file':(name,content if content is not None else text.encode(),'application/octet-stream')},headers={'x-user-id':'D4'})

def json_file(path):return json.loads(Path(path).read_text())

def test_success_and_pending_duplicate_are_idempotent(client):
    r=upload(client);assert r.status_code==200,r.text
    first=r.json();assert isinstance(first['metadata']['expiry_date'],str)
    assert isinstance(first['metadata']['retention_days'],int)
    assert first['governed_chunks'];assert first['governed_chunks'][0]['parent_document_uri']==first['document_uri']
    repeat=upload(client);assert repeat.status_code==200,repeat.text
    assert repeat.json()['duplicate_upload'] is True
    assert repeat.json()['document_uri']==first['document_uri']
    assert len(json_file(WORK/'dedup_store.json')['exact_hashes'])==1
    pending=client.get('/api/ingestion/pending',headers={'x-user-id':'D4'}).json()
    assert len(pending)==1 and pending[0]['document_uri']==first['document_uri']

def test_quality_failure_does_not_poison_retry(client):
    with patch.object(ingestion,'calculate_quality_score',side_effect=RuntimeError('injected quality failure')):
        assert upload(client).status_code==500
    assert json_file(WORK/'dedup_store.json')['exact_hashes']=={}
    assert json_file(LIFECYCLE_STORE_FILE)=={}
    assert upload(client).status_code==200

def test_commit_failure_rolls_back_files_and_retry_works(client):
    original=state.atomic_write;failed=False
    def failing(path,data):
        nonlocal failed
        if Path(path)==WORK/'dedup_store.json' and not failed:
            failed=True;raise OSError('injected disk failure')
        return original(path,data)
    old_staged=set(STAGING_DATA_DIR.glob('*_staged.json'))
    with patch.object(state,'atomic_write',side_effect=failing):assert upload(client).status_code==500
    assert json_file(WORK/'dedup_store.json')['exact_hashes']=={}
    assert json_file(LIFECYCLE_STORE_FILE)=={}
    assert set(STAGING_DATA_DIR.glob('*_staged.json'))==old_staged
    assert upload(client).status_code==200

def test_legacy_uncommitted_hash_can_be_retried(client):
    (WORK/'dedup_store.json').write_text(json.dumps({'exact_hashes':{compute_sha256(TEXT):{'document_uri':'watson:Doc_001','source_filename':'validation-study.txt'}},'title_registry':[]}))
    response=upload(client);assert response.status_code==200,response.text
    assert response.json()['document_uri']!='watson:Doc_001'
    entry=json_file(WORK/'dedup_store.json')['exact_hashes'][compute_sha256(TEXT)]
    assert entry['document_uri']==response.json()['document_uri']

def test_legacy_object_expiry_is_readable_after_reload(client):
    doc=upload(client).json();path=STAGING_DATA_DIR/f"{doc['doc_id']}_staged.json"
    doc['metadata']['expiry_date']={'expiry_date':'2028-10-26','retention_days':730}
    path.write_text(json.dumps(doc))
    pending=client.get('/api/ingestion/pending',headers={'x-user-id':'D4'}).json()
    assert pending[0]['metadata']['expiry_date']=='2028-10-26'
    assert upload(client).json()['metadata']['expiry_date']=='2028-10-26'

def test_concurrent_same_document_creates_one_pending_review(tmp_path):
    file=tmp_path/'concurrent.txt';file.write_text(TEXT)
    with ThreadPoolExecutor(max_workers=2) as pool:
        results=list(pool.map(lambda _:api.coordinator.stage_file(file,actor_id='D4'),range(2)))
    assert len({r['document_uri'] for r in results})==1
    assert sum(bool(r.get('duplicate_upload')) for r in results)==1
    assert len(json_file(WORK/'dedup_store.json')['exact_hashes'])==1

def test_same_filename_different_content_preserves_both_raw_files(client):
    first=upload(client).json();second=upload(client,text='Different clinical document about Keytruda. Different title and evidence.').json()
    assert first['document_uri']!=second['document_uri']
    assert (WORK/first['source_path']).read_text()==TEXT
    assert (WORK/second['source_path']).is_file()

def test_invalid_empty_and_traversal_filename(client):
    assert upload(client,name='empty.txt',content=b'').status_code==400
    assert upload(client,name='script.exe').status_code==400
    result=upload(client,name='../safe.txt');assert result.status_code==200,result.text
    assert result.json()['source_filename']=='safe.txt'
    assert not (WORK.parent/'safe.txt').exists()

def test_corrupt_registry_is_not_silently_reset(client):
    (WORK/'dedup_store.json').write_text('broken json')
    response=upload(client);assert response.status_code==400
    assert (WORK/'dedup_store.json').read_text()=='broken json'

def test_pii_is_detected_and_governed_chunks_are_redacted(client):
    text=TEXT+'\nEmail: patient@example.com\nSSN: 123-45-6789'
    response=upload(client,text=text);assert response.status_code==200,response.text
    doc=response.json();assert doc['has_pii'];assert doc['has_critical_pii']
    chunks='\n'.join(c['text'] for c in doc['governed_chunks'])
    assert 'patient@example.com' not in chunks and '123-45-6789' not in chunks
    assert 'REDACTED' in chunks

def test_approval_failure_restores_artifacts_and_remains_pending(client):
    doc=upload(client).json();before={p:p.read_bytes() for p in [PHARMA_KG_FILE,FAISS_INDEX_FILE,CHUNK_URI_MAP_FILE]}
    with patch.object(api.coordinator.enrichment_pipeline,'index_chunks',side_effect=RuntimeError('injected index failure')):
        with pytest.raises(RuntimeError,match='index failure'):
            api.coordinator.review_and_activate(doc['document_uri'],'D4','ADMIN','APPROVE',pii_override=True)
    assert json_file(LIFECYCLE_STORE_FILE)[doc['document_uri']]['lifecycle_state']=='UNDER_REVIEW'
    for p,value in before.items():assert p.read_bytes()==value
    result=api.coordinator.review_and_activate(doc['document_uri'],'D4','ADMIN','APPROVE',pii_override=True)
    assert result['status']=='ACTIVE'

def test_approve_then_exact_duplicate_is_409(client):
    doc=upload(client).json()
    response=client.post('/api/ingestion/review',json={'document_uri':doc['document_uri'],'decision':'APPROVE','pii_override':True},headers={'x-user-id':'D4'})
    assert response.status_code==200,response.text
    assert upload(client).status_code==409
    assert client.get('/api/ingestion/pending',headers={'x-user-id':'D4'}).json()==[]
    # Approved evidence must be visible without restarting the server.
    search=client.post('/api/search',json={'query':'Keytruda oncology evidence','top_k':5},headers={'x-user-id':'D4'})
    assert search.status_code==200,search.text
    assert doc['document_uri'] in search.text,search.text

def test_reject_then_duplicate_does_not_silently_restage(client):
    doc=upload(client).json()
    result=client.post('/api/ingestion/review',json={'document_uri':doc['document_uri'],'decision':'REJECT'},headers={'x-user-id':'D4'})
    assert result.status_code==200,result.text
    assert upload(client).status_code==409

def test_pending_review_not_visible_to_unrelated_viewer(client):
    upload(client)
    assert client.get('/api/ingestion/pending',headers={'x-user-id':'D3'}).json()==[]

@pytest.mark.parametrize('extension',['pdf','docx','pptx','txt'])
def test_supported_formats_are_staged(client,tmp_path,extension):
    path=tmp_path/('clinical.'+extension)
    if extension=='pdf':
        import pymupdf
        doc=pymupdf.open();page=doc.new_page();page.insert_textbox((50,50,550,750),TEXT,fontsize=11);doc.save(path);doc.close()
    elif extension=='docx':
        from docx import Document
        doc=Document();doc.add_paragraph(TEXT);doc.save(path)
    elif extension=='pptx':
        from pptx import Presentation
        doc=Presentation();slide=doc.slides.add_slide(doc.slide_layouts[1]);slide.shapes.title.text='Clinical survey';slide.placeholders[1].text=TEXT;doc.save(path)
    else:path.write_text(TEXT)
    response=upload(client,name=path.name,content=path.read_bytes())
    assert response.status_code==200,response.text
    assert isinstance(response.json()['metadata']['expiry_date'],str)

def test_read_only_dedup_check_does_not_register(tmp_path):
    target=tmp_path/'registry.json'
    result,_=check_deduplication({'raw_text':'brand new content','document_uri':'watson:Doc_Test','source_filename':'test.txt'},store_path=str(target),audit_path=str(tmp_path/'audit.jsonl'),register=False)
    assert result=='PASSED_UNIQUE' and not target.exists()

def test_crash_journal_recovery_restores_precommit_state(tmp_path):
    staging=tmp_path/'staging';transaction=staging/'.transactions'/'interrupted';transaction.mkdir(parents=True)
    (tmp_path/'state.json').write_text('new incomplete state');(transaction/'0.bak').write_text('previous valid state')
    (transaction/'manifest.json').write_text(json.dumps([{'path':'state.json','backup':'0.bak'},{'path':'new-file.json','backup':None}]))
    (tmp_path/'new-file.json').write_text('partial')
    state.recover_transactions(tmp_path,staging)
    assert (tmp_path/'state.json').read_text()=='previous valid state'
    assert not (tmp_path/'new-file.json').exists()


def test_other_requests_respond_during_slow_upload(client):
    import threading
    entered=threading.Event();release=threading.Event()
    def slow_stage(*args,**kwargs):
        entered.set();release.wait(timeout=10)
        return {"document_uri":"watson:Doc_Slow","metadata":{"expiry_date":"2028-01-01"}}
    with patch.object(api.coordinator,'stage_file',side_effect=slow_stage),ThreadPoolExecutor(max_workers=2) as pool:
        attempt=pool.submit(upload,client)
        assert entered.wait(timeout=3)
        try:
            health=pool.submit(client.get,'/api/health').result(timeout=2)
            assert health.status_code==200
        finally:release.set()
        assert attempt.result(timeout=5).status_code==200


def test_audit_error_after_commit_can_reopen_pending_review(client):
    with patch.object(ingestion,'log_audit_event',side_effect=OSError('injected audit disk failure')):
        assert upload(client).status_code==500
    result=upload(client)
    assert result.status_code==200,result.text
    assert result.json()['duplicate_upload'] is True


def test_legacy_date_migration_keeps_original_backup(tmp_path):
    import zipfile
    staging=tmp_path/'data/staging';staging.mkdir(parents=True)
    stores=tmp_path/'data/stores';stores.mkdir()
    old={'expiry_date':'2028-10-26','retention_days':730}
    staged=staging/'test_staged.json';staged.write_text(json.dumps({'metadata':{'expiry_date':old}}))
    lifecycle=stores/'lifecycle_store.json';lifecycle.write_text(json.dumps({'doc':{'expiry_date':old,'lifecycle_state':'UNDER_REVIEW'}}))
    original=staged.read_bytes()
    assert state.repair_legacy_dates(tmp_path,staging,lifecycle)==2
    assert json_file(staged)['metadata']['expiry_date']=='2028-10-26'
    assert json_file(lifecycle)['doc']['retention_days']==730
    backups=list((stores/'migration_backups').glob('*.zip'));assert len(backups)==1
    with zipfile.ZipFile(backups[0]) as archive:assert archive.read('data/staging/test_staged.json')==original
    assert state.repair_legacy_dates(tmp_path,staging,lifecycle)==0


def test_nested_seed_vocabulary_populates_scope_and_study_type(client):
    doc=upload(client).json()
    assert doc['metadata']['therapeutic_area']=='Oncology'
    assert 'Keytruda' in doc['metadata']['brands_mentioned']
    assert doc['metadata']['study_type']=='HCP Perception Survey'
    assert json_file(LIFECYCLE_STORE_FILE)[doc['document_uri']]['allowed_therapeutic_areas']==['Oncology']


def test_legacy_unowned_pending_can_be_reopened_by_its_uploader(client):
    doc=upload(client).json();path=STAGING_DATA_DIR/f"{doc['doc_id']}_staged.json"
    doc.pop('staged_by');doc['metadata']['therapeutic_area']=None;path.write_text(json.dumps(doc))
    records=json_file(LIFECYCLE_STORE_FILE);records[doc['document_uri']].pop('staged_by');LIFECYCLE_STORE_FILE.write_text(json.dumps(records))
    response=client.post('/api/ingestion/upload',files={'file':('validation-study.txt',TEXT.encode(),'text/plain')},headers={'x-user-id':'D2'})
    assert response.status_code==200,response.text
    assert response.json()['duplicate_upload'] is True
    pending=client.get('/api/ingestion/pending',headers={'x-user-id':'D2'}).json()
    assert any(row['document_uri']==doc['document_uri'] for row in pending)


def test_truncated_legacy_staging_record_can_be_retried(client):
    doc=upload(client).json();path=STAGING_DATA_DIR/f"{doc['doc_id']}_staged.json"
    path.write_text('{')
    assert state.repair_legacy_dates(WORK,STAGING_DATA_DIR,LIFECYCLE_STORE_FILE)==0
    assert client.get('/api/ingestion/pending',headers={'x-user-id':'D4'}).status_code==200
    retry=upload(client);assert retry.status_code==200,retry.text
    assert json_file(path)['document_uri']==doc['document_uri']
