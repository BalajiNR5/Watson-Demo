import os
import sys
import unittest
from pathlib import Path

BACKEND_DIR = Path(__file__).resolve().parent.parent / "backend"
if str(BACKEND_DIR) not in sys.path:
    sys.path.insert(0, str(BACKEND_DIR))
ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from watson.retrieval.graphrag_assembler import GraphRAGAssembler
from watson.shared.models import QueryRoute, QuestionType


class TestSemanticInvariantsAndRouting(unittest.TestCase):
    """
    PRD Section 13 & Mandated Invariant Test Suite covering:
    Test A: Keytruda never inherits Xolair's Asthma indication.
    Test B: Dupixent remains linked to Atopic Dermatitis when answering US HCP questions.
    Test C: Xolair remains linked to Asthma/Respiratory/India.
    Test D: Multi-brand answers maintain independent evidence tuples.
    Test E: Temporal sentiment questions route to temporal SPARQL analysis.
    Test F: Missing temporal observations produce an explicit evidence-gap response.
    Test G: Invalid RDF paths do not become clinical facts.
    Test H: Correct citations resolve to the same document as their associated claim.
    Test I: Successful Dupixent direct synthesis remains unchanged.
    Test J: VIEWER and ADMIN cannot access unauthorized evidence through comparison or graph traversal.
    """

    @classmethod
    def setUpClass(cls):
        cls.assembler = GraphRAGAssembler()

    def test_invariant_a_keytruda_never_inherits_asthma(self):
        """Test A: Keytruda never inherits Xolair's Asthma indication in multi-brand queries."""
        query = (
            "Compare the market access considerations for Keytruda in EU oncology, "
            "Dupixent in US immunology, and Xolair in Indian respiratory care. "
            "What factors are common, and what differences can the available evidence establish?"
        )
        res = self.assembler.retrieve_and_synthesize(query=query, user_id="D4")

        self.assertEqual(res.pipeline_execution_status, "COMPLETED")
        self.assertEqual(res.answer_relevance_status, "RELEVANT")

        # Keytruda must be mapped to NSCLC and Oncology, NEVER Asthma
        for line in res.answer.splitlines():
            if "keytruda" in line.lower() and "|" in line:
                self.assertNotIn("asthma", line.lower(), "Keytruda table row was contaminated with Asthma!")
                self.assertIn("nsclc", line.lower(), "Keytruda table row missing canonical NSCLC indication!")
                self.assertIn("oncology", line.lower(), "Keytruda table row missing canonical Oncology therapeutic area!")
                self.assertIn(":doc_007:", line.lower(), "Keytruda table row did not cite EU study Doc_007!")

    def test_invariant_b_dupixent_remains_linked_to_ad_in_us(self):
        """Test B: Dupixent remains linked to Atopic Dermatitis when answering US HCP questions."""
        query = (
            "What concerns do healthcare professionals express about Dupixent for "
            "atopic dermatitis in the United States, and what improvements do they recommend?"
        )
        res = self.assembler.retrieve_and_synthesize(query=query, user_id="D4")

        self.assertEqual(res.pipeline_execution_status, "COMPLETED")
        self.assertEqual(res.answer_grounding_status, "GROUNDED")
        self.assertEqual(res.answer_relevance_status, "RELEVANT")

        ans_lower = res.answer.lower()
        self.assertIn("dupixent", ans_lower)
        self.assertIn("atopic dermatitis", ans_lower)

        # Must cite US Doc_005, not India Doc_014
        doc_005_cites = [c for c in res.citations if ":Doc_005:" in c.source_uri]
        doc_014_cites = [c for c in res.citations if ":Doc_014:" in c.source_uri]
        self.assertGreater(len(doc_005_cites), 0, "Failed to cite US study Doc_005 for Dupixent US HCP query")
        self.assertEqual(len(doc_014_cites), 0, "Conflicting India study Doc_014 leaked into single US query")

    def test_invariant_c_xolair_remains_linked_to_asthma_respiratory_india(self):
        """Test C: Xolair remains linked to Asthma/Respiratory/India."""
        query = (
            "Compare the market access considerations for Keytruda in EU oncology, "
            "Dupixent in US immunology, and Xolair in Indian respiratory care."
        )
        res = self.assembler.retrieve_and_synthesize(query=query, user_id="D4")

        found_xolair_row = False
        for line in res.answer.splitlines():
            if "xolair" in line.lower() and "|" in line:
                found_xolair_row = True
                self.assertIn("asthma", line.lower())
                self.assertIn("respiratory", line.lower())
                self.assertIn("india", line.lower())
                self.assertIn(":doc_008:", line.lower())

        self.assertTrue(found_xolair_row, "Xolair comparison table row not found")

    def test_invariant_d_multi_brand_maintains_independent_evidence_tuples(self):
        """Test D: Multi-brand answers maintain independent evidence tuples."""
        query = (
            "Compare the market access considerations for Keytruda in EU oncology, "
            "Dupixent in US immunology, and Xolair in Indian respiratory care."
        )
        intent = self.assembler.router.analyze_intent(query)

        self.assertEqual(len(intent.requested_subjects), 3)

        s1, s2, s3 = intent.requested_subjects[0], intent.requested_subjects[1], intent.requested_subjects[2]

        # Keytruda tuple
        self.assertEqual(s1.brand, "Keytruda")
        self.assertEqual(s1.drug, "Pembrolizumab")
        self.assertEqual(s1.indication, "nsclc")
        self.assertEqual(s1.therapeutic_area, "Oncology")
        self.assertEqual(s1.geography, "EU")
        self.assertEqual(s1.document_uri, "watson:Doc_007")

        # Dupixent tuple
        self.assertEqual(s2.brand, "Dupixent")
        self.assertEqual(s2.drug, "Dupilumab")
        self.assertEqual(s2.indication, "atopic dermatitis")
        self.assertEqual(s2.therapeutic_area, "Immunology")
        self.assertEqual(s2.geography, "US")
        self.assertEqual(s2.document_uri, "watson:Doc_005")

        # Xolair tuple
        self.assertEqual(s3.brand, "Xolair")
        self.assertEqual(s3.drug, "Omalizumab")
        self.assertEqual(s3.indication, "asthma")
        self.assertEqual(s3.therapeutic_area, "Respiratory")
        self.assertEqual(s3.geography, "INDIA")
        self.assertEqual(s3.document_uri, "watson:Doc_008")

        # Immutable URIs must be completely disjoint
        uris_1 = set(filter(None, s1.to_evidence_tuple().values()))
        uris_2 = set(filter(None, s2.to_evidence_tuple().values()))
        uris_3 = set(filter(None, s3.to_evidence_tuple().values()))

        self.assertEqual(len(uris_1.intersection(uris_2)), 0)
        self.assertEqual(len(uris_1.intersection(uris_3)), 0)
        self.assertEqual(len(uris_2.intersection(uris_3)), 0)

    def test_invariant_e_temporal_sentiment_routes_to_sparql(self):
        """Test E: Temporal sentiment questions route to temporal SPARQL analysis."""
        query = "Which drugs had declining HCP sentiment before 2023 versus 2023 onward?"
        intent = self.assembler.router.analyze_intent(query)

        self.assertEqual(intent.route, QueryRoute.SPARQL)
        self.assertEqual(intent.question_type, QuestionType.TEMPORAL_SENTIMENT_ANALYSIS)

        res = self.assembler.retrieve_and_synthesize(query=query, user_id="D4")
        self.assertEqual(res.pipeline_execution_status, "COMPLETED")
        self.assertIn("opdivo", res.answer.lower())
        self.assertIn("-0.17", res.answer)
        self.assertIn("0.72", res.answer)
        self.assertIn(":doc_015:", res.answer.lower())

    def test_invariant_f_missing_temporal_observations_produce_evidence_gap(self):
        """Test F: Missing temporal observations produce an explicit evidence-gap response."""
        query = "Compare pre-2023 versus 2023+ sentiment scores for Farxiga"
        intent = self.assembler.router.analyze_intent(query)

        self.assertEqual(intent.question_type, QuestionType.TEMPORAL_SENTIMENT_ANALYSIS)

        res = self.assembler.retrieve_and_synthesize(query=query, user_id="D4")
        self.assertEqual(res.pipeline_execution_status, "COMPLETED")

        ans_lower = res.answer.lower()
        self.assertTrue(
            "no pre-2023 sentiment assertions" in ans_lower
            or "insufficient" in ans_lower
            or "baseline unavailable" in ans_lower
        )
        # Must not fabricate a pre-2023 score for Farxiga
        self.assertNotIn("pre-2023: 0.", ans_lower)

    def test_invariant_g_invalid_rdf_paths_do_not_become_clinical_facts(self):
        """Test G: Invalid RDF paths (e.g. Keytruda treating Asthma) do not become clinical facts."""
        query = "Using the semantic knowledge graph, does Keytruda treat asthma?"
        res = self.assembler.retrieve_and_synthesize(query=query, user_id="D4")

        self.assertEqual(res.pipeline_execution_status, "COMPLETED")
        ans_lower = res.answer.lower()
        # Must NOT assert that Keytruda treats asthma
        self.assertNotIn("keytruda treats asthma", ans_lower)
        self.assertNotIn("watson:ontology:treatsindication <http://watson.pharma.org/entity/indication/asthma>", ans_lower)

    def test_invariant_h_citations_resolve_to_same_document_as_claim(self):
        """Test H: Correct citations resolve to the same document as their associated claim."""
        query = (
            "Compare the market access considerations for Keytruda in EU oncology, "
            "Dupixent in US immunology, and Xolair in Indian respiratory care."
        )
        res = self.assembler.retrieve_and_synthesize(query=query, user_id="D4")

        table_rows = [line for line in res.answer.splitlines() if line.startswith("| **")]
        self.assertEqual(len(table_rows), 3)

        for row in table_rows:
            if "Keytruda" in row:
                self.assertIn("[watson:Doc_007:chunk:b:0000]", row)
            elif "Dupixent" in row:
                self.assertIn("[watson:Doc_005:chunk:b:0000]", row)
            elif "Xolair" in row:
                self.assertIn("[watson:Doc_008:chunk:b:0000]", row)

    def test_invariant_i_dupixent_direct_synthesis_unchanged(self):
        """Test I: Successful Dupixent direct synthesis remains unchanged."""
        query = (
            "What concerns do healthcare professionals express about Dupixent for "
            "atopic dermatitis in the United States, and what improvements do they recommend?"
        )
        res = self.assembler.retrieve_and_synthesize(query=query, user_id="D4")

        self.assertEqual(res.pipeline_execution_status, "COMPLETED")
        self.assertEqual(res.answer_relevance_status, "RELEVANT")
        self.assertEqual(res.answer_grounding_status, "GROUNDED")
        self.assertIn("dupixent", res.answer.lower())
        self.assertTrue(len(res.citations) > 0)
        self.assertTrue(any(":Doc_005:" in c.source_uri for c in res.citations))

    def test_invariant_j_viewer_security_isolation(self):
        """Test J: VIEWER cannot access unauthorized evidence through comparison or graph traversal."""
        # User D3 is a Viewer restricted to Public/Internal and Oncology/Respiratory
        allowed_chunks = self.assembler.get_allowed_chunk_uris(user_id="D3")
        total_chunks = len(self.assembler.index_manager.chunk_uri_map)

        self.assertLess(len(allowed_chunks), total_chunks)
        self.assertEqual(len(allowed_chunks), 20)

        # Viewer queries cross-market comparison
        res_viewer = self.assembler.retrieve_and_synthesize(
            query="Compare Keytruda in EU with Farxiga in CKD",
            user_id="D3",
        )
        self.assertEqual(res_viewer.user_role, "VIEWER")
        for chunk in res_viewer.scored_chunks:
            self.assertIn(chunk.chunk_uri, allowed_chunks)


if __name__ == "__main__":
    unittest.main()
