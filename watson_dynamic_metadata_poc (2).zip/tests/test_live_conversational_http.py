from __future__ import annotations

import sys
from pathlib import Path

BACKEND_DIR = Path(__file__).resolve().parent.parent / "backend"
if str(BACKEND_DIR) not in sys.path:
    sys.path.insert(0, str(BACKEND_DIR))
ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

import pytest
from fastapi.testclient import TestClient

from backend.app.main import app

client = TestClient(app)


def test_live_greeting_with_name_punctuation():
    """Validates that 'Hi Watson!' routes to CONVERSATIONAL without document retrieval."""
    response = client.post("/api/chat", json={"query": "Hi Watson!", "top_k": 5})
    assert response.status_code == 200
    data = response.json()

    assert data["route"] == "CONVERSATIONAL"
    assert data["conversation_intent"] == "GREETING"
    assert data["active_provider"] == "CONVERSATIONAL_GATE"
    assert len(data["scored_chunks"]) == 0
    assert len(data["citations"]) == 0
    assert "Watson" in data["answer"]
    assert "Doc_011" not in data["answer"]

    # Verify stages 4-15 are marked SKIPPED
    stages = data.get("live_stages", [])
    assert len(stages) == 15
    for s in stages:
        if s["stage_number"] in [1, 2, 3]:
            assert s["status"] == "COMPLETED"
        else:
            assert s["status"] == "SKIPPED"


def test_live_capability_inquiry():
    """Validates that 'What kind of pharmaceutical research questions can you help me answer?' routes correctly."""
    response = client.post(
        "/api/chat",
        json={"query": "What kind of pharmaceutical research questions can you help me answer?", "top_k": 5},
    )
    assert response.status_code == 200
    data = response.json()

    assert data["route"] == "CONVERSATIONAL"
    assert data["conversation_intent"] == "CAPABILITY_HELP"
    assert data["active_provider"] == "CONVERSATIONAL_GATE"
    assert len(data["scored_chunks"]) == 0
    assert len(data["citations"]) == 0
    assert "Doc_" not in data["answer"]
    assert "Jardiance" not in data["answer"]


def test_live_market_research_help_inquiry():
    """Validates capability query variations like 'How can Watson help with market research?'"""
    response = client.post(
        "/api/chat",
        json={"query": "How can Watson help with market research?", "top_k": 5},
    )
    assert response.status_code == 200
    data = response.json()

    assert data["route"] == "CONVERSATIONAL"
    assert data["conversation_intent"] == "CAPABILITY_HELP"
    assert len(data["scored_chunks"]) == 0


def test_live_research_query_grounded_synthesis():
    """Validates that real research queries still execute full hybrid GraphRAG retrieval with citations."""
    response = client.post(
        "/api/chat",
        json={"query": "Summarize the HCP concerns about Dupixent in US atopic dermatitis", "top_k": 5},
    )
    assert response.status_code == 200
    data = response.json()

    assert data["route"] in ["HYBRID", "VECTOR", "GRAPH_TRAVERSAL"]
    assert data["conversation_intent"] == "RESEARCH_QUESTION"
    assert len(data["scored_chunks"]) > 0
    assert len(data["citations"]) > 0
    assert any("Doc_005" in c.get("doc_uri", "") for c in data["citations"])
    assert "HCP" in data["answer"] or "Healthcare Professional" in data["answer"]
