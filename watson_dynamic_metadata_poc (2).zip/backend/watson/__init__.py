from __future__ import annotations
import sys
from pathlib import Path

_WATSON_DIR = Path(__file__).resolve().parent
_BACKEND_DIR = _WATSON_DIR.parent
for _sub in (_BACKEND_DIR, _WATSON_DIR / "semantics", _WATSON_DIR / "ingestion", _WATSON_DIR / "governance", _BACKEND_DIR / "_compat_shims"):
    if _sub.is_dir() and str(_sub) not in sys.path:
        sys.path.append(str(_sub))
