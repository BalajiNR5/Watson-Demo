"""
Watson Platform — Production Semantic / Structural Chunker (updated_chunker.py)
================================================================================

This module implements ONLY the empirically selected production chunking strategy
(Strategy B: Semantic / Structural Chunking) in accordance with Watson PRD Section 4.2
and the validated retrieval evaluation decisions documented in design_decisions.md.

Design & Architectural Decision:
- Fixed-size sliding window strategies (A256, A512) were empirically evaluated and
  rejected due to multi-topic context dilution, cross-document retrieval failures,
  and omission of presentation speaker notes.
- Strategy B achieved 100% Top-1 document retrieval accuracy and 100% evidence
  completeness across all canonical evaluation queries.
- Therefore, this production module contains NO RUNTIME BRANCHING for fixed-size
  strategies. It executes exclusively the format-aware semantic/structural strategy.
- NO LangChain or generic framework dependencies are used. Chunking logic is 100%
  custom, deterministic, and auditable.

Format Rules:
1. PDF: Bounded by physical pages. Content never crosses page boundaries.
   Pages <= 600 tokens remain a single chunk. Pages > 600 tokens are split only
   within the page, retaining page_number and structural_part.
2. DOCX: Bounded by Heading 1 (H1) and Heading 2 (H2) sections. H3 and deeper
   subsections remain attached to their active H1/H2 parent.
3. PPTX: Exactly one chunk per slide, containing title, body, and speaker notes.
   Slides are not subjected to the PDF 600-token splitting rule.
4. TXT: Bounded by parser paragraph text blocks. Blocks > 600 tokens are split
   within the block.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple


# -----------------------------------------------------------------------------
# Configuration Constants
# -----------------------------------------------------------------------------

PRODUCTION_STRATEGY_NAME = "semantic_structural"
PRODUCTION_STRATEGY_CODE = "B"
MAX_TOKENS_PER_PAGE_CHUNK = 600
SUPPORTED_FORMATS = {"pdf", "docx", "pptx", "txt"}


# -----------------------------------------------------------------------------
# Auditable Local Tokenizer
# -----------------------------------------------------------------------------

class Tokenizer:
    """Local tokenizer with a dependency-free fallback.

    If tiktoken is installed, cl100k_base is used. Otherwise a deterministic
    regex tokenizer is used. The chosen tokenizer is recorded in every chunk,
    making token counts auditable.
    """

    _FALLBACK_PATTERN = re.compile(r"\s+|\w+|[^\w\s]", re.UNICODE)

    def __init__(self) -> None:
        self._encoding = None
        self.name = "regex_fallback"
        try:
            import tiktoken  # type: ignore

            self._encoding = tiktoken.get_encoding("cl100k_base")
            self.name = "tiktoken:cl100k_base"
        except Exception:
            self._encoding = None

    def encode(self, text: str) -> List[Any]:
        if not text:
            return []
        if self._encoding is not None:
            return list(self._encoding.encode(text))
        return self._FALLBACK_PATTERN.findall(text)

    def decode(self, tokens: Sequence[Any]) -> str:
        if not tokens:
            return ""
        if self._encoding is not None:
            return self._encoding.decode(list(tokens))
        return "".join(str(token) for token in tokens)

    def count(self, text: str) -> int:
        return len(self.encode(text))


TOKENIZER = Tokenizer()


# -----------------------------------------------------------------------------
# Text Normalization and Source Offset Helpers
# -----------------------------------------------------------------------------

def normalize_text(text: Optional[str]) -> str:
    """Normalize extracted text whitespace and line endings deterministically."""
    if not text:
        return ""
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = text.replace("\t", " ").replace("\xa0", " ")
    lines = [re.sub(r"[ ]+", " ", line).strip() for line in text.split("\n")]

    cleaned: List[str] = []
    previous_blank = False
    for line in lines:
        if not line:
            if not previous_blank:
                cleaned.append("")
            previous_blank = True
        else:
            cleaned.append(line)
            previous_blank = False
    return "\n".join(cleaned).strip()


def load_json(path: Path) -> Dict[str, Any]:
    """Load and validate JSON file."""
    with path.open("r", encoding="utf-8") as handle:
        value = json.load(handle)
    if not isinstance(value, dict):
        raise ValueError(f"Parsed document must be a JSON object: {path}")
    return value


def save_json(value: Any, path: Path) -> None:
    """Save data as pretty JSON with UTF-8 encoding."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(value, handle, indent=2, ensure_ascii=False)


def validate_parsed_document(document: Dict[str, Any]) -> None:
    """Ensure ParsedDocument adheres to parser.py contract."""
    required = ("document_uri", "source_filename", "format", "raw_text")
    missing = [key for key in required if key not in document]
    if missing:
        raise ValueError("ParsedDocument missing required field(s): " + ", ".join(missing))

    fmt = str(document.get("format", "")).lower()
    if fmt not in SUPPORTED_FORMATS:
        raise ValueError(f"Unsupported parsed format: {fmt!r}")

    if not isinstance(document.get("raw_text"), str):
        raise ValueError("ParsedDocument.raw_text must be a string")


def split_tokens(text: str, max_tokens: int) -> List[str]:
    """Split text into non-overlapping token windows of max_tokens."""
    if max_tokens <= 0:
        raise ValueError("max_tokens must be > 0")
    tokens = TOKENIZER.encode(text)
    if not tokens:
        return []
    pieces: List[str] = []
    for start in range(0, len(tokens), max_tokens):
        window = tokens[start:start + max_tokens]
        piece = TOKENIZER.decode(window)
        if piece:
            pieces.append(piece)
    return pieces


def locate_text(raw_text: str, text: str, cursor: int = 0) -> Tuple[Optional[int], Optional[int]]:
    """Best-effort source character span using Python's [start, end) convention."""
    if not text:
        return None, None

    pos = raw_text.find(text, max(cursor, 0))
    if pos < 0:
        pos = raw_text.find(text)
    if pos < 0:
        return None, None
    return pos, pos + len(text)


def page_lookup(document: Dict[str, Any]) -> Dict[int, Dict[str, Any]]:
    """Create map of page_number -> page dict from ParsedDocument."""
    result: Dict[int, Dict[str, Any]] = {}
    for page in document.get("pages") or []:
        try:
            number = int(page.get("page_number"))
        except (TypeError, ValueError):
            continue
        result[number] = page
    return result


def source_provenance(
    document: Dict[str, Any],
    page_numbers: Optional[Sequence[int]] = None,
    unit_type: Optional[str] = None,
    unit_indices: Optional[Sequence[int]] = None,
    heading: Optional[str] = None,
    heading_level: Optional[str] = None,
) -> Dict[str, Any]:
    """Assemble standardized provenance metadata record."""
    pages = sorted({int(p) for p in (page_numbers or [])})
    units = [int(u) for u in (unit_indices or [])]
    lookup = page_lookup(document)

    provenance: Dict[str, Any] = {
        "source_filename": document.get("source_filename"),
        "format": str(document.get("format", "")).lower(),
        "page_start": pages[0] if pages else None,
        "page_end": pages[-1] if pages else None,
        "page_numbers": pages,
        "unit_type": unit_type,
        "unit_indices": units,
    }

    if heading is not None:
        provenance["heading"] = heading
    if heading_level is not None:
        provenance["heading_level"] = heading_level

    parser_spans = []
    for number in pages:
        span = (lookup.get(number) or {}).get("page_span")
        if isinstance(span, dict):
            parser_spans.append({"page_number": number, "page_span": span})
    if parser_spans:
        provenance["parser_page_spans"] = parser_spans

    return provenance


def make_chunk(
    document: Dict[str, Any],
    chunk_index: int,
    text: str,
    *,
    char_start: Optional[int],
    char_end: Optional[int],
    provenance: Dict[str, Any],
    structural_part: Optional[int] = None,
) -> Dict[str, Any]:
    """Construct a single production chunk dictionary adhering to platform schema."""
    parent_uri = document.get("document_uri")
    # Canonical chunk_uri format: preserves backward-compatible URI namespace
    chunk_uri = f"{parent_uri}:chunk:b:{chunk_index:04d}"

    chunk: Dict[str, Any] = {
        "chunk_uri": chunk_uri,
        "parent_document_uri": parent_uri,
        "source_filename": document.get("source_filename"),
        "format": str(document.get("format", "")).lower(),
        "strategy": PRODUCTION_STRATEGY_NAME,
        "strategy_code": PRODUCTION_STRATEGY_CODE,
        "chunk_index": chunk_index,
        "text": text,
        "char_start": char_start,
        "char_end": char_end,
        "token_count": TOKENIZER.count(text),
        "tokenizer": TOKENIZER.name,
        "source_provenance": provenance,
    }
    if structural_part is not None:
        chunk["structural_part"] = structural_part
    return chunk


# -----------------------------------------------------------------------------
# Format-Specific Semantic / Structural Chunking Implementations
# -----------------------------------------------------------------------------

def _append_structural_text_chunks(
    chunks: List[Dict[str, Any]],
    document: Dict[str, Any],
    text: str,
    *,
    max_tokens: int,
    page_numbers: Optional[Sequence[int]],
    unit_type: str,
    unit_indices: Sequence[int],
    heading: Optional[str] = None,
    heading_level: Optional[str] = None,
    cursor: int = 0,
) -> int:
    """Helper to partition text into <= max_tokens parts while preserving provenance."""
    text = normalize_text(text)
    if not text:
        return cursor

    pieces = split_tokens(text, max_tokens) if TOKENIZER.count(text) > max_tokens else [text]
    raw_text = document.get("raw_text", "")
    local_cursor = cursor

    for part_number, piece in enumerate(pieces, start=1):
        char_start, char_end = locate_text(raw_text, piece, local_cursor)
        if char_end is not None:
            local_cursor = char_end

        provenance = source_provenance(
            document,
            page_numbers=page_numbers,
            unit_type=unit_type,
            unit_indices=unit_indices,
            heading=heading,
            heading_level=heading_level,
        )
        chunks.append(
            make_chunk(
                document,
                len(chunks),
                piece,
                char_start=char_start,
                char_end=char_end,
                provenance=provenance,
                structural_part=part_number if len(pieces) > 1 else None,
            )
        )
    return local_cursor


def _pdf_structural_chunks(document: Dict[str, Any], max_tokens: int) -> List[Dict[str, Any]]:
    """PDF: Chunk strictly by physical page. Split oversized pages only within that page."""
    chunks: List[Dict[str, Any]] = []
    units = document.get("structural_units") or []

    # Fallback to pages array if structural_units is unpopulated
    if not units:
        units = [
            {
                "unit_type": "page",
                "unit_index": page.get("page_number"),
                "text": page.get("text", ""),
            }
            for page in (document.get("pages") or [])
        ]

    cursor = 0
    for unit in units:
        try:
            page_number = int(unit.get("unit_index"))
        except (TypeError, ValueError):
            continue
        cursor = _append_structural_text_chunks(
            chunks,
            document,
            unit.get("text", ""),
            max_tokens=max_tokens,
            page_numbers=[page_number],
            unit_type="page",
            unit_indices=[page_number],
            cursor=cursor,
        )
    return chunks


def _docx_section_text(units: Sequence[Dict[str, Any]]) -> str:
    """Concatenate heading and body elements of a section group."""
    parts: List[str] = []
    for unit in units:
        heading = normalize_text(unit.get("heading"))
        body = normalize_text(unit.get("text"))
        if heading:
            parts.append(heading)
        if body:
            parts.append(body)
    return normalize_text("\n\n".join(parts))


def _docx_structural_chunks(document: Dict[str, Any], max_tokens: int) -> List[Dict[str, Any]]:
    """DOCX: Chunk strictly at H1 and H2 boundaries. Subordinate H3+ stay in active parent."""
    chunks: List[Dict[str, Any]] = []
    units = document.get("structural_units") or []
    if not units:
        return chunks

    groups: List[List[Dict[str, Any]]] = []
    current: List[Dict[str, Any]] = []

    for unit in units:
        level = str(unit.get("heading_level") or "").upper()
        is_h1_h2 = level in {"H1", "H2"}
        if is_h1_h2 and current:
            groups.append(current)
            current = []
        current.append(unit)

    if current:
        groups.append(current)

    cursor = 0
    for group in groups:
        text = _docx_section_text(group)
        if not text:
            continue
        first_boundary = next(
            (u for u in group if str(u.get("heading_level") or "").upper() in {"H1", "H2"}),
            group[0],
        )
        indices = [
            int(u.get("unit_index"))
            for u in group
            if str(u.get("unit_index", "")).isdigit()
        ]
        cursor = _append_structural_text_chunks(
            chunks,
            document,
            text,
            max_tokens=max_tokens,
            page_numbers=[],  # DOCX lacks physical page rendering
            unit_type="section",
            unit_indices=indices,
            heading=first_boundary.get("heading"),
            heading_level=first_boundary.get("heading_level"),
            cursor=cursor,
        )
    return chunks


def _pptx_slide_text(unit: Dict[str, Any]) -> str:
    """Assemble single slide text containing title, body, and speaker notes."""
    title = normalize_text(unit.get("title"))
    body = normalize_text(unit.get("body"))
    notes = normalize_text(unit.get("speaker_notes"))

    parts: List[str] = []
    if title:
        parts.append(title)
    if body:
        parts.append(body)
    if notes:
        parts.append(notes)

    if not parts:
        return normalize_text(unit.get("text", ""))
    return normalize_text("\n\n".join(parts))


def _pptx_structural_chunks(document: Dict[str, Any]) -> List[Dict[str, Any]]:
    """PPTX: Exactly one chunk per slide (title + body + speaker notes).

    In accordance with Watson Section 4.2 design decision, presentation slides
    are NOT subjected to the 600-token splitting rule to preserve slide integrity.
    """
    chunks: List[Dict[str, Any]] = []
    units = document.get("structural_units") or []

    for unit in units:
        try:
            slide_number = int(unit.get("unit_index"))
        except (TypeError, ValueError):
            continue

        text = _pptx_slide_text(unit)
        if not text:
            continue

        raw_text = document.get("raw_text", "")
        char_start, char_end = locate_text(raw_text, normalize_text(unit.get("text", "")))
        provenance = source_provenance(
            document,
            page_numbers=[slide_number],
            unit_type="slide",
            unit_indices=[slide_number],
        )
        chunks.append(
            make_chunk(
                document,
                len(chunks),
                text,
                char_start=char_start,
                char_end=char_end,
                provenance=provenance,
            )
        )
    return chunks


def _txt_structural_chunks(document: Dict[str, Any], max_tokens: int) -> List[Dict[str, Any]]:
    """TXT: Chunk by parser-provided paragraph text blocks."""
    chunks: List[Dict[str, Any]] = []
    units = document.get("structural_units") or []
    if not units and document.get("raw_text"):
        units = [{"unit_type": "text_block", "unit_index": 1, "text": document["raw_text"]}]

    cursor = 0
    for unit in units:
        try:
            index = int(unit.get("unit_index"))
        except (TypeError, ValueError):
            continue
        cursor = _append_structural_text_chunks(
            chunks,
            document,
            unit.get("text", ""),
            max_tokens=max_tokens,
            page_numbers=[],
            unit_type="text_block",
            unit_indices=[index],
            cursor=cursor,
        )
    return chunks


# -----------------------------------------------------------------------------
# Production Public API
# -----------------------------------------------------------------------------

def chunk_semantic_structural(
    document: Dict[str, Any],
    max_tokens: int = MAX_TOKENS_PER_PAGE_CHUNK,
) -> List[Dict[str, Any]]:
    """Generate semantic/structural chunks for a parsed document.

    Dispatches to format-specific handlers:
    - PDF: _pdf_structural_chunks
    - DOCX: _docx_structural_chunks
    - PPTX: _pptx_structural_chunks
    - TXT: _txt_structural_chunks
    """
    if max_tokens <= 0:
        raise ValueError("max_tokens must be > 0")

    fmt = str(document.get("format", "")).lower()
    if fmt == "pdf":
        return _pdf_structural_chunks(document, max_tokens)
    if fmt == "docx":
        return _docx_structural_chunks(document, max_tokens)
    if fmt == "pptx":
        return _pptx_structural_chunks(document)
    if fmt == "txt":
        return _txt_structural_chunks(document, max_tokens)
    raise ValueError(f"Unsupported format for semantic/structural chunking: {fmt}")


# Backward-compatible alias for existing tests
chunk_strategy_b = chunk_semantic_structural


def chunk_document(
    parsed_document: Dict[str, Any],
    *,
    max_tokens: int = MAX_TOKENS_PER_PAGE_CHUNK,
) -> Dict[str, Any]:
    """Production entry point for document chunking.

    Processes ParsedDocument exclusively via Strategy B (Semantic / Structural).
    No fixed-size parameters or branching are exposed.

    Returns:
        Structured dictionary containing:
        - document_uri, source_filename, format, tokenizer
        - strategy: 'semantic_structural'
        - chunk_count
        - chunks: list of production chunks
        - strategies: backwards-compatible dict for downstream PII / metadata tools
    """
    validate_parsed_document(parsed_document)

    chunks = chunk_semantic_structural(parsed_document, max_tokens=max_tokens)

    # Standardized production envelope
    result: Dict[str, Any] = {
        "document_uri": parsed_document.get("document_uri"),
        "source_filename": parsed_document.get("source_filename"),
        "format": str(parsed_document.get("format", "")).lower(),
        "strategy": PRODUCTION_STRATEGY_NAME,
        "tokenizer": TOKENIZER.name,
        "configuration": {
            "strategy": PRODUCTION_STRATEGY_NAME,
            "max_tokens_per_page_chunk": max_tokens,
            "pdf_boundary": "physical page boundary, split > 600 tokens",
            "docx_boundary": "H1/H2 heading boundaries, H3+ preserved with parent",
            "pptx_boundary": "one chunk per slide (title + body + speaker notes)",
            "txt_boundary": "parser text_block paragraph boundaries",
        },
        "chunk_count": len(chunks),
        "chunks": chunks,
        # Full backward compatibility for downstream modules (pii_detector, metadata_extractor)
        "strategies": {
            "B": {
                "name": PRODUCTION_STRATEGY_NAME,
                "chunk_count": len(chunks),
                "chunks": chunks,
            }
        },
    }
    return result


# -----------------------------------------------------------------------------
# Production CLI
# -----------------------------------------------------------------------------

def output_name_for(parsed_json: Path) -> str:
    """Generate standardized chunk filename from parsed JSON filename."""
    stem = parsed_json.stem
    if stem.endswith("_parsed"):
        stem = stem[:-7]
    return f"{stem}_chunks.json"


def process_file(
    input_path: Path,
    output_dir: Path,
    max_tokens: int = MAX_TOKENS_PER_PAGE_CHUNK,
) -> bool:
    """Process a single parsed JSON file into production structural chunks."""
    try:
        document = load_json(input_path)
        result = chunk_document(document, max_tokens=max_tokens)
        output_name = output_name_for(input_path)
        output_path = output_dir / output_name
        save_json(result, output_path)

        print(f"Chunked: {input_path}")
        print(f"Saved:   {output_path}")
        print(f"  Production Chunks ({PRODUCTION_STRATEGY_NAME}): {result['chunk_count']}")
        return True
    except Exception as exc:
        print(f"ERROR while chunking {input_path.name}: {exc}", file=sys.stderr)
        return False


def discover_parsed_json_files(path: Path) -> List[Path]:
    """Discover parsed JSON files from file or directory path."""
    if path.is_file():
        return [path]
    if path.is_dir():
        preferred = sorted(path.glob("*_parsed.json"))
        if preferred:
            return preferred
        return sorted(path.glob("*.json"))
    return []


def build_arg_parser() -> argparse.ArgumentParser:
    """Build production command-line interface.

    NOTE: No strategy selection options (A256, A512, both) are provided.
    The production chunker strictly executes Semantic / Structural chunking.
    """
    parser = argparse.ArgumentParser(
        description="Watson Production Chunker: Semantic / Structural Chunking (Strategy B)."
    )
    parser.add_argument(
        "input",
        help="Parsed JSON file or directory containing parsed JSON files (e.g., staging/)",
    )
    parser.add_argument(
        "--output-dir",
        default="chunks/production",
        help="Directory for production chunk JSON output (default: chunks/production)",
    )
    parser.add_argument(
        "--max-tokens",
        type=int,
        default=MAX_TOKENS_PER_PAGE_CHUNK,
        help=f"Max tokens before splitting oversized PDF pages or TXT blocks (default: {MAX_TOKENS_PER_PAGE_CHUNK})",
    )
    return parser


def main() -> int:
    args = build_arg_parser().parse_args()
    input_path = Path(args.input)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    files = discover_parsed_json_files(input_path)
    if not files:
        print(f"No parsed JSON files found: {input_path}", file=sys.stderr)
        return 1

    print(f"Watson Production Chunker [Strategy: {PRODUCTION_STRATEGY_NAME}]")
    print(f"Tokenizer: {TOKENIZER.name}")
    print(f"Discovered {len(files)} parsed document(s).")

    success = 0
    for path in files:
        if process_file(path, output_dir, max_tokens=args.max_tokens):
            success += 1

    print("\nProduction chunking complete.")
    print(f"Successfully processed: {success}/{len(files)}")
    print(f"Output directory: {output_dir.resolve()}")
    return 0 if success == len(files) else 1


if __name__ == "__main__":
    raise SystemExit(main())
