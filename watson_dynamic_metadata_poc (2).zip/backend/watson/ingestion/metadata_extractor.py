"""
Watson Project - Layer 1 Metadata Extractor
==========================================

Purpose
-------
Build and maintain the PRD-defined 15-field metadata record from:
  1) ParsedDocument / parser.py output
  2) system-generated values
  3) controlled-vocabulary / NER enrichment
  4) PII detector output
  5) future HITL review output

This module does NOT implement the HITL review layer, ABAC enforcement,
lifecycle transitions, expiry/retention policy, or PII detection itself.
It exposes stable interfaces so those components can integrate later.

Canonical 15 fields
-------------------
1.  document_uri
2.  source_filename
3.  format
4.  ingest_timestamp
5.  word_count
6.  extracted_title
7.  extracted_author
8.  study_type
9.  therapeutic_area
10. geography
11. brands_mentioned
12. indications_mentioned
13. language
14. pii_assessment
15. sensitivity_level
"""

from __future__ import annotations

import argparse
import copy
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple
from uuid import uuid4

try:
    from langdetect import detect as _langdetect
except Exception:  # pragma: no cover - optional dependency
    _langdetect = None

try:
    import spacy
except Exception:  # pragma: no cover - optional dependency
    spacy = None


# -----------------------------------------------------------------------------
# PRD contract
# -----------------------------------------------------------------------------

METADATA_FIELDS: Tuple[str, ...] = (
    "document_uri",
    "source_filename",
    "format",
    "ingest_timestamp",
    "word_count",
    "extracted_title",
    "extracted_author",
    "study_type",
    "therapeutic_area",
    "geography",
    "brands_mentioned",
    "indications_mentioned",
    "language",
    "pii_assessment",
    "sensitivity_level",
)

SUPPORTED_FORMATS = {"pdf", "docx", "pptx", "txt"}

STUDY_TYPES = {
    "HCP Perception Survey",
    "Competitive Landscape Report",
    "Indication Deep Dive",
    "Market Access Insight",
    "KOL Interview Summary",
    "Therapy Area Landscape",
}

SENSITIVITY_LEVELS = {
    "PUBLIC",
    "INTERNAL",
    "RESTRICTED",
    "CONFIDENTIAL",
}

# Required to become ACTIVE according to the metadata table.
ACTIVE_REQUIRED_FIELDS = {
    "document_uri",
    "source_filename",
    "format",
    "ingest_timestamp",
    "word_count",
    "study_type",
    "therapeutic_area",
    "geography",
    "language",
    "pii_assessment",
    "sensitivity_level",
}

# PII assessment must exist before UNDER_REVIEW.
UNDER_REVIEW_REQUIRED_FIELDS = {
    "pii_assessment",
}

# Fields that the future HITL review component is allowed to provide/confirm
# within the 15-field metadata record. ABAC-only attributes are intentionally
# not stored here.
HITL_METADATA_FIELDS = {
    "study_type",
    "therapeutic_area",
    "geography",
    "sensitivity_level",
}


# -----------------------------------------------------------------------------
# Utility helpers
# -----------------------------------------------------------------------------

def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _as_non_empty_string(value: Any) -> Optional[str]:
    if value is None:
        return None
    value = str(value).strip()
    return value or None


def _unique_preserve_order(values: Iterable[str]) -> List[str]:
    seen = set()
    output: List[str] = []
    for value in values:
        if value not in seen:
            seen.add(value)
            output.append(value)
    return output


def _normalize_vocab(values: Any) -> List[str]:
    """Convert common JSON vocabulary shapes into a clean list of strings."""
    if values is None:
        return []

    if isinstance(values, str):
        return [values.strip()] if values.strip() else []

    if isinstance(values, Mapping):
        # Dictionaries may be {canonical: aliases} or {key: value}.
        flattened: List[str] = []
        for key, val in values.items():
            if isinstance(key, str) and key.strip():
                flattened.append(key.strip())
            if isinstance(val, str) and val.strip():
                flattened.append(val.strip())
            elif isinstance(val, Sequence) and not isinstance(val, (str, bytes)):
                for item in val:
                    if isinstance(item, str) and item.strip():
                        flattened.append(item.strip())
        return _unique_preserve_order(flattened)

    if isinstance(values, Sequence) and not isinstance(values, (str, bytes)):
        return _unique_preserve_order(
            str(item.get("canonical_name", "") if isinstance(item, Mapping) else item).strip()
            for item in values
            if item is not None and str(item.get("canonical_name", "") if isinstance(item, Mapping) else item).strip()
        )

    return []


def _get_case_insensitive(mapping: Mapping[str, Any], *keys: str) -> Any:
    lookup = {str(k).lower(): v for k, v in mapping.items()}
    for key in keys:
        if key.lower() in lookup:
            return lookup[key.lower()]
    return None


def _load_vocab_file(path: Optional[Path]) -> Dict[str, List[str]]:
    """
    Load optional controlled vocabularies.

    Supported top-level key aliases include:
      BRANDS / brands
      INDICATIONS / indications
      THERAPEUTIC_AREAS / therapeutic_areas / therapeutic_area
      GEOGRAPHIES / geographies / geography / GEO

    Unknown keys are ignored. This keeps taxonomy_manager.py a separate module.
    """
    result = {
        "brands": [],
        "indications": [],
        "therapeutic_areas": [],
        "geographies": [],
    }

    if path is None:
        return result

    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Vocabulary file not found: {path}")

    with path.open("r", encoding="utf-8") as handle:
        payload = json.load(handle)

    if not isinstance(payload, Mapping):
        raise ValueError("Vocabulary JSON must contain a top-level object/dictionary.")

    if isinstance(payload.get("vocabularies"), Mapping):
        payload = payload["vocabularies"]

    result["brands"] = _normalize_vocab(
        _get_case_insensitive(payload, "BRANDS", "brands")
    )
    result["indications"] = _normalize_vocab(
        _get_case_insensitive(payload, "INDICATIONS", "indications")
    )
    result["therapeutic_areas"] = _normalize_vocab(
        _get_case_insensitive(
            payload,
            "THERAPEUTIC_AREAS",
            "therapeutic_areas",
            "therapeutic_area",
            "TA",
        )
    )
    result["geographies"] = _normalize_vocab(
        _get_case_insensitive(
            payload,
            "GEOGRAPHIES",
            "geographies",
            "geography",
            "GEO",
        )
    )

    return result


def _safe_word_count(raw_text: str) -> int:
    # PRD method: len(raw_text.split())
    return len((raw_text or "").split())


def _detect_language(raw_text: str) -> Optional[str]:
    if not raw_text or not raw_text.strip() or _langdetect is None:
        return None
    try:
        return _langdetect(raw_text)
    except Exception:
        return None


def _phrase_pattern(phrase: str) -> re.Pattern[str]:
    """
    Case-insensitive controlled phrase matching with conservative boundaries.
    Works for words and multi-word phrases without matching inside larger tokens.
    """
    escaped = re.escape(phrase.strip())
    return re.compile(rf"(?<!\w){escaped}(?!\w)", re.IGNORECASE)


def _find_controlled_mentions(text: str, vocabulary: Sequence[str]) -> List[str]:
    if not text or not vocabulary:
        return []

    matches: List[Tuple[int, str]] = []
    for canonical in vocabulary:
        match = _phrase_pattern(canonical).search(text)
        if match:
            matches.append((match.start(), canonical))

    matches.sort(key=lambda item: (item[0], item[1].lower()))
    return _unique_preserve_order(value for _, value in matches)


def _extract_first_heading_or_title(parsed_document: Mapping[str, Any]) -> Optional[str]:
    structural_units = parsed_document.get("structural_units") or []
    if isinstance(structural_units, Sequence):
        for unit in structural_units:
            if not isinstance(unit, Mapping):
                continue
            for key in ("heading", "title"):
                candidate = _as_non_empty_string(unit.get(key))
                if candidate:
                    return candidate

    raw_text = str(parsed_document.get("raw_text") or "")
    for line in raw_text.splitlines():
        candidate = line.strip()
        if candidate:
            return candidate
    return None


# -----------------------------------------------------------------------------
# Metadata Extractor
# -----------------------------------------------------------------------------

class MetadataExtractor:
    """
    PRD-aligned 15-field metadata record builder.

    The extractor is deliberately decoupled from Parser, PII, HITL, Taxonomy,
    Lifecycle and ABAC implementations. It accepts their outputs through stable
    contracts instead of importing or duplicating their business logic.
    """

    def __init__(
        self,
        *,
        vocabulary_path: Optional[Path] = None,
        brands: Optional[Sequence[str]] = None,
        indications: Optional[Sequence[str]] = None,
        therapeutic_areas: Optional[Sequence[str]] = None,
        geographies: Optional[Sequence[str]] = None,
    ) -> None:
        loaded = _load_vocab_file(vocabulary_path)

        self.brands = _unique_preserve_order(
            loaded["brands"] + _normalize_vocab(brands)
        )
        self.indications = _unique_preserve_order(
            loaded["indications"] + _normalize_vocab(indications)
        )
        self.therapeutic_areas = _unique_preserve_order(
            loaded["therapeutic_areas"] + _normalize_vocab(therapeutic_areas)
        )
        self.geographies = _unique_preserve_order(
            loaded["geographies"] + _normalize_vocab(geographies)
        )

        self._brand_nlp = None

    # ------------------------------------------------------------------
    # Parser -> Metadata Extractor
    # ------------------------------------------------------------------

    def build_from_parsed_document(
        self,
        parsed_document: Mapping[str, Any],
        *,
        pii_output: Optional[Any] = None,
    ) -> Dict[str, Any]:
        """
        Build the canonical 15-field record from a parser ParsedDocument.

        pii_output is optional because PII may complete later in the governed
        ingestion flow. If present, it is normalized and attached.

        No mock HITL values are created. HITL-owned fields remain None until the
        real review component later calls apply_hitl_review().
        """
        if not isinstance(parsed_document, Mapping):
            raise TypeError("parsed_document must be a dictionary-like object.")

        raw_text = str(parsed_document.get("raw_text") or "")
        extracted = parsed_document.get("extracted_metadata") or {}
        if not isinstance(extracted, Mapping):
            extracted = {}

        document_uri = (
            _as_non_empty_string(parsed_document.get("document_uri"))
            or _as_non_empty_string(extracted.get("document_uri"))
            or f"Watson:Doc_{uuid4()}"
        )

        source_filename = (
            _as_non_empty_string(parsed_document.get("source_filename"))
            or _as_non_empty_string(extracted.get("source_filename"))
        )

        fmt = (
            _as_non_empty_string(parsed_document.get("format"))
            or _as_non_empty_string(extracted.get("format"))
        )
        fmt = fmt.lower().lstrip(".") if fmt else None

        ingest_timestamp = (
            _as_non_empty_string(extracted.get("ingest_timestamp"))
            or _utc_now_iso()
        )

        title = (
            _as_non_empty_string(extracted.get("extracted_title"))
            or _extract_first_heading_or_title(parsed_document)
            or "untitled"
        )

        author = _as_non_empty_string(extracted.get("extracted_author"))

        language = (
            _as_non_empty_string(extracted.get("language"))
            or _detect_language(raw_text)
        )

        brands_mentioned = self.extract_brands(raw_text)
        indications_mentioned = self.extract_indications(raw_text)

        # PRD allows HITL or NER for these. Here we make a controlled-vocabulary
        # inference if possible; otherwise leave None for future HITL review.
        therapeutic_area = self.infer_therapeutic_area(raw_text)
        geography = self.infer_geography(raw_text)

        record: Dict[str, Any] = {
            "document_uri": document_uri,
            "source_filename": source_filename,
            "format": fmt,
            "ingest_timestamp": ingest_timestamp,
            "word_count": _safe_word_count(raw_text),
            "extracted_title": title,
            "extracted_author": author,
            "study_type": next((value for value in sorted(STUDY_TYPES) if re.search(r"\b" + re.escape(value) + r"\b", raw_text, re.IGNORECASE)), None),
            "therapeutic_area": therapeutic_area,
            "geography": geography,
            "brands_mentioned": brands_mentioned,
            "indications_mentioned": indications_mentioned,
            "language": language,
            "pii_assessment": None,
            "sensitivity_level": None,  # future HITL assignment
        }

        if pii_output is not None:
            record = self.attach_pii_assessment(record, pii_output)

        return self._canonicalize(record)

    # ------------------------------------------------------------------
    # NER / controlled enrichment
    # ------------------------------------------------------------------

    def _build_brand_entity_ruler(self):
        if spacy is None or not self.brands:
            return None

        if self._brand_nlp is not None:
            return self._brand_nlp

        nlp = spacy.blank("en")
        ruler = nlp.add_pipe(
            "entity_ruler",
            config={"phrase_matcher_attr": "LOWER"},
        )
        ruler.add_patterns(
            [
                {"label": "BRAND", "pattern": brand, "id": brand}
                for brand in self.brands
            ]
        )
        self._brand_nlp = nlp
        return nlp

    def extract_brands(self, raw_text: str) -> List[str]:
        """
        PRD intent: spaCy EntityRuler against the BRANDS dictionary.
        Falls back to deterministic controlled phrase matching if spaCy is not
        installed so the integration contract remains usable in minimal setups.
        """
        if not raw_text or not self.brands:
            return []

        nlp = self._build_brand_entity_ruler()
        if nlp is None:
            return _find_controlled_mentions(raw_text, self.brands)

        doc = nlp(raw_text)
        values: List[str] = []
        for ent in doc.ents:
            if ent.label_ != "BRAND":
                continue
            canonical = ent.ent_id_ or ent.text
            values.append(canonical)
        return _unique_preserve_order(values)

    def extract_indications(self, raw_text: str) -> List[str]:
        # PRD intent: string match against INDICATIONS dictionary.
        return _find_controlled_mentions(raw_text, self.indications)

    def infer_therapeutic_area(self, raw_text: str) -> Optional[str]:
        matches = _find_controlled_mentions(raw_text, self.therapeutic_areas)
        return matches[0] if matches else None

    def infer_geography(self, raw_text: str) -> Optional[str]:
        matches = _find_controlled_mentions(raw_text, self.geographies)
        return matches[0] if matches else None

    # ------------------------------------------------------------------
    # PII Detector -> Metadata Extractor
    # ------------------------------------------------------------------

    @staticmethod
    def normalize_pii_assessment(pii_output: Any) -> Dict[str, Any]:
        """
        Normalize a PII detector output into the metadata field contract:
          {
            "pii_detected": bool,
            "pii_types": [...],
            "pii_spans": [...]
          }

        Accepted future integration shapes:
          - direct assessment dictionary
          - dictionary containing "pii_assessment"
          - dictionary containing "chunks" where each chunk has a PII assessment
          - list of per-chunk assessment dictionaries

        Detection remains the responsibility of the PII module; this method only
        adapts/aggregates its output.
        """

        def extract_assessment(item: Any) -> Optional[Mapping[str, Any]]:
            if not isinstance(item, Mapping):
                return None
            nested = item.get("pii_assessment")
            if isinstance(nested, Mapping):
                return nested
            if any(key in item for key in ("pii_detected", "pii_types", "pii_spans")):
                return item
            return None

        assessments: List[Mapping[str, Any]] = []

        if isinstance(pii_output, Mapping):
            chunk_list = pii_output.get("chunk_assessments") or pii_output.get("chunks")
            if isinstance(chunk_list, Sequence) and not isinstance(chunk_list, (str, bytes)):
                for chunk in chunk_list:
                    assessment = extract_assessment(chunk)
                    if assessment is not None:
                        assessments.append(assessment)
            elif "deduplicated_findings" in pii_output or "summary" in pii_output:
                summary = pii_output.get("summary") if isinstance(pii_output.get("summary"), Mapping) else {}
                assessments.append({
                    "pii_detected": pii_output.get("pii_detected", False),
                    "pii_types": summary.get("pii_types") or pii_output.get("pii_types", []),
                    "pii_spans": pii_output.get("deduplicated_findings") or pii_output.get("pii_spans", []),
                })
            else:
                direct = extract_assessment(pii_output)
                if direct is not None:
                    assessments.append(direct)
        elif isinstance(pii_output, Sequence) and not isinstance(pii_output, (str, bytes)):
            for item in pii_output:
                assessment = extract_assessment(item)
                if assessment is not None:
                    assessments.append(assessment)

        if not assessments:
            raise ValueError(
                "PII output does not contain a recognizable pii_assessment "
                "or per-chunk PII result."
            )

        pii_detected = False
        pii_types: List[str] = []
        pii_spans: List[Any] = []

        for assessment in assessments:
            detected = bool(assessment.get("pii_detected", False))
            types = assessment.get("pii_types") or []
            spans = assessment.get("pii_spans") or []

            pii_detected = pii_detected or detected

            if isinstance(types, str):
                types = [types]
            if isinstance(types, Sequence):
                for pii_type in types:
                    if pii_type is not None:
                        pii_types.append(str(pii_type))

            if isinstance(spans, Sequence) and not isinstance(spans, (str, bytes)):
                pii_spans.extend(copy.deepcopy(list(spans)))

        return {
            "pii_detected": pii_detected,
            "pii_types": _unique_preserve_order(pii_types),
            "pii_spans": pii_spans,
        }

    def attach_pii_assessment(
        self,
        metadata_record: Mapping[str, Any],
        pii_output: Any,
    ) -> Dict[str, Any]:
        record = self._canonicalize(metadata_record)
        record["pii_assessment"] = self.normalize_pii_assessment(pii_output)
        return self._canonicalize(record)

    # ------------------------------------------------------------------
    # Future HITL -> Metadata Extractor
    # ------------------------------------------------------------------

    def apply_hitl_review(
        self,
        metadata_record: Mapping[str, Any],
        review_payload: Mapping[str, Any],
    ) -> Dict[str, Any]:
        """
        Integration point for the REAL future HITL component.

        This method does not implement HITL and does not generate mock values.
        It accepts reviewed/assigned values produced by that component and merges
        only the metadata-owned HITL fields into the canonical record.

        Expected usable keys:
          study_type
          therapeutic_area
          geography
          sensitivity_level

        A future HITL payload may contain additional governance/ABAC values; they
        are deliberately ignored here because they belong to their own modules.
        """
        if not isinstance(review_payload, Mapping):
            raise TypeError("review_payload must be a dictionary-like object.")

        record = self._canonicalize(metadata_record)

        for field in HITL_METADATA_FIELDS:
            if field not in review_payload:
                continue

            value = review_payload[field]
            if field in {"study_type", "therapeutic_area", "geography", "sensitivity_level"}:
                value = _as_non_empty_string(value)

            if field == "study_type" and value is not None and value not in STUDY_TYPES:
                raise ValueError(
                    f"Invalid study_type: {value!r}. Expected one of: "
                    + ", ".join(sorted(STUDY_TYPES))
                )

            if (
                field == "sensitivity_level"
                and value is not None
                and value not in SENSITIVITY_LEVELS
            ):
                raise ValueError(
                    f"Invalid sensitivity_level: {value!r}. Expected one of: "
                    + ", ".join(sorted(SENSITIVITY_LEVELS))
                )

            # If vocabularies are available, enforce the controlled value here.
            # taxonomy_manager.py remains the authoritative validator later.
            if (
                field == "therapeutic_area"
                and value is not None
                and self.therapeutic_areas
                and value not in self.therapeutic_areas
            ):
                raise ValueError(
                    f"therapeutic_area {value!r} is not present in the loaded vocabulary."
                )

            if (
                field == "geography"
                and value is not None
                and self.geographies
                and value not in self.geographies
            ):
                raise ValueError(
                    f"geography {value!r} is not present in the loaded vocabulary."
                )

            record[field] = value

        return self._canonicalize(record)

    # ------------------------------------------------------------------
    # Validation / readiness
    # ------------------------------------------------------------------

    def validate(self, metadata_record: Mapping[str, Any]) -> Dict[str, Any]:
        record = self._canonicalize(metadata_record)

        errors: List[str] = []
        warnings: List[str] = []

        if not record["document_uri"]:
            errors.append("document_uri is missing")
        if not record["source_filename"]:
            errors.append("source_filename is missing")

        fmt = record["format"]
        if not fmt:
            errors.append("format is missing")
        elif fmt not in SUPPORTED_FORMATS:
            errors.append(f"unsupported format: {fmt}")

        if not record["ingest_timestamp"]:
            errors.append("ingest_timestamp is missing")

        if not isinstance(record["word_count"], int) or record["word_count"] < 0:
            errors.append("word_count must be a non-negative integer")

        if record["extracted_title"] in (None, ""):
            warnings.append('extracted_title absent; expected fallback "untitled"')

        if record["study_type"] is not None and record["study_type"] not in STUDY_TYPES:
            errors.append("study_type is not one of the six controlled PRD values")

        if (
            record["sensitivity_level"] is not None
            and record["sensitivity_level"] not in SENSITIVITY_LEVELS
        ):
            errors.append("sensitivity_level is not a controlled PRD value")

        if record["language"] and str(record["language"]).lower() != "en":
            warnings.append(f"non-English document flagged: {record['language']}")

        if record["extracted_author"] is None:
            warnings.append("extracted_author is null (allowed by PRD)")

        if not record["brands_mentioned"]:
            warnings.append("no brands_mentioned found (preferred, not mandatory)")

        if not record["indications_mentioned"]:
            warnings.append("no indications_mentioned found (preferred, not mandatory)")

        pii = record.get("pii_assessment")
        pii_blocked = False
        governance_warnings: List[str] = []

        if pii is not None:
            if not isinstance(pii, Mapping):
                errors.append("pii_assessment must be a dictionary")
            else:
                if "pii_detected" not in pii:
                    errors.append("pii_assessment missing 'pii_detected'")
                elif not isinstance(pii["pii_detected"], bool):
                    errors.append("pii_assessment 'pii_detected' must be a boolean")
                elif pii["pii_detected"] is True:
                    pii_blocked = True
                    gov_msg = (
                        "Document contains detected PII; blocked from ACTIVE lifecycle transition "
                        "pending HITL override"
                    )
                    warnings.append(gov_msg)
                    governance_warnings.append(gov_msg)

                if "pii_types" not in pii:
                    errors.append("pii_assessment missing 'pii_types'")
                elif not isinstance(pii["pii_types"], list):
                    errors.append("pii_assessment 'pii_types' must be a list")

                if "pii_spans" not in pii:
                    errors.append("pii_assessment missing 'pii_spans'")
                elif not isinstance(pii["pii_spans"], list):
                    errors.append("pii_assessment 'pii_spans' must be a list")

        missing_under_review = sorted(
            field
            for field in UNDER_REVIEW_REQUIRED_FIELDS
            if self._missing(record.get(field))
        )

        missing_active = sorted(
            field
            for field in ACTIVE_REQUIRED_FIELDS
            if self._missing(record.get(field))
        )

        metadata_complete = not errors and not missing_active

        return {
            "schema_valid": set(record.keys()) == set(METADATA_FIELDS),
            "field_count": len(record),
            "errors": errors,
            "warnings": warnings,
            "governance_warnings": governance_warnings,
            "missing_before_under_review": missing_under_review,
            "missing_for_active": missing_active,
            "ready_for_under_review": not errors and not missing_under_review,
            "ready_for_active": metadata_complete and not pii_blocked,
            "metadata_complete_for_active": metadata_complete,
            "pii_governance_blocked": pii_blocked,
            "requires_pii_hitl_override": pii_blocked,
        }

    @staticmethod
    def _missing(value: Any) -> bool:
        if value is None:
            return True
        if isinstance(value, str) and not value.strip():
            return True
        if isinstance(value, Mapping) and not value:
            return True
        return False

    @staticmethod
    def _canonicalize(record: Mapping[str, Any]) -> Dict[str, Any]:
        if not isinstance(record, Mapping):
            raise TypeError("metadata_record must be a dictionary-like object.")

        canonical = {field: copy.deepcopy(record.get(field)) for field in METADATA_FIELDS}

        # Canonical list fields.
        for field in ("brands_mentioned", "indications_mentioned"):
            value = canonical[field]
            if value is None:
                canonical[field] = []
            elif isinstance(value, str):
                canonical[field] = [value]
            elif isinstance(value, Sequence):
                canonical[field] = _unique_preserve_order(
                    str(item) for item in value if item is not None
                )
            else:
                canonical[field] = [str(value)]

        # Normalize scalar values that should be strings.
        for field in (
            "document_uri",
            "source_filename",
            "format",
            "ingest_timestamp",
            "extracted_title",
            "extracted_author",
            "study_type",
            "therapeutic_area",
            "geography",
            "language",
            "sensitivity_level",
        ):
            if canonical[field] is not None:
                canonical[field] = _as_non_empty_string(canonical[field])

        if canonical["format"]:
            canonical["format"] = canonical["format"].lower().lstrip(".")

        if canonical["extracted_title"] is None:
            canonical["extracted_title"] = "untitled"

        word_count = canonical["word_count"]
        if word_count is None:
            canonical["word_count"] = 0
        elif not isinstance(word_count, int):
            try:
                canonical["word_count"] = int(word_count)
            except Exception:
                canonical["word_count"] = -1

        return canonical


# -----------------------------------------------------------------------------
# JSON / CLI integration helpers
# -----------------------------------------------------------------------------

def load_json(path: Path) -> Any:
    path = Path(path)
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def save_json(payload: Any, path: Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2, ensure_ascii=False)


def output_name_for(parsed_json: Path) -> str:
    stem = Path(parsed_json).stem
    if stem.endswith("_parsed"):
        stem = stem[:-7]
    return f"{stem}_metadata.json"


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Watson PRD-aligned 15-field metadata extractor. "
            "Consumes ParsedDocument JSON and optionally attaches real PII/HITL outputs."
        )
    )
    parser.add_argument("parsed_json", help="Parser output JSON (ParsedDocument)")
    parser.add_argument(
        "--pii-json",
        help="Optional PII detector output JSON to populate pii_assessment",
    )
    parser.add_argument(
        "--hitl-json",
        help=(
            "Optional REAL HITL review output JSON. This does not implement or mock HITL; "
            "it only consumes the future component's reviewed metadata fields."
        ),
    )
    parser.add_argument(
        "--vocab-json",
        help="Optional controlled-vocabulary JSON for brands/indications/TA/geography",
    )
    parser.add_argument(
        "--output-dir",
        default="metadata",
        help="Output directory (default: metadata)",
    )
    parser.add_argument(
        "--print-record",
        action="store_true",
        help="Print the generated 15-field metadata record",
    )
    parser.add_argument(
        "--print-validation",
        action="store_true",
        help="Print schema/readiness validation",
    )
    return parser


def main() -> int:
    args = build_arg_parser().parse_args()

    parsed_path = Path(args.parsed_json)
    parsed_document = load_json(parsed_path)

    extractor = MetadataExtractor(
        vocabulary_path=Path(args.vocab_json) if args.vocab_json else None
    )

    pii_output = load_json(Path(args.pii_json)) if args.pii_json else None
    record = extractor.build_from_parsed_document(
        parsed_document,
        pii_output=pii_output,
    )

    if args.hitl_json:
        review_payload = load_json(Path(args.hitl_json))
        record = extractor.apply_hitl_review(record, review_payload)

    validation = extractor.validate(record)

    output_path = Path(args.output_dir) / output_name_for(parsed_path)
    save_json(record, output_path)

    print(f"Metadata record saved: {output_path}")

    if args.print_record:
        print(json.dumps(record, indent=2, ensure_ascii=False))

    if args.print_validation:
        print(json.dumps(validation, indent=2, ensure_ascii=False))

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
