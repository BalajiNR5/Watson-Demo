"""Recoverable file commits for the single-worker local ingestion service."""
from __future__ import annotations

from functools import wraps
import json
import os
from pathlib import Path
import shutil
import tempfile
import threading
import uuid
import zipfile

LOCK = threading.RLock()


def serialized(function):
    @wraps(function)
    def wrapped(*args, **kwargs):
        with LOCK:
            return function(*args, **kwargs)
    return wrapped


def json_bytes(value):
    return json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False).encode("utf-8")


def atomic_write(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if data is None:
        path.unlink(missing_ok=True)
        return
    descriptor, name = tempfile.mkstemp(prefix=".watson-", dir=path.parent)
    try:
        with os.fdopen(descriptor, "wb") as output:
            output.write(data)
            output.flush()
            os.fsync(output.fileno())
        os.replace(name, path)
    finally:
        Path(name).unlink(missing_ok=True)


def _restore(folder, root):
    manifest = json.loads((folder / "manifest.json").read_text(encoding="utf-8"))
    for entry in reversed(manifest):
        target = (root / entry["path"]).resolve()
        if not target.is_relative_to(root):
            raise ValueError("Invalid ingestion recovery path")
        data = (folder / entry["backup"]).read_bytes() if entry["backup"] else None
        atomic_write(target, data)


def recover_transactions(root, staging):
    root = Path(root).resolve()
    journal = Path(staging) / ".transactions"
    with LOCK:
        if not journal.exists():
            return
        for folder in sorted(journal.iterdir()):
            if not folder.is_dir():
                continue
            if (folder / "manifest.json").exists() and not (folder / "COMMITTED").exists():
                _restore(folder, root)
            shutil.rmtree(folder)


def commit_files(changes, root, staging):
    root = Path(root).resolve()
    with LOCK:
        folder = Path(staging) / ".transactions" / uuid.uuid4().hex
        folder.mkdir(parents=True)
        manifest = []
        restored = False
        try:
            for index, path in enumerate(changes):
                path = Path(path).resolve()
                relative = path.relative_to(root)
                backup = f"{index}.bak" if path.exists() else None
                if backup:
                    (folder / backup).write_bytes(path.read_bytes())
                manifest.append({"path": str(relative), "backup": backup})
            atomic_write(folder / "manifest.json", json_bytes(manifest))
            try:
                for path, data in changes.items():
                    atomic_write(path, data)
                atomic_write(folder / "COMMITTED", b"committed")
            except BaseException:
                _restore(folder, root)
                restored = True
                raise
        finally:
            # An interrupted process leaves the journal for next-start recovery.
            # A failed rollback must also retain its manifest and backups.
            if restored or (folder / "COMMITTED").exists() or not (folder / "manifest.json").exists():
                shutil.rmtree(folder, ignore_errors=True)


def normalize_stage(value):
    value = json.loads(json.dumps(value))
    metadata = value.setdefault("metadata", {})
    expiry = metadata.get("expiry_date")
    if isinstance(expiry, dict):
        metadata.setdefault("retention_days", expiry.get("retention_days"))
        metadata["expiry_date"] = expiry.get("expiry_date")
    return value


def repair_legacy_dates(root, staging, lifecycle):
    """Flatten the known old date-object shape, with an untouched backup first."""
    from datetime import date
    root = Path(root).resolve()
    changes = {}

    def fix(record):
        expiry = record.get("expiry_date")
        if not isinstance(expiry, dict) or not isinstance(expiry.get("expiry_date"), str):
            return False
        try:
            date.fromisoformat(expiry["expiry_date"])
        except ValueError:
            return False
        record["expiry_date"] = expiry["expiry_date"]
        if isinstance(expiry.get("retention_days"), int):
            record["retention_days"] = expiry["retention_days"]
        return True

    with LOCK:
        for path in Path(staging).glob("*_staged.json"):
            try:
                value = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                # Preserve an incomplete old file; re-upload can replace that attempt.
                continue
            changed = fix(value)
            if isinstance(value.get("metadata"), dict):
                changed = fix(value["metadata"]) or changed
            if changed:
                changes[path] = json_bytes(value)
        lifecycle = Path(lifecycle)
        if lifecycle.exists():
            value = json.loads(lifecycle.read_text(encoding="utf-8"))
            changed = False
            for record in value.values():
                if isinstance(record, dict):
                    changed = fix(record) or changed
            if changed:
                changes[lifecycle] = json_bytes(value)
        if changes:
            backup = lifecycle.parent / "migration_backups" / ("ingestion-dates-" + uuid.uuid4().hex + ".zip")
            backup.parent.mkdir(parents=True, exist_ok=True)
            with zipfile.ZipFile(backup, "w", zipfile.ZIP_DEFLATED) as archive:
                for path in changes:
                    archive.writestr(str(Path(path).relative_to(root)), Path(path).read_bytes())
            commit_files(changes, root, staging)
    return len(changes)
