# dedup_detector.py

import os
import json
import hashlib
import re
import datetime
from typing import Dict, Any, Tuple, Optional
from difflib import SequenceMatcher

DEDUP_STORE_PATH = "dedup_store.json"
AUDIT_LOG_PATH = "audit_log.jsonl"

def normalize_date_string(date_str: Optional[str]) -> str:
    """
    Normalizes ISO timestamps (e.g. '2026-09-27T08:32:04.946314+00:00')
    and PDF metadata date strings (e.g. 'D:20200731115439+05'30'') into a
    comparable 14-digit YYYYMMDDHHMMSS string for chronological versioning.
    """
    if not date_str:
        return ""
    if date_str.startswith("D:"):
        digits = re.sub(r'\D', '', date_str[2:])
        return digits[:14].ljust(14, '0')
    digits = re.sub(r'\D', '', date_str)
    return digits[:14].ljust(14, '0')

def load_dedup_store(store_path: str = DEDUP_STORE_PATH) -> Dict[str, Any]:
    """Loads or initializes the central deduplication registry store."""
    if os.path.exists(store_path):
        try:
            with open(store_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except (OSError, ValueError) as exc:
            raise ValueError(f"Cannot read deduplication registry {store_path}: {exc}") from exc
    return {"exact_hashes": {}, "title_registry": []}

def save_dedup_store(store_data: Dict[str, Any], store_path: str = DEDUP_STORE_PATH) -> None:
    """Saves updated deduplication registry to JSON file."""
    os.makedirs(os.path.dirname(store_path) or ".", exist_ok=True)
    with open(store_path, "w", encoding="utf-8") as f:
        json.dump(store_data, f, indent=2)

def log_audit_event(event_type: str, doc_uri: Optional[str], details: Dict[str, Any], audit_path: str = AUDIT_LOG_PATH) -> None:
    """Appends an operational event record to audit_log.jsonl."""
    os.makedirs(os.path.dirname(audit_path) or ".", exist_ok=True)
    record = {
        "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "event_type": event_type,
        "document_uri": doc_uri,
        "details": details
    }
    with open(audit_path, "a", encoding="utf-8") as f:
        f.write(json.dumps(record) + "\n")

def compute_sha256(text: str) -> str:
    """Computes SHA-256 checksum of raw document text."""
    return hashlib.sha256(text.encode("utf-8")).hexdigest()

def _load_referenced_text(entry: Dict[str, Any], parsed_artifact_dir: Optional[str]) -> str:
    reference = entry.get("parsed_artifact")
    candidates = []
    if reference:
        candidates.append(reference)
        if parsed_artifact_dir and not os.path.isabs(reference):
            candidates.append(os.path.join(parsed_artifact_dir, reference))
    if parsed_artifact_dir and entry.get("document_uri"):
        candidates.append(os.path.join(parsed_artifact_dir, f"{entry['document_uri'].split(':')[-1]}_parsed.json"))
    for candidate in candidates:
        try:
            with open(candidate, "r", encoding="utf-8") as handle:
                value = json.load(handle)
                return str(value.get("raw_text", ""))
        except (OSError, ValueError, TypeError):
            continue
    return ""

def check_deduplication(
    parsed_doc: Dict[str, Any],
    store_path: str = DEDUP_STORE_PATH,
    audit_path: str = AUDIT_LOG_PATH,
    parsed_artifact_dir: Optional[str] = None,
    register: bool = True,
    store_override: Optional[Dict[str, Any]] = None,
) -> Tuple[str, Dict[str, Any]]:
    """
    3-tier deduplication & version check strictly calibrated to the
    ParsedDocument JSON snapshot schema.
    """
    store = store_override if store_override is not None else load_dedup_store(store_path)

    # 1. Extract fields supporting both root level and extracted_metadata
    meta = parsed_doc.get("extracted_metadata", {})
    doc_uri = parsed_doc.get("document_uri") or meta.get("document_uri")
    source_filename = parsed_doc.get("source_filename") or meta.get("source_filename", "")
    raw_text = parsed_doc.get("raw_text", "")

    file_title = (
        meta.get("extracted_title")
        or meta.get("file_title")
        or os.path.splitext(source_filename)[0]
    )
    file_author = meta.get("extracted_author") or meta.get("file_author")

    # Raw date string extraction & normalization
    raw_date = (
        meta.get("extracted_date") or
        meta.get("creation_date") or
        meta.get("created_date") or
        meta.get("ingest_timestamp") or
        datetime.datetime.now(datetime.timezone.utc).isoformat()
    )
    norm_date = normalize_date_string(raw_date)
    first_200_hash = compute_sha256(raw_text[:200])

    # --------------------------------------------------------
    # Tier 1: Exact Duplicate Detection (SHA-256 Hash)
    # --------------------------------------------------------
    raw_hash = compute_sha256(raw_text)
    if raw_hash in store.get("exact_hashes", {}):
        original = store["exact_hashes"][raw_hash]
        orig_uri = original.get("document_uri")

        details = {
            "result": "EXACT_DUPLICATE",
            "action": "REJECTED",
            "reason": "exact_duplicate",
            "original_document_uri": orig_uri,
            "sha256_hash": raw_hash
        }
        log_audit_event("DEDUP_HIT", doc_uri, details, audit_path)
        return "EXACT_DUPLICATE", details

    # --------------------------------------------------------
    # Tier 2 & 3: Version Detection & Near-Duplicate Check
    # --------------------------------------------------------
    filename_base = os.path.splitext(source_filename)[0].lower()

    for entry in store.get("title_registry", []):
        entry_title = (entry.get("title") or "").lower()
        entry_filename = os.path.splitext(entry.get("filename", ""))[0].lower()
        entry_author = entry.get("author")
        entry_first_200_hash = entry.get("first_200_hash") or entry.get("first_200_chars_hash", "")
        entry_uri = entry.get("document_uri")
        entry_norm_date = entry.get("norm_date", "")

        # Scoped comparison rule: match title, filename base, or first 200 chars
        same_scope = (
            (file_title and entry_title and file_title.lower() == entry_title)
            or (filename_base and entry_filename and filename_base == entry_filename)
        ) and first_200_hash == entry_first_200_hash

        # --- Tier 2: Version Detection ---
        if (
            entry.get("lifecycle_state") == "ACTIVE"
            and file_title
            and entry_title
            and file_title.lower() == entry_title
            and file_author
            and entry_author
            and file_author.lower() == entry_author.lower()
            and norm_date
            and entry_norm_date
            and norm_date > entry_norm_date
        ):
            details = {
                "result": "NEW_VERSION",
                "action": "HOLD_UNDER_REVIEW",
                "reason": "new_version - HITL review must decide whether to archive the old active document",
                "original_document_uri": entry_uri,
                "new_creation_date": raw_date,
                "old_creation_date": entry.get("raw_date", "")
            }
            log_audit_event("DEDUP_CHECK", doc_uri, details, audit_path)
            return "NEW_VERSION", details

        # --- Tier 3: Near-Duplicate Detection ---
        # Candidate scope is deliberately restricted before comparing full text.
        entry_text = _load_referenced_text(entry, parsed_artifact_dir)
        if same_scope and entry_text:
            ratio = SequenceMatcher(None, raw_text, entry_text).ratio()
            if ratio > 0.85:
                details = {
                    "result": "NEAR_DUPLICATE",
                    "action": "HOLD_UNDER_REVIEW",
                    "reason": "near_duplicate - please verify.",
                    "original_document_uri": entry_uri,
                    "similarity_ratio": round(ratio, 4)
                }
                log_audit_event("DEDUP_CHECK", doc_uri, details, audit_path)
                return "NEAR_DUPLICATE", details

    # --------------------------------------------------------
    # Tier 4: Unique Document Registration
    # --------------------------------------------------------
    if not register:
        return "PASSED_UNIQUE", {"result": "PASSED_UNIQUE", "action": "PROCEED_TO_PII", "sha256_hash": raw_hash}

    store["exact_hashes"][raw_hash] = {
        "document_uri": doc_uri,
        "source_filename": source_filename,
        "title": file_title,
        "author": file_author,
        "date": raw_date,
        "lifecycle_state": parsed_doc.get("lifecycle_state", "DRAFT"),
        "ingest_timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat()
    }

    store.setdefault("title_registry", []).append({
        "document_uri": doc_uri,
        "title": file_title,
        "filename": source_filename,
        "filename_base": filename_base,
        "author": file_author,
        "date": raw_date,
        "raw_date": raw_date,
        "norm_date": norm_date,
        "first_200_hash": first_200_hash,
        "parsed_artifact": parsed_doc.get("parsed_artifact") or "",
        "lifecycle_state": parsed_doc.get("lifecycle_state", "DRAFT"),
    })

    save_dedup_store(store, store_path)

    details = {
        "result": "PASSED_UNIQUE",
        "action": "PROCEED_TO_PII",
        "sha256_hash": raw_hash
    }
    log_audit_event("DEDUP_CHECK", doc_uri, details, audit_path)
    return "PASSED_UNIQUE", details

def update_registry_lifecycle_state(
    document_uri: str,
    lifecycle_state: str,
    store_path: str = DEDUP_STORE_PATH,
) -> bool:
    """Synchronize a registered document's lifecycle state with the lifecycle store."""
    store = load_dedup_store(store_path)
    updated = False
    for entry in store.get("title_registry", []):
        if entry.get("document_uri") == document_uri:
            entry["lifecycle_state"] = lifecycle_state
            updated = True
    for entry in store.get("exact_hashes", {}).values():
        if entry.get("document_uri") == document_uri:
            entry["lifecycle_state"] = lifecycle_state
            updated = True
    if updated:
        save_dedup_store(store, store_path)
    return updated


def detect_duplicates(parsed_document: Dict[str, Any], store_path: str = DEDUP_STORE_PATH) -> Dict[str, Any]:
    """Helper wrapper for pipeline integration returning structured duplicate decision."""
    if "raw_text" not in parsed_document:
        parsed_document["raw_text"] = parsed_document.get("text_content", "")
    res, details = check_deduplication(
        parsed_document,
        store_path=store_path,
    )
    decision = "EXACT_DUPLICATE_REJECT" if res == "EXACT_DUPLICATE" else res
    return {
        "status": res,
        "decision": decision,
        "match_uri": details.get("original_document_uri"),
        "details": details,
    }