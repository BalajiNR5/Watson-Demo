"""
Watson Platform — Databricks Pharmaceuticals Product MVM Dynamic Metadata Ingestor
==================================================================================
Reusable, deterministic ingestion module for the Databricks Lakehouse Industry
Data Model (Industry: Pharmaceuticals, Domain: Product, Flavour: MVM, Version: v1).

Capabilities:
1. Fetches authoritative JSON from GitHub or loads a verified local JSON fixture
   for offline/air-gapped execution.
2. Parses model identity, version, division, domain ('Product'), subdomains
   ('Market Authorization' and 'Product Identity'), products/tables, attributes/
   columns, data types, descriptions, primary keys, and foreign-key relationships.
3. Validates structural schema rules and intra-domain / cross-domain FK endpoints.
4. Enforces idempotency, deduplication, deterministic ordering, and diff tracking
   (added, changed, removed, unchanged products/attributes/relationships).
5. Preserves last-known-good output artifacts if network fetch, JSON parsing, or
   schema validation fails.
"""
from __future__ import annotations

import copy
import datetime
import hashlib
import json
import logging
import os
import tempfile
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from watson.shared.audit import log_audit_event
from watson.shared.config import BASE_DIR, FIXTURES_DATA_DIR

logger = logging.getLogger("watson.ingestion.databricks_metadata")

AUTHORITATIVE_GITHUB_BLOB_URL = (
    "https://github.com/databricks-industry-solutions/lakehouse-industry-data-models/"
    "blob/main/data-models/pharmaceuticals/v1/mvm/model.json"
)
AUTHORITATIVE_RAW_JSON_URL = (
    "https://raw.githubusercontent.com/databricks-industry-solutions/lakehouse-industry-data-models/"
    "main/data-models/pharmaceuticals/v1/mvm/model.json"
)
AUTHORITATIVE_EXPLORER_URL = (
    "https://databricks-industry-solutions.github.io/lakehouse-industry-data-models/"
    "?industry=pharmaceuticals&flavour=mvm"
)

DEFAULT_FIXTURE_PATH = FIXTURES_DATA_DIR / "databricks_pharmaceuticals_v1_mvm_model.json"
OUTPUTS_DIR = BASE_DIR / "outputs"
REPORTS_DIR = BASE_DIR / "reports"

CATALOG_OUTPUT_FILE = OUTPUTS_DIR / "databricks_pharma_product_catalog.json"
SUMMARY_OUTPUT_FILE = OUTPUTS_DIR / "ingestion_summary.json"
INGESTION_REPORT_FILE = REPORTS_DIR / "ingestion_report.md"


class MetadataIngestionError(Exception):
    """Raised when Databricks model metadata fetch, parse, or validation fails."""


def _utc_now() -> str:
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def _atomic_write_json(target_path: Path, data: Dict[str, Any]) -> None:
    target_path.parent.mkdir(parents=True, exist_ok=True)
    raw_bytes = json.dumps(data, indent=2, ensure_ascii=False).encode("utf-8")
    fd, tmp_name = tempfile.mkstemp(prefix=".watson-dbx-", dir=str(target_path.parent))
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(raw_bytes)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp_name, target_path)
    finally:
        Path(tmp_name).unlink(missing_ok=True)


class DatabricksProductMetadataIngestor:
    """
    Deterministic, fault-tolerant ingestion service for Databricks Pharmaceuticals
    Product MVM schema metadata.
    """

    def __init__(
        self,
        catalog_path: Path = CATALOG_OUTPUT_FILE,
        summary_path: Path = SUMMARY_OUTPUT_FILE,
        report_path: Path = INGESTION_REPORT_FILE,
        default_fixture_path: Path = DEFAULT_FIXTURE_PATH,
    ):
        self.catalog_path = Path(catalog_path)
        self.summary_path = Path(summary_path)
        self.report_path = Path(report_path)
        self.default_fixture_path = Path(default_fixture_path)

    def fetch_or_load_source(
        self,
        *,
        source_url: Optional[str] = None,
        fixture_path: Optional[Path | str] = None,
        allow_fixture_fallback: bool = True,
        timeout_seconds: int = 10,
    ) -> Tuple[Dict[str, Any], Dict[str, Any]]:
        """
        Loads source JSON from an explicit local fixture or fetches from the
        authoritative GitHub URL (with optional fallback to local fixture when
        running in an offline/air-gapped environment).
        """
        if fixture_path is not None:
            fpath = Path(fixture_path)
            if not fpath.exists() or not fpath.is_file():
                raise MetadataIngestionError(f"Local fixture file not found: {fpath}")
            try:
                raw_bytes = fpath.read_bytes()
                payload = json.loads(raw_bytes.decode("utf-8"))
            except Exception as exc:
                raise MetadataIngestionError(f"Malformed JSON in local fixture {fpath.name}: {exc}") from exc
            if not isinstance(payload, dict):
                raise MetadataIngestionError("Root of model.json must be a JSON object.")
            return payload, {
                "source_mode": "local_fixture",
                "source_location": str(fpath.name),
                "authoritative_url": AUTHORITATIVE_GITHUB_BLOB_URL,
                "explorer_url": AUTHORITATIVE_EXPLORER_URL,
                "source_sha256": hashlib.sha256(raw_bytes).hexdigest(),
                "fallback_used": False,
            }

        target_url = source_url or AUTHORITATIVE_RAW_JSON_URL
        if target_url == AUTHORITATIVE_GITHUB_BLOB_URL:
            fetch_url = AUTHORITATIVE_RAW_JSON_URL
        else:
            fetch_url = target_url

        try:
            req = urllib.request.Request(
                fetch_url,
                headers={"Accept": "application/json", "User-Agent": "Watson-Metadata-Ingestor/2.0"},
            )
            with urllib.request.urlopen(req, timeout=timeout_seconds) as resp:
                raw_bytes = resp.read()
            payload = json.loads(raw_bytes.decode("utf-8"))
            if not isinstance(payload, dict):
                raise MetadataIngestionError("Remote JSON root is not an object.")
            return payload, {
                "source_mode": "remote_url",
                "source_location": target_url,
                "authoritative_url": AUTHORITATIVE_GITHUB_BLOB_URL,
                "explorer_url": AUTHORITATIVE_EXPLORER_URL,
                "source_sha256": hashlib.sha256(raw_bytes).hexdigest(),
                "fallback_used": False,
            }
        except Exception as remote_exc:
            if not allow_fixture_fallback:
                raise MetadataIngestionError(f"Failed to fetch remote model JSON from {fetch_url}: {remote_exc}") from remote_exc

            if not self.default_fixture_path.exists():
                raise MetadataIngestionError(
                    f"Remote fetch failed ({remote_exc}) and local fixture {self.default_fixture_path} is unavailable."
                ) from remote_exc

            try:
                raw_bytes = self.default_fixture_path.read_bytes()
                payload = json.loads(raw_bytes.decode("utf-8"))
            except Exception as fix_exc:
                raise MetadataIngestionError(f"Local fallback fixture is malformed: {fix_exc}") from fix_exc

            if not isinstance(payload, dict):
                raise MetadataIngestionError("Root of fallback fixture must be a JSON object.")

            return payload, {
                "source_mode": "local_fixture_fallback",
                "source_location": str(self.default_fixture_path.name),
                "authoritative_url": AUTHORITATIVE_GITHUB_BLOB_URL,
                "explorer_url": AUTHORITATIVE_EXPLORER_URL,
                "source_sha256": hashlib.sha256(raw_bytes).hexdigest(),
                "fallback_used": True,
                "remote_error": str(remote_exc),
            }

    def parse_and_validate_product_domain(
        self,
        raw_model: Dict[str, Any],
        target_subdomains: Optional[List[str]] = None,
    ) -> Tuple[Dict[str, Any], Dict[str, Any]]:
        """
        Parses and validates the Pharmaceuticals -> Product -> MVM schema structure.
        Extracts model identity, version, subdomains, products, attributes, keys,
        and intra/cross-domain relationships.
        """
        if not isinstance(raw_model, dict):
            raise MetadataIngestionError("Model payload must be a dictionary.")

        industry = str(raw_model.get("industry") or raw_model.get("model_name") or "").strip()
        if not industry or "pharma" not in industry.lower():
            raise MetadataIngestionError(
                f"Invalid or unexpected industry '{industry}'. Expected 'pharmaceuticals'."
            )

        flavour = str(raw_model.get("flavour") or raw_model.get("model_scope") or "").strip().lower()
        if not flavour or "mvm" not in flavour:
            raise MetadataIngestionError(
                f"Invalid model flavour '{flavour}'. Expected 'mvm' (Minimum Viable Model)."
            )

        version = str(raw_model.get("version") or "v1").strip()

        # Locate 'product' domain from list or dict of domains
        domains_raw = raw_model.get("domains")
        product_domain: Optional[Dict[str, Any]] = None
        if isinstance(domains_raw, list):
            for d in domains_raw:
                if isinstance(d, dict):
                    dname = str(d.get("name") or d.get("domain") or d.get("display_name") or "").strip().lower()
                    if dname == "product":
                        product_domain = d
                        break
        elif isinstance(domains_raw, dict):
            for k, d in domains_raw.items():
                if str(k).strip().lower() == "product" and isinstance(d, dict):
                    product_domain = d
                    break
        elif str(raw_model.get("domain") or "").strip().lower() == "product":
            product_domain = raw_model

        if not product_domain:
            raise MetadataIngestionError("Required 'Product' domain not found in source model JSON.")

        allowed_subdomains = {
            s.strip().lower()
            for s in (target_subdomains or ["market authorization", "product identity"])
        }

        # Collect candidate products from subdomains and/or domain-level products list
        raw_products_map: Dict[str, Dict[str, Any]] = {}
        subdomains_meta: Dict[str, Dict[str, Any]] = {}

        subdomains_raw = product_domain.get("subdomains", {})
        if isinstance(subdomains_raw, dict):
            for sub_key, sub_val in subdomains_raw.items():
                norm_sub = str(sub_key).strip().lower().replace("_", " ")
                if allowed_subdomains and norm_sub not in allowed_subdomains:
                    continue
                if isinstance(sub_val, dict):
                    subdomains_meta[norm_sub] = {
                        "subdomain_id": norm_sub.replace(" ", "_"),
                        "name": norm_sub,
                        "display_name": sub_val.get("display_name") or norm_sub.title(),
                        "description": sub_val.get("description") or f"Product {norm_sub.title()} subdomain.",
                        "products": [],
                    }
                    prods_in_sub = sub_val.get("products", {})
                    if isinstance(prods_in_sub, dict):
                        for pname, pval in prods_in_sub.items():
                            if isinstance(pval, dict):
                                pcopy = dict(pval)
                                pcopy.setdefault("name", pname)
                                pcopy["subdomain"] = norm_sub
                                raw_products_map[pname.strip().lower()] = pcopy
                    elif isinstance(prods_in_sub, list):
                        for pval in prods_in_sub:
                            if isinstance(pval, dict):
                                pname = str(pval.get("name") or pval.get("table_name") or "").strip().lower()
                                if pname:
                                    pcopy = dict(pval)
                                    pcopy["subdomain"] = norm_sub
                                    raw_products_map[pname] = pcopy

        # Also check domain-level products array if present
        domain_prods = product_domain.get("products") or product_domain.get("data_products") or []
        if isinstance(domain_prods, list):
            for pval in domain_prods:
                if not isinstance(pval, dict):
                    continue
                pname = str(pval.get("name") or pval.get("table_name") or "").strip().lower()
                if not pname:
                    continue
                norm_sub = str(pval.get("subdomain") or "").strip().lower().replace("_", " ")
                if allowed_subdomains and norm_sub and norm_sub not in allowed_subdomains:
                    continue
                if pname not in raw_products_map:
                    pcopy = dict(pval)
                    pcopy["subdomain"] = norm_sub or "product identity"
                    raw_products_map[pname] = pcopy
                    if pcopy["subdomain"] not in subdomains_meta:
                        subdomains_meta[pcopy["subdomain"]] = {
                            "subdomain_id": pcopy["subdomain"].replace(" ", "_"),
                            "name": pcopy["subdomain"],
                            "display_name": pcopy["subdomain"].title(),
                            "description": f"Product {pcopy['subdomain'].title()} subdomain.",
                            "products": [],
                        }

        if not raw_products_map:
            raise MetadataIngestionError(
                "No valid products found in 'Market Authorization' or 'Product Identity' subdomains."
            )

        # Normalize & validate products, attributes, and keys
        normalized_products: List[Dict[str, Any]] = []
        all_relationships: List[Dict[str, Any]] = []
        validation_errors: List[str] = []
        validation_warnings: List[str] = []

        # First pass: collect product names and primary keys
        product_pk_lookup: Dict[str, List[str]] = {}
        for pname in sorted(raw_products_map.keys()):
            pdata = raw_products_map[pname]
            pk_raw = pdata.get("primary_key")
            if isinstance(pk_raw, list):
                pks = [str(k).strip() for k in pk_raw if str(k).strip()]
            elif isinstance(pk_raw, str) and pk_raw.strip():
                pks = [pk_raw.strip()]
            else:
                pks = []
            product_pk_lookup[pname] = pks

        seen_rel_keys = set()

        for pname in sorted(raw_products_map.keys()):
            pdata = raw_products_map[pname]
            subdomain_name = str(pdata.get("subdomain") or "product identity").strip().lower()
            desc = str(pdata.get("description") or "").strip()
            pks = product_pk_lookup[pname]

            attrs_raw = pdata.get("attributes") or pdata.get("columns") or []
            if not isinstance(attrs_raw, list) or len(attrs_raw) == 0:
                validation_errors.append(f"Product '{pname}' has no attributes/columns.")
                continue

            seen_attr_names = set()
            norm_attrs: List[Dict[str, Any]] = []
            explicit_fks = pdata.get("foreign_keys") or []
            fk_by_col: Dict[str, Dict[str, Any]] = {}
            if isinstance(explicit_fks, list):
                for fk in explicit_fks:
                    if isinstance(fk, dict) and fk.get("column"):
                        fk_by_col[str(fk["column"]).strip().lower()] = fk

            for attr in attrs_raw:
                if not isinstance(attr, dict):
                    validation_errors.append(f"Invalid non-object attribute in product '{pname}'.")
                    continue
                aname = str(attr.get("name") or "").strip()
                if not aname:
                    validation_errors.append(f"Attribute missing name in product '{pname}'.")
                    continue
                aname_low = aname.lower()
                if aname_low in seen_attr_names:
                    # Deduplicate repeated attribute definitions deterministically
                    continue
                seen_attr_names.add(aname_low)

                dtype = str(attr.get("data_type") or attr.get("type") or "STRING").strip().upper()
                adesc = str(attr.get("description") or "").strip()
                is_pk = bool(attr.get("is_primary_key") or attr.get("pk") or (aname in pks))
                if is_pk and aname not in pks:
                    pks.append(aname)

                fk_entry = fk_by_col.get(aname_low)
                ref_str = str(attr.get("references") or "").strip()
                is_fk = bool(attr.get("is_foreign_key") or attr.get("fk") or fk_entry is not None or bool(ref_str))

                ref_domain = None
                ref_table = None
                ref_col = None

                if fk_entry:
                    ref_table = str(fk_entry.get("referenced_table") or "").strip().lower()
                    ref_domain = str(fk_entry.get("referenced_domain") or "product").strip().lower()
                    if "." in ref_table:
                        ref_domain, ref_table = ref_table.split(".", 1)
                    ref_col = str(fk_entry.get("referenced_column") or f"{ref_table}_id").strip().lower()
                    ref_str = f"{ref_domain}.{ref_table}.{ref_col}"
                elif ref_str:
                    parts = [p.strip().lower() for p in ref_str.split(".") if p.strip()]
                    if len(parts) == 3:
                        ref_domain, ref_table, ref_col = parts
                    elif len(parts) == 2:
                        ref_domain = "product"
                        ref_table, ref_col = parts
                    elif len(parts) == 1:
                        ref_domain = "product"
                        ref_table = parts[0]
                        ref_col = f"{ref_table}_id"

                if is_fk and (not ref_table or not ref_col):
                    validation_errors.append(
                        f"Foreign key attribute '{pname}.{aname}' is missing a valid target endpoint."
                    )

                norm_attr = {
                    "id": f"dbx:attr:product.{pname}.{aname_low}",
                    "name": aname_low,
                    "product_name": pname,
                    "subdomain": subdomain_name,
                    "data_type": dtype,
                    "description": adesc,
                    "is_primary_key": is_pk,
                    "is_foreign_key": is_fk,
                    "classification_tag": str(attr.get("classification_tag") or ("internal" if (is_pk or is_fk) else "public")),
                    "references": ref_str if is_fk else None,
                }
                norm_attrs.append(norm_attr)

                # Record CONTAINS_ATTRIBUTE relationship
                contains_key = ("CONTAINS_ATTRIBUTE", f"product.{pname}", f"product.{pname}.{aname_low}")
                if contains_key not in seen_rel_keys:
                    seen_rel_keys.add(contains_key)
                    all_relationships.append({
                        "id": f"dbx:rel:contains:{pname}:{aname_low}",
                        "relationship_type": "CONTAINS_ATTRIBUTE",
                        "source_id": f"dbx:product:product.{pname}",
                        "source_product": pname,
                        "source_column": None,
                        "target_id": f"dbx:attr:product.{pname}.{aname_low}",
                        "target_domain": "product",
                        "target_product": pname,
                        "target_column": aname_low,
                        "is_intra_domain": True,
                        "endpoint_status": "VALID",
                    })

                if is_fk and ref_table and ref_col:
                    is_intra = (ref_domain == "product")
                    endpoint_status = "VALID"
                    if is_intra:
                        if ref_table not in raw_products_map:
                            endpoint_status = "DANGLING_TARGET_PRODUCT"
                            validation_errors.append(
                                f"Dangling intra-domain FK: '{pname}.{aname_low}' references missing product 'product.{ref_table}'."
                            )
                        else:
                            target_pks = product_pk_lookup.get(ref_table, [])
                            if target_pks and ref_col not in [k.lower() for k in target_pks]:
                                endpoint_status = "TARGET_COLUMN_NOT_PK"
                                validation_warnings.append(
                                    f"Intra-domain FK '{pname}.{aname_low}' references '{ref_table}.{ref_col}' which is not primary key {target_pks}."
                                )
                    else:
                        endpoint_status = "EXTERNAL_DOMAIN_REFERENCE"

                    fk_rel_key = ("FOREIGN_KEY_TO", f"product.{pname}.{aname_low}", f"{ref_domain}.{ref_table}.{ref_col}")
                    if fk_rel_key not in seen_rel_keys:
                        seen_rel_keys.add(fk_rel_key)
                        all_relationships.append({
                            "id": f"dbx:rel:fk:{pname}.{aname_low}->{ref_domain}.{ref_table}.{ref_col}",
                            "relationship_type": "FOREIGN_KEY_TO",
                            "constraint_name": f"fk_{pname}_{aname_low}",
                            "source_id": f"dbx:product:product.{pname}",
                            "source_attribute_id": f"dbx:attr:product.{pname}.{aname_low}",
                            "source_product": pname,
                            "source_column": aname_low,
                            "target_id": f"dbx:product:{ref_domain}.{ref_table}",
                            "target_attribute_id": f"dbx:attr:{ref_domain}.{ref_table}.{ref_col}",
                            "target_domain": ref_domain,
                            "target_product": ref_table,
                            "target_column": ref_col,
                            "is_intra_domain": is_intra,
                            "endpoint_status": endpoint_status,
                        })

            if not pks:
                validation_errors.append(f"Product '{pname}' is missing a primary key definition.")
            else:
                attr_names_set = {a["name"] for a in norm_attrs}
                for pk_col in pks:
                    if pk_col.lower() not in attr_names_set:
                        validation_errors.append(
                            f"Primary key column '{pk_col}' not found in attributes of product '{pname}'."
                        )

            prod_record = {
                "id": f"dbx:product:product.{pname}",
                "name": pname,
                "qualified_name": f"product.{pname}",
                "domain": "product",
                "subdomain": subdomain_name,
                "description": desc,
                "primary_key": pks,
                "attribute_count": len(norm_attrs),
                "foreign_key_count": sum(1 for a in norm_attrs if a["is_foreign_key"]),
                "intra_domain_fk_count": sum(
                    1 for r in all_relationships
                    if r["relationship_type"] == "FOREIGN_KEY_TO" and r["source_product"] == pname and r["is_intra_domain"]
                ),
                "cross_domain_fk_count": sum(
                    1 for r in all_relationships
                    if r["relationship_type"] == "FOREIGN_KEY_TO" and r["source_product"] == pname and not r["is_intra_domain"]
                ),
                "attributes": norm_attrs,
            }
            normalized_products.append(prod_record)
            if subdomain_name in subdomains_meta:
                subdomains_meta[subdomain_name]["products"].append(pname)

        if validation_errors:
            raise MetadataIngestionError(
                f"Schema validation failed with {len(validation_errors)} error(s): " + "; ".join(validation_errors[:5])
            )

        fk_relationships = [r for r in all_relationships if r["relationship_type"] == "FOREIGN_KEY_TO"]
        contains_relationships = [r for r in all_relationships if r["relationship_type"] == "CONTAINS_ATTRIBUTE"]
        intra_fks = [r for r in fk_relationships if r["is_intra_domain"]]
        cross_fks = [r for r in fk_relationships if not r["is_intra_domain"]]

        # Compute deterministic catalog fingerprint over canonical schema content
        canonical_payload = {
            "industry": "pharmaceuticals",
            "domain": "product",
            "flavour": "mvm",
            "version": version,
            "products": normalized_products,
            "foreign_keys": fk_relationships,
        }
        catalog_fingerprint = hashlib.sha256(
            json.dumps(canonical_payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
        ).hexdigest()

        catalog = {
            "schema_version": "1.0.0",
            "catalog_id": f"databricks_pharmaceuticals_product_mvm_{version}",
            "catalog_fingerprint_sha256": catalog_fingerprint,
            "model_identity": {
                "model_name": raw_model.get("model_name") or "Pharmaceuticals",
                "industry": "pharmaceuticals",
                "division": product_domain.get("division") or "Business",
                "division_type": product_domain.get("division_type") or "BIZ",
                "domain": "product",
                "domain_display_name": product_domain.get("display_name") or "Product",
                "flavour": "mvm",
                "version": version,
                "description": product_domain.get("description") or raw_model.get("description") or "",
            },
            "subdomains": list(subdomains_meta.values()),
            "counts": {
                "subdomains_count": len(subdomains_meta),
                "products_count": len(normalized_products),
                "attributes_count": sum(p["attribute_count"] for p in normalized_products),
                "primary_keys_count": sum(len(p["primary_key"]) for p in normalized_products),
                "foreign_keys_total": len(fk_relationships),
                "intra_domain_foreign_keys": len(intra_fks),
                "cross_domain_foreign_keys": len(cross_fks),
                "contains_attribute_edges": len(contains_relationships),
                "total_schema_relationships": len(all_relationships),
            },
            "products": normalized_products,
            "relationships": {
                "foreign_keys": fk_relationships,
                "contains_attribute": contains_relationships,
            },
        }

        validation_summary = {
            "valid": True,
            "errors_count": 0,
            "warnings_count": len(validation_warnings),
            "warnings": validation_warnings,
            "checks_performed": [
                "root_json_object_check",
                "industry_pharmaceuticals_check",
                "flavour_mvm_check",
                "domain_product_presence_check",
                "subdomains_membership_check",
                "non_empty_products_and_attributes_check",
                "primary_key_existence_in_attributes_check",
                "intra_domain_foreign_key_endpoint_integrity_check",
                "duplicate_product_and_attribute_deduplication_check",
            ],
        }
        return catalog, validation_summary

    def compute_diff(
        self,
        previous_catalog: Optional[Dict[str, Any]],
        new_catalog: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Computes product, attribute, and relationship diff against previous catalog."""
        if not previous_catalog or "products" not in previous_catalog:
            return {
                "is_initial_ingest": True,
                "previous_version": None,
                "new_version": new_catalog["model_identity"]["version"],
                "catalog_changed": True,
                "products": {
                    "added": [p["name"] for p in new_catalog["products"]],
                    "changed": [],
                    "removed": [],
                    "unchanged": [],
                    "added_count": len(new_catalog["products"]),
                    "changed_count": 0,
                    "removed_count": 0,
                    "unchanged_count": 0,
                },
                "attributes": {
                    "added_count": new_catalog["counts"]["attributes_count"],
                    "changed_count": 0,
                    "removed_count": 0,
                    "unchanged_count": 0,
                    "added_items": [],
                },
                "foreign_keys": {
                    "added_count": new_catalog["counts"]["foreign_keys_total"],
                    "removed_count": 0,
                    "unchanged_count": 0,
                },
            }

        prev_prods = {p["name"]: p for p in previous_catalog.get("products", [])}
        new_prods = {p["name"]: p for p in new_catalog.get("products", [])}

        p_added = sorted(set(new_prods) - set(prev_prods))
        p_removed = sorted(set(prev_prods) - set(new_prods))
        p_changed = []
        p_unchanged = []

        attr_added = []
        attr_removed = []
        attr_changed = []
        attr_unchanged_count = 0

        for pname in sorted(set(new_prods) & set(prev_prods)):
            old_p = prev_prods[pname]
            new_p = new_prods[pname]
            old_attrs = {a["name"]: a for a in old_p.get("attributes", [])}
            new_attrs = {a["name"]: a for a in new_p.get("attributes", [])}

            a_add = sorted(set(new_attrs) - set(old_attrs))
            a_rem = sorted(set(old_attrs) - set(new_attrs))
            for an in a_add:
                attr_added.append(f"{pname}.{an}")
            for an in a_rem:
                attr_removed.append(f"{pname}.{an}")

            prod_modified = bool(a_add or a_rem or old_p.get("description") != new_p.get("description"))
            for an in sorted(set(new_attrs) & set(old_attrs)):
                oa = old_attrs[an]
                na = new_attrs[an]
                if oa.get("data_type") != na.get("data_type") or oa.get("description") != na.get("description") or oa.get("references") != na.get("references"):
                    attr_changed.append(f"{pname}.{an}")
                    prod_modified = True
                else:
                    attr_unchanged_count += 1

            if prod_modified:
                p_changed.append(pname)
            else:
                p_unchanged.append(pname)

        for pname in p_added:
            for a in new_prods[pname].get("attributes", []):
                attr_added.append(f"{pname}.{a['name']}")
        for pname in p_removed:
            for a in prev_prods[pname].get("attributes", []):
                attr_removed.append(f"{pname}.{a['name']}")

        prev_fks = {r["id"] for r in previous_catalog.get("relationships", {}).get("foreign_keys", [])}
        new_fks = {r["id"] for r in new_catalog.get("relationships", {}).get("foreign_keys", [])}

        return {
            "is_initial_ingest": False,
            "previous_version": previous_catalog.get("model_identity", {}).get("version"),
            "new_version": new_catalog["model_identity"]["version"],
            "catalog_changed": previous_catalog.get("catalog_fingerprint_sha256") != new_catalog["catalog_fingerprint_sha256"],
            "products": {
                "added": p_added,
                "changed": p_changed,
                "removed": p_removed,
                "unchanged": p_unchanged,
                "added_count": len(p_added),
                "changed_count": len(p_changed),
                "removed_count": len(p_removed),
                "unchanged_count": len(p_unchanged),
            },
            "attributes": {
                "added_count": len(attr_added),
                "changed_count": len(attr_changed),
                "removed_count": len(attr_removed),
                "unchanged_count": attr_unchanged_count,
                "added_items": attr_added,
                "changed_items": attr_changed,
                "removed_items": attr_removed,
            },
            "foreign_keys": {
                "added_count": len(new_fks - prev_fks),
                "removed_count": len(prev_fks - new_fks),
                "unchanged_count": len(new_fks & prev_fks),
            },
        }

    def ingest(
        self,
        *,
        source_url: Optional[str] = None,
        fixture_path: Optional[Path | str] = None,
        allow_fixture_fallback: bool = True,
        actor_id: str = "D4",
        write_report: bool = True,
    ) -> Dict[str, Any]:
        """
        Executes the full dynamic metadata ingestion workflow:
        Fetch/Load -> Parse & Validate -> Diff against LKG -> Atomically Commit Outputs -> Audit.
        Preserves last-known-good artifacts if any validation or I/O step fails.
        """
        ingested_at = _utc_now()
        previous_catalog: Optional[Dict[str, Any]] = None
        if self.catalog_path.exists():
            try:
                previous_catalog = json.loads(self.catalog_path.read_text(encoding="utf-8"))
            except Exception:
                previous_catalog = None

        try:
            raw_model, provenance = self.fetch_or_load_source(
                source_url=source_url,
                fixture_path=fixture_path,
                allow_fixture_fallback=allow_fixture_fallback,
            )
            catalog, validation = self.parse_and_validate_product_domain(raw_model)
            diff_summary = self.compute_diff(previous_catalog, catalog)

            provenance["ingested_at_utc"] = ingested_at
            provenance["ingested_by"] = actor_id
            catalog["provenance"] = provenance
            catalog["validation"] = validation
            catalog["last_refresh_diff"] = diff_summary

            summary_payload = {
                "status": "SUCCESS",
                "ingested_at_utc": ingested_at,
                "actor_id": actor_id,
                "model_identity": catalog["model_identity"],
                "provenance": provenance,
                "counts": catalog["counts"],
                "subdomain_breakdown": [
                    {
                        "subdomain": s["name"],
                        "display_name": s["display_name"],
                        "products_count": len(s["products"]),
                        "products": s["products"],
                        "attributes_count": sum(
                            p["attribute_count"] for p in catalog["products"] if p["subdomain"] == s["name"]
                        ),
                        "foreign_keys_count": sum(
                            p["foreign_key_count"] for p in catalog["products"] if p["subdomain"] == s["name"]
                        ),
                    }
                    for s in catalog["subdomains"]
                ],
                "validation": validation,
                "diff": diff_summary,
                "artifacts": {
                    "catalog_path": str(self.catalog_path.relative_to(BASE_DIR)) if self.catalog_path.is_relative_to(BASE_DIR) else str(self.catalog_path),
                    "summary_path": str(self.summary_path.relative_to(BASE_DIR)) if self.summary_path.is_relative_to(BASE_DIR) else str(self.summary_path),
                    "report_path": str(self.report_path.relative_to(BASE_DIR)) if self.report_path.is_relative_to(BASE_DIR) else str(self.report_path),
                },
            }

            # Atomically write catalog and summary
            _atomic_write_json(self.catalog_path, catalog)
            _atomic_write_json(self.summary_path, summary_payload)

            if write_report:
                self._write_markdown_report(catalog, summary_payload)

            log_audit_event(
                event_type="DATABRICKS_METADATA_INGEST",
                user_id=actor_id,
                message=(
                    f"Ingested Databricks Pharmaceuticals Product MVM ({catalog['model_identity']['version']}): "
                    f"{catalog['counts']['products_count']} products, {catalog['counts']['attributes_count']} attributes, "
                    f"{catalog['counts']['foreign_keys_total']} FKs."
                ),
                metadata={
                    "version": catalog["model_identity"]["version"],
                    "source_mode": provenance["source_mode"],
                    "products_count": catalog["counts"]["products_count"],
                    "attributes_count": catalog["counts"]["attributes_count"],
                    "foreign_keys_total": catalog["counts"]["foreign_keys_total"],
                    "catalog_changed": diff_summary["catalog_changed"],
                },
            )
            return summary_payload

        except Exception as exc:
            log_audit_event(
                event_type="DATABRICKS_METADATA_INGEST",
                user_id=actor_id,
                message=f"Databricks metadata ingestion failed (last-known-good preserved): {exc}",
                metadata={"status": "FAILED", "error": str(exc), "lkg_preserved": self.catalog_path.exists()},
            )
            if isinstance(exc, MetadataIngestionError):
                raise
            raise MetadataIngestionError(f"Unexpected ingestion error: {exc}") from exc

    def _write_markdown_report(self, catalog: Dict[str, Any], summary: Dict[str, Any]) -> None:
        self.report_path.parent.mkdir(parents=True, exist_ok=True)
        ident = catalog["model_identity"]
        counts = catalog["counts"]
        prov = catalog["provenance"]
        val = catalog["validation"]
        diff = summary["diff"]

        lines = [
            "# Databricks Pharmaceuticals Product MVM — Dynamic Metadata Ingestion Report",
            "",
            "## 1. Model Identity & Provenance",
            "",
            "| Field | Verified Value |",
            "| :--- | :--- |",
            f"| **Industry** | `{ident['industry']}` ({ident['model_name']}) |",
            f"| **Division** | `{ident['division']}` (`{ident['division_type']}`) |",
            f"| **Domain** | `{ident['domain']}` ({ident['domain_display_name']}) |",
            f"| **Flavour** | `{ident['flavour']}` (Minimum Viable Model) |",
            f"| **Model Version** | `{ident['version']}` |",
            f"| **Authoritative Source URL** | `{prov['authoritative_url']}` |",
            f"| **Model Explorer URL** | `{prov['explorer_url']}` |",
            f"| **Ingestion Source Mode** | `{prov['source_mode']}` (`{prov['source_location']}`) |",
            f"| **Source SHA-256** | `{prov['source_sha256']}` |",
            f"| **Catalog Fingerprint SHA-256** | `{catalog['catalog_fingerprint_sha256']}` |",
            f"| **Ingested Timestamp (UTC)** | `{prov['ingested_at_utc']}` |",
            f"| **Ingested By (Actor ID)** | `{prov['ingested_by']}` |",
            "",
            "## 2. Extracted Counts Summary",
            "",
            "| Metric | Extracted Count |",
            "| :--- | ---: |",
            f"| **Subdomains Included** | {counts['subdomains_count']} |",
            f"| **Data Products (Tables)** | {counts['products_count']} |",
            f"| **Total Attributes (Columns)** | {counts['attributes_count']} |",
            f"| **Primary Keys** | {counts['primary_keys_count']} |",
            f"| **Total Foreign Keys** | {counts['foreign_keys_total']} |",
            f"| **Intra-Domain Foreign Keys (`product.*`)** | {counts['intra_domain_foreign_keys']} |",
            f"| **Cross-Domain Foreign Keys (`masterdata.*`, `intellectual.*`, etc.)** | {counts['cross_domain_foreign_keys']} |",
            f"| **`CONTAINS_ATTRIBUTE` Edges** | {counts['contains_attribute_edges']} |",
            f"| **Total Schema Graph Edges** | {counts['total_schema_relationships']} |",
            "",
            "## 3. Subdomain Breakdown",
            "",
            "| Subdomain | Products Count | Attributes Count | Foreign Keys Count | Member Products |",
            "| :--- | ---: | ---: | ---: | :--- |",
        ]
        for sb in summary["subdomain_breakdown"]:
            prods_str = ", ".join(f"`{p}`" for p in sb["products"])
            lines.append(
                f"| **{sb['display_name']}** (`{sb['subdomain']}`) | {sb['products_count']} | {sb['attributes_count']} | {sb['foreign_keys_count']} | {prods_str} |"
            )

        lines.extend([
            "",
            "## 4. Product Catalog Inventory",
            "",
            "| Product (Table) | Subdomain | Primary Key | Attributes | Total FKs | Intra-Domain FKs | Cross-Domain FKs | Description |",
            "| :--- | :--- | :--- | ---: | ---: | ---: | ---: | :--- |",
        ])
        for p in catalog["products"]:
            pk_str = ", ".join(f"`{k}`" for k in p["primary_key"])
            short_desc = p["description"][:110] + ("..." if len(p["description"]) > 110 else "")
            lines.append(
                f"| `{p['name']}` | `{p['subdomain']}` | {pk_str} | {p['attribute_count']} | {p['foreign_key_count']} | {p['intra_domain_fk_count']} | {p['cross_domain_fk_count']} | {short_desc} |"
            )

        lines.extend([
            "",
            "## 5. Validation & Integrity Checks",
            "",
            f"- **Validation Status:** `{'PASS' if val['valid'] else 'FAIL'}`",
            f"- **Structural Errors:** `{val['errors_count']}`",
            f"- **Validation Warnings:** `{val['warnings_count']}`",
            "- **Executed Integrity Gates:**",
        ])
        for chk in val["checks_performed"]:
            lines.append(f"  - `{chk}`: **PASS**")

        lines.extend([
            "",
            "## 6. Idempotency & Refresh Diff Status",
            "",
            f"- **Initial Ingest:** `{diff['is_initial_ingest']}`",
            f"- **Catalog Content Changed:** `{diff['catalog_changed']}`",
            f"- **Products Diff:** `{diff['products']['added_count']}` added, `{diff['products']['changed_count']}` changed, `{diff['products']['removed_count']}` removed, `{diff['products']['unchanged_count']}` unchanged",
            f"- **Attributes Diff:** `{diff['attributes']['added_count']}` added, `{diff['attributes']['changed_count']}` changed, `{diff['attributes']['removed_count']}` removed, `{diff['attributes']['unchanged_count']}` unchanged",
            f"- **Foreign Keys Diff:** `{diff['foreign_keys']['added_count']}` added, `{diff['foreign_keys']['removed_count']}` removed, `{diff['foreign_keys']['unchanged_count']}` unchanged",
            "",
        ])

        self.report_path.write_text("\n".join(lines), encoding="utf-8")


if __name__ == "__main__":
    ingestor = DatabricksProductMetadataIngestor()
    res = ingestor.ingest()
    print(json.dumps(res["counts"], indent=2))
