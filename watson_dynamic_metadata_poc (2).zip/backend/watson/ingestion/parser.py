import json
import sys
import re
import zipfile
import shutil
import subprocess
import tempfile
from pathlib import Path
from datetime import datetime, timezone

try:
    from docx import Document
except Exception:
    Document = None

try:
    from pptx import Presentation
except Exception:
    Presentation = None

import pymupdf

try:
    from langdetect import detect
except ImportError:
    detect = None


# ============================================================
# BASIC UTILITIES
# ============================================================

def count_words(text):
    return len(text.split())


def normalize_text(text):
    """
    Normalize extracted text:
    - Normalize line endings
    - Replace tabs and non-breaking spaces
    - Remove extra spaces
    - Keep paragraph separation
    """
    if not text:
        return ""

    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = text.replace("\t", " ")
    text = text.replace("\xa0", " ")

    lines = []

    for line in text.split("\n"):
        line = re.sub(r"[ ]+", " ", line)
        line = line.strip()
        lines.append(line)

    cleaned_lines = []
    previous_blank = False

    for line in lines:
        if line == "":
            if not previous_blank:
                cleaned_lines.append("")
            previous_blank = True
        else:
            cleaned_lines.append(line)
            previous_blank = False

    return "\n".join(cleaned_lines).strip()


def generate_document_uri(document_number):
    return f"watson:Doc_{document_number:03d}"


def split_text_into_blocks(text):
    normalized = normalize_text(text)

    if not normalized:
        return []

    blocks = re.split(r"\n\s*\n+", normalized)
    blocks = [
        normalize_text(block)
        for block in blocks
        if normalize_text(block)
    ]

    return blocks if blocks else [normalized]


def build_pdf_structural_units(pages):
    return [
        {
            "unit_type": "page",
            "unit_index": page.get("page_number", index + 1),
            "text": page.get("text", "")
        }
        for index, page in enumerate(pages)
    ]


def build_docx_structural_units(document):
    units = []
    current = None
    unit_index = 0

    def flush_current():
        nonlocal current
        if current and (
            current.get("text") or current.get("heading")
        ):
            units.append(current)
        current = None

    for paragraph in document.paragraphs:
        text = paragraph.text.strip()
        if not text:
            continue

        style_name = (
            paragraph.style.name
            if getattr(paragraph, "style", None) is not None
            else ""
        )
        heading_match = re.match(
            r"^Heading\s*(\d+)$",
            style_name,
            re.I
        )

        if heading_match:
            flush_current()
            unit_index += 1
            current = {
                "unit_type": "section",
                "unit_index": unit_index,
                "heading_level": f"H{heading_match.group(1)}",
                "heading": text,
                "text": ""
            }
            continue

        if current is None:
            unit_index += 1
            current = {
                "unit_type": "section",
                "unit_index": unit_index,
                "heading_level": None,
                "heading": None,
                "text": ""
            }

        current["text"] = normalize_text(
            "\n\n".join(
                part for part in [
                    current.get("text", ""),
                    text
                ] if part
            )
        )

    for table in document.tables:
        table_text_parts = []

        for row in table.rows:
            row_values = [
                cell.text.strip()
                for cell in row.cells
                if cell.text.strip()
            ]
            if row_values:
                table_text_parts.append(
                    " | ".join(row_values)
                )

        if table_text_parts:
            table_text = normalize_text(
                "\n\n".join(table_text_parts)
            )

            if current is None:
                unit_index += 1
                current = {
                    "unit_type": "section",
                    "unit_index": unit_index,
                    "heading_level": None,
                    "heading": None,
                    "text": ""
                }

            current["text"] = normalize_text(
                "\n\n".join(
                    part for part in [
                        current.get("text", ""),
                        table_text
                    ] if part
                )
            )

    flush_current()

    if not units:
        units = [{
            "unit_type": "section",
            "unit_index": 1,
            "heading_level": None,
            "heading": None,
            "text": ""
        }]

    return units


def build_pptx_structural_units(presentation):
    units = []

    for slide_index, slide in enumerate(
        presentation.slides,
        start=1
    ):
        title = None
        body_parts = []

        if getattr(slide.shapes, "title", None):
            title = slide.shapes.title.text.strip()

        for shape in slide.shapes:
            if not hasattr(shape, "text"):
                continue

            text = shape.text.strip()
            if not text:
                continue

            if getattr(slide.shapes, "title", None) is not None and shape == slide.shapes.title:
                continue

            body_parts.append(text)

        speaker_notes = ""
        notes_slide = getattr(slide, "notes_slide", None)
        if notes_slide is not None:
            note_parts = []
            for note_shape in notes_slide.shapes:
                if hasattr(note_shape, "text"):
                    note_text = note_shape.text.strip()
                    if note_text:
                        note_parts.append(note_text)
            speaker_notes = normalize_text(
                "\n\n".join(note_parts)
            )

        combined_parts = []
        if title:
            combined_parts.append(title)
        if body_parts:
            combined_parts.extend(body_parts)

        slide_text = normalize_text(
            "\n\n".join(combined_parts)
        )

        units.append({
            "unit_type": "slide",
            "unit_index": slide_index,
            "title": title,
            "body": normalize_text("\n\n".join(body_parts)),
            "speaker_notes": speaker_notes,
            "text": slide_text
        })

    return units


def build_txt_structural_units(raw_text):
    blocks = split_text_into_blocks(raw_text)

    return [
        {
            "unit_type": "text_block",
            "unit_index": index + 1,
            "text": block
        }
        for index, block in enumerate(blocks)
    ]


# ============================================================
# LANGUAGE DETECTION
# ============================================================

def detect_language(text):
    if not text or not text.strip():
        return None

    if detect is None:
        return None

    try:
        return detect(text)
    except Exception:
        return None


# ============================================================
# PDF METADATA
# ============================================================

def extract_pdf_metadata(pdf):
    metadata = pdf.metadata or {}

    return {
        "title": metadata.get("title") or None,
        "author": metadata.get("author") or None,
        "creation_date": metadata.get("creationDate") or None
    }


def extract_title(raw_text, pdf_metadata):
    embedded_title = pdf_metadata.get("title")

    if embedded_title:
        return embedded_title.strip()

    for line in raw_text.splitlines():
        line = line.strip()
        if line:
            return line

    return None


def extract_author(pdf_metadata):
    author = pdf_metadata.get("author")

    if author:
        return author.strip()

    return None


# ============================================================
# IMAGE DETECTION
# ============================================================

def detect_page_images(page):
    try:
        images = page.get_images(full=True)
        return len(images)
    except Exception:
        return 0


def detect_docx_images(docx_path):
    try:
        with zipfile.ZipFile(
            docx_path,
            "r"
        ) as archive:
            return len([
                name
                for name in archive.namelist()
                if name.startswith("word/media/")
            ])
    except Exception:
        return 0


def detect_pptx_images(pptx_path):
    try:
        with zipfile.ZipFile(
            pptx_path,
            "r"
        ) as archive:
            return len([
                name
                for name in archive.namelist()
                if name.startswith("ppt/media/")
            ])
    except Exception:
        return 0


# ============================================================
# PDF READING ORDER
# ============================================================

def extract_page_text_in_reading_order(page):
    """
    Extract PDF text in approximate human reading order.
    """
    try:
        blocks = page.get_text("blocks")
    except Exception:
        return ""

    valid_blocks = []

    for block in blocks:
        if len(block) < 5:
            continue

        x0, y0, x1, y1, text = block[:5]

        if not text or not text.strip():
            continue

        valid_blocks.append({
            "x0": x0,
            "y0": y0,
            "x1": x1,
            "y1": y1,
            "text": text
        })

    if not valid_blocks:
        return ""

    valid_blocks.sort(
        key=lambda b: (b["x0"], b["y0"])
    )

    columns = []

    for block in valid_blocks:
        placed = False

        for column in columns:
            column_x0 = min(
                item["x0"]
                for item in column
            )
            column_x1 = max(
                item["x1"]
                for item in column
            )
            overlap = (
                min(block["x1"], column_x1)
                - max(block["x0"], column_x0)
            )
            block_width = max(
                block["x1"] - block["x0"],
                1
            )
            if (
                overlap > 0
                or abs(block["x0"] - column_x1)
                < block_width * 0.25
            ):
                column.append(block)
                placed = True
                break

        if not placed:
            columns.append([block])

    columns.sort(
        key=lambda column:
        min(item["x0"] for item in column)
    )

    ordered_blocks = []

    for column in columns:
        column.sort(
            key=lambda b: b["y0"]
        )
        ordered_blocks.extend(column)

    text_parts = [
        block["text"]
        for block in ordered_blocks
    ]

    return normalize_text(
        "\n\n".join(text_parts)
    )


# ============================================================
# PDF MULTI-COLUMN DETECTION
# ============================================================

def detect_multi_column_warning(page):
    try:
        blocks = page.get_text("blocks")
    except Exception:
        return None

    valid_blocks = []

    for block in blocks:
        if len(block) < 5:
            continue

        x0, y0, x1, y1, text = block[:5]

        if not text or not text.strip():
            continue

        valid_blocks.append(
            (x0, y0, x1, y1, text)
        )

    if len(valid_blocks) < 4:
        return None

    page_width = page.rect.width
    midpoint = page_width / 2

    left_blocks = 0
    right_blocks = 0

    for block in valid_blocks:
        x0, _, x1, _, _ = block
        center_x = (x0 + x1) / 2

        if center_x < midpoint:
            left_blocks += 1
        else:
            right_blocks += 1

    if left_blocks >= 2 and right_blocks >= 2:
        return {
            "type": "POSSIBLE_MULTI_COLUMN_LAYOUT",
            "page": page.number + 1,
            "message": (
                "Page contains text blocks distributed "
                "across multiple columns. Reading order "
                "was approximated."
            )
        }

    return None


# ============================================================
# PDF PAGE WARNINGS
# ============================================================

def detect_page_warnings(
    page,
    page_text,
    image_count
):
    warnings = []

    word_count = count_words(page_text)

    if word_count == 0:
        if image_count > 0:
            warnings.append({
                "type": "SCANNED_PDF",
                "message": (
                    "Page contains image content but no "
                    "extractable text. OCR may be required."
                )
            })
        else:
            warnings.append({
                "type": "EMPTY_PAGE_TEXT",
                "message": (
                    "Page contains no extractable text."
                )
            })

    elif word_count < 10:
        warnings.append({
            "type": "LOW_TEXT_CONTENT",
            "message": (
                "Page contains very little "
                "extractable text."
            )
        })

    if image_count > 0:
        warnings.append({
            "type": "IMAGE_CONTENT_PRESENT",
            "message": (
                f"Page contains {image_count} "
                "embedded image(s)."
            )
        })

    multi_column_warning = (
        detect_multi_column_warning(page)
    )

    if multi_column_warning:
        warnings.append(
            multi_column_warning
        )

    return warnings


# ============================================================
# PDF DOCUMENT METADATA
# ============================================================

def build_pdf_metadata(
    pdf,
    pdf_path,
    raw_text,
    document_number
):
    pdf_metadata = extract_pdf_metadata(pdf)

    return {
        "document_uri": generate_document_uri(
            document_number
        ),
        "source_filename": pdf_path.name,
        "format": "pdf",
        "ingest_timestamp": datetime.now(
            timezone.utc
        ).isoformat(),
        "word_count": count_words(raw_text),
        "extracted_title": extract_title(
            raw_text,
            pdf_metadata
        ),
        "extracted_author": extract_author(
            pdf_metadata
        ),
        "creation_date": pdf_metadata.get(
            "creation_date"
        ),
        "language": detect_language(
            raw_text
        )
    }


# ============================================================
# PDF PARSER
# ============================================================

def parse_pdf(
    pdf_path,
    document_number,
    source_filename=None,
    output_format="pdf"
):
    pdf_path = Path(pdf_path)

    if not pdf_path.exists():
        raise FileNotFoundError(
            f"File not found: {pdf_path}"
        )

    if pdf_path.suffix.lower() != ".pdf":
        raise ValueError(
            f"Not a PDF file: {pdf_path}"
        )

    pdf = pymupdf.open(pdf_path)

    all_text = []
    parse_warnings = []

    # Page-level information
    pages = []
    cumulative_word_count = 0

    try:
        for page_index, page in enumerate(pdf):
            page_number = page_index + 1

            # ----------------------------
            # Extract page text
            # ----------------------------
            page_text = (
                extract_page_text_in_reading_order(
                    page
                )
            )
            all_text.append(page_text)

            page_word_count = count_words(
                page_text
            )

            # ----------------------------
            # Detect images
            # ----------------------------
            image_count = detect_page_images(
                page
            )

            # ----------------------------
            # Detect warnings
            # ----------------------------
            page_warnings = detect_page_warnings(
                page,
                page_text,
                image_count
            )
            parse_warnings.extend(
                page_warnings
            )

            # ----------------------------
            # PAGE SPAN
            # ----------------------------
            page_start = cumulative_word_count + 1
            page_end = cumulative_word_count + page_word_count
            cumulative_word_count += page_word_count

            pages.append({
                "page_number": page_number,
                "text": page_text,
                "word_count": page_word_count,
                "page_span": {
                    "start": page_start,
                    "end": page_end
                }
            })

        # ----------------------------
        # Combine document text
        # ----------------------------
        raw_text = normalize_text(
            "\n\n".join(all_text)
        )

        structural_units = build_pdf_structural_units(pages)

        document_word_count = count_words(
            raw_text
        )

        # ----------------------------
        # Document-level scanned PDF check
        # ----------------------------
        if document_word_count == 0:
            parse_warnings = [
                warning
                for warning in parse_warnings
                if warning.get("type")
                not in [
                    "EMPTY_PAGE_TEXT",
                    "SCANNED_PDF"
                ]
            ]

            has_images = any(
                detect_page_images(page) > 0
                for page in pdf
            )

            if has_images:
                parse_warnings.append({
                    "type": "SCANNED_PDF",
                    "message": (
                        "Document contains no extractable "
                        "text and appears to contain scanned "
                        "image pages. OCR may be required."
                    )
                })

        # ----------------------------
        # Metadata
        # ----------------------------
        extracted_metadata = (
            build_pdf_metadata(
                pdf,
                pdf_path,
                raw_text,
                document_number
            )
        )

        # If this PDF came from DOCX conversion,
        # preserve the original filename and format.
        if source_filename is not None:
            extracted_metadata[
                "source_filename"
            ] = source_filename

            extracted_metadata[
                "format"
            ] = output_format

        return {
            "document_uri":
                generate_document_uri(
                    document_number
                ),
            "source_filename":
                source_filename
                if source_filename
                else pdf_path.name,
            "format": output_format,
            "page_or_slide_count":
                len(pdf),
            "raw_text":
                raw_text,
            "pages":
                pages,
            "structural_units":
                structural_units,
            "extracted_metadata":
                extracted_metadata,
            "parse_warnings":
                parse_warnings
        }

    finally:
        pdf.close()


# ============================================================
# DOCX PARSER
# ============================================================

def parse_docx(
    docx_path,
    document_number
):
    docx_path = Path(docx_path)

    if Document is None:
        raise ImportError(
            "python-docx is not installed.\n"
            "Install it using:\n"
            "pip install python-docx"
        )

    document = Document(docx_path)

    text_parts = []

    for paragraph in document.paragraphs:
        text = paragraph.text.strip()
        if text:
            text_parts.append(text)

    for table in document.tables:
        for row in table.rows:
            row_values = [
                cell.text.strip()
                for cell in row.cells
                if cell.text.strip()
            ]
            if row_values:
                text_parts.append(
                    " | ".join(row_values)
                )

    raw_text = normalize_text(
        "\n\n".join(text_parts)
    )

    structural_units = build_docx_structural_units(document)

    warnings = detect_document_warnings(
        raw_text,
        empty_warning_type="EMPTY_DOCX",
        scanned_warning_type="SCANNED_DOCX",
        format_label="DOCX document"
    )

    core_properties = getattr(
        document,
        "core_properties",
        None
    )

    extracted_metadata = {
        "document_uri":
            generate_document_uri(
                document_number
            ),
        "source_filename":
            docx_path.name,
        "format":
            "docx",
        "ingest_timestamp":
            datetime.now(
                timezone.utc
            ).isoformat(),
        "word_count":
            count_words(raw_text),
        "extracted_title":
            (
                core_properties.title
                if core_properties and core_properties.title
                else docx_path.stem
            ),
        "extracted_author":
            (
                core_properties.author
                if core_properties and core_properties.author
                else None
            ),
        "creation_date":
            (
                core_properties.created.isoformat()
                if core_properties and core_properties.created
                else None
            ),
        "language":
            detect_language(
                raw_text
            )
    }

    word_count = count_words(raw_text)

    page_entry = {
        "page_number": 1,
        "text": raw_text,
        "word_count": word_count,
        "page_span": {
            "start": 1,
            "end": word_count
        }
    }

    return {
        "document_uri":
            generate_document_uri(
                document_number
            ),
        "source_filename":
            docx_path.name,
        "format":
            "docx",
        "page_or_slide_count":
            1,
        "word_count":
            word_count,
        "raw_text":
            raw_text,
        "pages":
            [page_entry],
        "structural_units":
            structural_units,
        "extracted_metadata":
            extracted_metadata,
        "parse_warnings":
            warnings
    }


# ============================================================
# GENERIC DOCUMENT WARNINGS
# ============================================================

def detect_document_warnings(
    raw_text,
    image_count=0,
    empty_warning_type="EMPTY_DOCUMENT",
    scanned_warning_type="SCANNED_DOCUMENT",
    format_label="document"
):
    warnings = []

    word_count = count_words(raw_text)

    if word_count == 0:
        if image_count > 0:
            warnings.append({
                "type":
                    scanned_warning_type,
                "message":
                    (
                        f"{format_label} contains image "
                        "content but no extractable text."
                    )
            })
        else:
            warnings.append({
                "type":
                    empty_warning_type,
                "message":
                    (
                        f"{format_label} contains no "
                        "extractable text."
                    )
            })

    elif word_count < 10:
        warnings.append({
            "type":
                "LOW_TEXT_CONTENT",
            "message":
                (
                    f"{format_label} contains very "
                    "little extractable text."
                )
        })

    if image_count > 0:
        warnings.append({
            "type":
                "IMAGE_CONTENT_PRESENT",
            "message":
                (
                    f"{format_label} contains "
                    f"{image_count} embedded image(s)."
                )
        })

    return warnings


# ============================================================
# PPTX PARSER
# ============================================================

def parse_pptx(
    pptx_path,
    document_number
):
    pptx_path = Path(pptx_path)

    if Presentation is None:
        raise ImportError(
            "python-pptx is not installed.\n"
            "Install it using:\n"
            "pip install python-pptx"
        )

    presentation = Presentation(
        pptx_path
    )

    all_text = []
    warnings = []

    # Slide-level information
    pages = []
    cumulative_word_count = 0
    structural_units = []

    for slide_index, slide in enumerate(
        presentation.slides
    ):
        slide_number = slide_index + 1

        slide_text_parts = []

        for shape in slide.shapes:
            if hasattr(shape, "text"):
                text = shape.text.strip()
                if text:
                    slide_text_parts.append(
                        text
                    )
            if getattr(
                shape,
                "has_table",
                False
            ):
                for row in shape.table.rows:
                    row_text = []
                    for cell in row.cells:
                        cell_text = (
                            cell.text.strip()
                        )
                        if cell_text:
                            row_text.append(
                                cell_text
                            )
                    if row_text:
                        slide_text_parts.append(
                            " | ".join(row_text)
                        )

        slide_text = normalize_text(
            "\n\n".join(
                slide_text_parts
            )
        )

        slide_word_count = count_words(
            slide_text
        )

        all_text.append(
            slide_text
        )

        if not slide_text:
            warnings.append({
                "type":
                    "EMPTY_SLIDE_TEXT",
                "slide":
                    slide_number,
                "message":
                    (
                        "slide contains no "
                        "extractable text."
                    )
            })

        # ----------------------------
        # Slide page span
        # ----------------------------
        slide_start = cumulative_word_count + 1
        slide_end = cumulative_word_count + slide_word_count
        cumulative_word_count += slide_word_count

        pages.append({
            "page_number":
                slide_number,
            "text":
                slide_text,
            "word_count":
                slide_word_count,
            "page_span": {
                "start":
                    slide_start,
                "end":
                    slide_end
            }
        })

        structural_units.append({
            "unit_type": "slide",
            "unit_index": slide_number,
            "title": (
                slide.shapes.title.text.strip()
                if getattr(slide.shapes, "title", None)
                else None
            ),
            "body": normalize_text(
                "\n\n".join(
                    [
                        shape.text.strip()
                        for shape in slide.shapes
                        if hasattr(shape, "text")
                        and shape.text.strip()
                        and not (
                            getattr(slide.shapes, "title", None) is not None
                            and shape == slide.shapes.title
                        )
                    ]
                )
            ),
            "speaker_notes": normalize_text(
                "\n\n".join(
                    note_shape.text.strip()
                    for note_shape in getattr(slide, "notes_slide", slide).shapes
                    if hasattr(note_shape, "text")
                    and note_shape.text.strip()
                )
            ) if getattr(slide, "notes_slide", None) is not None else "",
            "text": slide_text
        })

    raw_text = normalize_text(
        "\n\n".join(all_text)
    )

    image_count = detect_pptx_images(
        pptx_path
    )

    warnings.extend(
        detect_document_warnings(
            raw_text,
            image_count=image_count,
            empty_warning_type="EMPTY_PPTX",
            scanned_warning_type="SCANNED_PPTX",
            format_label="PPTX presentation"
        )
    )

    core_properties = (
        presentation.core_properties
    )

    extracted_metadata = {
        "document_uri":
            generate_document_uri(
                document_number
            ),
        "source_filename":
            pptx_path.name,
        "format":
            "pptx",
        "ingest_timestamp":
            datetime.now(
                timezone.utc
            ).isoformat(),
        "word_count":
            count_words(raw_text),
        "extracted_title":
            (
                core_properties.title
                if core_properties.title
                else None
            ),
        "extracted_author":
            (
                core_properties.author
                if core_properties.author
                else None
            ),
        "creation_date":
            (
                core_properties.created.isoformat()
                if core_properties.created
                else None
            ),
        "language":
            detect_language(
                raw_text
            )
    }

    return {
        "document_uri":
            generate_document_uri(
                document_number
            ),
        "source_filename":
            pptx_path.name,
        "format":
            "pptx",
        "page_or_slide_count":
            len(presentation.slides),
        "word_count":
            count_words(raw_text),
        "raw_text":
            raw_text,
        "pages":
            pages,
        "structural_units":
            structural_units,
        "extracted_metadata":
            extracted_metadata,
        "parse_warnings":
            warnings
    }


# ============================================================
# TXT PARSER
# ============================================================

def parse_txt(
    txt_path,
    document_number
):
    txt_path = Path(txt_path)
    try:
        raw_text = txt_path.read_text(
            encoding="utf-8"
        )
    except UnicodeDecodeError:
        raw_text = txt_path.read_text(
            encoding="latin-1"
        )
    raw_text = normalize_text(
        raw_text
    )
    structural_units = build_txt_structural_units(raw_text)
    warnings = detect_document_warnings(
        raw_text,
        empty_warning_type="EMPTY_TXT",
        scanned_warning_type="SCANNED_TXT",
        format_label="TXT document"
    )

    extracted_metadata = {
        "document_uri":
            generate_document_uri(
                document_number
            ),
        "source_filename":
            txt_path.name,
        "format":
            "txt",
        "ingest_timestamp":
            datetime.now(
                timezone.utc
            ).isoformat(),
        "word_count":
            count_words(raw_text),
        "extracted_title":
            txt_path.stem,
        "extracted_author":
            None,
        "creation_date":
            None,
        "language":
            detect_language(
                raw_text
            )
    }

    word_count = count_words(raw_text)

    page_entry = {
        "page_number": 1,
        "text": raw_text,
        "word_count": word_count,
        "page_span": {
            "start": 1,
            "end": word_count
        }
    }

    return {
        "document_uri":
            generate_document_uri(
                document_number
            ),
        "source_filename":
            txt_path.name,
        "format":
            "txt",
        "page_or_slide_count":
            1,
        "word_count":
            word_count,
        "raw_text":
            raw_text,
        "pages":
            [page_entry],
        "structural_units":
            structural_units,
        "extracted_metadata":
            extracted_metadata,
        "parse_warnings":
            warnings
    }


# ============================================================
# MULTI-FORMAT DISPATCHER
# ============================================================

def parse_document(
    file_path,
    document_number=1
):
    file_path = Path(file_path)
    extension = file_path.suffix.lower()
    if extension == ".pdf":
        return parse_pdf(
            file_path,
            document_number
        )
    elif extension == ".docx":
        return parse_docx(
            file_path,
            document_number
        )
    elif extension == ".pptx":
        return parse_pptx(
            file_path,
            document_number
        )
    elif extension == ".txt":
        return parse_txt(
            file_path,
            document_number
        )
    else:
        raise ValueError(
            f"Unsupported file format: "
            f"{extension}"
        )


# ============================================================
# SAVE JSON
# ============================================================

def save_json(
    parsed_document,
    output_path
):
    with open(
        output_path,
        "w",
        encoding="utf-8"
    ) as file:
        json.dump(
            parsed_document,
            file,
            indent=2,
            ensure_ascii=False
        )


# ============================================================
# PROCESS ONE DOCUMENT
# ============================================================

def process_single_document(
    file_path,
    document_number,
    staging_dir
):
    file_path = Path(file_path)
    # Use the original source filename stem for the
    # output JSON name so files like doc_001.pdf create
    # doc_001_parsed.json and doc_002.pdf creates
    # doc_002_parsed.json.
    output_stem = file_path.stem
    document_number = int(
        document_number
    )
    print(
        f"\nParsing: {file_path}"
    )
    try:
        parsed_document = parse_document(
            file_path,
            document_number
        )
        output_path = (
            staging_dir
            / f"{output_stem}_parsed.json"
        )
        save_json(
            parsed_document,
            output_path
        )
        print(
            f"Saved: {output_path}"
        )
        return True
    except Exception as error:
        print(
            f"ERROR while parsing "
            f"{file_path.name}: {error}"
        )
        return False


# ============================================================
# MAIN
# ============================================================

def main():
    if len(sys.argv) < 2:
        print("\nUsage:")
        print("  python parser.py <file>")
        print("  python parser.py <folder>")
        print(
            "\nSupported formats:"
        )
        print(
            "  PDF, DOCX, PPTX, TXT"
        )
        return
    input_path = Path(
        sys.argv[1]
    )
    staging_dir = Path(
        "staging"
    )
    staging_dir.mkdir(
        exist_ok=True
    )
    supported_extensions = {
        ".pdf",
        ".docx",
        ".pptx",
        ".txt"
    }
    # ============================================================
    # SINGLE FILE
    # ============================================================
    if input_path.is_file():
        if (
            input_path.suffix.lower()
            not in supported_extensions
        ):
            print(
                f"Unsupported file format: "
                f"{input_path.suffix}"
            )
            return
        # Single file always gets Doc 001.
        success = (
            process_single_document(
                input_path,
                1,
                staging_dir
            )
        )
        print(
            "\nProcessing complete."
        )
        if success:
            print(
                "successfully parsed: "
                "1 document"
            )
        else:
            print(
                "successfully parsed: "
                "0 documents"
            )
        return
    # ============================================================
    # FOLDER
    # ============================================================
    if input_path.is_dir():
        files = sorted(
            [
                file
                for file in input_path.iterdir()
                if (
                    file.is_file()
                    and file.suffix.lower()
                    in supported_extensions
                )
            ]
        )
        if not files:
            print(
                "No supported documents found "
                f"in: {input_path}"
            )
            return
        print(
            f"\nFound {len(files)} document(s)."
        )
        print(
            "Processing order:"
        )
        for index, file in enumerate(
            files,
            start=1
        ):
            print(
                f"  {index}. {file.name}"
            )
        success_count = 0
        # ============================================================
        # STRICT SEQUENTIAL NUMBERING
        # ============================================================
        for document_number, file in enumerate(
            files,
            start=1
        ):
            success = (
                process_single_document(
                    file,
                    document_number,
                    staging_dir
                )
            )
            if success:
                success_count += 1
        print(
            "\n=========================================="
        )
        print(
            "Batch processing complete."
        )
        print(
            f"Total documents: {len(files)}"
        )
        print(
            f"Successfully parsed: "
            f"{success_count}"
        )
        print(
            f"Failed: "
            f"{len(files) - success_count}"
        )
        print(
            f"Output directory: "
            f"{staging_dir}"
        )
        print(
            "=========================================="
        )
        return
    # ============================================================
    # INVALID INPUT
    # ============================================================
    print(
        f"Input path does not exist: "
        f"{input_path}"
    )


# ============================================================
# PROGRAM ENTRY POINT
# ============================================================

if __name__ == "__main__":
    main()