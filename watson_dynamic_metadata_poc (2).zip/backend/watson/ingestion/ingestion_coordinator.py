from __future__ import annotations

import hashlib
import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from watson.governance.expiry_manager import calculate_expiry_date
from watson.governance.lifecycle_manager import (
    load_lifecycle_store,
    save_lifecycle_store,
    transition_document_state,
)
from watson.governance.quality_scorer import calculate_quality_score
from watson.ingestion.chunker import chunk_parsed_document
from watson.ingestion.dedup_detector import check_deduplication, load_dedup_store, compute_sha256, normalize_date_string
from watson.ingestion.staging_state import serialized, commit_files, json_bytes, recover_transactions, normalize_stage, repair_legacy_dates
from watson.ingestion.metadata_extractor import MetadataExtractor
from watson.ingestion.parser import parse_document
from watson.ingestion.pii_detector import detect_pii_entities, mask_pii_text
from watson.semantics.enrichment_pipeline import Layer2EnrichmentPipeline
from watson.shared.audit import log_audit_event
from watson.shared.config import (
    BASE_DIR, AUDIT_LOG_FILE, CHUNK_URI_MAP_FILE,
    LIFECYCLE_STORE_FILE,
    RAW_DATA_DIR,
    SEED_VOCABULARIES_FILE,
    STAGING_DATA_DIR,
)
from watson.shared.exceptions import (
    ABACAccessDeniedError,
    DedupError,
    LifecycleViolationError,
    ParsingError,
)
from watson.shared.ids import make_chunk_uri, make_doc_id, make_doc_uri

logger = logging.getLogger("watson.ingestion.coordinator")


class IngestionCoordinator:
    """
    Central Ingestion Coordinator orchestrating:
    Upload -> Parse -> Dedup -> Chunk -> PII -> Metadata -> Review -> Activate -> Enrich
    Enforces atomic lifecycle gates and prevents unreviewed self-approval.
    """

    def __init__(self):
        recover_transactions(BASE_DIR, STAGING_DATA_DIR)
        repair_legacy_dates(BASE_DIR, STAGING_DATA_DIR, LIFECYCLE_STORE_FILE)
        self.metadata_extractor = MetadataExtractor(vocabulary_path=SEED_VOCABULARIES_FILE)
        self.enrichment_pipeline = Layer2EnrichmentPipeline()

    @serialized
    def stage_file(self, file_path: Path, actor_id: str = "SYSTEM", correlation_id: Optional[str] = None) -> Dict[str, Any]:
        """Check without registration, prepare everything, then commit durable state."""
        recover_transactions(BASE_DIR, STAGING_DATA_DIR)
        file_path = Path(file_path)
        file_bytes = file_path.read_bytes()
        if not file_bytes:
            raise ParsingError("The uploaded file is empty.")
        file_hash = hashlib.sha256(file_bytes).hexdigest()
        try:
            parsed_doc = parse_document(str(file_path))
        except Exception as exc:
            raise ParsingError(f"Failed to parse {file_path.name}: {exc}") from exc
        full_text = parsed_doc.get("raw_text") or parsed_doc.get("text_content") or ""
        if not full_text.strip():
            raise ParsingError("No readable text was extracted. Use a text-based document or OCR it first.")
        doc_id = make_doc_id(file_path.stem, file_hash)
        doc_uri = make_doc_uri(doc_id)
        parsed_doc["document_uri"] = doc_uri
        parsed_doc["raw_text"] = full_text
        parsed_doc["source_filename"] = file_path.name
        parsed_doc.setdefault("extracted_metadata", {})["document_uri"] = doc_uri

        registry_path = BASE_DIR / "dedup_store.json"
        registry = load_dedup_store(str(registry_path))
        store = load_lifecycle_store(LIFECYCLE_STORE_FILE)
        text_hash = compute_sha256(full_text)
        existing = registry.get("exact_hashes", {}).get(text_hash)
        # Old builds registered the parser's placeholder Doc_001 for every file.
        # Resolve by the recorded filename rather than trusting that placeholder.
        if existing:
            filename = existing.get("source_filename", "")
            matches = [(uri, record) for uri, record in store.items()
                       if record.get("source_filename") == filename]
            for uri, record in matches:
                if record.get("lifecycle_state") == "UNDER_REVIEW":
                    for staged_path in STAGING_DATA_DIR.glob("*_staged.json"):
                        try:
                            candidate = json.loads(staged_path.read_text(encoding="utf-8"))
                        except (OSError, ValueError):
                            logger.warning("Skipping an unreadable legacy staging record: %s", staged_path.name)
                            continue
                        if candidate.get("document_uri") == uri and candidate.get("source_filename") == filename:
                            candidate = normalize_stage(candidate)
                            if not candidate.get("staged_by"):
                                # Legacy records had no uploader. Possession of this exact
                                # content reopens the already-staged attempt, not a new one.
                                candidate["staged_by"] = actor_id
                                record["staged_by"] = actor_id
                                if not candidate["metadata"].get("therapeutic_area"):
                                    area = self.metadata_extractor.infer_therapeutic_area(full_text)
                                    candidate["metadata"]["therapeutic_area"] = area
                                    if area and not record.get("allowed_therapeutic_areas"):
                                        record["allowed_therapeutic_areas"] = [area]
                                commit_files({staged_path: json_bytes(candidate), LIFECYCLE_STORE_FILE: json_bytes(store)}, BASE_DIR, STAGING_DATA_DIR)
                            candidate["duplicate_upload"] = True
                            log_audit_event(event_type="INGEST", user_id=actor_id, document_uri=uri,
                                            message="Reopened an existing pending review after duplicate upload.",
                                            correlation_id=correlation_id)
                            return candidate
                else:
                    raise DedupError(f"Exact duplicate of {uri} ({record.get('lifecycle_state')}).")
            # Never discard a registration that still has indexed evidence.
            mapping = json.loads(CHUNK_URI_MAP_FILE.read_text(encoding="utf-8")) if CHUNK_URI_MAP_FILE.exists() else {}
            entries = mapping.get("index_to_chunk", mapping)
            if any(isinstance(v, dict) and v.get("source_filename") == filename for v in entries.values()):
                raise DedupError("This content already has indexed evidence. Review its document history instead of uploading it again.")
            # Only the uncommitted matching attempt is replaced after success.
            registry["exact_hashes"].pop(text_hash)
            registry["title_registry"] = [e for e in registry.get("title_registry", []) if e.get("filename") != filename]

        decision, _ = check_deduplication(parsed_doc, store_path=str(registry_path),
            audit_path=str(AUDIT_LOG_FILE), register=False, store_override=registry)
        if decision == "EXACT_DUPLICATE":
            raise DedupError("This document is already registered.")
        chunking = chunk_parsed_document(parsed_doc, strategy="B")
        chunks = chunking.get("chunks", [])
        if not chunks:
            raise ParsingError("The document did not produce any reviewable chunks.")
        findings = detect_pii_entities(full_text)
        critical_types = {"PERSON", "PATIENT_NAME", "SSN", "MRN", "PHONE", "AADHAAR", "PASSPORT_NUMBER", "NATIONAL_ID", "DATE_OF_BIRTH"}
        for chunk in chunks:
            text = chunk.get("text", "")
            local_findings = detect_pii_entities(text)
            if local_findings:
                chunk["text"] = mask_pii_text(text, local_findings)
                chunk["pii_redacted"] = True
        metadata = self.metadata_extractor.build_from_parsed_document(parsed_doc)
        metadata.update(document_uri=doc_uri, source_filename=file_path.name, sha256=file_hash)
        metadata["quality_score"] = calculate_quality_score(metadata, full_text).get("quality_score", 0.8)
        ingest_iso = datetime.now(timezone.utc).isoformat()
        expiry = calculate_expiry_date(metadata.get("study_type") or "HCP Perception Survey", ingest_iso)
        metadata.update(expiry_date=expiry["expiry_date"], retention_days=expiry["retention_days"])
        staged = {
            "document_uri": doc_uri, "doc_id": doc_id, "source_filename": file_path.name,
            "format": parsed_doc.get("format", file_path.suffix.lstrip(".")),
            "sha256": file_hash, "text_sha256": text_hash, "staged_by": actor_id,
            "lifecycle_state": "UNDER_REVIEW", "ready_for_layer2": False,
            "metadata": metadata, "governed_chunks": chunks,
            "has_pii": bool(findings), "has_critical_pii": any(p.get("type") in critical_types for p in findings),
            "pii_findings": findings, "staged_timestamp": ingest_iso,
            "dedup_status": decision,
        }
        record = {
            "document_uri": doc_uri, "lifecycle_state": "UNDER_REVIEW", "staged_by": actor_id,
            "sensitivity_level": metadata.get("sensitivity_level") or "INTERNAL",
            "allowed_therapeutic_areas": [metadata["therapeutic_area"]] if metadata.get("therapeutic_area") else [],
            "allowed_geographies": [metadata["geography"]] if metadata.get("geography") else [],
            "quality_score": metadata["quality_score"], "expiry_date": expiry["expiry_date"],
            "retention_days": expiry["retention_days"], "ingest_timestamp": ingest_iso,
            "source_filename": file_path.name, "sha256": file_hash,
        }
        store[doc_uri] = record
        title = metadata.get("extracted_title") or file_path.stem
        entry = {"document_uri": doc_uri, "source_filename": file_path.name, "filename": file_path.name,
                 "title": title, "author": metadata.get("extracted_author"), "date": ingest_iso,
                 "raw_date": ingest_iso, "norm_date": normalize_date_string(ingest_iso),
                 "first_200_hash": compute_sha256(full_text[:200]), "lifecycle_state": "UNDER_REVIEW"}
        registry.setdefault("exact_hashes", {})[text_hash] = dict(entry)
        registry.setdefault("title_registry", []).append(dict(entry))
        raw_target = RAW_DATA_DIR / doc_id / file_path.name
        staged["source_path"] = str(raw_target.relative_to(BASE_DIR))
        commit_files({raw_target: file_bytes,
                      STAGING_DATA_DIR / f"{doc_id}_staged.json": json_bytes(staged),
                      LIFECYCLE_STORE_FILE: json_bytes(store), registry_path: json_bytes(registry)}, BASE_DIR, STAGING_DATA_DIR)
        log_audit_event(event_type="STATE_TRANSITION", user_id=actor_id, document_uri=doc_uri,
                        old_state="DRAFT", new_state="UNDER_REVIEW", message="Document staged for review.",
                        metadata={"recovered_uncommitted_attempt": bool(existing)}, correlation_id=correlation_id)
        return staged

    @serialized
    def pending_documents(self, user):
        records = load_lifecycle_store(LIFECYCLE_STORE_FILE)
        result = []
        for path in STAGING_DATA_DIR.glob("*_staged.json"):
            try:
                staged = normalize_stage(json.loads(path.read_text(encoding="utf-8")))
            except (OSError, ValueError):
                logger.warning("Skipping an unreadable legacy staging record: %s", path.name)
                continue
            record = records.get(staged.get("document_uri"), {})
            if record.get("lifecycle_state") != "UNDER_REVIEW":
                continue
            if user["role"] != "ADMIN" and staged.get("staged_by") != user["user_id"]:
                scopes = user.get("allowed_therapeutic_areas", [])
                if user["role"] not in ("SPOC", "COMPLIANCE_OFFICER") or ("*" not in scopes and staged.get("metadata", {}).get("therapeutic_area") not in scopes):
                    continue
            result.append(staged)
        return result


    @serialized
    def review_and_activate(
        self,
        doc_uri: str,
        reviewer_id: str,
        reviewer_role: str,
        decision: str,  # "APPROVE" or "REJECT"
        review_note: str = "",
        pii_override: bool = False,
        sensitivity_level: Optional[str] = None,
        allowed_ta: Optional[List[str]] = None,
        allowed_geo: Optional[List[str]] = None,
        expiry_date: Optional[str] = None,
        correlation_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Executes H06 -> H10:
        HITL approval gate. On APPROVE, sets ACTIVE, commits ACL,
        and triggers Layer 2 semantic enrichment and FAISS indexing.
        """
        if reviewer_role not in ("ADMIN", "SPOC", "COMPLIANCE_OFFICER"):
            raise ABACAccessDeniedError("Only SPOC or ADMIN roles are authorized to review documents.")

        if decision not in ("APPROVE", "REJECT"):
            raise ValueError("Review decision must be APPROVE or REJECT.")
        store = load_lifecycle_store(LIFECYCLE_STORE_FILE)
        if doc_uri not in store:
            raise FileNotFoundError(f"Document {doc_uri} not found in lifecycle store.")

        doc_record = store[doc_uri]
        if doc_record.get("lifecycle_state") != "UNDER_REVIEW":
            raise LifecycleViolationError(
                f"Cannot review document in state {doc_record.get('lifecycle_state')}. Must be UNDER_REVIEW."
            )

        doc_id = doc_uri.replace("watson:Doc_", "")
        stage_file = STAGING_DATA_DIR / f"{doc_id}_staged.json"
        staged_pkg = {}
        if stage_file.exists():
            with open(stage_file, "r", encoding="utf-8") as f:
                staged_pkg = normalize_stage(json.load(f))
        if not staged_pkg:
            raise LifecycleViolationError("Staging record is missing. Retry the upload before reviewing.")

        if decision == "REJECT":
            doc_record["lifecycle_state"] = "REJECTED"
            doc_record["rejection_reason"] = review_note
            save_lifecycle_store(store, LIFECYCLE_STORE_FILE)

            log_audit_event(
                event_type="STATE_TRANSITION",
                user_id=reviewer_id,
                document_uri=doc_uri,
                old_state="UNDER_REVIEW",
                new_state="REJECTED",
                message=f"Document rejected: {review_note}",
                correlation_id=correlation_id,
            )
            return {"status": "REJECTED", "document_uri": doc_uri}

        # Handle APPROVE
        if staged_pkg.get("has_critical_pii") and not pii_override:
            raise LifecycleViolationError("Document contains unredacted critical PII. Requires explicit pii_override.")

        if pii_override:
            log_audit_event(
                event_type="PII_OVERRIDE",
                user_id=reviewer_id,
                document_uri=doc_uri,
                message=f"PII review override authorized by {reviewer_id}: {review_note}",
                correlation_id=correlation_id,
            )

        # Update ACL metadata
        if sensitivity_level:
            doc_record["sensitivity_level"] = sensitivity_level
        if allowed_ta is not None:
            doc_record["allowed_therapeutic_areas"] = allowed_ta
        if allowed_geo is not None:
            doc_record["allowed_geographies"] = allowed_geo
        if expiry_date:
            doc_record["expiry_date"] = expiry_date

        doc_record["lifecycle_state"] = "ACTIVE"
        doc_record["reviewed_by"] = reviewer_id
        doc_record["review_note"] = review_note
        doc_record["review_timestamp"] = datetime.now(timezone.utc).isoformat()
        # Trigger Layer 2 Semantic Enrichment & Vector Indexing
        staged_pkg["lifecycle_state"] = "ACTIVE"
        staged_pkg["ready_for_layer2"] = True
        staged_pkg["sensitivity_level"] = doc_record["sensitivity_level"]
        staged_pkg["allowed_therapeutic_areas"] = doc_record["allowed_therapeutic_areas"]
        staged_pkg["allowed_geographies"] = doc_record["allowed_geographies"]

        metadata = staged_pkg.get("metadata", {})
        for field in ("study_type", "therapeutic_area", "geography", "quality_score", "retention_days"):
            staged_pkg[field] = metadata.get(field)
        expiry = doc_record.get("expiry_date")
        doc_record["expiry_date"] = expiry.get("expiry_date") if isinstance(expiry, dict) else expiry
        staged_pkg["expiry_date"] = doc_record.get("expiry_date")
        artifacts = [getattr(self.enrichment_pipeline, name, None) for name in ("kg_path", "faiss_path", "chunk_map_path")]
        before = {Path(path): Path(path).read_bytes() if Path(path).exists() else None for path in artifacts if path}
        try:
            enrichment_result = self.enrichment_pipeline.enrich_document_package(staged_pkg)
            registry_path = BASE_DIR / "dedup_store.json"
            registry = load_dedup_store(str(registry_path))
            for entry in list(registry.get("exact_hashes", {}).values()) + registry.get("title_registry", []):
                if entry.get("document_uri") == doc_uri:
                    entry["lifecycle_state"] = "ACTIVE"
            commit_files({LIFECYCLE_STORE_FILE: json_bytes(store), stage_file: json_bytes(staged_pkg),
                          registry_path: json_bytes(registry)}, BASE_DIR, STAGING_DATA_DIR)
        except Exception:
            if before:
                commit_files(before, BASE_DIR, STAGING_DATA_DIR)
                # Keep the in-memory graph/index aligned with restored files.
                pipeline = self.enrichment_pipeline
                if hasattr(pipeline, "graph"):
                    pipeline.graph.remove((None, None, None))
                    if pipeline.kg_path.exists():
                        pipeline.graph.parse(str(pipeline.kg_path), format="turtle")
                if hasattr(pipeline, "_init_vector_store"):
                    pipeline._init_vector_store()
            raise
        log_audit_event(event_type="STATE_TRANSITION", user_id=reviewer_id, document_uri=doc_uri,
                        old_state="UNDER_REVIEW", new_state="ACTIVE",
                        message="Document enriched and activated after review.", correlation_id=correlation_id)

        return {
            "status": "ACTIVE",
            "document_uri": doc_uri,
            "enrichment": enrichment_result,
        }

    @serialized
    def archive_document(
        self,
        doc_uri: str,
        user_id: str,
        reason: str = "Archived by administrator",
    ) -> Dict[str, Any]:
        """Archives an ACTIVE document and immediately invalidates search access."""
        store = load_lifecycle_store(LIFECYCLE_STORE_FILE)
        if doc_uri not in store:
            raise FileNotFoundError(f"Document {doc_uri} not found.")

        current = store[doc_uri].get("lifecycle_state")
        if current != "ACTIVE":
            raise LifecycleViolationError(f"Cannot archive document in state '{current}'. Must be ACTIVE.")

        store[doc_uri]["lifecycle_state"] = "ARCHIVED"
        store[doc_uri]["archive_reason"] = reason
        store[doc_uri]["archived_timestamp"] = datetime.now(timezone.utc).isoformat()
        save_lifecycle_store(store, LIFECYCLE_STORE_FILE)

        log_audit_event(
            event_type="STATE_TRANSITION",
            user_id=user_id,
            document_uri=doc_uri,
            old_state="ACTIVE",
            new_state="ARCHIVED",
            message=f"Document archived: {reason}",
        )
        return {"status": "ARCHIVED", "document_uri": doc_uri}

    @serialized
    def reinstate_document(
        self,
        doc_uri: str,
        user_id: str,
        reason: str = "Reinstated by administrator",
    ) -> Dict[str, Any]:
        """Reinstates an ARCHIVED document back to ACTIVE."""
        store = load_lifecycle_store(LIFECYCLE_STORE_FILE)
        if doc_uri not in store:
            raise FileNotFoundError(f"Document {doc_uri} not found.")

        current = store[doc_uri].get("lifecycle_state")
        if current != "ARCHIVED":
            raise LifecycleViolationError(f"Cannot reinstate document in state '{current}'. Must be ARCHIVED.")

        store[doc_uri]["lifecycle_state"] = "ACTIVE"
        store[doc_uri]["reinstated_timestamp"] = datetime.now(timezone.utc).isoformat()
        save_lifecycle_store(store, LIFECYCLE_STORE_FILE)

        log_audit_event(
            event_type="STATE_TRANSITION",
            user_id=user_id,
            document_uri=doc_uri,
            old_state="ARCHIVED",
            new_state="ACTIVE",
            message=f"Document reinstated: {reason}",
        )
        return {"status": "ACTIVE", "document_uri": doc_uri}
