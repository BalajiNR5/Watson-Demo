"""
Watson chunk.py

Compatible with the updated parser.py ParsedDocument contract.

Implements the mandatory comparison from the Watson project brief:
  Strategy A - Fixed-Size with Overlap
      * 256 tokens per chunk
      * 51-token overlap (~20%)
  Strategy B - Semantic / Structural
      * DOCX: H1/H2 heading boundaries
      * PDF: page boundaries; split a page further if > 600 tokens
      * PPTX: one chunk per slide, including title/body/speaker notes
      * TXT: parser text-block boundaries; split an oversized block at 600 tokens

The parser owns source structure/provenance. This module owns chunk formation.
No external API is used.
"""

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple


# -----------------------------------------------------------------------------
# Configuration
# -----------------------------------------------------------------------------

STRATEGY_A_CHUNK_TOKENS = 256
STRATEGY_A_OVERLAP_TOKENS = 51
STRATEGY_B_MAX_TOKENS = 600

SUPPORTED_FORMATS = {"pdf", "docx", "pptx", "txt"}


# -----------------------------------------------------------------------------
# Tokenization
# -----------------------------------------------------------------------------

class Tokenizer:
    """Local tokenizer with a dependency-free fallback.

    If tiktoken is installed, cl100k_base is used. Otherwise a deterministic
    regex tokenizer is used. The chosen tokenizer is recorded in every chunk,
    making token counts auditable.
    """

    _FALLBACK_PATTERN = re.compile(r"\s+|\w+|[^\w\s]", re.UNICODE)

    def __init__(self) -> None:
        self._encoding = None
        self.name = "regex_fallback"
        try:
            import tiktoken  # type: ignore

            self._encoding = tiktoken.get_encoding("cl100k_base")
            self.name = "tiktoken:cl100k_base"
        except Exception:
            self._encoding = None

    def encode(self, text: str) -> List[Any]:
        if not text:
            return []
        if self._encoding is not None:
            return list(self._encoding.encode(text))
        return self._FALLBACK_PATTERN.findall(text)

    def decode(self, tokens: Sequence[Any]) -> str:
        if not tokens:
            return ""
        if self._encoding is not None:
            return self._encoding.decode(list(tokens))
        return "".join(str(token) for token in tokens)

    def count(self, text: str) -> int:
        return len(self.encode(text))


TOKENIZER = Tokenizer()


# -----------------------------------------------------------------------------
# Generic helpers
# -----------------------------------------------------------------------------

def normalize_text(text: Optional[str]) -> str:
    if not text:
        return ""
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = text.replace("\t", " ").replace("\xa0", " ")
    lines = [re.sub(r"[ ]+", " ", line).strip() for line in text.split("\n")]

    cleaned: List[str] = []
    previous_blank = False
    for line in lines:
        if not line:
            if not previous_blank:
                cleaned.append("")
            previous_blank = True
        else:
            cleaned.append(line)
            previous_blank = False
    return "\n".join(cleaned).strip()


def load_json(path: Path) -> Dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        value = json.load(handle)
    if not isinstance(value, dict):
        raise ValueError(f"Parsed document must be a JSON object: {path}")
    return value


def save_json(value: Any, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(value, handle, indent=2, ensure_ascii=False)


def validate_parsed_document(document: Dict[str, Any]) -> None:
    required = ("document_uri", "source_filename", "format", "raw_text")
    missing = [key for key in required if key not in document]
    if missing:
        raise ValueError("ParsedDocument missing required field(s): " + ", ".join(missing))

    fmt = str(document.get("format", "")).lower()
    if fmt not in SUPPORTED_FORMATS:
        raise ValueError(f"Unsupported parsed format: {fmt!r}")

    if not isinstance(document.get("raw_text"), str):
        raise ValueError("ParsedDocument.raw_text must be a string")


def split_tokens(text: str, max_tokens: int) -> List[str]:
    """Split text into non-overlapping token windows of max_tokens."""
    if max_tokens <= 0:
        raise ValueError("max_tokens must be > 0")
    tokens = TOKENIZER.encode(text)
    if not tokens:
        return []
    pieces: List[str] = []
    for start in range(0, len(tokens), max_tokens):
        window = tokens[start:start + max_tokens]
        piece = TOKENIZER.decode(window)
        if piece:
            pieces.append(piece)
    return pieces


def locate_text(raw_text: str, text: str, cursor: int = 0) -> Tuple[Optional[int], Optional[int]]:
    """Best-effort source character span using Python's [start, end) convention."""
    if not text:
        return None, None

    pos = raw_text.find(text, max(cursor, 0))
    if pos < 0:
        pos = raw_text.find(text)
    if pos < 0:
        # Structural text can differ slightly from raw_text (e.g. PPTX notes).
        return None, None
    return pos, pos + len(text)


def page_lookup(document: Dict[str, Any]) -> Dict[int, Dict[str, Any]]:
    result: Dict[int, Dict[str, Any]] = {}
    for page in document.get("pages") or []:
        try:
            number = int(page.get("page_number"))
        except (TypeError, ValueError):
            continue
        result[number] = page
    return result


def page_numbers_for_char_span(
    document: Dict[str, Any],
    char_start: Optional[int],
    char_end: Optional[int],
) -> List[int]:
    """Infer source page/slide numbers from parser page text in raw_text.

    Parser page_span is word-based, whereas Strategy A is token/character based.
    We therefore reconstruct page character intervals from each page's text.
    """
    if char_start is None or char_end is None:
        return []

    raw_text = document.get("raw_text", "")
    hits: List[int] = []
    cursor = 0
    for page in document.get("pages") or []:
        page_text = normalize_text(page.get("text", ""))
        if not page_text:
            continue
        start, end = locate_text(raw_text, page_text, cursor)
        if start is None or end is None:
            continue
        cursor = end
        if char_start < end and char_end > start:
            try:
                hits.append(int(page.get("page_number")))
            except (TypeError, ValueError):
                pass
    return hits


def source_provenance(
    document: Dict[str, Any],
    page_numbers: Optional[Sequence[int]] = None,
    unit_type: Optional[str] = None,
    unit_indices: Optional[Sequence[int]] = None,
    heading: Optional[str] = None,
    heading_level: Optional[str] = None,
) -> Dict[str, Any]:
    pages = sorted({int(p) for p in (page_numbers or [])})
    units = [int(u) for u in (unit_indices or [])]
    lookup = page_lookup(document)

    provenance: Dict[str, Any] = {
        "source_filename": document.get("source_filename"),
        "format": str(document.get("format", "")).lower(),
        "page_start": pages[0] if pages else None,
        "page_end": pages[-1] if pages else None,
        "page_numbers": pages,
        "unit_type": unit_type,
        "unit_indices": units,
    }

    if heading is not None:
        provenance["heading"] = heading
    if heading_level is not None:
        provenance["heading_level"] = heading_level

    parser_spans = []
    for number in pages:
        span = (lookup.get(number) or {}).get("page_span")
        if isinstance(span, dict):
            parser_spans.append({"page_number": number, "page_span": span})
    if parser_spans:
        provenance["parser_page_spans"] = parser_spans

    return provenance


def make_chunk(
    document: Dict[str, Any],
    strategy: str,
    chunk_index: int,
    text: str,
    *,
    char_start: Optional[int],
    char_end: Optional[int],
    provenance: Dict[str, Any],
    structural_part: Optional[int] = None,
) -> Dict[str, Any]:
    parent_uri = document.get("document_uri")
    chunk_uri = f"{parent_uri}:chunk:{strategy.lower()}:{chunk_index:04d}"

    chunk: Dict[str, Any] = {
        "chunk_uri": chunk_uri,
        "parent_document_uri": parent_uri,
        "source_filename": document.get("source_filename"),
        "format": str(document.get("format", "")).lower(),
        "strategy": strategy,
        "chunk_index": chunk_index,
        "text": text,
        "char_start": char_start,
        "char_end": char_end,
        "token_count": TOKENIZER.count(text),
        "tokenizer": TOKENIZER.name,
        "source_provenance": provenance,
    }
    if structural_part is not None:
        chunk["structural_part"] = structural_part
    return chunk


# -----------------------------------------------------------------------------
# Strategy A - fixed size + overlap
# -----------------------------------------------------------------------------

def chunk_strategy_a(
    document: Dict[str, Any],
    chunk_tokens: int = STRATEGY_A_CHUNK_TOKENS,
    overlap_tokens: int = STRATEGY_A_OVERLAP_TOKENS,
) -> List[Dict[str, Any]]:
    if chunk_tokens <= 0:
        raise ValueError("chunk_tokens must be > 0")
    if overlap_tokens < 0 or overlap_tokens >= chunk_tokens:
        raise ValueError("overlap_tokens must satisfy 0 <= overlap < chunk_tokens")

    raw_text = document.get("raw_text", "")
    tokens = TOKENIZER.encode(raw_text)
    if not tokens:
        return []

    step = chunk_tokens - overlap_tokens
    chunks: List[Dict[str, Any]] = []

    for token_start in range(0, len(tokens), step):
        window = tokens[token_start:token_start + chunk_tokens]
        if not window:
            break

        text = TOKENIZER.decode(window)
        if not text:
            continue

        char_start = len(TOKENIZER.decode(tokens[:token_start]))
        char_end = char_start + len(text)

        pages = page_numbers_for_char_span(document, char_start, char_end)
        provenance = source_provenance(document, page_numbers=pages)

        chunks.append(
            make_chunk(
                document,
                "A",
                len(chunks),
                text,
                char_start=char_start,
                char_end=char_end,
                provenance=provenance,
            )
        )

        if token_start + chunk_tokens >= len(tokens):
            break

    return chunks


# -----------------------------------------------------------------------------
# Strategy B helpers
# -----------------------------------------------------------------------------

def _append_structural_text_chunks(
    chunks: List[Dict[str, Any]],
    document: Dict[str, Any],
    text: str,
    *,
    max_tokens: int,
    page_numbers: Optional[Sequence[int]],
    unit_type: str,
    unit_indices: Sequence[int],
    heading: Optional[str] = None,
    heading_level: Optional[str] = None,
    cursor: int = 0,
) -> int:
    text = normalize_text(text)
    if not text:
        return cursor

    pieces = split_tokens(text, max_tokens) if TOKENIZER.count(text) > max_tokens else [text]
    raw_text = document.get("raw_text", "")
    local_cursor = cursor

    for part_number, piece in enumerate(pieces, start=1):
        char_start, char_end = locate_text(raw_text, piece, local_cursor)
        if char_end is not None:
            local_cursor = char_end

        provenance = source_provenance(
            document,
            page_numbers=page_numbers,
            unit_type=unit_type,
            unit_indices=unit_indices,
            heading=heading,
            heading_level=heading_level,
        )
        chunks.append(
            make_chunk(
                document,
                "B",
                len(chunks),
                piece,
                char_start=char_start,
                char_end=char_end,
                provenance=provenance,
                structural_part=part_number if len(pieces) > 1 else None,
            )
        )
    return local_cursor


def _pdf_strategy_b(document: Dict[str, Any], max_tokens: int) -> List[Dict[str, Any]]:
    chunks: List[Dict[str, Any]] = []
    units = document.get("structural_units") or []

    # Parser contract: one structural unit per PDF page.
    if not units:
        units = [
            {
                "unit_type": "page",
                "unit_index": page.get("page_number"),
                "text": page.get("text", ""),
            }
            for page in (document.get("pages") or [])
        ]

    cursor = 0
    for unit in units:
        try:
            page_number = int(unit.get("unit_index"))
        except (TypeError, ValueError):
            continue
        cursor = _append_structural_text_chunks(
            chunks,
            document,
            unit.get("text", ""),
            max_tokens=max_tokens,
            page_numbers=[page_number],
            unit_type="page",
            unit_indices=[page_number],
            cursor=cursor,
        )
    return chunks


def _docx_section_text(units: Sequence[Dict[str, Any]]) -> str:
    parts: List[str] = []
    for unit in units:
        heading = normalize_text(unit.get("heading"))
        body = normalize_text(unit.get("text"))
        if heading:
            parts.append(heading)
        if body:
            parts.append(body)
    return normalize_text("\n\n".join(parts))


def _docx_strategy_b(document: Dict[str, Any], max_tokens: int) -> List[Dict[str, Any]]:
    """Chunk DOCX at H1/H2 boundaries.

    The parser deliberately preserves all Heading N levels. Here, only H1/H2
    start a new Strategy-B section; H3+ remain inside the current H1/H2 chunk.
    Oversized sections are split at 600 tokens to keep downstream processing
    bounded while preserving the H1/H2 semantic grouping.
    """
    chunks: List[Dict[str, Any]] = []
    units = document.get("structural_units") or []
    if not units:
        return chunks

    groups: List[List[Dict[str, Any]]] = []
    current: List[Dict[str, Any]] = []

    for unit in units:
        level = str(unit.get("heading_level") or "").upper()
        is_h1_h2 = level in {"H1", "H2"}
        if is_h1_h2 and current:
            groups.append(current)
            current = []
        current.append(unit)

    if current:
        groups.append(current)

    cursor = 0
    for group in groups:
        text = _docx_section_text(group)
        if not text:
            continue
        first_boundary = next(
            (u for u in group if str(u.get("heading_level") or "").upper() in {"H1", "H2"}),
            group[0],
        )
        indices = [
            int(u.get("unit_index"))
            for u in group
            if str(u.get("unit_index", "")).isdigit()
        ]
        cursor = _append_structural_text_chunks(
            chunks,
            document,
            text,
            max_tokens=max_tokens,
            page_numbers=[],  # DOCX parser has no trustworthy physical-page mapping.
            unit_type="section",
            unit_indices=indices,
            heading=first_boundary.get("heading"),
            heading_level=first_boundary.get("heading_level"),
            cursor=cursor,
        )
    return chunks


def _pptx_slide_text(unit: Dict[str, Any]) -> str:
    """Build one slide chunk containing title, body and speaker notes once."""
    title = normalize_text(unit.get("title"))
    body = normalize_text(unit.get("body"))
    notes = normalize_text(unit.get("speaker_notes"))

    parts: List[str] = []
    if title:
        parts.append(title)
    if body:
        parts.append(body)
    if notes:
        parts.append(notes)

    # Compatibility fallback for older parsed JSON that only has `text`.
    if not parts:
        return normalize_text(unit.get("text", ""))
    return normalize_text("\n\n".join(parts))


def _pptx_strategy_b(document: Dict[str, Any]) -> List[Dict[str, Any]]:
    chunks: List[Dict[str, Any]] = []
    units = document.get("structural_units") or []

    for unit in units:
        try:
            slide_number = int(unit.get("unit_index"))
        except (TypeError, ValueError):
            continue

        # PRD explicitly requires one chunk per slide. Do not apply the 600-token
        # PDF rule to PPTX.
        text = _pptx_slide_text(unit)
        if not text:
            continue

        raw_text = document.get("raw_text", "")
        char_start, char_end = locate_text(raw_text, normalize_text(unit.get("text", "")))
        provenance = source_provenance(
            document,
            page_numbers=[slide_number],
            unit_type="slide",
            unit_indices=[slide_number],
        )
        chunks.append(
            make_chunk(
                document,
                "B",
                len(chunks),
                text,
                char_start=char_start,
                char_end=char_end,
                provenance=provenance,
            )
        )
    return chunks


def _txt_strategy_b(document: Dict[str, Any], max_tokens: int) -> List[Dict[str, Any]]:
    chunks: List[Dict[str, Any]] = []
    units = document.get("structural_units") or []
    if not units and document.get("raw_text"):
        units = [{"unit_type": "text_block", "unit_index": 1, "text": document["raw_text"]}]

    cursor = 0
    for unit in units:
        try:
            index = int(unit.get("unit_index"))
        except (TypeError, ValueError):
            continue
        cursor = _append_structural_text_chunks(
            chunks,
            document,
            unit.get("text", ""),
            max_tokens=max_tokens,
            page_numbers=[],
            unit_type="text_block",
            unit_indices=[index],
            cursor=cursor,
        )
    return chunks


def chunk_strategy_b(
    document: Dict[str, Any],
    max_tokens: int = STRATEGY_B_MAX_TOKENS,
) -> List[Dict[str, Any]]:
    if max_tokens <= 0:
        raise ValueError("max_tokens must be > 0")

    fmt = str(document.get("format", "")).lower()
    if fmt == "pdf":
        return _pdf_strategy_b(document, max_tokens)
    if fmt == "docx":
        return _docx_strategy_b(document, max_tokens)
    if fmt == "pptx":
        return _pptx_strategy_b(document)
    if fmt == "txt":
        return _txt_strategy_b(document, max_tokens)
    raise ValueError(f"Unsupported format for Strategy B: {fmt}")


# -----------------------------------------------------------------------------
# Public API
# -----------------------------------------------------------------------------

def chunk_document(
    parsed_document: Dict[str, Any],
    strategy: str = "both",
    *,
    strategy_a_chunk_tokens: int = STRATEGY_A_CHUNK_TOKENS,
    strategy_a_overlap_tokens: int = STRATEGY_A_OVERLAP_TOKENS,
    strategy_b_max_tokens: int = STRATEGY_B_MAX_TOKENS,
) -> Dict[str, Any]:
    validate_parsed_document(parsed_document)

    requested = strategy.strip().lower()
    if requested not in {"a", "b", "both"}:
        raise ValueError("strategy must be one of: A, B, both")

    result: Dict[str, Any] = {
        "document_uri": parsed_document.get("document_uri"),
        "source_filename": parsed_document.get("source_filename"),
        "format": str(parsed_document.get("format", "")).lower(),
        "tokenizer": TOKENIZER.name,
        "configuration": {
            "strategy_a": {
                "chunk_tokens": strategy_a_chunk_tokens,
                "overlap_tokens": strategy_a_overlap_tokens,
            },
            "strategy_b": {
                "pdf_max_tokens_per_page_chunk": strategy_b_max_tokens,
                "docx_boundary": "H1/H2",
                "pptx_boundary": "one chunk per slide including speaker notes",
                "txt_boundary": "parser text_block",
            },
        },
        "strategies": {},
    }

    if requested in {"a", "both"}:
        chunks_a = chunk_strategy_a(
            parsed_document,
            chunk_tokens=strategy_a_chunk_tokens,
            overlap_tokens=strategy_a_overlap_tokens,
        )
        result["strategies"]["A"] = {
            "name": "fixed_size_with_overlap",
            "chunk_count": len(chunks_a),
            "chunks": chunks_a,
        }

    if requested in {"b", "both"}:
        chunks_b = chunk_strategy_b(parsed_document, max_tokens=strategy_b_max_tokens)
        result["strategies"]["B"] = {
            "name": "semantic_structural",
            "chunk_count": len(chunks_b),
            "chunks": chunks_b,
        }

    return result


def chunk_parsed_document(
    parsed_document: Dict[str, Any],
    strategy: str = "B",
) -> Dict[str, Any]:
    """Helper wrapper for pipeline integration returning flattened chunk list."""
    strat = "b" if strategy.strip().lower() in ("b", "semantic_structural") else "a"
    res = chunk_document(parsed_document, strategy=strat)
    strat_key = "B" if strat == "b" else "A"
    chunks = res.get("strategies", {}).get(strat_key, {}).get("chunks", [])
    return {
        "document_uri": parsed_document.get("document_uri"),
        "strategy": strat_key,
        "chunk_count": len(chunks),
        "chunks": chunks,
        "raw_result": res,
    }


# -----------------------------------------------------------------------------
# CLI / batch processing
# -----------------------------------------------------------------------------

def output_name_for(parsed_json: Path) -> str:
    stem = parsed_json.stem
    if stem.endswith("_parsed"):
        stem = stem[:-7]
    return f"{stem}_chunks.json"


def process_file(
    input_path: Path,
    output_dir: Path,
    strategy: str,
    chunk_tokens: int = 256,
    overlap_tokens: Optional[int] = None,
) -> bool:
    try:
        strat_key = strategy.strip().lower()
        if strat_key == "a512" and chunk_tokens == 256:
            chunk_tokens = 512
        if overlap_tokens is None:
            overlap_tokens = int(round(chunk_tokens * 0.20))

        run_strat = "a" if strat_key in {"a", "a256", "a512"} else ("b" if strat_key == "b" else "both")

        document = load_json(input_path)
        result = chunk_document(
            document,
            strategy=run_strat,
            strategy_a_chunk_tokens=chunk_tokens,
            strategy_a_overlap_tokens=overlap_tokens,
        )
        output_name = output_name_for(input_path)
        output_path = output_dir / output_name
        save_json(result, output_path)
        print(f"Chunked: {input_path}")
        print(f"Saved:   {output_path}")

        # Also write strategy-specific subfolders if strategies were run
        if "A" in result.get("strategies", {}):
            strat_a_result = dict(result)
            strat_a_result["strategies"] = {"A": result["strategies"]["A"]}
            save_json(strat_a_result, output_dir / f"strategy_a_{chunk_tokens}" / output_name)
            if chunk_tokens == 256:
                save_json(strat_a_result, output_dir / "strategy_a" / output_name)
        if "B" in result.get("strategies", {}):
            strat_b_result = dict(result)
            strat_b_result["strategies"] = {"B": result["strategies"]["B"]}
            save_json(strat_b_result, output_dir / "strategy_b" / output_name)

        for key, payload in result.get("strategies", {}).items():
            print(f"  Strategy {key}: {payload['chunk_count']} chunk(s)")
        return True
    except Exception as exc:
        print(f"ERROR while chunking {input_path.name}: {exc}", file=sys.stderr)
        return False


def discover_parsed_json_files(path: Path) -> List[Path]:
    if path.is_file():
        return [path]
    if path.is_dir():
        preferred = sorted(path.glob("*_parsed.json"))
        if preferred:
            return preferred
        return sorted(path.glob("*.json"))
    return []


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Watson chunker: Strategy A fixed-overlap and Strategy B structural chunking."
    )
    parser.add_argument("input", help="Parsed JSON file or directory containing parsed JSON files")
    parser.add_argument(
        "--strategy",
        choices=["A", "B", "both", "a", "b", "A256", "A512", "a256", "a512"],
        default="both",
        help="Chunking strategy to run (default: both)",
    )
    parser.add_argument(
        "--chunk-tokens",
        type=int,
        default=256,
        help="Strategy A chunk size in tokens (default: 256)",
    )
    parser.add_argument(
        "--overlap-tokens",
        type=int,
        default=None,
        help="Strategy A overlap in tokens (default: ~20% of chunk-tokens)",
    )
    parser.add_argument(
        "--output-dir",
        default="chunks",
        help="Directory for chunk JSON output (default: chunks)",
    )
    return parser


def main() -> int:
    args = build_arg_parser().parse_args()
    input_path = Path(args.input)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    files = discover_parsed_json_files(input_path)
    if not files:
        print(f"No parsed JSON files found: {input_path}", file=sys.stderr)
        return 1

    chunk_tokens = args.chunk_tokens
    if args.strategy.lower() == "a512":
        chunk_tokens = 512
    overlap_tokens = args.overlap_tokens

    print(f"Tokenizer: {TOKENIZER.name}")
    print(f"Found {len(files)} parsed document(s).")

    success = 0
    for path in files:
        if process_file(
            path,
            output_dir,
            args.strategy,
            chunk_tokens=chunk_tokens,
            overlap_tokens=overlap_tokens,
        ):
            success += 1

    print("\nChunking complete.")
    print(f"Successfully chunked: {success}/{len(files)}")
    print(f"Output directory: {output_dir}")
    return 0 if success == len(files) else 1


if __name__ == "__main__":
    raise SystemExit(main())

