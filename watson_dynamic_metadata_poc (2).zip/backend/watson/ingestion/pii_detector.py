from __future__ import annotations

import argparse
from functools import lru_cache
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

SCHEMA_VERSION = "1.0"
MODULE_VERSION = "4.4.1"

PATTERNS: Dict[str, re.Pattern[str]] = {
    "EMAIL": re.compile(
        r"(?<![\w.+-])[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,63}(?!\w)",
        re.IGNORECASE,
    ),
    "PHONE": re.compile(
        r"(?i)\b(?:phone|telephone|mobile|contact\s+number)\s*[:\-]?\s*"
        r"(?P<value>(?:(?:\+\d{1,3}[ .-]?)?(?:\(\d{2,5}\)|\d{2,5})?[ .-]?)?"
        r"\d(?:[ .-]?\d){7,12})\b"
    ),
    "DATE_OF_BIRTH": re.compile(
        r"(?i)\b(?:dob|date\s+of\s+birth|born\s+on)\s*[:\-]?\s*"
        r"(?P<value>(?:0?[1-9]|[12]\d|3[01])[/-](?:0?[1-9]|1[0-2])"
        r"[/-](?:19|20)\d{2}|(?:19|20)\d{2}[/-](?:0?[1-9]|1[0-2])"
        r"[/-](?:0?[1-9]|[12]\d|3[01]))\b"
    ),
    "AADHAAR": re.compile(
        r"(?i)\b(?:aadhaar|aadhar)\s*(?:no\.?|number)?\s*[:\-]?\s*"
        r"(?P<value>\d{4}[ -]?\d{4}[ -]?\d{4})\b"
    ),
    "SSN": re.compile(
        r"(?i)\b(?:ssn|social\s+security(?:\s+number)?)\s*[:\-]?\s*"
        r"(?P<value>\d{3}-\d{2}-\d{4})\b"
    ),
    "PASSPORT_NUMBER": re.compile(
        r"(?i)\bpassport\s*(?:no\.?|number)?\s*[:\-]?\s*"
        r"(?P<value>[A-Z][0-9]{7}|[A-Z0-9]{6,12})\b"
    ),
    "NATIONAL_ID": re.compile(
        r"(?i)\b(?:national\s+id|national\s+identity(?:\s+number)?)"
        r"\s*[:\-]?\s*(?P<value>[A-Z0-9][A-Z0-9 -]{4,20}[A-Z0-9])\b"
    ),
}

LABELLED_PERSON = re.compile(
    r"(?i)\b(?:interviewee|patient|participant|respondent|name)\b(?:\s*:\s*|\s+-\s+)"
    r"(?P<value>(?:dr|mr|mrs|ms|prof\.?\s+)?"
    r"[A-Z][A-Za-z' -]+(?:\s+[A-Z][A-Za-z' -]+){1,3})"
)

TITLED_PERSON = re.compile(
    r"\b(?P<value>(?:Dr|Mr|Mrs|Ms|Prof)\.?\s+"
    r"[A-Z][A-Za-z' -]+(?:\s+[A-Z][A-Za-z' -]+){1,3})\b"
)


def _load_pharma_exclusions() -> set[str]:
    exclusions = {
        "watson", "kols", "kol", "hcps", "hcp", "executive summary", "background",
        "evidence signals", "governance note", "chunking guidance", "market access",
        "synthetic id", "field", "value", "overview", "report", "survey", "landscape",
        "study", "clinical", "efficacy", "safety", "tolerability", "trial", "trials",
        "governance", "note", "guidance", "synthetic", "section", "table", "figure",
        "appendix", "header", "footer", "objective", "methodology", "results", "conclusion",
        "keytruda", "pembrolizumab", "tecfidera", "dimethyl fumarate", "opdivo", "nivolumab",
        "oncology", "neurology", "immunology", "cardiology", "dermatology",
        "multiple sclerosis", "melanoma", "nsclc", "lung cancer", "crohn's disease",
        "united states", "united kingdom", "germany", "france", "japan", "european union"
    }
    for cand in [
        Path(__file__).resolve().parent / "seed_vocabularies.json",
        Path(__file__).resolve().parent / "data" / "seed_vocabularies.json",
    ]:
        if cand.exists():
            try:
                with open(cand, "r", encoding="utf-8") as f:
                    v = json.load(f).get("vocabularies", {})
                for fam in v.values():
                    for item in fam:
                        c_name = item.get("canonical_name", "").strip().lower()
                        if c_name:
                            exclusions.add(c_name)
                            for w in c_name.split():
                                exclusions.add(w)
                        for a in item.get("aliases", []):
                            if a.strip():
                                a_low = a.strip().lower()
                                exclusions.add(a_low)
                                for w in a_low.split():
                                    exclusions.add(w)
            except Exception:
                pass
    return exclusions

PHARMA_EXCLUSIONS = _load_pharma_exclusions()


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def load_spacy(model_name: str, required: bool):
    try:
        import spacy
        return spacy.load(model_name)
    except Exception as exc:
        if required:
            raise RuntimeError(
                f"spaCy model {model_name!r} is unavailable. "
                "Install spaCy and run: python -m spacy download en_core_web_sm. "
                f"Details: {exc}"
            ) from exc
        return None


def strategy_chunks(report: Dict[str, Any]) -> Iterable[Tuple[str, str, List[Dict[str, Any]]]]:
    strategies = report.get("strategies")
    if not isinstance(strategies, dict) or not strategies:
        raise ValueError("Expected a non-empty root 'strategies' object from chunker.py")

    for strategy_key, payload in strategies.items():
        if not isinstance(payload, dict):
            raise ValueError(f"strategies.{strategy_key} must be an object")
        chunks = payload.get("chunks")
        if not isinstance(chunks, list):
            raise ValueError(f"strategies.{strategy_key}.chunks must be a list")
        yield str(strategy_key), str(payload.get("name") or ""), chunks


def validate_chunk(chunk: Dict[str, Any]) -> None:
    required = (
        "chunk_uri",
        "parent_document_uri",
        "strategy",
        "chunk_index",
        "text",
        "source_provenance",
    )
    missing = [field for field in required if field not in chunk]
    if missing:
        raise ValueError("Chunk missing required field(s): " + ", ".join(missing))
    if not isinstance(chunk["text"], str):
        raise ValueError("chunk.text must be a string")

    start = chunk.get("char_start")
    end = chunk.get("char_end")
    if (start is None) != (end is None):
        raise ValueError("char_start and char_end must both be integers or both be null")
    if start is not None:
        if not isinstance(start, int) or not isinstance(end, int):
            raise ValueError("char_start and char_end must be integers")
        if start < 0 or end < start:
            raise ValueError("Invalid chunk character offsets")


def value_span(match: re.Match[str]) -> Tuple[int, int]:
    if "value" in match.re.groupindex and match.group("value") is not None:
        return match.span("value")
    return match.span()


def regex_findings(text: str) -> Iterable[Tuple[str, int, int, str, str, float]]:
    for pii_type, pattern in PATTERNS.items():
        for match in pattern.finditer(text):
            start, end = value_span(match)
            value = text[start:end]
            if pii_type == "PHONE":
                digit_count = len(re.sub(r"\D", "", value))
                if not 8 <= digit_count <= 15:
                    continue
            yield pii_type, start, end, value, "regex", 0.99


ADDRESS_WORDS = {"laan", "street", "st", "road", "rd", "avenue", "ave", "drive", "blvd", "way", "lane", "building", "floor", "suite", "box", "plaza"}
PHARMA_SUFFIXES = ("mab", "nib", "lib", "tinib", "zomib", "stat", "ase", "ine", "cin", "vir", "tin")


def _is_valid_person_candidate(text: str) -> bool:
    val = text.strip()
    if not val or len(val) < 3 or "\n" in val:
        return False
    if val.lower() in PHARMA_EXCLUSIONS:
        return False
    parts = val.split()
    lower_parts = [p.lower().rstrip(".,;:") for p in parts]
    if any(p in PHARMA_EXCLUSIONS for p in lower_parts):
        return False
    if any(any(p == addr or p.endswith(addr) for addr in ADDRESS_WORDS) for p in lower_parts):
        return False
    if any(any(p.endswith(sfx) for sfx in PHARMA_SUFFIXES) for p in lower_parts):
        return False
    if re.search(r"[A-Za-z]+\d+", val):
        return False
    has_title = any(lower_parts[0].startswith(tit) for tit in ("dr", "mr", "mrs", "ms", "prof"))
    if len(parts) < 2 and not has_title:
        return False
    for p in parts:
        cleaned = re.sub(r"^[('\"`]|['\")`.,;:]$", "", p)
        if cleaned and not cleaned[0].isupper():
            return False
    return True


def person_findings(text: str, nlp) -> Iterable[Tuple[str, int, int, str, str, float]]:
    seen = set()
    if nlp is not None:
        for entity in nlp(text).ents:
            if entity.label_ == "PERSON":
                if not _is_valid_person_candidate(entity.text):
                    continue
                seen.add((entity.start_char, entity.end_char))
                yield (
                    "PERSON",
                    entity.start_char,
                    entity.end_char,
                    entity.text,
                    "spacy_ner",
                    0.80,
                )

    # Deterministic supplement for explicitly labelled/titled people.
    for pattern in (LABELLED_PERSON, TITLED_PERSON):
        for match in pattern.finditer(text):
            start, end = match.span("value")
            cand_text = text[start:end].strip()
            if not _is_valid_person_candidate(cand_text):
                continue
            if (start, end) not in seen:
                seen.add((start, end))
                yield "PERSON", start, end, cand_text, "labelled_regex", 0.90


def scan_chunk(chunk: Dict[str, Any], nlp) -> List[Dict[str, Any]]:
    validate_chunk(chunk)
    text = chunk["text"]
    chunk_start: Optional[int] = chunk.get("char_start")

    candidates = list(regex_findings(text)) + list(person_findings(text, nlp))
    unique: Dict[Tuple[str, int, int], Dict[str, Any]] = {}

    for pii_type, start, end, value, detector, confidence in candidates:
        unique[(pii_type, start, end)] = {
            "type": pii_type,
            "text": value,
            "start": start,
            "end": end,
            "document_start": chunk_start + start if chunk_start is not None else None,
            "document_end": chunk_start + end if chunk_start is not None else None,
            "detector": detector,
            "confidence": confidence,
            "source_provenance": chunk["source_provenance"],
        }

    return sorted(
        unique.values(),
        key=lambda finding: (finding["start"], finding["end"], finding["type"]),
    )


def assess_report(
    report: Dict[str, Any],
    spacy_model: str = "en_core_web_sm",
    require_spacy: bool = False,
) -> Dict[str, Any]:
    nlp = load_spacy(spacy_model, require_spacy)
    document_uri = report.get("document_uri")

    chunk_assessments: List[Dict[str, Any]] = []
    deduplicated: Dict[Tuple[Any, ...], Dict[str, Any]] = {}
    strategies_assessed: List[str] = []

    for strategy_key, strategy_name, chunks in strategy_chunks(report):
        strategies_assessed.append(strategy_key)
        for chunk in chunks:
            findings = scan_chunk(chunk, nlp)
            chunk_assessments.append(
                {
                    "strategy_key": strategy_key,
                    "strategy_name": strategy_name,
                    "chunk_uri": chunk["chunk_uri"],
                    "chunk_index": chunk["chunk_index"],
                    "pii_detected": bool(findings),
                    "pii_types": sorted({finding["type"] for finding in findings}),
                    "pii_spans": findings,
                }
            )

            for finding in findings:
                if finding["document_start"] is not None:
                    identity = (
                        document_uri,
                        strategy_key,
                        finding["type"],
                        finding["document_start"],
                        finding["document_end"],
                    )
                else:
                    # Structural PPTX notes may not exist in raw_text, therefore
                    # chunk-local offsets and provenance are authoritative.
                    identity = (
                        document_uri,
                        strategy_key,
                        chunk["chunk_uri"],
                        finding["type"],
                        finding["start"],
                        finding["end"],
                    )

                row = deduplicated.setdefault(
                    identity,
                    {
                        "type": finding["type"],
                        "text": finding["text"],
                        "document_start": finding["document_start"],
                        "document_end": finding["document_end"],
                        "chunk_uris": [],
                        "source_provenance": [],
                    },
                )
                row["chunk_uris"].append(chunk["chunk_uri"])
                row["source_provenance"].append(finding["source_provenance"])

    unique_findings = list(deduplicated.values())
    for finding in unique_findings:
        finding["chunk_uris"] = list(dict.fromkeys(finding["chunk_uris"]))
        provenance_by_json = {
            json.dumps(item, sort_keys=True): item
            for item in finding["source_provenance"]
        }
        finding["source_provenance"] = list(provenance_by_json.values())

    pii_types = sorted({finding["type"] for finding in unique_findings})
    detected = bool(unique_findings)

    return {
        "schema_version": SCHEMA_VERSION,
        "module_version": MODULE_VERSION,
        "document_uri": document_uri,
        "source_filename": report.get("source_filename"),
        "format": report.get("format"),
        "pii_detected": detected,
        "overall_action": "FLAGGED_FOR_REVIEW" if detected else "CLEAR_FOR_NEXT_GATE",
        "lifecycle_recommendation": "REJECTED" if detected else "DRAFT",
        "hitl_override_required": detected,
        "lifecycle_state_changed": False,
        "lifecycle_note": (
            "PII detected: lifecycle_manager.py should reject by default unless a HITL reviewer explicitly overrides."
            if detected
            else "PII assessment completed with no findings; lifecycle_manager.py may assign DRAFT and continue."
        ),
        "assessment_timestamp": utc_now(),
        "strategies_assessed": strategies_assessed,
        "chunk_assessments": chunk_assessments,
        "deduplicated_findings": unique_findings,
        "summary": {
            "chunk_count_assessed": len(chunk_assessments),
            "affected_chunk_count": sum(
                1 for assessment in chunk_assessments if assessment["pii_detected"]
            ),
            "unique_finding_count": len(unique_findings),
            "pii_types": pii_types,
        },
    }


def append_pii_audit_event(audit_path: Path, assessment: Dict[str, Any]) -> None:
    """Append the PRD-required PII_FLAG event without copying raw PII values."""
    if not assessment["pii_detected"]:
        return
    event = {
        "timestamp": utc_now(),
        "event_type": "PII_FLAG",
        "document_uri": assessment.get("document_uri"),
        "details": {
            "pii_types": assessment["summary"]["pii_types"],
            "affected_chunk_count": assessment["summary"]["affected_chunk_count"],
            "unique_finding_count": assessment["summary"]["unique_finding_count"],
            "overall_action": assessment["overall_action"],
            "lifecycle_recommendation": assessment.get("lifecycle_recommendation"),
            "hitl_override_required": assessment.get("hitl_override_required", False),
        },
    }
    audit_path.parent.mkdir(parents=True, exist_ok=True)
    with audit_path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(event, ensure_ascii=False) + "\n")


def output_name(input_path: Path) -> str:
    stem = input_path.stem
    if stem.endswith("_chunks"):
        stem = stem[:-7]
    return f"{stem}_pii.json"


def process_file(
    input_path: Path,
    output_dir: Path,
    audit_log: Path,
    spacy_model: str,
    require_spacy: bool,
) -> Path:
    report = json.loads(input_path.read_text(encoding="utf-8"))
    assessment = assess_report(report, spacy_model, require_spacy)

    output_dir.mkdir(parents=True, exist_ok=True)
    output_path = output_dir / output_name(input_path)
    output_path.write_text(
        json.dumps(assessment, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    append_pii_audit_event(audit_log, assessment)
    return output_path


def discover_inputs(path: Path) -> List[Path]:
    if path.is_file():
        return [path]
    if path.is_dir():
        return sorted(path.glob("*_chunks.json"))
    return []


def main() -> int:
    parser = argparse.ArgumentParser(description="Watson chunk-level PII detector")
    parser.add_argument("input", help="Chunk JSON file or directory")
    parser.add_argument("--output-dir", default="staging")
    parser.add_argument("--audit-log", default="audit_log.jsonl")
    parser.add_argument("--spacy-model", default="en_core_web_sm")
    parser.add_argument("--require-spacy", action="store_true")
    args = parser.parse_args()

    inputs = discover_inputs(Path(args.input))
    if not inputs:
        print(f"No *_chunks.json files found: {args.input}")
        return 1

    success = 0
    for input_path in inputs:
        try:
            output_path = process_file(
                input_path,
                Path(args.output_dir),
                Path(args.audit_log),
                args.spacy_model,
                args.require_spacy,
            )
            result = json.loads(output_path.read_text(encoding="utf-8"))
            print(
                json.dumps(
                    {
                        "input": str(input_path),
                        "output": str(output_path),
                        "document_uri": result["document_uri"],
                        "pii_detected": result["pii_detected"],
                        "overall_action": result["overall_action"],
                        "pii_types": result["summary"]["pii_types"],
                    },
                    ensure_ascii=False,
                )
            )
            success += 1
        except Exception as exc:
            print(f"ERROR processing {input_path.name}: {exc}")
    print(f"PII assessment complete: {success}/{len(inputs)} file(s)")
    return 0 if success == len(inputs) else 1


@lru_cache(maxsize=1)
def _local_pii_nlp():
    try:
        import spacy
        return spacy.load("en_core_web_sm")
    except Exception:
        return None


def detect_pii_entities(text: str) -> List[Dict[str, Any]]:
    """Scan text using one cached local NLP model, plus regex checks."""
    nlp = _local_pii_nlp()
    dummy = {
        "text": text,
        "chunk_uri": "watson:temp_chunk",
        "parent_document_uri": "watson:temp_doc",
        "strategy": "B",
        "chunk_index": 0,
        "source_provenance": {},
        "char_start": 0,
        "char_end": len(text),
    }
    return scan_chunk(dummy, nlp)


def mask_pii_text(text: str, findings: List[Dict[str, Any]]) -> str:
    """Masks detected PII spans in text with category tags."""
    sorted_f = sorted(findings, key=lambda x: x.get("start", 0), reverse=True)
    masked = text
    for f in sorted_f:
        s, e = f.get("start", 0), f.get("end", 0)
        cat = f.get("type", "PII")
        masked = masked[:s] + f"[{cat}_REDACTED]" + masked[e:]
    return masked


if __name__ == "__main__":
    raise SystemExit(main())
