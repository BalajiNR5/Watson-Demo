"""
Watson Platform — Artifact-Driven Visual Graph Explorer & Data Catalog Service
==============================================================================
Constructs the live graph payload for the KG Explorer UI directly from:
1. `outputs/databricks_pharma_product_catalog.json`
2. `outputs/ingestion_summary.json`
3. `outputs/semantic_mapping_report.json`
4. `data/seed/seed_vocabularies.json`
5. `ontology/pharma.ttl` and `ontology/pharma_kg_inferred.ttl` (`assembler.graph`)

Never fabricates mock nodes or edges. Supports View A (Databricks Product Model),
View B (Watson Semantic Model), View C (Integrated Mapping View - Default),
and interactive Data Catalog + Entity Mapping inspection.
"""
from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

import rdflib
from rdflib import Graph, Namespace, OWL, RDF, RDFS, URIRef

from watson.ingestion.databricks_metadata_ingestor import (
    CATALOG_OUTPUT_FILE,
    SUMMARY_OUTPUT_FILE,
    DatabricksProductMetadataIngestor,
)
from watson.semantics.metadata_compatibility import (
    MAPPING_REPORT_FILE,
    SemanticCompatibilityEngine,
)
from watson.shared.config import (
    PHARMA_KG_FILE,
    PHARMA_KG_INFERRED_FILE,
    PHARMA_ONTOLOGY_FILE,
    SEED_VOCABULARIES_FILE,
)

logger = logging.getLogger("watson.semantics.graph_explorer")

WATSON = Namespace("http://watson.pharma.org/ontology/")
ENTITY = Namespace("http://watson.pharma.org/entity/")


class GraphExplorerService:
    """Builds the unified graph, data catalog, and entity mapping payload from real artifacts."""

    def __init__(
        self,
        catalog_path: Path = CATALOG_OUTPUT_FILE,
        summary_path: Path = SUMMARY_OUTPUT_FILE,
        mapping_path: Path = MAPPING_REPORT_FILE,
        seed_vocab_path: Path = SEED_VOCABULARIES_FILE,
        ontology_path: Path = PHARMA_ONTOLOGY_FILE,
        kg_path: Path = PHARMA_KG_INFERRED_FILE,
    ):
        self.catalog_path = Path(catalog_path)
        self.summary_path = Path(summary_path)
        self.mapping_path = Path(mapping_path)
        self.seed_vocab_path = Path(seed_vocab_path)
        self.ontology_path = Path(ontology_path)
        self.kg_path = Path(kg_path if kg_path.exists() else PHARMA_KG_FILE)
        self._last_known_good_payload: Optional[Dict[str, Any]] = None

    def ensure_artifacts_exist(self) -> None:
        """Generates initial Databricks catalog and mapping report if not yet present."""
        if not self.catalog_path.exists() or not self.summary_path.exists():
            ingestor = DatabricksProductMetadataIngestor(
                catalog_path=self.catalog_path,
                summary_path=self.summary_path,
            )
            ingestor.ingest(actor_id="SYSTEM_INIT")
        if not self.mapping_path.exists():
            compat = SemanticCompatibilityEngine(
                seed_vocab_path=self.seed_vocab_path,
                catalog_path=self.catalog_path,
                mapping_output_path=self.mapping_path,
            )
            compat.generate_mappings(actor_id="SYSTEM_INIT")

    def build_explorer_payload(self, runtime_graph: Optional[Graph] = None) -> Dict[str, Any]:
        """
        Assembles the complete, deduplicated nodes, edges, data catalog, and mapping
        records from actual generated artifacts and Watson's semantic graph.
        """
        try:
            self.ensure_artifacts_exist()
            catalog = json.loads(self.catalog_path.read_text(encoding="utf-8"))
            summary = json.loads(self.summary_path.read_text(encoding="utf-8"))
            mapping_report = json.loads(self.mapping_path.read_text(encoding="utf-8"))
            seed_vocab = json.loads(self.seed_vocab_path.read_text(encoding="utf-8"))

            g = runtime_graph
            if g is None or len(g) == 0:
                g = Graph()
                if self.ontology_path.exists():
                    g.parse(str(self.ontology_path), format="turtle")
                if self.kg_path.exists():
                    g.parse(str(self.kg_path), format="turtle")

            nodes_by_id: Dict[str, Dict[str, Any]] = {}
            edges_by_id: Dict[str, Dict[str, Any]] = {}

            def add_node(node: Dict[str, Any]) -> None:
                nid = node["id"]
                if nid not in nodes_by_id:
                    nodes_by_id[nid] = node

            def add_edge(edge: Dict[str, Any]) -> None:
                eid = edge["id"]
                if eid not in edges_by_id:
                    edges_by_id[eid] = edge

            model_ident = catalog.get("model_identity", {})
            model_ver = model_ident.get("version", "v1")
            prov = catalog.get("provenance", {})

            # Lookup map for product mappings
            prod_map_lookup: Dict[str, Dict[str, Any]] = {
                m["source_concept_name"]: m
                for m in mapping_report.get("product_mappings", [])
            }

            # -----------------------------------------------------------------
            # 1. Databricks Data Products, Key Attributes & Schema Relationships
            # -----------------------------------------------------------------
            for prod in catalog.get("products", []):
                pname = prod["name"]
                pid = prod["id"]  # dbx:product:product.<name>
                m_info = prod_map_lookup.get(pname, {})
                m_status = m_info.get("mapping_status", "UNRESOLVED")

                add_node({
                    "id": pid,
                    "label": pname,
                    "display_name": f"product.{pname}",
                    "node_type": "DATABRICKS_PRODUCT",
                    "model_source": "DATABRICKS",
                    "source_model": "Databricks Pharmaceuticals Product MVM",
                    "source_model_name": "Databricks Pharmaceuticals Product MVM",
                    "version": model_ver,
                    "domain": "product",
                    "subdomain": prod["subdomain"],
                    "description": prod["description"],
                    "primary_key": prod["primary_key"],
                    "attribute_count": prod["attribute_count"],
                    "foreign_key_count": prod["foreign_key_count"],
                    "intra_domain_fk_count": prod.get("intra_domain_fk_count", 0),
                    "cross_domain_fk_count": prod.get("cross_domain_fk_count", 0),
                    "attributes": prod["attributes"],
                    "mapping_status": m_status,
                    "mapped_target_id": m_info.get("target_concept_id"),
                    "mapped_target_name": m_info.get("target_concept_name"),
                    "mapping_rationale": m_info.get("rationale"),
                    "conflict_notes": m_info.get("conflict_notes"),
                    "validation_notes": m_info.get("validation_status", "VERIFIED"),
                    "aligned_watson_instances": m_info.get("aligned_watson_instances", []),
                    "provenance": {
                        "source_type": prov.get("source_mode", "databricks_mvm"),
                        "authoritative_url": prov.get("authoritative_url"),
                        "source_url": prov.get("authoritative_url"),
                        "source_mode": prov.get("source_mode"),
                        "ingested_at_utc": prov.get("ingested_at_utc"),
                        "catalog_fingerprint": catalog.get("catalog_fingerprint_sha256"),
                    },
                })

                # Add primary key, foreign key, and mapped semantic attributes as inspectable graph nodes
                mapped_attr_names = {
                    am["source_attribute"] for am in m_info.get("attribute_mappings", [])
                }
                for attr in prod.get("attributes", []):
                    aname = attr["name"]
                    is_key_or_mapped = (
                        attr["is_primary_key"]
                        or attr["is_foreign_key"]
                        or aname in mapped_attr_names
                        or aname in {
                            "product_name",
                            "drug_substance_name",
                            "indication_name",
                            "therapeutic_area_name",
                            "excipient_name",
                            "formulation_name",
                            "sku_code",
                            "ndc_11_digit",
                            "identifier_value",
                            "label_type",
                            "lifecycle_stage",
                            "real_world_evidence_score",
                        }
                    )
                    if is_key_or_mapped:
                        aid = attr["id"]
                        attr_map_match = next(
                            (am for am in m_info.get("attribute_mappings", []) if am["source_attribute"] == aname),
                            None,
                        )
                        add_node({
                            "id": aid,
                            "label": f"{pname}.{aname}",
                            "short_label": aname,
                            "display_name": f"product.{pname}.{aname}",
                            "node_type": "DATABRICKS_ATTRIBUTE",
                            "model_source": "DATABRICKS",
                            "source_model": "Databricks Pharmaceuticals Product MVM",
                            "source_model_name": "Databricks Pharmaceuticals Product MVM",
                            "version": model_ver,
                            "domain": "product",
                            "subdomain": prod["subdomain"],
                            "parent_product": pname,
                            "parent_product_id": pid,
                            "data_type": attr["data_type"],
                            "description": attr["description"],
                            "is_primary_key": attr["is_primary_key"],
                            "is_foreign_key": attr["is_foreign_key"],
                            "references": attr.get("references"),
                            "classification_tag": attr.get("classification_tag", "public"),
                            "mapping_status": attr_map_match["status"] if attr_map_match else m_status,
                            "mapped_target_id": attr_map_match["target_property"] if attr_map_match else None,
                            "mapping_rationale": (
                                f"Column '{aname}' ({attr['data_type']}) in product.{pname}."
                                + (f" Mapped to {attr_map_match['target_property']}." if attr_map_match else "")
                            ),
                            "validation_notes": "KEY_ATTRIBUTE" if (attr["is_primary_key"] or attr["is_foreign_key"]) else "SEMANTIC_ATTRIBUTE",
                            "provenance": {
                                "source_type": prov.get("source_mode", "databricks_mvm"),
                                "authoritative_url": prov.get("authoritative_url"),
                                "source_url": prov.get("authoritative_url"),
                                "ingested_at_utc": prov.get("ingested_at_utc"),
                            },
                        })
                        add_edge({
                            "id": f"edge:contains:{pid}->{aid}",
                            "source": pid,
                            "target": aid,
                            "label": "CONTAINS_ATTRIBUTE",
                            "relationship_type": "CONTAINS_ATTRIBUTE",
                            "model_scope": "DATABRICKS",
                            "subdomain": prod["subdomain"],
                        })

            # Foreign key relationships (both product->product and attribute->target)
            for fk in catalog.get("relationships", {}).get("foreign_keys", []):
                src_pid = fk["source_id"]
                tgt_pid = fk["target_id"]
                src_prod_obj = next((p for p in catalog["products"] if p["id"] == src_pid), None)
                sub_name = src_prod_obj["subdomain"] if src_prod_obj else "product identity"

                if not fk["is_intra_domain"]:
                    ext_domain = fk["target_domain"]
                    ext_table = fk["target_product"]
                    ext_qname = f"{ext_domain}.{ext_table}"
                    add_node({
                        "id": tgt_pid,
                        "label": ext_qname,
                        "display_name": ext_qname,
                        "node_type": "EXTERNAL_SCHEMA_ENDPOINT",
                        "model_source": "DATABRICKS",
                        "source_model": "Databricks Pharmaceuticals MVM (Cross-Domain Reference)",
                        "source_model_name": "Databricks Pharmaceuticals MVM (Cross-Domain Reference)",
                        "version": model_ver,
                        "domain": ext_domain,
                        "subdomain": "cross-domain reference",
                        "description": f"External Databricks MVM table '{ext_qname}' referenced by foreign key '{fk['source_product']}.{fk['source_column']}'.",
                        "primary_key": [fk["target_column"]],
                        "mapping_status": "CONFLICT" if ext_qname == "masterdata.country" else "UNRESOLVED",
                        "mapped_target_id": "watson:Geography" if ext_qname == "masterdata.country" else None,
                        "mapping_rationale": (
                            "Cross-domain country FK has scope conflict with Watson supranational Geography (EU/Global)."
                            if ext_qname == "masterdata.country"
                            else f"Cross-domain schema reference target in '{ext_domain}' domain."
                        ),
                        "validation_notes": "EXTERNAL_DOMAIN_REFERENCE",
                        "provenance": {
                            "source_type": prov.get("source_mode", "databricks_mvm"),
                            "authoritative_url": prov.get("authoritative_url"),
                            "source_url": prov.get("authoritative_url"),
                            "ingested_at_utc": prov.get("ingested_at_utc"),
                        },
                    })

                add_edge({
                    "id": fk["id"],
                    "source": src_pid,
                    "target": tgt_pid,
                    "label": f"FK: {fk['source_column']} → {fk['target_product']}.{fk['target_column']}",
                    "relationship_type": "FOREIGN_KEY_TO",
                    "source_column": fk["source_column"],
                    "target_column": fk["target_column"],
                    "is_intra_domain": fk["is_intra_domain"],
                    "model_scope": "DATABRICKS",
                    "subdomain": sub_name,
                })

            # -----------------------------------------------------------------
            # 2. Watson Ontology Classes (Layer 2 OWL Schema)
            # -----------------------------------------------------------------
            watson_classes = [
                ("watson:TherapeuticArea", "TherapeuticArea", "Medical therapeutic area class (Oncology, Immunology, Cardiology, Neurology, Rare Disease, Respiratory, Metabolic).", None, "EXACT"),
                ("watson:Brand", "Brand", "Commercial pharmaceutical brand product class (e.g., Keytruda, Dupixent, Farxiga).", None, "CONFLICT"),
                ("watson:Drug", "Drug", "Active pharmaceutical ingredient / chemical or biologic drug substance class.", None, "EXACT"),
                ("watson:BiologicDrug", "BiologicDrug", "Monoclonal antibody, recombinant protein, or biologic therapy subclass of watson:Drug.", "watson:Drug", "EXACT"),
                ("watson:SmallMoleculeDrug", "SmallMoleculeDrug", "Chemically synthesized small-molecule drug subclass of watson:Drug.", "watson:Drug", "EXACT"),
                ("watson:Indication", "Indication", "Approved or investigational disease condition treated by a Brand or Drug.", None, "EXACT"),
                ("watson:Geography", "Geography", "Country or supranational market region (Global, US, EU, UK, Germany, France, Japan, India, Canada).", None, "CONFLICT"),
                ("watson:StudyType", "StudyType", "Market research study design template (e.g., HCP Perception Survey, Competitive Landscape Report).", None, "UNRESOLVED"),
                ("watson:Document", "Document", "Root governed document class in Watson Layer 1/2.", None, "PROPOSED"),
                ("watson:MarketResearchDocument", "MarketResearchDocument", "Governed pharmaceutical market research document subclass of watson:Document.", "watson:Document", "UNRESOLVED"),
                ("watson:EvidenceChunk", "EvidenceChunk", "Governed document text chunk indexed in FAISS and linked to provenance.", None, "UNRESOLVED"),
                ("watson:Finding", "Finding", "Clinical, commercial, or market access finding extracted from evidence chunks.", None, "UNRESOLVED"),
                ("watson:ClinicalFinding", "ClinicalFinding", "Clinical efficacy, safety, or biomarker finding subclass of watson:Finding.", "watson:Finding", "UNRESOLVED"),
                ("watson:CommercialFinding", "CommercialFinding", "Market share, pricing, or commercial adoption finding subclass of watson:Finding.", "watson:Finding", "UNRESOLVED"),
            ]

            for cid, clabel, cdesc, parent_cid, c_map_status in watson_classes:
                add_node({
                    "id": cid,
                    "label": clabel,
                    "display_name": cid,
                    "node_type": "WATSON_CLASS",
                    "model_source": "WATSON",
                    "source_model": "Watson OWL 2 RL Ontology (ontology/pharma.ttl)",
                    "source_model_name": "Watson OWL 2 RL Ontology (ontology/pharma.ttl)",
                    "version": seed_vocab.get("vocabulary_version", "0.1-poc"),
                    "domain": "watson_ontology",
                    "subdomain": "owl_classes",
                    "description": cdesc,
                    "mapping_status": c_map_status,
                    "mapping_rationale": f"Formal OWL class '{cid}' in ontology/pharma.ttl.",
                    "validation_notes": "WATSON_OWL_CLASS",
                    "provenance": {
                        "source_type": "watson_ontology",
                        "source_file": "ontology/pharma.ttl",
                        "uri": f"http://watson.pharma.org/ontology/{clabel}",
                    },
                })
                if parent_cid:
                    add_edge({
                        "id": f"edge:subclass:{cid}->{parent_cid}",
                        "source": cid,
                        "target": parent_cid,
                        "label": "SUBCLASS_OF",
                        "relationship_type": "SUBCLASS_OF",
                        "model_scope": "WATSON",
                        "subdomain": "owl_classes",
                    })

            # -----------------------------------------------------------------
            # 3. Watson Curated Vocabulary Entities (`seed_vocabularies.json` + KG)
            # -----------------------------------------------------------------
            family_to_owl_class = {
                "therapeutic_areas": "watson:TherapeuticArea",
                "brands": "watson:Brand",
                "drugs": "watson:Drug",
                "indications": "watson:Indication",
                "geographies": "watson:Geography",
                "study_templates": "watson:StudyType",
            }
            family_to_dbx_table = {
                "therapeutic_areas": ("dbx:product:product.therapeutic_area", "EXACT"),
                "brands": ("dbx:product:product.medicinal_product", "CONFLICT"),
                "drugs": ("dbx:product:product.drug_substance", "EXACT"),
                "indications": ("dbx:product:product.indication", "EXACT"),
                "geographies": ("dbx:external:masterdata.country", "CONFLICT"),
                "study_templates": (None, "UNRESOLVED"),
            }

            vocab_families = seed_vocab.get("vocabularies", {})
            for fam_name, items in vocab_families.items():
                owl_cls = family_to_owl_class.get(fam_name, "watson:Entity")
                dbx_tbl, fam_status = family_to_dbx_table.get(fam_name, (None, "UNRESOLVED"))
                for item in items:
                    eid = item.get("canonical_id") or item["id"]
                    ename = item["canonical_name"]
                    aliases = item.get("aliases", [])
                    add_node({
                        "id": eid,
                        "label": ename,
                        "display_name": f"{ename} ({eid})",
                        "node_type": "WATSON_ENTITY",
                        "model_source": "WATSON",
                        "source_model": "Watson Curated Seed Vocabulary (seed_vocabularies.json)",
                        "source_model_name": "Watson Curated Seed Vocabulary (seed_vocabularies.json)",
                        "version": seed_vocab.get("vocabulary_version", "0.1-poc"),
                        "domain": "watson_vocabulary",
                        "subdomain": fam_name,
                        "owl_class": owl_cls,
                        "aliases": aliases,
                        "description": (
                            f"Curated Watson canonical entity '{ename}' ({eid}) in family '{fam_name}'. "
                            f"Aliases: {', '.join(aliases) if aliases else 'none'}."
                        ),
                        "mapping_status": fam_status,
                        "mapped_target_id": dbx_tbl,
                        "mapping_rationale": (
                            f"Instance of '{owl_cls}'. Note: '{eid}' is a specific domain entity instance, NOT a schema table definition. "
                            + (
                                f"Its parent class '{owl_cls}' aligns with Databricks table '{dbx_tbl}' ({fam_status})."
                                if dbx_tbl
                                else "Watson-native study template concept with no Databricks Product table counterpart."
                            )
                        ),
                        "validation_notes": "CURATED_SEED_ENTITY",
                        "provenance": {
                            "source_type": "seed_vocabularies",
                            "source_file": "data/seed/seed_vocabularies.json",
                            "canonical_id": eid,
                            "generated_at_utc": seed_vocab.get("generated_at_utc"),
                        },
                    })
                    add_edge({
                        "id": f"edge:instance:{eid}->{owl_cls}",
                        "source": eid,
                        "target": owl_cls,
                        "label": "INSTANCE_OF",
                        "relationship_type": "INSTANCE_OF",
                        "model_scope": "WATSON",
                        "subdomain": fam_name,
                    })

                    if fam_name == "brands" and item.get("drug_id"):
                        add_edge({
                            "id": f"edge:brand_drug:{eid}->{item['drug_id']}",
                            "source": eid,
                            "target": item["drug_id"],
                            "label": "IS_BRAND_OF",
                            "relationship_type": "IS_BRAND_OF",
                            "model_scope": "WATSON",
                            "subdomain": "brands",
                        })

                    if fam_name == "indications" and item.get("therapeutic_area_id"):
                        add_edge({
                            "id": f"edge:ind_ta:{eid}->{item['therapeutic_area_id']}",
                            "source": eid,
                            "target": item["therapeutic_area_id"],
                            "label": "IN_THERAPEUTIC_AREA",
                            "relationship_type": "IN_THERAPEUTIC_AREA",
                            "model_scope": "WATSON",
                            "subdomain": "indications",
                        })

            for s, p, o in g.triples((None, WATSON.treatsIndication, None)):
                s_local = str(s).split("/")[-1]
                o_local = str(o).split("/")[-1]
                b_id = f"brand:{s_local}"
                i_id = f"indication:{o_local}"
                if b_id in nodes_by_id and i_id in nodes_by_id:
                    add_edge({
                        "id": f"edge:treats:{b_id}->{i_id}",
                        "source": b_id,
                        "target": i_id,
                        "label": "TREATS_INDICATION",
                        "relationship_type": "TREATS_INDICATION",
                        "model_scope": "WATSON",
                        "subdomain": "brands",
                    })

            for s, p, o in g.triples((None, WATSON.competesWith, None)):
                s_local = str(s).split("/")[-1]
                o_local = str(o).split("/")[-1]
                b1 = f"brand:{s_local}"
                b2 = f"brand:{o_local}"
                if b1 < b2 and b1 in nodes_by_id and b2 in nodes_by_id:
                    add_edge({
                        "id": f"edge:competes:{b1}<->{b2}",
                        "source": b1,
                        "target": b2,
                        "label": "COMPETES_WITH",
                        "relationship_type": "COMPETES_WITH",
                        "model_scope": "WATSON",
                        "subdomain": "brands",
                    })

            # -----------------------------------------------------------------
            # 4. Explicit Cross-Model Mapping Edges (Databricks <-> Watson)
            # -----------------------------------------------------------------
            for m in mapping_report.get("product_mappings", []) + mapping_report.get("cross_domain_mappings", []):
                src_id = m["source_concept_id"]
                tgt_id = m.get("target_concept_id")
                m_status = m["mapping_status"]
                if tgt_id and src_id in nodes_by_id and tgt_id in nodes_by_id:
                    add_edge({
                        "id": f"edge:map:{src_id}->{tgt_id}",
                        "source": src_id,
                        "target": tgt_id,
                        "label": f"MAPPED_TO ({m_status})",
                        "relationship_type": "MAPPED_TO",
                        "mapping_status": m_status,
                        "rationale": m["rationale"],
                        "conflict_notes": m.get("conflict_notes"),
                        "confidence": m.get("confidence", 0.0),
                        "model_scope": "CROSS_MODEL",
                        "subdomain": m.get("source_subdomain", "cross-model"),
                    })

            nodes_list = list(nodes_by_id.values())
            edges_list = list(edges_by_id.values())

            dbx_nodes = [n for n in nodes_list if n["model_source"] == "DATABRICKS"]
            dbx_node_ids = {n["id"] for n in dbx_nodes}
            dbx_edges = [e for e in edges_list if e["source"] in dbx_node_ids and e["target"] in dbx_node_ids]

            watson_nodes = [n for n in nodes_list if n["model_source"] == "WATSON"]
            watson_node_ids = {n["id"] for n in watson_nodes}
            watson_edges = [e for e in edges_list if e["source"] in watson_node_ids and e["target"] in watson_node_ids]

            raw_diff = summary.get("diff", catalog.get("last_refresh_diff", {}))
            prod_diff = raw_diff.get("products", {})
            added_attr_items = raw_diff.get("attributes", {}).get("added_items", [])
            changed_prod_details = []
            for cp in prod_diff.get("changed", []):
                if isinstance(cp, dict):
                    changed_prod_details.append(cp)
                else:
                    p_added = [
                        (a.get("attribute") or a.get("name") or str(a)).split(".")[-1]
                        if isinstance(a, dict)
                        else str(a).split(".")[-1]
                        for a in added_attr_items
                        if (isinstance(a, dict) and (a.get("product") == cp or str(a.get("attribute", "")).startswith(f"{cp}.")))
                        or (isinstance(a, str) and a.startswith(f"{cp}."))
                    ]
                    changed_prod_details.append({"product": cp, "added_attributes": p_added})
            normalized_diff_summary = {
                "is_initial_ingest": raw_diff.get("is_initial_ingest", False),
                "previous_version": raw_diff.get("previous_version"),
                "new_version": raw_diff.get("new_version", model_ver),
                "added_products": prod_diff.get("added", []),
                "changed_products": changed_prod_details,
                "removed_products": prod_diff.get("removed", []),
                "unchanged_products_count": prod_diff.get("unchanged_count", len(prod_diff.get("unchanged", []))),
                "added_attributes_count": raw_diff.get("attributes", {}).get("added_count", 0),
                "added_attribute_items": added_attr_items,
            }

            # Enrich product_mappings with convenience keys for UI & tests
            enriched_product_mappings = []
            for pm in mapping_report.get("product_mappings", []) + mapping_report.get("cross_domain_mappings", []) + mapping_report.get("watson_only_concepts", []):
                item = dict(pm)
                item.setdefault("databricks_product", pm.get("source_concept_name"))
                item.setdefault("databricks_subdomain", pm.get("source_subdomain"))
                item.setdefault("watson_target_uri", pm.get("target_concept_id"))
                item.setdefault("watson_target_label", pm.get("target_concept_name"))
                enriched_product_mappings.append(item)

            enriched_attribute_mappings = []
            for am in mapping_report.get("attribute_mappings", []):
                item = dict(am)
                item.setdefault("databricks_product", am.get("source_product"))
                item.setdefault("databricks_attribute", am.get("source_attribute"))
                item.setdefault("watson_Target", am.get("target_property"))
                item.setdefault("mapping_status", am.get("status", "EXACT"))
                enriched_attribute_mappings.append(item)

            status_breakdown = mapping_report.get("summary_counts", {}).get("product_mapping_status_breakdown", {})

            counts_obj = {
                "total_nodes": len(nodes_list),
                "total_edges": len(edges_list),
                "databricks_products": sum(1 for n in nodes_list if n["node_type"] == "DATABRICKS_PRODUCT"),
                "databricks_attributes_rendered": sum(1 for n in nodes_list if n["node_type"] == "DATABRICKS_ATTRIBUTE"),
                "databricks_attributes_total_catalog": catalog["counts"]["attributes_count"],
                "external_schema_endpoints": sum(1 for n in nodes_list if n["node_type"] == "EXTERNAL_SCHEMA_ENDPOINT"),
                "watson_classes": sum(1 for n in nodes_list if n["node_type"] == "WATSON_CLASS"),
                "watson_entities": sum(1 for n in nodes_list if n["node_type"] == "WATSON_ENTITY"),
                "cross_model_mappings": sum(1 for e in edges_list if e["relationship_type"] == "MAPPED_TO"),
                "rdf_graph_triples": len(g),
                "mapping_status_counts": status_breakdown,
            }

            summary_obj = {
                "databricks_products_count": counts_obj["databricks_products"],
                "databricks_attributes_count": catalog["counts"]["attributes_count"],
                "databricks_foreign_keys_count": catalog["counts"]["foreign_keys_total"],
                "watson_classes_count": counts_obj["watson_classes"],
                "watson_entities_count": counts_obj["watson_entities"],
                "mapping_status_counts": status_breakdown,
            }

            payload = {
                "status": "READY",
                "generated_at": summary.get("ingested_at_utc"),
                "default_view": "integrated",
                "model_identity": model_ident,
                "provenance": prov,
                "last_refresh_diff": raw_diff,
                "refresh_state": {
                    "last_successful_refresh": summary.get("ingested_at_utc"),
                    "source_version": model_ver,
                    "diff_summary": normalized_diff_summary,
                    "used_last_known_good": summary.get("used_last_known_good", False),
                },
                "seed_vocabulary_verification": mapping_report.get("seed_vocabulary_verification", {}),
                "counts": counts_obj,
                "summary": summary_obj,
                "views": {
                    "integrated": {
                        "title": "View C: Integrated Semantic Mapping View (Default)",
                        "description": "Databricks Pharmaceuticals Product MVM tables mapped to Watson OWL classes & curated entities",
                        "nodes": nodes_list,
                        "edges": edges_list,
                    },
                    "databricks": {
                        "title": "View A: Databricks Pharmaceuticals Product MVM Model",
                        "description": "15 Product domain tables (Market Authorization & Product Identity), key attributes, and foreign keys",
                        "nodes": dbx_nodes,
                        "edges": dbx_edges,
                    },
                    "watson": {
                        "title": "View B: Watson Curated Semantic Model",
                        "description": "Watson OWL 2 RL classes and 52 curated entities (Brands, Drugs, Indications, Therapeutic Areas)",
                        "nodes": watson_nodes,
                        "edges": watson_edges,
                    },
                },
                "nodes": nodes_list,
                "edges": edges_list,
                "catalog_products": catalog.get("products", []),
                "subdomains": catalog.get("subdomains", []),
                "mappings": mapping_report.get("mappings", []),
                "product_mappings": enriched_product_mappings,
                "attribute_mappings": enriched_attribute_mappings,
            }
            self._last_known_good_payload = payload
            return payload

        except Exception as exc:
            logger.exception("Failed to build Graph Explorer payload")
            if self._last_known_good_payload is not None:
                fallback = dict(self._last_known_good_payload)
                fallback["refresh_warning"] = f"Refresh failed ({exc}); displaying last-known-good graph state."
                return fallback
            raise
