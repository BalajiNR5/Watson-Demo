# entity_resolver.py
"""
Watson Layer 2 — Entity Resolver
Resolves NER mentions to canonical semantic entities following the strict PRD hierarchy:
1. Exact canonical match
2. Case-insensitive canonical / alias match
3. RapidFuzz similarity > 0.85
4. Otherwise provisional / HITL escalation (recorded in provisional_entities.json)

Emits ENTITY_RESOLUTION audit events.
"""

from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
import json
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from rapidfuzz import fuzz

try:
    from watson.shared.config import (
        SEED_VOCABULARIES_FILE as VOCAB_PATH,
        TAXONOMY_STORE_FILE as TAXONOMY_PATH,
        AUDIT_LOG_FILE as AUDIT_LOG_PATH,
        PROVISIONAL_ENTITIES_FILE as PROVISIONAL_ENTITIES_PATH,
    )
except ImportError:
    ROOT = Path(__file__).resolve().parent
    VOCAB_PATH = ROOT / "data" / "seed_vocabularies.json"
    if not VOCAB_PATH.exists():
        VOCAB_PATH = ROOT / "seed_vocabularies.json"
    TAXONOMY_PATH = ROOT / "taxonomy_store.json"
    AUDIT_LOG_PATH = ROOT / "audit_log.jsonl"
    PROVISIONAL_ENTITIES_PATH = ROOT / "provisional_entities.json"
ENTITY_BASE_URI = "http://watson.pharma.org/entity/"


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass
class ResolutionDecision:
    mention: str
    entity_type: str
    document_uri: str
    chunk_uri: str
    canonical_id: Optional[str]
    canonical_name: Optional[str]
    canonical_uri: Optional[str]
    resolution_method: str
    confidence: float
    status: str  # "RESOLVED" or "PROVISIONAL"
    timestamp: str
    char_start: Optional[int] = None
    char_end: Optional[int] = None

    @property
    def tier_matched(self) -> int:
        if self.resolution_method == "EXACT_CANONICAL":
            return 1
        elif "ALIAS" in self.resolution_method or "CASE_INSENSITIVE" in self.resolution_method:
            return 2
        elif "FUZZY" in self.resolution_method:
            return 3
        return 4


class EntityResolver:
    """Multi-tiered pharmaceutical entity resolver."""

    def __init__(
        self,
        vocab_path: Optional[Path | str] = None,
        taxonomy_path: Optional[Path | str] = None,
        audit_path: Optional[Path | str] = None,
        provisional_path: Optional[Path | str] = None,
    ):
        self.vocab_path = Path(vocab_path) if vocab_path else VOCAB_PATH
        self.taxonomy_path = Path(taxonomy_path) if taxonomy_path else TAXONOMY_PATH
        self.audit_path = Path(audit_path) if audit_path else AUDIT_LOG_PATH
        self.provisional_path = Path(provisional_path) if provisional_path else PROVISIONAL_ENTITIES_PATH
        
        self.entities_by_type: Dict[str, List[Dict[str, Any]]] = {}
        self._load_knowledge()

    def _load_knowledge(self) -> None:
        """Loads canonical entities from seed vocabulary and taxonomy."""
        if not self.vocab_path.exists():
            raise FileNotFoundError(f"Vocab file missing: {self.vocab_path}")

        with open(self.vocab_path, "r", encoding="utf-8") as f:
            vdata = json.load(f)["vocabularies"]

        type_mapping = {
            "Brand": ("brands", "brand"),
            "Drug": ("drugs", "drug"),
            "Indication": ("indications", "indication"),
            "TherapeuticArea": ("therapeutic_areas", "ta"),
            "Geography": ("geographies", "geo"),
            "StudyType": ("study_templates", "study"),
        }

        for etype, (vkey, prefix) in type_mapping.items():
            self.entities_by_type[etype] = []
            for item in vdata.get(vkey, []):
                cid = item["id"]
                local_name = cid.split(":")[-1]
                curi = f"{ENTITY_BASE_URI}{prefix}/{local_name}"
                self.entities_by_type[etype].append({
                    "id": cid,
                    "canonical_name": item["canonical_name"],
                    "uri": curi,
                    "aliases": item.get("aliases", []),
                    "status": item.get("status", "ACTIVE"),
                })

        # Also support alias mapping for HCPs
        self.entities_by_type["HCP"] = [
            {"id": "hcp:dr_sarah_jenkins", "canonical_name": "Dr. Sarah Jenkins", "uri": f"{ENTITY_BASE_URI}hcp/dr_sarah_jenkins", "aliases": ["Sarah Jenkins", "Dr Jenkins", "Jenkins"], "status": "ACTIVE"},
            {"id": "hcp:dr_kenji_sato", "canonical_name": "Dr. Kenji Sato", "uri": f"{ENTITY_BASE_URI}hcp/dr_kenji_sato", "aliases": ["Kenji Sato", "Dr Sato", "Sato"], "status": "ACTIVE"},
            {"id": "hcp:dr_elena_rostova", "canonical_name": "Dr. Elena Rostova", "uri": f"{ENTITY_BASE_URI}hcp/dr_elena_rostova", "aliases": ["Elena Rostova", "Dr Rostova", "Rostova"], "status": "ACTIVE"},
            {"id": "hcp:dr_marcus_weber", "canonical_name": "Dr. Marcus Weber", "uri": f"{ENTITY_BASE_URI}hcp/dr_marcus_weber", "aliases": ["Marcus Weber", "Dr Weber", "Weber"], "status": "ACTIVE"},
            {"id": "hcp:dr_priya_sharma", "canonical_name": "Dr. Priya Sharma", "uri": f"{ENTITY_BASE_URI}hcp/dr_priya_sharma", "aliases": ["Priya Sharma", "Dr Sharma", "Sharma"], "status": "ACTIVE"},
        ]

    def resolve(
        self,
        mention: str,
        entity_type: str,
        document_uri: str,
        chunk_uri: str,
        char_start: Optional[int] = None,
        char_end: Optional[int] = None,
    ) -> ResolutionDecision:
        """
        Resolves mention to canonical entity using the 4-tier resolution sequence:
        1. Exact canonical match
        2. Case-insensitive canonical / alias match
        3. RapidFuzz score > 0.85
        4. Otherwise provisional / HITL
        """
        mention_clean = mention.strip()
        candidates = self.entities_by_type.get(entity_type, [])
        now = utc_now()

        # Tier 1: Exact canonical match
        for cand in candidates:
            if mention_clean == cand["canonical_name"]:
                decision = ResolutionDecision(
                    mention=mention,
                    entity_type=entity_type,
                    document_uri=document_uri,
                    chunk_uri=chunk_uri,
                    canonical_id=cand["id"],
                    canonical_name=cand["canonical_name"],
                    canonical_uri=cand["uri"],
                    resolution_method="EXACT_CANONICAL",
                    confidence=1.0,
                    status="RESOLVED",
                    timestamp=now,
                    char_start=char_start,
                    char_end=char_end,
                )
                self._record_decision(decision)
                return decision

        # Tier 2: Case-insensitive canonical or alias match
        m_lower = mention_clean.lower()
        for cand in candidates:
            if m_lower == cand["canonical_name"].lower():
                decision = ResolutionDecision(
                    mention=mention,
                    entity_type=entity_type,
                    document_uri=document_uri,
                    chunk_uri=chunk_uri,
                    canonical_id=cand["id"],
                    canonical_name=cand["canonical_name"],
                    canonical_uri=cand["uri"],
                    resolution_method="CASE_INSENSITIVE_CANONICAL",
                    confidence=1.0,
                    status="RESOLVED",
                    timestamp=now,
                    char_start=char_start,
                    char_end=char_end,
                )
                self._record_decision(decision)
                return decision

            for alias in cand.get("aliases", []):
                if m_lower == alias.lower():
                    decision = ResolutionDecision(
                        mention=mention,
                        entity_type=entity_type,
                        document_uri=document_uri,
                        chunk_uri=chunk_uri,
                        canonical_id=cand["id"],
                        canonical_name=cand["canonical_name"],
                        canonical_uri=cand["uri"],
                        resolution_method="CASE_INSENSITIVE_ALIAS",
                        confidence=0.98,
                        status="RESOLVED",
                        timestamp=now,
                        char_start=char_start,
                        char_end=char_end,
                    )
                    self._record_decision(decision)
                    return decision

        # Tier 3: RapidFuzz fuzzy match with score > 0.85
        best_cand: Optional[Dict[str, Any]] = None
        best_score: float = 0.0
        best_matched_term: str = ""

        for cand in candidates:
            # Score canonical name
            c_score = fuzz.ratio(m_lower, cand["canonical_name"].lower()) / 100.0
            if c_score > best_score:
                best_score = c_score
                best_cand = cand
                best_matched_term = cand["canonical_name"]

            # Score aliases
            for alias in cand.get("aliases", []):
                a_score = fuzz.ratio(m_lower, alias.lower()) / 100.0
                if a_score > best_score:
                    best_score = a_score
                    best_cand = cand
                    best_matched_term = alias

        if best_cand and best_score > 0.85:
            decision = ResolutionDecision(
                mention=mention,
                entity_type=entity_type,
                document_uri=document_uri,
                chunk_uri=chunk_uri,
                canonical_id=best_cand["id"],
                canonical_name=best_cand["canonical_name"],
                canonical_uri=best_cand["uri"],
                resolution_method="FUZZY_MATCH",
                confidence=round(best_score, 4),
                status="RESOLVED",
                timestamp=now,
                char_start=char_start,
                char_end=char_end,
            )
            self._record_decision(decision)
            return decision

        # Tier 4: Unresolved / Provisional -> HITL
        decision = ResolutionDecision(
            mention=mention,
            entity_type=entity_type,
            document_uri=document_uri,
            chunk_uri=chunk_uri,
            canonical_id=None,
            canonical_name=None,
            canonical_uri=None,
            resolution_method="UNRESOLVED",
            confidence=round(best_score, 4),
            status="PROVISIONAL",
            timestamp=now,
            char_start=char_start,
            char_end=char_end,
        )
        self._record_decision(decision)
        return decision

    def _record_decision(self, decision: ResolutionDecision) -> None:
        """Logs ENTITY_RESOLUTION audit event and records provisional entities."""
        # 1. Audit event
        event = {
            "timestamp": decision.timestamp,
            "event_type": "ENTITY_RESOLUTION",
            "document_uri": decision.document_uri,
            "chunk_uri": decision.chunk_uri,
            "details": asdict(decision),
        }
        self.audit_path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.audit_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(event, ensure_ascii=False) + "\n")

        # 2. Provisional entities file
        if decision.status == "PROVISIONAL":
            self._append_provisional(decision)

    def _append_provisional(self, decision: ResolutionDecision) -> None:
        entries = []
        if self.provisional_path.exists():
            try:
                with open(self.provisional_path, "r", encoding="utf-8") as f:
                    entries = json.load(f)
            except Exception:
                entries = []
        entries.append(asdict(decision))
        self.provisional_path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.provisional_path, "w", encoding="utf-8") as f:
            json.dump(entries, f, indent=2, ensure_ascii=False)


if __name__ == "__main__":
    resolver = EntityResolver()
    # Test cases for the 4 tiers
    t1 = resolver.resolve("Keytruda", "Brand", "watson:Doc_001", "watson:Doc_001:chunk:0001")
    t2 = resolver.resolve("KEYTRUDA", "Brand", "watson:Doc_001", "watson:Doc_001:chunk:0001")
    t3 = resolver.resolve("Keytrudaa", "Brand", "watson:Doc_001", "watson:Doc_001:chunk:0001")
    t4 = resolver.resolve("CompletelyUnknownMoleculeX", "Drug", "watson:Doc_001", "watson:Doc_001:chunk:0001")

    print(f"Tier 1 (Exact): {t1.resolution_method} -> {t1.canonical_name} ({t1.status})")
    print(f"Tier 2 (Case/Alias): {t2.resolution_method} -> {t2.canonical_name} ({t2.status})")
    print(f"Tier 3 (Fuzzy): {t3.resolution_method} -> {t3.canonical_name} ({t3.confidence}) ({t3.status})")
    print(f"Tier 4 (Provisional): {t4.resolution_method} -> {t4.canonical_name} ({t4.status})")
