# populate_graph.py
"""
Watson Layer 2 — Seed Knowledge Graph Generator
Populates static domain knowledge from pharma.ttl and seed_vocabularies.json.
Meets the PRD requirement of 700+ triples for static canonical entities.
Does NOT seed runtime MarketResearchDocument or DocumentChunk instances.
"""

from __future__ import annotations
import json
from pathlib import Path
from typing import Dict, Any, List
import rdflib
from rdflib import Graph, Literal, Namespace, RDF, RDFS, OWL, XSD, SKOS

ROOT = Path(__file__).resolve().parent
ONTOLOGY_PATH = ROOT / "pharma.ttl"
VOCAB_PATH = ROOT / "data" / "seed_vocabularies.json"
if not VOCAB_PATH.exists():
    VOCAB_PATH = ROOT / "seed_vocabularies.json"
OUTPUT_PATH = ROOT / "pharma_kg.ttl"

WATSON = Namespace("http://watson.pharma.org/ontology/")
ENTITY = Namespace("http://watson.pharma.org/entity/")
DC = Namespace("http://purl.org/dc/elements/1.1/")


def clean_id(raw_id: str) -> str:
    """Extract clean local identifier from id string like 'brand:keytruda'."""
    return raw_id.split(":")[-1].strip()


def build_seed_kg(
    ontology_path: Path = ONTOLOGY_PATH,
    vocab_path: Path = VOCAB_PATH,
    output_path: Path = OUTPUT_PATH,
) -> Graph:
    """Builds and serializes the static Seed Knowledge Graph."""
    g = Graph()
    g.bind("watson", WATSON)
    g.bind("entity", ENTITY)
    g.bind("skos", SKOS)
    g.bind("owl", OWL)
    g.bind("dc", DC)

    # 1. Parse base ontology
    if ontology_path.exists():
        g.parse(str(ontology_path), format="turtle")

    # 2. Load seed vocabularies
    with open(vocab_path, "r", encoding="utf-8") as f:
        vocab_data = json.load(f)["vocabularies"]

    # Drug classification lookup for Biologic vs Small Molecule (for OWL reasoning test Q6)
    biologics = {
        "drug:pembrolizumab",
        "drug:nivolumab",
        "drug:dupilumab",
        "drug:nusinersen",
        "drug:omalizumab",
    }

    # Brand to Indication mappings based on clinical approvals
    brand_indications = {
        "brand:keytruda": ["indication:nsclc", "indication:melanoma"],
        "brand:opdivo": ["indication:nsclc", "indication:melanoma"],
        "brand:dupixent": ["indication:atopic_dermatitis", "indication:asthma"],
        "brand:entresto": ["indication:heart_failure"],
        "brand:spinraza": ["indication:sma"],
        "brand:jardiance": ["indication:type_2_diabetes", "indication:ckd", "indication:heart_failure"],
        "brand:farxiga": ["indication:type_2_diabetes", "indication:ckd", "indication:heart_failure"],
        "brand:tecfidera": ["indication:multiple_sclerosis"],
        "brand:trikafta": ["indication:cystic_fibrosis"],
        "brand:xolair": ["indication:asthma"],
    }

    # Drug to Indication mappings
    drug_indications = {
        "drug:pembrolizumab": ["indication:nsclc", "indication:melanoma"],
        "drug:nivolumab": ["indication:nsclc", "indication:melanoma"],
        "drug:dupilumab": ["indication:atopic_dermatitis", "indication:asthma"],
        "drug:sacubitril_valsartan": ["indication:heart_failure"],
        "drug:nusinersen": ["indication:sma"],
        "drug:empagliflozin": ["indication:type_2_diabetes", "indication:ckd", "indication:heart_failure"],
        "drug:dapagliflozin": ["indication:type_2_diabetes", "indication:ckd", "indication:heart_failure"],
        "drug:dimethyl_fumarate": ["indication:multiple_sclerosis"],
        "drug:elexacaftor_tezacaftor_ivacaftor": ["indication:cystic_fibrosis"],
        "drug:omalizumab": ["indication:asthma"],
    }

    # External database alignments (MeSH, ChEMBL, RxNorm, Wikidata)
    external_alignments = {
        "brand:keytruda": {"rxnorm": "1547545", "wikidata": "Q18193855", "chembl": "CHEMBL3137343"},
        "brand:opdivo": {"rxnorm": "1597876", "wikidata": "Q7041793", "chembl": "CHEMBL2108770"},
        "brand:dupixent": {"rxnorm": "1918318", "wikidata": "Q29048680", "chembl": "CHEMBL3707241"},
        "brand:entresto": {"rxnorm": "1656328", "wikidata": "Q20668388", "chembl": "CHEMBL3301610"},
        "brand:spinraza": {"rxnorm": "1863174", "wikidata": "Q28062299", "chembl": "CHEMBL3707358"},
        "brand:jardiance": {"rxnorm": "1545653", "wikidata": "Q17505672", "chembl": "CHEMBL2107830"},
        "brand:farxiga": {"rxnorm": "1488564", "wikidata": "Q15708304", "chembl": "CHEMBL1743048"},
        "brand:tecfidera": {"rxnorm": "1373458", "wikidata": "Q418465", "chembl": "CHEMBL1200766"},
        "brand:trikafta": {"rxnorm": "2205166", "wikidata": "Q73583279", "chembl": "CHEMBL4298135"},
        "brand:xolair": {"rxnorm": "352741", "wikidata": "Q423719", "chembl": "CHEMBL1201583"},
        "indication:nsclc": {"mesh": "D002289", "snomed": "254637007"},
        "indication:melanoma": {"mesh": "D008545", "snomed": "372244006"},
        "indication:atopic_dermatitis": {"mesh": "D003876", "snomed": "24079001"},
        "indication:heart_failure": {"mesh": "D006333", "snomed": "84114007"},
        "indication:sma": {"mesh": "D009134", "snomed": "5262007"},
        "indication:type_2_diabetes": {"mesh": "D003924", "snomed": "44054006"},
        "indication:multiple_sclerosis": {"mesh": "D009103", "snomed": "24700007"},
        "indication:cystic_fibrosis": {"mesh": "D003550", "snomed": "190905008"},
        "indication:asthma": {"mesh": "D001249", "snomed": "195967001"},
        "indication:ckd": {"mesh": "D051436", "snomed": "709044004"},
    }

    # 3. Populate Therapeutic Areas
    for ta in vocab_data["therapeutic_areas"]:
        cid = ta["id"]
        local_name = clean_id(cid)
        uri = ENTITY[f"ta/{local_name}"]
        g.add((uri, RDF.type, WATSON.TherapeuticArea))
        g.add((uri, RDFS.label, Literal(ta["canonical_name"], datatype=XSD.string)))
        g.add((uri, SKOS.prefLabel, Literal(ta["canonical_name"], datatype=XSD.string)))
        g.add((uri, WATSON.canonicalId, Literal(cid, datatype=XSD.string)))
        g.add((uri, WATSON.canonicalName, Literal(ta["canonical_name"], datatype=XSD.string)))
        g.add((uri, WATSON.statusCode, Literal(ta.get("status", "ACTIVE"), datatype=XSD.string)))
        g.add((uri, RDFS.comment, Literal(f"Therapeutic Area: {ta['canonical_name']}", datatype=XSD.string)))
        for alias in ta.get("aliases", []):
            g.add((uri, SKOS.altLabel, Literal(alias, datatype=XSD.string)))

    # 4. Populate Indications
    for ind in vocab_data["indications"]:
        cid = ind["id"]
        local_name = clean_id(cid)
        uri = ENTITY[f"indication/{local_name}"]
        g.add((uri, RDF.type, WATSON.Indication))
        g.add((uri, RDFS.label, Literal(ind["canonical_name"], datatype=XSD.string)))
        g.add((uri, SKOS.prefLabel, Literal(ind["canonical_name"], datatype=XSD.string)))
        g.add((uri, WATSON.canonicalId, Literal(cid, datatype=XSD.string)))
        g.add((uri, WATSON.canonicalName, Literal(ind["canonical_name"], datatype=XSD.string)))
        g.add((uri, WATSON.statusCode, Literal(ind.get("status", "ACTIVE"), datatype=XSD.string)))
        g.add((uri, RDFS.comment, Literal(f"Medical indication: {ind['canonical_name']}", datatype=XSD.string)))
        for alias in ind.get("aliases", []):
            g.add((uri, SKOS.altLabel, Literal(alias, datatype=XSD.string)))
        
        # Link to Therapeutic Area
        ta_id = ind.get("therapeutic_area_id")
        if ta_id:
            ta_uri = ENTITY[f"ta/{clean_id(ta_id)}"]
            g.add((uri, WATSON.inTherapeuticArea, ta_uri))
            g.add((ta_uri, WATSON.hasIndication, uri))

        # Add external alignments
        ext = external_alignments.get(cid, {})
        for sys_name, code in ext.items():
            g.add((uri, RDFS.seeAlso, Literal(f"{sys_name}:{code}", datatype=XSD.string)))
            g.add((uri, SKOS.exactMatch, Literal(f"urn:{sys_name}:{code}", datatype=XSD.string)))

    # 5. Populate Drugs
    for drug in vocab_data["drugs"]:
        cid = drug["id"]
        local_name = clean_id(cid)
        uri = ENTITY[f"drug/{local_name}"]
        is_biologic = cid in biologics
        drug_class = WATSON.BiologicDrug if is_biologic else WATSON.SmallMoleculeDrug
        g.add((uri, RDF.type, drug_class))
        g.add((uri, RDF.type, WATSON.Drug))
        g.add((uri, RDFS.label, Literal(drug["canonical_name"], datatype=XSD.string)))
        g.add((uri, SKOS.prefLabel, Literal(drug["canonical_name"], datatype=XSD.string)))
        g.add((uri, WATSON.canonicalId, Literal(cid, datatype=XSD.string)))
        g.add((uri, WATSON.canonicalName, Literal(drug["canonical_name"], datatype=XSD.string)))
        g.add((uri, WATSON.statusCode, Literal(drug.get("status", "ACTIVE"), datatype=XSD.string)))
        g.add((uri, RDFS.comment, Literal(f"Active drug substance: {drug['canonical_name']}", datatype=XSD.string)))
        for alias in drug.get("aliases", []):
            g.add((uri, SKOS.altLabel, Literal(alias, datatype=XSD.string)))

        # Link to Indications
        for ind_id in drug_indications.get(cid, []):
            ind_uri = ENTITY[f"indication/{clean_id(ind_id)}"]
            g.add((uri, WATSON.targetsIndication, ind_uri))
            g.add((ind_uri, WATSON.targetedByDrug, uri))

    # 6. Populate Brands
    for brand in vocab_data["brands"]:
        cid = brand["id"]
        local_name = clean_id(cid)
        uri = ENTITY[f"brand/{local_name}"]
        g.add((uri, RDF.type, WATSON.Brand))
        g.add((uri, RDFS.label, Literal(brand["canonical_name"], datatype=XSD.string)))
        g.add((uri, SKOS.prefLabel, Literal(brand["canonical_name"], datatype=XSD.string)))
        g.add((uri, WATSON.canonicalId, Literal(cid, datatype=XSD.string)))
        g.add((uri, WATSON.canonicalName, Literal(brand["canonical_name"], datatype=XSD.string)))
        g.add((uri, WATSON.statusCode, Literal(brand.get("status", "ACTIVE"), datatype=XSD.string)))
        g.add((uri, RDFS.comment, Literal(f"Commercial brand product: {brand['canonical_name']}", datatype=XSD.string)))
        for alias in brand.get("aliases", []):
            g.add((uri, SKOS.altLabel, Literal(alias, datatype=XSD.string)))

        # Link to Drug
        drug_id = brand.get("drug_id")
        if drug_id:
            drug_uri = ENTITY[f"drug/{clean_id(drug_id)}"]
            g.add((drug_uri, WATSON.hasBrand, uri))
            g.add((uri, WATSON.isBrandOf, drug_uri))

        # Link to Indications
        for ind_id in brand_indications.get(cid, []):
            ind_uri = ENTITY[f"indication/{clean_id(ind_id)}"]
            g.add((uri, WATSON.treatsIndication, ind_uri))
            g.add((ind_uri, WATSON.treatedByBrand, uri))

        # Add external alignments
        ext = external_alignments.get(cid, {})
        for sys_name, code in ext.items():
            g.add((uri, RDFS.seeAlso, Literal(f"{sys_name}:{code}", datatype=XSD.string)))
            g.add((uri, SKOS.exactMatch, Literal(f"urn:{sys_name}:{code}", datatype=XSD.string)))

    # Competitor Brand Relationships (competesWith)
    competitor_pairs = [
        ("brand:keytruda", "brand:opdivo"),
        ("brand:jardiance", "brand:farxiga"),
        ("brand:dupixent", "brand:xolair"),
    ]
    for b1, b2 in competitor_pairs:
        b1_uri = ENTITY[f"brand/{clean_id(b1)}"]
        b2_uri = ENTITY[f"brand/{clean_id(b2)}"]
        g.add((b1_uri, WATSON.competesWith, b2_uri))
        g.add((b2_uri, WATSON.competesWith, b1_uri))

    # Transitive Indication Hierarchy (isSubIndicationOf)
    sub_indications = [
        ("indication:nsclc", "indication:lung_cancer"),
        ("indication:lung_cancer", "indication:solid_tumor"),
        ("indication:atopic_dermatitis", "indication:inflammatory_skin_disease"),
    ]
    for sub_id, parent_id in sub_indications:
        sub_uri = ENTITY[f"indication/{clean_id(sub_id)}"]
        parent_uri = ENTITY[f"indication/{clean_id(parent_id)}"]
        g.add((parent_uri, RDF.type, WATSON.Indication))
        g.add((parent_uri, RDFS.label, Literal(clean_id(parent_id).replace("_", " ").title(), datatype=XSD.string)))
        g.add((parent_uri, WATSON.canonicalName, Literal(clean_id(parent_id).replace("_", " ").title(), datatype=XSD.string)))
        g.add((sub_uri, WATSON.isSubIndicationOf, parent_uri))

    # 7. Populate Geographies
    for geo in vocab_data["geographies"]:
        cid = geo["id"]
        local_name = clean_id(cid)
        uri = ENTITY[f"geo/{local_name}"]
        g.add((uri, RDF.type, WATSON.Geography))
        g.add((uri, RDFS.label, Literal(geo["canonical_name"], datatype=XSD.string)))
        g.add((uri, SKOS.prefLabel, Literal(geo["canonical_name"], datatype=XSD.string)))
        g.add((uri, WATSON.canonicalId, Literal(cid, datatype=XSD.string)))
        g.add((uri, WATSON.canonicalName, Literal(geo["canonical_name"], datatype=XSD.string)))
        g.add((uri, WATSON.statusCode, Literal(geo.get("status", "ACTIVE"), datatype=XSD.string)))
        g.add((uri, RDFS.comment, Literal(f"Geographic market: {geo['canonical_name']}", datatype=XSD.string)))
        for alias in geo.get("aliases", []):
            g.add((uri, SKOS.altLabel, Literal(alias, datatype=XSD.string)))
        
        # Hierarchy: European countries have broader relation to EU
        if local_name in {"germany", "france"}:
            eu_uri = ENTITY["geo/eu"]
            g.add((uri, SKOS.broader, eu_uri))
            g.add((eu_uri, SKOS.narrower, uri))

    # 8. Populate Study Types / Templates
    for st in vocab_data["study_templates"]:
        cid = st["id"]
        local_name = clean_id(cid)
        uri = ENTITY[f"study/{local_name}"]
        g.add((uri, RDF.type, WATSON.StudyType))
        g.add((uri, RDFS.label, Literal(st["canonical_name"], datatype=XSD.string)))
        g.add((uri, SKOS.prefLabel, Literal(st["canonical_name"], datatype=XSD.string)))
        g.add((uri, WATSON.canonicalId, Literal(cid, datatype=XSD.string)))
        g.add((uri, WATSON.canonicalName, Literal(st["canonical_name"], datatype=XSD.string)))
        g.add((uri, WATSON.statusCode, Literal(st.get("status", "ACTIVE"), datatype=XSD.string)))
        g.add((uri, RDFS.comment, Literal(f"PMR study template: {st['canonical_name']}", datatype=XSD.string)))
        retention = st.get("retention_years", 3)
        g.add((uri, WATSON.retentionYears, Literal(retention, datatype=XSD.integer)))
        for alias in st.get("aliases", []):
            g.add((uri, SKOS.altLabel, Literal(alias, datatype=XSD.string)))

    # 9. Populate Key Opinion Leaders / Healthcare Professionals
    kols = [
        ("hcp:dr_sarah_jenkins", "Dr. Sarah Jenkins", "Oncology Key Opinion Leader", "Oncology", "geo:us"),
        ("hcp:dr_kenji_sato", "Dr. Kenji Sato", "Neurology Specialist", "Neurology", "geo:japan"),
        ("hcp:dr_elena_rostova", "Dr. Elena Rostova", "Cardiovascular Director", "Cardiology", "geo:france"),
        ("hcp:dr_marcus_weber", "Dr. Marcus Weber", "Nephrology & Diabetes Lead", "Metabolic", "geo:germany"),
        ("hcp:dr_priya_sharma", "Dr. Priya Sharma", "Respiratory Clinical Expert", "Respiratory", "geo:india"),
    ]
    for hcp_id, name, title, ta_name, geo_id in kols:
        local_name = clean_id(hcp_id)
        uri = ENTITY[f"hcp/{local_name}"]
        g.add((uri, RDF.type, WATSON.KeyOpinionLeader))
        g.add((uri, RDF.type, WATSON.HCP))
        g.add((uri, RDFS.label, Literal(name, datatype=XSD.string)))
        g.add((uri, SKOS.prefLabel, Literal(name, datatype=XSD.string)))
        g.add((uri, WATSON.canonicalId, Literal(hcp_id, datatype=XSD.string)))
        g.add((uri, WATSON.canonicalName, Literal(name, datatype=XSD.string)))
        g.add((uri, RDFS.comment, Literal(title, datatype=XSD.string)))
        geo_uri = ENTITY[f"geo/{clean_id(geo_id)}"]
        g.add((uri, WATSON.coversGeography, geo_uri))

    # Serialize
    output_path.parent.mkdir(parents=True, exist_ok=True)
    g.serialize(destination=str(output_path), format="turtle")
    print(f"Populated Seed KG saved to {output_path} with {len(g)} triples.")
    return g


if __name__ == "__main__":
    build_seed_kg()
