# taxonomy_manager.py
"""
Watson Layer 2 — Operational Controlled Taxonomy Manager
Manages versioned, controlled taxonomy terms for Therapeutic Areas, Indications, and Study Types.
Emits TAXONOMY_UPDATE audit events on every mutation.
"""

from __future__ import annotations
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

try:
    from watson.shared.config import (
        TAXONOMY_STORE_FILE as TAXONOMY_STORE_PATH,
        SEED_VOCABULARIES_FILE as VOCAB_PATH,
        AUDIT_LOG_FILE as AUDIT_LOG_PATH,
    )
except ImportError:
    ROOT = Path(__file__).resolve().parent
    TAXONOMY_STORE_PATH = ROOT / "taxonomy_store.json"
    VOCAB_PATH = ROOT / "data" / "seed_vocabularies.json"
    if not VOCAB_PATH.exists():
        VOCAB_PATH = ROOT / "seed_vocabularies.json"
    AUDIT_LOG_PATH = ROOT / "audit_log.jsonl"


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def bump_version(ver: str) -> str:
    """Bumps semantic version patch or minor: e.g. 1.0.0 -> 1.0.1."""
    parts = ver.split(".")
    if len(parts) == 3:
        try:
            return f"{parts[0]}.{parts[1]}.{int(parts[2]) + 1}"
        except ValueError:
            pass
    return f"{ver}.1"


def init_taxonomy_from_seed(
    vocab_path: Path = VOCAB_PATH,
    store_path: Path = TAXONOMY_STORE_PATH,
) -> Dict[str, Any]:
    """Initializes operational taxonomy_store.json from seed_vocabularies.json."""
    with open(vocab_path, "r", encoding="utf-8") as f:
        vocab = json.load(f)["vocabularies"]

    now = utc_now()
    taxonomy = {
        "taxonomy_version": "1.0.0",
        "created_at": now,
        "updated_at": now,
        "categories": {
            "therapeutic_areas": [
                {
                    "id": item["id"],
                    "canonical_name": item["canonical_name"],
                    "status": item.get("status", "ACTIVE"),
                    "aliases": item.get("aliases", []),
                    "version_added": "1.0.0",
                    "updated_at": now,
                }
                for item in vocab.get("therapeutic_areas", [])
            ],
            "indications": [
                {
                    "id": item["id"],
                    "canonical_name": item["canonical_name"],
                    "therapeutic_area_id": item.get("therapeutic_area_id"),
                    "status": item.get("status", "ACTIVE"),
                    "aliases": item.get("aliases", []),
                    "version_added": "1.0.0",
                    "updated_at": now,
                }
                for item in vocab.get("indications", [])
            ],
            "study_types": [
                {
                    "id": item["id"],
                    "canonical_name": item["canonical_name"],
                    "retention_years": item.get("retention_years", 3),
                    "status": item.get("status", "ACTIVE"),
                    "aliases": item.get("aliases", []),
                    "version_added": "1.0.0",
                    "updated_at": now,
                }
                for item in vocab.get("study_templates", [])
            ],
        },
    }

    store_path.parent.mkdir(parents=True, exist_ok=True)
    with open(store_path, "w", encoding="utf-8") as f:
        json.dump(taxonomy, f, indent=2, ensure_ascii=False)
    return taxonomy


def load_taxonomy(store_path: Optional[Path | str] = None) -> Dict[str, Any]:
    p = Path(store_path) if store_path else TAXONOMY_STORE_PATH
    if not p.exists():
        return init_taxonomy_from_seed(store_path=p)
    with open(p, "r", encoding="utf-8") as f:
        return json.load(f)


def save_taxonomy(taxonomy: Dict[str, Any], store_path: Optional[Path | str] = None) -> None:
    p = Path(store_path) if store_path else TAXONOMY_STORE_PATH
    p.parent.mkdir(parents=True, exist_ok=True)
    taxonomy["updated_at"] = utc_now()
    with open(p, "w", encoding="utf-8") as f:
        json.dump(taxonomy, f, indent=2, ensure_ascii=False)


def log_taxonomy_audit(
    action: str,
    category: str,
    term_id: str,
    old_version: str,
    new_version: str,
    details: Dict[str, Any],
    audit_path: Optional[Path | str] = None,
) -> None:
    """Appends TAXONOMY_UPDATE event to audit log."""
    p = Path(audit_path) if audit_path else AUDIT_LOG_PATH
    p.parent.mkdir(parents=True, exist_ok=True)
    event = {
        "timestamp": utc_now(),
        "event_type": "TAXONOMY_UPDATE",
        "action": action,
        "category": category,
        "term_id": term_id,
        "old_version": old_version,
        "new_version": new_version,
        "details": details,
    }
    with open(p, "a", encoding="utf-8") as f:
        f.write(json.dumps(event, ensure_ascii=False) + "\n")


class TaxonomyManager:
    """Provides controlled CRUD, validation, and versioning for taxonomy."""

    def __init__(
        self,
        store_path: Optional[Path | str] = None,
        audit_path: Optional[Path | str] = None,
    ):
        self.store_path = Path(store_path) if store_path else TAXONOMY_STORE_PATH
        self.audit_path = Path(audit_path) if audit_path else AUDIT_LOG_PATH
        self.data = load_taxonomy(self.store_path)

    @property
    def version(self) -> str:
        return self.data.get("taxonomy_version", "1.0.0")

    @property
    def categories(self) -> List[str]:
        return list(self.data.get("categories", {}).keys())

    def list_terms(
        self,
        category: str,
        status: Optional[str] = "ACTIVE",
    ) -> List[Dict[str, Any]]:
        terms = self.data.get("categories", {}).get(category, [])
        if status is None:
            return list(terms)
        return [t for t in terms if t.get("status") == status]

    def find_term(
        self,
        category: str,
        identifier_or_name: str,
    ) -> Optional[Dict[str, Any]]:
        query = identifier_or_name.strip().lower()
        for t in self.data.get("categories", {}).get(category, []):
            if t.get("id", "").lower() == query:
                return t
            if t.get("canonical_name", "").lower() == query:
                return t
            for a in t.get("aliases", []):
                if a.lower() == query:
                    return t
        return None

    def validate_term(
        self,
        category: str,
        name_or_id: str,
    ) -> Tuple[bool, Optional[str], str]:
        """
        Validates if a term is controlled and active.
        Returns: (is_valid, canonical_name, reason)
        """
        term = self.find_term(category, name_or_id)
        if not term:
            return False, None, f"Unknown term '{name_or_id}' in category '{category}'"
        if term.get("status") != "ACTIVE":
            return False, term.get("canonical_name"), f"Term '{name_or_id}' is DEPRECATED in taxonomy"
        return True, term.get("canonical_name"), "Valid controlled taxonomy term"

    def add_term(
        self,
        category: str,
        term_id: str,
        canonical_name: str,
        aliases: Optional[List[str]] = None,
        extra: Optional[Dict[str, Any]] = None,
        actor: str = "SYSTEM",
        reason: Optional[str] = None,
    ) -> Dict[str, Any]:
        existing = self.find_term(category, term_id)
        if existing:
            raise ValueError(f"Term '{term_id}' already exists in category '{category}'")

        old_v = self.version
        new_v = bump_version(old_v)
        now = utc_now()

        new_entry = {
            "id": term_id,
            "canonical_name": canonical_name,
            "status": "ACTIVE",
            "aliases": aliases or [],
            "version_added": new_v,
            "updated_at": now,
        }
        if extra:
            new_entry.update(extra)

        if category not in self.data.setdefault("categories", {}):
            self.data["categories"][category] = []
        self.data["categories"][category].append(new_entry)
        self.data["taxonomy_version"] = new_v

        save_taxonomy(self.data, self.store_path)
        log_taxonomy_audit(
            action="ADD_TERM",
            category=category,
            term_id=term_id,
            old_version=old_v,
            new_version=new_v,
            details={"actor": actor, "reason": reason, "entry": new_entry},
            audit_path=self.audit_path,
        )
        return new_entry

    def deprecate_term(
        self,
        category: str,
        term_id: str,
        actor: str = "SYSTEM",
        reason: Optional[str] = None,
    ) -> Dict[str, Any]:
        term = self.find_term(category, term_id)
        if not term:
            raise KeyError(f"Term '{term_id}' not found in category '{category}'")
        if term.get("status") == "DEPRECATED":
            return term

        old_v = self.version
        new_v = bump_version(old_v)
        now = utc_now()

        term["status"] = "DEPRECATED"
        term["version_deprecated"] = new_v
        term["updated_at"] = now
        term["deprecation_reason"] = reason or "Deprecated by taxonomy administrator"
        self.data["taxonomy_version"] = new_v

        save_taxonomy(self.data, self.store_path)
        log_taxonomy_audit(
            action="DEPRECATE_TERM",
            category=category,
            term_id=term_id,
            old_version=old_v,
            new_version=new_v,
            details={"actor": actor, "reason": reason},
            audit_path=self.audit_path,
        )
        return term

    def reactivate_term(
        self,
        category: str,
        term_id: str,
        actor: str = "SYSTEM",
        reason: Optional[str] = None,
    ) -> Dict[str, Any]:
        term = self.find_term(category, term_id)
        if not term:
            raise KeyError(f"Term '{term_id}' not found in category '{category}'")
        if term.get("status") == "ACTIVE":
            return term

        old_v = self.version
        new_v = bump_version(old_v)
        now = utc_now()

        term["status"] = "ACTIVE"
        term["updated_at"] = now
        term["reactivation_reason"] = reason or "Reactivated by taxonomy administrator"
        self.data["taxonomy_version"] = new_v

        save_taxonomy(self.data, self.store_path)
        log_taxonomy_audit(
            action="REACTIVATE_TERM",
            category=category,
            term_id=term_id,
            old_version=old_v,
            new_version=new_v,
            details={"actor": actor, "reason": reason},
            audit_path=self.audit_path,
        )
        return term


if __name__ == "__main__":
    init_taxonomy_from_seed()
    tm = TaxonomyManager()
    print(f"Taxonomy initialized. Version: {tm.version}")
    for cat in ["therapeutic_areas", "indications", "study_types"]:
        terms = tm.list_terms(cat)
        print(f"  {cat}: {len(terms)} active terms")
