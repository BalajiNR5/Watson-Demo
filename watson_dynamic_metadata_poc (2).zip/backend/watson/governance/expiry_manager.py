# expiry_manager.py

from datetime import datetime, timedelta
from pathlib import Path
import json

LIFECYCLE_STORE = Path("lifecycle_store.json")

RETENTION_RULES = {
    "HCP Perception Survey": 730,
    "KOL Interview": 365,
    "Competitive Landscape": 1825,
    "Indication Deep Dive": 730,
    "Market Access Insight": 1095,
    "Therapy Area Landscape": 730
}

def load_store():
    if not LIFECYCLE_STORE.exists():
        return {}

    with open(
        LIFECYCLE_STORE,
        "r",
        encoding="utf-8"
    ) as f:
        return json.load(f)

def save_store(store):
    with open(
        LIFECYCLE_STORE,
        "w",
        encoding="utf-8"
    ) as f:
        json.dump(
            store,
            f,
            indent=2
        )

def calculate_expiry_date(
    study_type,
    ingest_date,
    override_days=None
):
    ingest_date_obj = (
        datetime
        .fromisoformat(ingest_date)
        .date()
    )

    retention_days = (
        override_days
        if override_days is not None
        else RETENTION_RULES.get(
            study_type,
            730
        )
    )

    expiry_date = (
        ingest_date_obj
        + timedelta(days=retention_days)
    )

    return {
        "retention_days": retention_days,
        "expiry_date": expiry_date.isoformat()
    }

def assign_expiry(
    document_uri,
    study_type,
    ingest_date,
    override_days=None
):
    result = calculate_expiry_date(
        study_type,
        ingest_date,
        override_days
    )

    store = load_store()

    if document_uri not in store:
        store[document_uri] = {}

    store[document_uri].update(
        {
            "document_uri": document_uri,
            "study_type": study_type,
            "ingest_date": ingest_date,
            "retention_days":
                result["retention_days"],
            "expiry_date":
                result["expiry_date"]
        }
    )

    save_store(store)

    return result

if __name__ == "__main__":
    result = assign_expiry(
        document_uri="watson:Doc_001",
        study_type="KOL Interview",
        ingest_date="2026-09-28"
    )

    print(result)