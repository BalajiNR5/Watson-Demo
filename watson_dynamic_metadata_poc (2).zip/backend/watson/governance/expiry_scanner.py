# expiry_scanner.py

from datetime import datetime, UTC
from pathlib import Path
import json

LIFECYCLE_STORE = Path(
    "lifecycle_store.json"
)

AUDIT_LOG = Path(
    "audit_log.jsonl"
)

def utc_now():
    return datetime.now(
        UTC
    ).isoformat()

def load_store():

    if not LIFECYCLE_STORE.exists():
        return {}

    with open(
        LIFECYCLE_STORE,
        "r",
        encoding="utf-8"
    ) as f:
        return json.load(f)

def save_store(store):

    with open(
        LIFECYCLE_STORE,
        "w",
        encoding="utf-8"
    ) as f:
        json.dump(
            store,
            f,
            indent=2
        )

def write_expiry_event(
    document_uri,
    old_state,
    new_state,
    expiry_date
):

    event = {
        "timestamp": utc_now(),
        "event_type": "EXPIRY_TRIGGERED",
        "document_uri": document_uri,
        "details": {
            "old_state": old_state,
            "new_state": new_state,
            "expiry_date": expiry_date,
            "note":
                "Expired - please confirm renewal or archive."
        }
    }

    with open(
        AUDIT_LOG,
        "a",
        encoding="utf-8"
    ) as f:
        f.write(
            json.dumps(event)
            + "\n"
        )

def scan_expired_documents(store_path=None, audit_path=None, reference_date=None):

    p_store = Path(store_path) if store_path else LIFECYCLE_STORE
    p_audit = Path(audit_path) if audit_path else AUDIT_LOG

    if not p_store.exists():
        return []

    with open(p_store, "r", encoding="utf-8") as f:
        store = json.load(f)

    if reference_date is not None:
        today = reference_date.date() if isinstance(reference_date, datetime) else reference_date
    else:
        today = datetime.now(UTC).date()

    expired_docs = []

    for doc_uri, record in store.items():

        if record.get("lifecycle_state") != "ACTIVE":
            continue

        expiry_date_str = record.get("expiry_date") or (record.get("expiry") or {}).get("expiry_date")

        if not expiry_date_str:
            continue

        expiry_date = (
            datetime
            .fromisoformat(
                expiry_date_str
            )
            .date()
        )

        if expiry_date < today:

            old_state = record["lifecycle_state"]

            record["lifecycle_state"] = "ARCHIVED"

            record["review_note"] = "Expired - document archived pending explicit reinstatement."

            event = {
                "timestamp": utc_now(),
                "event_type": "EXPIRY_TRIGGERED",
                "document_uri": doc_uri,
                "details": {
                    "old_state": old_state,
                    "new_state": "ARCHIVED",
                    "expiry_date": expiry_date_str,
                    "note": "Expired - please confirm renewal or archive."
                }
            }
            with open(p_audit, "a", encoding="utf-8") as f:
                f.write(json.dumps(event) + "\n")

            expired_docs.append(doc_uri)

    with open(p_store, "w", encoding="utf-8") as f:
        json.dump(store, f, indent=2)

    return expired_docs

def documents_expiring_within_90_days(store_path=None, reference_date=None):

    p_store = Path(store_path) if store_path else LIFECYCLE_STORE

    if not p_store.exists():
        return []

    with open(p_store, "r", encoding="utf-8") as f:
        store = json.load(f)

    if reference_date is not None:
        today = reference_date.date() if isinstance(reference_date, datetime) else reference_date
    else:
        today = datetime.now(UTC).date()

    results = []

    for doc_uri, record in store.items():

        if record.get("lifecycle_state") != "ACTIVE":
            continue

        expiry_date_str = record.get("expiry_date") or (record.get("expiry") or {}).get("expiry_date")

        if not expiry_date_str:
            continue

        expiry_date = (
            datetime
            .fromisoformat(
                expiry_date_str
            )
            .date()
        )

        days_remaining = (expiry_date - today).days

        if 0 <= days_remaining <= 90:

            results.append(
                {
                    "document_uri": doc_uri,
                    "study_type": record.get("study_type"),
                    "expiry_date": expiry_date_str,
                    "days_remaining": days_remaining
                }
            )

    return sorted(
        results,
        key=lambda x: x["expiry_date"]
    )

if __name__ == "__main__":

    print(
        "\nExpired Documents"
    )

    print(
        scan_expired_documents()
    )

    print(
        "\nExpiring Within 90 Days"
    )

    print(
        documents_expiring_within_90_days()
    )