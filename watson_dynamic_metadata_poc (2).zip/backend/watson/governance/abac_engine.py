# abac_engine.py
"""
Watson Platform — Layer 1 ABAC (Attribute-Based Access Control) Engine
======================================================================
Enforces fine-grained governance on governed ACTIVE document packages based
on user identity, role, clearance sensitivity level, therapeutic areas, and
geographical boundaries.
"""

from __future__ import annotations

import argparse
import datetime
import json
import os
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

USER_REGISTRY_PATH = Path("user_registry.json")
LIFECYCLE_STORE_PATH = Path("lifecycle_store.json")
AUDIT_LOG_PATH = Path("audit_log.jsonl")


def utc_now() -> str:
    return datetime.datetime.now(datetime.timezone.utc).isoformat().replace("+00:00", "Z")


def load_user_registry(path: str | Path = USER_REGISTRY_PATH) -> Dict[str, Any]:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"User registry not found: {p}")
    with open(p, "r", encoding="utf-8") as file:
        return json.load(file)


def load_lifecycle_store(path: str | Path = LIFECYCLE_STORE_PATH) -> Dict[str, Any]:
    p = Path(path)
    if not p.exists():
        return {}
    with open(p, "r", encoding="utf-8") as file:
        return json.load(file)


def log_abac_audit(
    event_type: str,
    document_uri: str,
    user_id: str,
    details: Dict[str, Any],
    audit_path: str | Path = AUDIT_LOG_PATH,
) -> None:
    p = Path(audit_path)
    p.parent.mkdir(parents=True, exist_ok=True)
    record = {
        "timestamp": utc_now(),
        "event_type": event_type,
        "document_uri": document_uri,
        "user_id": user_id,
        "details": details,
    }
    with open(p, "a", encoding="utf-8") as file:
        file.write(json.dumps(record, ensure_ascii=False) + "\n")


def evaluate_access(
    user_id: str,
    document_uri: str,
    *,
    user_registry_path: str | Path = USER_REGISTRY_PATH,
    lifecycle_store_path: str | Path = LIFECYCLE_STORE_PATH,
    audit_log_path: str | Path = AUDIT_LOG_PATH,
) -> Tuple[bool, str, Dict[str, Any]]:
    """
    Evaluates whether `user_id` is permitted to access `document_uri`.
    
    Governance Rules:
    1. Document must exist in lifecycle store.
    2. Document must be in 'ACTIVE' state. Any non-ACTIVE state -> ACCESS DENIED.
    3. User must exist in user_registry. Unknown user -> ACCESS DENIED.
    4. User's role must exist and permit document's sensitivity_level.
    5. Document therapeutic area must intersect user's allowed therapeutic areas.
    6. Document geography must intersect user's allowed geographies.
    7. Safe denial: Any missing required attribute results in immediate DENIAL.
    
    Returns:
        (access_allowed: bool, reason: str, audit_details: Dict[str, Any])
    """
    try:
        user_reg = load_user_registry(user_registry_path)
    except FileNotFoundError:
        details = {"error": "user_registry_missing", "user_id": user_id}
        log_abac_audit("ABAC_DENIED", document_uri, user_id, details, audit_log_path)
        return False, "User registry not found", details

    lifecycle_store = load_lifecycle_store(lifecycle_store_path)

    # 1. Document Existence
    if document_uri not in lifecycle_store:
        details = {"reason": "document_not_found", "document_uri": document_uri}
        log_abac_audit("ABAC_DENIED", document_uri, user_id, details, audit_log_path)
        return False, f"Document not found in governance store: {document_uri}", details

    doc_record = lifecycle_store[document_uri]

    # 2. Lifecycle State Check
    lifecycle_state = doc_record.get("lifecycle_state")
    if lifecycle_state != "ACTIVE":
        details = {
            "reason": "document_not_active",
            "lifecycle_state": lifecycle_state,
            "document_uri": document_uri,
        }
        log_abac_audit("ABAC_DENIED", document_uri, user_id, details, audit_log_path)
        return False, f"Document is not ACTIVE (current state: {lifecycle_state})", details

    # 3. User Identity Lookup
    users_table = user_reg.get("users", {})
    if user_id not in users_table:
        details = {"reason": "unknown_user", "user_id": user_id}
        log_abac_audit("ABAC_DENIED", document_uri, user_id, details, audit_log_path)
        return False, f"User {user_id} not registered in identity registry", details

    user = users_table[user_id]
    role = user.get("role")
    roles_table = user_reg.get("roles", {})
    if not role or role not in roles_table:
        details = {"reason": "unknown_or_missing_role", "user_id": user_id, "role": role}
        log_abac_audit("ABAC_DENIED", document_uri, user_id, details, audit_log_path)
        return False, f"User role {role} is invalid or undefined", details

    allowed_sensitivity = roles_table[role].get("allowed_sensitivity_levels", [])
    user_ta = user.get("allowed_therapeutic_areas", [])
    user_geo = user.get("allowed_geographies", [])

    # 4. Document Attribute Lookup
    doc_sensitivity = doc_record.get("sensitivity_level")
    doc_ta = doc_record.get("allowed_therapeutic_areas")
    if doc_ta is None:
        doc_ta = doc_record.get("therapeutic_area")
    doc_geo = doc_record.get("allowed_geographies")
    if doc_geo is None:
        doc_geo = doc_record.get("geography")

    # Fail-safe check for missing document attributes
    if not doc_sensitivity:
        details = {"reason": "missing_document_sensitivity", "document_uri": document_uri}
        log_abac_audit("ABAC_DENIED", document_uri, user_id, details, audit_log_path)
        return False, "Document sensitivity_level attribute is missing", details

    # 5. Sensitivity Check
    sensitivity_allowed = doc_sensitivity in allowed_sensitivity

    # 6. Therapeutic Area Check
    if role in ("ADMIN", "COMPLIANCE_OFFICER") or "*" in user_ta or "General" in user_ta:
        ta_allowed = True
    elif doc_ta is None:
        ta_allowed = False
    elif isinstance(doc_ta, list):
        ta_allowed = len(doc_ta) == 0 or bool(set(doc_ta) & set(user_ta))
    else:
        ta_allowed = doc_ta in user_ta

    # 7. Geography Check
    if role in ("ADMIN", "COMPLIANCE_OFFICER") or "*" in user_geo or "Global" in user_geo:
        geo_allowed = True
    elif doc_geo is None:
        geo_allowed = False
    elif isinstance(doc_geo, list):
        geo_allowed = len(doc_geo) == 0 or bool(set(doc_geo) & set(user_geo))
    else:
        geo_allowed = doc_geo in user_geo

    checks = {
        "sensitivity": {
            "document": doc_sensitivity,
            "allowed": allowed_sensitivity,
            "passed": sensitivity_allowed,
        },
        "therapeutic_area": {
            "document": doc_ta,
            "user_allowed": user_ta,
            "passed": ta_allowed,
        },
        "geography": {
            "document": doc_geo,
            "user_allowed": user_geo,
            "passed": geo_allowed,
        },
    }

    if not sensitivity_allowed:
        reason = f"Sensitivity level {doc_sensitivity} not permitted for role {role}"
        details = {"reason": reason, "checks": checks}
        log_abac_audit("ABAC_DENIED", document_uri, user_id, details, audit_log_path)
        return False, reason, details

    if not ta_allowed:
        reason = f"Therapeutic area {doc_ta} not in user's permitted areas"
        details = {"reason": reason, "checks": checks}
        log_abac_audit("ABAC_DENIED", document_uri, user_id, details, audit_log_path)
        return False, reason, details

    if not geo_allowed:
        reason = f"Geography {doc_geo} not in user's permitted geographies"
        details = {"reason": reason, "checks": checks}
        log_abac_audit("ABAC_DENIED", document_uri, user_id, details, audit_log_path)
        return False, reason, details

    # Access Allowed
    details = {
        "status": "ALLOWED",
        "user_id": user_id,
        "role": role,
        "document_uri": document_uri,
        "checks": checks,
    }
    log_abac_audit("ABAC_ALLOWED", document_uri, user_id, details, audit_log_path)
    return True, "Access granted", details


def main() -> int:
    parser = argparse.ArgumentParser(description="Watson ABAC Policy Enforcement Engine")
    parser.add_argument("--user-id", default="D3", help="User ID to evaluate (default: D3)")
    parser.add_argument("--doc-uri", default="watson:Doc_001", help="Document URI (default: watson:Doc_001)")
    parser.add_argument("--registry", default="user_registry.json", help="User registry path")
    parser.add_argument("--lifecycle-store", default="lifecycle_store.json", help="Lifecycle store path")
    parser.add_argument("--audit-log", default="audit_log.jsonl", help="Audit log path")
    args = parser.parse_args()

    allowed, reason, details = evaluate_access(
        args.user_id,
        args.doc_uri,
        user_registry_path=args.registry,
        lifecycle_store_path=args.lifecycle_store,
        audit_log_path=args.audit_log,
    )

    print("=" * 60)
    print("WATSON ABAC ACCESS DECISION")
    print("=" * 60)
    print(f"User ID:      {args.user_id}")
    print(f"Document URI: {args.doc_uri}")
    print(f"Decision:     {'ACCESS ALLOWED' if allowed else 'ACCESS DENIED'}")
    print(f"Reason:       {reason}")
    print(f"Details:      {json.dumps(details, indent=2)}")
    print("=" * 60)

    return 0 if allowed else 1


if __name__ == "__main__":
    raise SystemExit(main())