# audit_query.py

# ========================================================
# Audit Logging Utility
# ========================================================
import json
from datetime import datetime, timezone
from pathlib import Path
# ========================================================
# Configuration
# ========================================================
AUDIT_LOG_PATH = Path("audit_log.jsonl")
# ========================================================
# Audit Logger
# ========================================================
def log_audit(
    document_uri,
    action,
    details=None,
    sha256_hash=None
):
    """
    Append one audit event to audit_log.jsonl.
    Parameters
    ----------
    document_uri : str
        Unique URI of the document.
    action : str
        Audit event type, for example:
        INGEST
        PARSE_WARNING
        PII_FLAG
        DEDUP_HIT
        STATE_TRANSITION
        ABAC_TAGGED
        EXPIRY_TRIGGERED
        QUALITY_SCORED
    details : dict, optional
        Additional information about the event.
    sha256_hash : str, optional
        SHA-256 hash of the document.
    """
    event = {
        "timestamp": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "document_uri": document_uri,
        "action": action,
        "event_type": action,
        "details": details or {},
        "sha256_hash": sha256_hash
    }
    with open(AUDIT_LOG_PATH, "a", encoding="utf-8") as file:
        file.write(json.dumps(event, ensure_ascii=False) + "\n")

# ========================================================
# Audit Query Utility
# ========================================================
import argparse
import json
from pathlib import Path
# ========================================================
# Configuration
# ========================================================
AUDIT_LOG_PATH = Path("audit_log.jsonl")
# ========================================================
# Load Audit Log
# ========================================================
def load_audit_log(log_path):
    """
    Load audit events from audit_log.json.
    """
    if not log_path.exists():
        raise FileNotFoundError(
            f"Audit log not found: {log_path}"
        )
    events = []
    with open(log_path, "r", encoding="utf-8") as file:
        for line_number, line in enumerate(file, start=1):
            if not line.strip():
                continue
            try:
                event = json.loads(line)
            except json.JSONDecodeError as error:
                raise ValueError(
                    f"Invalid JSONL audit event on line {line_number}: {error}"
                ) from error
            if not isinstance(event, dict):
                raise ValueError(
                    f"Audit event on line {line_number} must be a JSON object."
                )
            events.append(event)
    return events
# ========================================================
# Filter Audit Events
# ========================================================
def filter_events(
    events,
    document_uri=None,
    action=None
):
    """
    Filter audit events by document URI
    and/or action.
    """
    filtered_events = []
    for event in events:
        if document_uri:
            if event.get(
                "document_uri"
            ) != document_uri:
                continue
        if action:
            act = event.get("action") or event.get("event_type")
            if act != action:
                continue
        filtered_events.append(event)
    return filtered_events
# ========================================================
# Get Last N Events
# ========================================================
def get_last_events(
    events,
    count
):
    """
    Return the latest N events.
    """
    if count <= 0:
        return events
    return events[-count:]
# ========================================================
# Display Events
# ========================================================
def display_events(events):
    if not events:
        print(
            "\nNo matching audit events found."
        )
        return
    print("\n")
    print("=" * 70)
    print("AUDIT TRAIL")
    print("=" * 70)
    for index, event in enumerate(
        events,
        start=1
    ):
        print(
            f"\nEvent #{index}"
        )
        print(
            f"Timestamp   : "
            f"{event.get('timestamp', 'N/A')}"
        )
        print(
            f"Document URI: "
            f"{event.get('document_uri', 'N/A')}"
        )
        act = event.get('action') or event.get('event_type', 'N/A')
        print(
            f"Action / Event: {act}"
        )
        print(
            f"Details     : "
            f"{json.dumps(event.get('details', {}), ensure_ascii=False)}"
        )
        print(
            f"SHA-256     : "
            f"{event.get('sha256_hash', 'N/A')}"
        )
    print("-" * 70)
# ========================================================
# Main
# ========================================================
def main():
    parser = argparse.ArgumentParser(
        description=(
            "Query the Watson audit log."
        )
    )
    parser.add_argument(
        "--last",
        type=int,
        default=15,
        help=(
            "Number of latest audit events "
            "to display."
        )
    )
    parser.add_argument(
        "--doc-uri",
        type=str,
        help=(
            "Filter by document URI."
        )
    )
    parser.add_argument(
        "--action",
        type=str,
        help=(
            "Filter by audit action."
        )
    )
    parser.add_argument(
        "--audit-log",
        type=str,
        default=str(AUDIT_LOG_PATH),
        help=(
            "Path to audit_log.json."
        )
    )
    args = parser.parse_args()
    try:
        # --------------------------------------------------------
        # Load audit log
        # --------------------------------------------------------
        events = load_audit_log(Path(args.audit_log))
        # --------------------------------------------------------
        # Filter
        # --------------------------------------------------------
        events = filter_events(
            events,
            document_uri=args.doc_uri,
            action=args.action,
        )
        # --------------------------------------------------------
        # Get latest events
        # --------------------------------------------------------
        events = get_last_events(events, args.last)
        # --------------------------------------------------------
        # Display
        # --------------------------------------------------------
        display_events(events)
    except Exception as error:
        print(f"\nERROR: {error}")
# ========================================================
# Entry Point
# ========================================================
if __name__ == "__main__":
    main()