# lifecycle_manager.py

"""Governed Layer 1 lifecycle orchestration."""
from __future__ import annotations
import argparse, io, json, re
from contextlib import redirect_stdout
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Mapping, Optional

from updated_chunker import chunk_document
from dedup_detector import check_deduplication, update_registry_lifecycle_state
from metadata_extractor import MetadataExtractor
from parser import parse_document
from pii_detector import assess_report
from quality_scorer import calculate_quality_score, write_quality_audit
from expiry_manager import calculate_expiry_date

ROOT = Path(__file__).resolve().parent
LIFECYCLE_STORE_PATH = ROOT / "lifecycle_store.json"
STAGING_DIR = ROOT / "staging"
AUDIT_LOG_PATH = ROOT / "audit_log.jsonl"
DEDUP_STORE_PATH = ROOT / "dedup_store.json"
STATES = {"DRAFT", "UNDER_REVIEW", "ACTIVE", "ARCHIVED", "REJECTED"}
TRANSITIONS = {"DRAFT": {"UNDER_REVIEW", "REJECTED"}, "UNDER_REVIEW": {"ACTIVE", "REJECTED"},
               "ACTIVE": {"ARCHIVED"}, "ARCHIVED": {"ACTIVE"}, "REJECTED": set()}
PII_REJECTION_NOTE = "PII detected needs human review"

def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

def load_store(path: Optional[Path] = None) -> Dict[str, Any]:
    path = Path(path) if path else LIFECYCLE_STORE_PATH
    if not path.exists() or path.stat().st_size == 0:
        return {}
    return json.loads(path.read_text(encoding="utf-8"))

def save_store(store: Mapping[str, Any], path: Optional[Path] = None) -> None:
    path = Path(path) if path else LIFECYCLE_STORE_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(store, indent=2, ensure_ascii=False), encoding="utf-8")

load_lifecycle_store = load_store
save_lifecycle_store = save_store

def append_audit(event_type: str, document_uri: str, details: Mapping[str, Any], path: Optional[Path] = None) -> None:
    p = Path(path) if path else AUDIT_LOG_PATH
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps({"timestamp": utc_now(), "event_type": event_type,
                                 "document_uri": document_uri, "details": dict(details)}) + "\n")

def _record(uri: str, filename: str, fmt: str, state: str) -> Dict[str, Any]:
    now = utc_now()
    return {"document_uri": uri, "source_filename": filename, "format": fmt,
            "lifecycle_state": state, "review_flag_reason": None, "rejection_reason": None,
            "sensitivity_level": None, "allowed_therapeutic_areas": [],
            "allowed_geographies": [], "expiry_date": None, "reviewed_by": None,
            "review_notes": None, "quality_score": None, "quality_breakdown": {},
            "ingest_timestamp": now, "updated_at": now}

def _transition(store: Dict[str, Any], uri: str, state: str, *, reason: Optional[str] = None,
                reviewed_by: Optional[str] = None, audit_path: Optional[Path] = None) -> Dict[str, Any]:
    record = store[uri]
    old = record["lifecycle_state"]
    if state not in TRANSITIONS.get(old, set()):
        raise ValueError(f"Invalid lifecycle transition: {old} -> {state}")
    record["lifecycle_state"], record["updated_at"] = state, utc_now()
    if state == "REJECTED": record["rejection_reason"] = reason
    if reviewed_by is not None: record["reviewed_by"] = reviewed_by
    append_audit("STATE_TRANSITION", uri, {"old_state": old, "new_state": state, "reason": reason}, path=audit_path)
    return record

transition_document_state = _transition

def _write(value: Any, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False), encoding="utf-8")

def _document_number(path: Path, store: Optional[Dict[str, Any]] = None) -> int:
    digits = "".join(c for c in path.stem if c.isdigit())
    if digits:
        cand = int(digits)
        if not store or f"watson:Doc_{cand:03d}" not in store:
            return cand
    if store:
        existing_nums = []
        for k in store.keys():
            m = re.search(r"Doc_(\d+)", k)
            if m:
                existing_nums.append(int(m.group(1)))
        if existing_nums:
            return max(existing_nums) + 1
    return 1

def ingest(
    file_path: str | Path,
    *,
    strategy: str = "semantic_structural",
    document_number: Optional[int] = None,
    lifecycle_store_path: Optional[Path | str] = None,
    dedup_store_path: Optional[Path | str] = None,
    audit_log_path: Optional[Path | str] = None,
    staging_dir: Optional[Path | str] = None,
) -> Dict[str, Any]:
    l_store = Path(lifecycle_store_path) if lifecycle_store_path else LIFECYCLE_STORE_PATH
    d_store = Path(dedup_store_path) if dedup_store_path else DEDUP_STORE_PATH
    a_log = Path(audit_log_path) if audit_log_path else AUDIT_LOG_PATH
    s_dir = Path(staging_dir) if staging_dir else STAGING_DIR

    source = Path(file_path).resolve()
    if not source.is_file(): raise FileNotFoundError(source)
    store = load_store(l_store)
    doc_num = document_number if document_number is not None else _document_number(source, store)
    with redirect_stdout(io.StringIO()):
        parsed = parse_document(source, doc_num)
    print(f"Parser: completed - format={parsed.get('format')}, words={parsed.get('word_count', 0)}")
    uri, stem = parsed["document_uri"], source.stem
    parsed_path = s_dir / f"{stem}_parsed.json"; _write(parsed, parsed_path)
    parsed["parsed_artifact"] = str(parsed_path)
    with redirect_stdout(io.StringIO()):
        chunks = chunk_document(parsed)
    print(
        f"Chunker: completed - "
        f"{chunks.get('chunk_count', len(chunks.get('chunks', [])))} "
        f"{chunks.get('strategy', 'semantic_structural')} chunks"
    )
    chunks_path = s_dir / f"{stem}_chunks.json"; _write(chunks, chunks_path)
    with redirect_stdout(io.StringIO()):
        result, details = check_deduplication(
            parsed,
            str(d_store),
            str(a_log),
            parsed_artifact_dir=str(s_dir),
        )
    print(f"Deduplication: {result.lower().replace('_', ' ')}")
    if result == "EXACT_DUPLICATE": state = "REJECTED"
    elif result in {"NEAR_DUPLICATE", "NEW_VERSION"}: state = "UNDER_REVIEW"
    else: state = "DRAFT"
    store = load_store(l_store)
    if uri in store: raise ValueError(f"Document URI already exists: {uri}")
    record = _record(uri, parsed["source_filename"], parsed.get("format", ""), state)
    record["deduplication"] = {"result": result, "details": details}
    try:
        p_rel = str(parsed_path.relative_to(ROOT))
        c_rel = str(chunks_path.relative_to(ROOT))
    except ValueError:
        p_rel = str(parsed_path)
        c_rel = str(chunks_path)
    record["artifacts"] = {"parsed": p_rel, "chunks": c_rel}
    if result == "EXACT_DUPLICATE":
        record["rejection_reason"] = f"Exact duplicate of {details.get('original_document_uri')}"
        record["reviewed_by"] = "SYSTEM_DEDUP_AUTOMATION"
    elif result in {"NEAR_DUPLICATE", "NEW_VERSION"}:
        record["review_flag_reason"] = details.get("reason")
    store[uri] = record; save_store(store, l_store)
    if state == "REJECTED":
        update_registry_lifecycle_state(uri, state, str(d_store)); return record
    with redirect_stdout(io.StringIO()):
        pii = assess_report(chunks)
    pii_path = s_dir / f"{stem}_pii.json"; _write(pii, pii_path)
    try:
        record["artifacts"]["pii"] = str(pii_path.relative_to(ROOT))
    except ValueError:
        record["artifacts"]["pii"] = str(pii_path)
    print(
        "PII detection: rejected - PII detected needs human review"
        if pii["pii_detected"]
        else f"PII detection: completed - {pii['summary']['chunk_count_assessed']} chunks clear"
    )
    if pii["pii_detected"]:
        _transition(store, uri, "REJECTED", reason=PII_REJECTION_NOTE, audit_path=a_log)
        save_store(store, l_store)
        update_registry_lifecycle_state(uri, "REJECTED", str(d_store)); return record
    with redirect_stdout(io.StringIO()):
        metadata = MetadataExtractor().build_from_parsed_document(parsed, pii_output=pii)
        quality = calculate_quality_score(metadata, parsed.get("raw_text", ""))
        write_quality_audit(uri, quality, audit_log_path=a_log)
    record["quality_score"] = quality.get("quality_score")
    record["quality_breakdown"] = quality.get("quality_breakdown", {})
    print("Metadata extraction: completed")
    print(f"Quality scoring: completed - score={record['quality_score']}")
    if state == "DRAFT": _transition(store, uri, "UNDER_REVIEW", audit_path=a_log)
    save_store(store, l_store); update_registry_lifecycle_state(uri, "UNDER_REVIEW", str(d_store))
    print("Lifecycle: UNDER_REVIEW - awaiting HITL review")
    return record

def review(
    document_uri: str,
    approved: bool,
    notes: str = "",
    metadata: Optional[Mapping[str, Any]] = None,
    abac_attributes: Optional[Mapping[str, Any]] = None,
    lifecycle_store_path: Optional[Path | str] = None,
    dedup_store_path: Optional[Path | str] = None,
    audit_log_path: Optional[Path | str] = None,
) -> Dict[str, Any]:
    l_store = Path(lifecycle_store_path) if lifecycle_store_path else LIFECYCLE_STORE_PATH
    d_store = Path(dedup_store_path) if dedup_store_path else DEDUP_STORE_PATH
    a_log = Path(audit_log_path) if audit_log_path else AUDIT_LOG_PATH

    store = load_store(l_store)
    if document_uri not in store:
        raise KeyError(f"Document URI not found in lifecycle store: {document_uri}")
    record = store[document_uri]
    if not approved:
        _transition(store, document_uri, "REJECTED", reason=notes or "Rejected by reviewer", audit_path=a_log)
    else:
        data = dict(metadata or {}); abac = dict(abac_attributes or {})
        nested = data.get("abac_attributes")
        if isinstance(nested, Mapping):
            abac = {**nested, **abac}
        sensitivity = data.get("sensitivity_level", abac.get("sensitivity_level", record.get("sensitivity_level")))
        areas = data.get("allowed_therapeutic_areas", abac.get("allowed_therapeutic_areas"))
        geos = data.get("allowed_geographies", abac.get("allowed_geographies"))
        reviewer = data.get("reviewed_by", abac.get("reviewed_by"))
        review_notes = notes or data.get("review_notes") or abac.get("review_notes")
        errors = []
        if sensitivity not in {"PUBLIC","INTERNAL","RESTRICTED","CONFIDENTIAL"}: errors.append("sensitivity_level")
        if not isinstance(areas, list): errors.append("allowed_therapeutic_areas")
        if not isinstance(geos, list): errors.append("allowed_geographies")
        if not reviewer: errors.append("reviewed_by")
        if not review_notes: errors.append("review_notes")
        if errors: raise ValueError("Invalid metadata/ABAC: " + ", ".join(errors))
        record.update({"sensitivity_level": sensitivity, "allowed_therapeutic_areas": areas,
                       "allowed_geographies": geos, "reviewed_by": reviewer, "review_notes": review_notes})
        for field in ("document_uri", "source_filename", "format", "expiry_date", "study_type"):
            if data.get(field) is not None:
                record[field] = data[field]
        if not record.get("expiry_date") and data.get("study_type"):
            exp_res = calculate_expiry_date(
                data["study_type"], record["ingest_timestamp"]
            )
            record["expiry_date"] = exp_res["expiry_date"]
            record["expiry"] = {"expiry_date": exp_res["expiry_date"], "retention_days": exp_res.get("retention_days")}
        elif record.get("expiry_date"):
            record["expiry"] = {"expiry_date": record["expiry_date"]}
        _transition(store, document_uri, "ACTIVE", audit_path=a_log)
    save_store(store, l_store)
    update_registry_lifecycle_state(document_uri, record["lifecycle_state"], str(d_store))
    return record

def build_governed_document_package(
    document_uri: str,
    *,
    lifecycle_store_path: Optional[Path | str] = None,
    staging_dir: Optional[Path | str] = None,
) -> Dict[str, Any]:
    """Constructs the final governed ACTIVE package ready for Layer 2 ingestion."""
    store = load_store(Path(lifecycle_store_path) if lifecycle_store_path else LIFECYCLE_STORE_PATH)
    if document_uri not in store:
        raise KeyError(f"Document not found in lifecycle store: {document_uri}")
    record = store[document_uri]
    if record.get("lifecycle_state") != "ACTIVE":
        raise ValueError(f"Document {document_uri} is not in ACTIVE state (current: {record.get('lifecycle_state')})")

    s_dir = Path(staging_dir) if staging_dir else STAGING_DIR
    chunks_path = Path(record["artifacts"]["chunks"])
    if not chunks_path.is_absolute():
        chunks_path = ROOT / chunks_path
    if not chunks_path.exists():
        chunks_path = s_dir / chunks_path.name
    
    chunks_data = json.loads(chunks_path.read_text(encoding="utf-8")) if chunks_path.exists() else {}
    governed_chunks = chunks_data.get("chunks", [])

    return {
        "lifecycle_state": "ACTIVE",
        "document_uri": document_uri,
        "source_filename": record["source_filename"],
        "format": record["format"],
        "chunk_count": len(governed_chunks),
        "governed_chunks": governed_chunks,
        "sensitivity_level": record["sensitivity_level"],
        "abac_attributes": {
            "sensitivity_level": record["sensitivity_level"],
            "allowed_therapeutic_areas": record["allowed_therapeutic_areas"],
            "allowed_geographies": record["allowed_geographies"],
        },
        "quality_score": record["quality_score"],
        "quality_breakdown": record["quality_breakdown"],
        "expiry_date": record["expiry_date"],
        "reviewed_by": record["reviewed_by"],
        "review_notes": record["review_notes"],
        "ingest_timestamp": record["ingest_timestamp"],
        "artifacts": record["artifacts"],
        "ready_for_layer2": True,
    }

def archive(document_uri: str) -> Dict[str, Any]:
    store = load_store(); _transition(store, document_uri, "ARCHIVED"); save_store(store); return store[document_uri]
def reinstate(document_uri: str, notes: str = "") -> Dict[str, Any]:
    return review(document_uri, True, notes, {"reviewed_by": "SYSTEM", "review_notes": notes or "Reinstated",
        "sensitivity_level": load_store()[document_uri].get("sensitivity_level"),
        "allowed_therapeutic_areas": load_store()[document_uri].get("allowed_therapeutic_areas", []),
        "allowed_geographies": load_store()[document_uri].get("allowed_geographies", [])})
def get_state(document_uri: str) -> str: return str(load_store()[document_uri]["lifecycle_state"])

def main() -> int:
    p = argparse.ArgumentParser(); sub = p.add_subparsers(dest="command", required=True)
    i = sub.add_parser("ingest"); i.add_argument("file_path"); i.add_argument("--strategy", default="semantic_structural")
    r = sub.add_parser("review"); r.add_argument("document_uri"); r.add_argument("--approved", action="store_true")
    r.add_argument("--notes", default=""); r.add_argument("--metadata-json", type=Path); r.add_argument("--abac-json", type=Path)
    for name in ("archive", "get-state", "reinstate"):
        x=sub.add_parser(name); x.add_argument("document_uri"); x.add_argument("--notes", default="")
    a=p.parse_args()
    if a.command=="get-state": print(get_state(a.document_uri)); return 0
    if a.command=="ingest": result=ingest(a.file_path, strategy=a.strategy); print(f"{result['document_uri']}: {result['lifecycle_state']}")
    elif a.command=="review":
        m=json.loads(a.metadata_json.read_text()) if a.metadata_json else {}; b=json.loads(a.abac_json.read_text()) if a.abac_json else {}
        result=review(a.document_uri, a.approved, a.notes, m, b); print(f"{result['document_uri']}: {result['lifecycle_state']}")
    elif a.command=="archive": result=archive(a.document_uri); print(f"{result['document_uri']}: {result['lifecycle_state']}")
    else: result=reinstate(a.document_uri, a.notes); print(f"{result['document_uri']}: {result['lifecycle_state']}")
    return 0

if __name__ == "__main__": raise SystemExit(main())