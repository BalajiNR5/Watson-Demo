# quality_scorer.py

"""quality_scorer.py
Watson Pharma Knowledge Intelligence Platform
Calculates document quality using four signals:
1. Metadata completeness -> 30%
2. Text richness -> 30%
3. HCP sample size -> 20%
4. Freshness -> 20%
Final score:
quality_score =
    0.3 * metadata_completeness
    + 0.3 * text_richness
    + 0.2 * hcp_sample_signal
    + 0.2 * freshness
The quality score is between 0.0 and 1.0.
"""
import re
import json
import sys
from pathlib import Path
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

# ========================================================
# CONFIGURATION
# ========================================================
METADATA_WEIGHT = 0.30
TEXT_RICHNESS_WEIGHT = 0.30
HCP_WEIGHT = 0.20
FRESHNESS_WEIGHT = 0.20
FRESHNESS_PERIOD_DAYS = 730

# ========================================================
# REQUIRED 15 METADATA FIELDS
# ========================================================
REQUIRED_METADATA_FIELDS = [
    "document_uri",
    "source_filename",
    "format",
    "ingest_timestamp",
    "word_count",
    "extracted_title",
    "extracted_author",
    "study_type",
    "therapeutic_area",
    "geography",
    "brands_mentioned",
    "indications_mentioned",
    "language",
    "pii_assessment",
    "sensitivity_level",
]

# ========================================================
# CLINICAL VOCABULARY
# ========================================================
# This is an implementation-level vocabulary for the POC.
#
# It is NOT added to the 15-field metadata schema.
#
# Later, this can be replaced with the project's taxonomy store.
CLINICAL_VOCABULARY = {
    # Therapy areas
    "oncology",
    "cardiology",
    "neurology",
    "immunology",
    # Diseases / conditions
    "cancer",
    "tumor",
    "tumour",
    "carcinoma",
    "melanoma",
    "leukemia",
    "leukaemia",
    "lymphoma",
    "hypertension",
    "heart failure",
    "epilepsy",
    "migraine",
    "inflammation",
    # Clinical concepts
    "patient",
    "patients",
    "diagnosis",
    "diagnostic",
    "treatment",
    "therapy",
    "therapeutic",
    "clinical trial",
    "clinical study",
    "clinical research",
    "efficacy",
    "safety",
    "adverse event",
    "adverse events",
    "side effect",
    "side effects",
    "endpoint",
    "endpoints",
    "biomarker",
    "biomarkers",
    "placebo",
    "randomized",
    "randomised",
    "double blind",
    "dose",
    "dosage",
    "response",
    "survival",
    "progression",
    "disease",
    "symptom",
    "symptoms",
    "drug",
    "drugs",
    "medicine",
    "medication",
    "pharmacology",
    "pharmacological",
    "clinical outcome",
    "clinical outcomes",
    "patient population",
    "tolerability",
    "contraindication",
    "contraindications",
}
import json
from datetime import datetime, timezone
from pathlib import Path
AUDIT_LOG_PATH = Path("audit_log.jsonl")
def write_quality_audit(
    doc_uri,
    quality_result,
    audit_log_path=AUDIT_LOG_PATH
):
    """
    Append quality-scoring information to audit_log.jsonl.
    The audit log is append-only.
    """
    breakdown = quality_result["quality_breakdown"]
    event = {
        "timestamp": datetime.now(
            timezone.utc
        ).isoformat().replace("+00:00", "Z"),
        "event_type": "ENRICHMENT_COMPLETE",
        "document_uri": doc_uri,
        "details": {
            "quality_score":
                quality_result["quality_score"],
            "metadata_completeness":
                breakdown["metadata_completeness"],
            "text_richness":
                breakdown["text_richness"],
            "hcp_sample_size":
                breakdown["hcp_sample_size"],
            "hcp_sample_signal":
                breakdown["hcp_sample_signal"],
            "freshness":
                breakdown["freshness"]
        }
    }
    with open(
        audit_log_path,
        "a",
        encoding="utf-8"
    ) as f:
        f.write(
            json.dumps(
                event,
                ensure_ascii=False
            )
            + "\n"
        )
    print(
        f"Audit event written for {doc_uri}"
    )
# ========================================================
# HELPER: CHECK WHETHER VALUE IS POPULATED
# ========================================================
def is_populated(value: Any) -> bool:
    """
    Return True if a metadata value contains meaningful data.
    """
    if value is None:
        return False
    if isinstance(value, str):
        return bool(value.strip())
    if isinstance(value, (list, tuple, set, dict)):
        return len(value) > 0
    return True

# ========================================================
# 1. METADATA COMPLETENESS
# ========================================================
def calculate_metadata_completeness(
    metadata: Dict[str, Any]
) -> float:
    """
    Calculate metadata completeness.
    completeness =
        populated required fields / total required fields
    Returns a value between 0.0 and 1.0.
    """
    if not metadata:
        return 0.0
    populated_count = 0
    for field in REQUIRED_METADATA_FIELDS:
        if is_populated(metadata.get(field)):
            populated_count += 1
    completeness = (
        populated_count / len(REQUIRED_METADATA_FIELDS)
    )
    return round(
        min(max(completeness, 0.0), 1.0),
        4
    )

# ========================================================
# 2. CLINICAL VOCABULARY EXTRACTION
# ========================================================
def extract_clinical_vocabulary(
    text: str
) -> List[str]:
    """
    Extract unique clinical vocabulary terms from text.
    Matching is case-insensitive.
    Returns:
        List of unique clinical terms found.
    """
    if not text:
        return []
    text_lower = text.lower()
    found_terms = set()
    # Longer phrases first.
    vocabulary = sorted(
        CLINICAL_VOCABULARY,
        key=len,
        reverse=True
    )
    for term in vocabulary:
        pattern = (
            r"(?<!\w)"
            + re.escape(term.lower())
            + r"(?!\w)"
        )
        if re.search(pattern, text_lower):
            found_terms.add(term)
    return sorted(found_terms)

# ========================================================
# 3. TOTAL WORD COUNT
# ========================================================
def calculate_word_count(
    text: str
) -> int:
    """
    Count words in document text.
    """
    if not text:
        return 0
    words = re.findall(
        r"\b\w+\b",
        text,
        flags=re.UNICODE
    )
    return len(words)

# ========================================================
# 4. TEXT RICHNESS
# ========================================================
def calculate_text_richness(
    text: str,
    clinical_terms: Optional[List[str]] = None
) -> float:
    """
    Calculate text richness.
    Project definition:
        unique clinical vocabulary / total words
    Returns a value between 0.0 and 1.0.
    """
    total_words = calculate_word_count(text)
    if total_words == 0:
        return 0.0
    if clinical_terms is None:
        clinical_terms = extract_clinical_vocabulary(text)
    unique_clinical_terms = len(
        set(clinical_terms)
    )
    richness = (
        unique_clinical_terms / total_words
    )
    return round(
        min(max(richness, 0.0), 1.0),
        4
    )

# ========================================================
# 5. HCP SAMPLE SIZE EXTRACTION
# ========================================================
def extract_hcp_sample_size(
    text: str
) -> Optional[int]:
    """
    Attempt to extract HCP sample size from document text.
    Supported examples:
    n=350 HCPs
    N = 350 HCPs
    350 HCPs
    sample size of 350 HCPs
    350 healthcare professionals
    Returns:
        Integer sample size or None if not found.
    """
    if not text:
        return None
    patterns = [
        # n=350 HCPs
        r"\bn\s*=\s*(\d+)\s*(?:hcp|hcps|healthcare professionals|health care professionals?)\b",
        # sample size of 350 HCPs
        r"\bsample\s+size\s+(?:of|was|is)\s+(\d+)\s*(?:hcp|hcps|healthcare professionals|health care professionals?)\b",
        # 350 HCPs
        r"\b(\d+)\s*(?:hcp|hcps)\b",
        # 350 healthcare professionals
        r"\b(\d+)\s*(?:healthcare professionals|health care professionals?)\b",
    ]
    for pattern in patterns:
        match = re.search(
            pattern,
            text,
            flags=re.IGNORECASE
        )
        if match:
            try:
                return int(match.group(1))
            except (ValueError, IndexError):
                return None
    return None

# ========================================================
# 6. HCP SAMPLE SIZE QUALITY SIGNAL
# ========================================================
def calculate_hcp_sample_signal(
    sample_size: Optional[int]
) -> float:
    """
    Convert HCP sample size into a quality signal.
    Project-defined points:
        >= 300 -> 1.0
        < 20 -> 0.1
    For values between 20 and 299, this implementation
    uses linear interpolation.
    Missing sample size is kept separate from '<20'.
    """
    # No sample size found.
    #
    # We do NOT interpret missing as '<20'.
    if sample_size is None:
        return 0.0
    # Under 20.
    if sample_size < 20:
        return 0.1
    # 300 or more.
    if sample_size >= 300:
        return 1.0
    # Linear interpolation between 20 and 300.
    signal = (
        0.1
        + (
            (sample_size - 20)
            / (300 - 20)
        )
        * (1.0 - 0.1)
    )
    return round(
        min(max(signal, 0.0), 1.0),
        4
    )

# ========================================================
# 7. FRESHNESS
# ========================================================
def calculate_freshness(
    ingest_timestamp: Optional[str],
    current_time: Optional[datetime] = None
) -> float:
    """
    Calculate freshness.
    Project definition:
        freshness =
            1 - days_since_ingest / 730
    Result is clamped to [0, 1].
    """
    if not ingest_timestamp:
        return 0.0
    try:
        timestamp = ingest_timestamp.strip()
        # Support timestamps ending in Z.
        if timestamp.endswith("Z"):
            timestamp = timestamp[:-1] + "+00:00"
        ingest_date = datetime.fromisoformat(
            timestamp
        )
        # If timestamp has no timezone,
        # assume UTC for the POC.
        if ingest_date.tzinfo is None:
            ingest_date = ingest_date.replace(
                tzinfo=timezone.utc
            )
        if current_time is None:
            current_time = datetime.now(
                timezone.utc
            )
        if current_time.tzinfo is None:
            current_time = current_time.replace(
                tzinfo=timezone.utc
            )
        days_since_ingest = (
            current_time - ingest_date
        ).days
        freshness = (
            1
            - (
                days_since_ingest
                / FRESHNESS_PERIOD_DAYS
            )
        )
        return round(
            min(max(freshness, 0.0), 1.0),
            4
        )
    except (
        ValueError,
        TypeError,
        AttributeError
    ):
        return 0.0

# ========================================================
# 8. FINAL QUALITY SCORE
# ========================================================
def calculate_quality_score(
    metadata: Dict[str, Any],
    raw_text: str,
    hcp_sample_size: Optional[int] = None,
    current_time: Optional[datetime] = None
) -> Dict[str, Any]:
    """
    Calculate the final document quality score.
    Four signals:
        Metadata completeness -> 30%
        Text richness -> 30%
        HCP Sample size -> 20%
        Freshness -> 20%
    Returns a dictionary containing:
        quality_score
        quality_breakdown
    """
    # --------------------------------------------------------
    # Signal 1: Metadata completeness
    # --------------------------------------------------------
    metadata_completeness = (
        calculate_metadata_completeness(
            metadata
        )
    )
    # --------------------------------------------------------
    # Signal 2: Text richness
    # --------------------------------------------------------
    clinical_terms = (
        extract_clinical_vocabulary(
            raw_text
        )
    )
    text_richness = (
        calculate_text_richness(
            raw_text,
            clinical_terms
        )
    )
    # --------------------------------------------------------
    # Signal 3: HCP sample size
    # --------------------------------------------------------
    # If the caller does not provide it,
    # try to extract it from raw text.
    if hcp_sample_size is None:
        hcp_sample_size = (
            extract_hcp_sample_size(
                raw_text
            )
        )
    hcp_sample_signal = (
        calculate_hcp_sample_signal(
            hcp_sample_size
        )
    )
    # --------------------------------------------------------
    # Signal 4: Freshness
    # --------------------------------------------------------
    freshness = calculate_freshness(
        metadata.get("ingest_timestamp"),
        current_time=current_time
    )
    # --------------------------------------------------------
    # Final score
    # --------------------------------------------------------
    quality_score = (
        METADATA_WEIGHT
        * metadata_completeness
        + TEXT_RICHNESS_WEIGHT
        * text_richness
        + HCP_WEIGHT
        * hcp_sample_signal
        + FRESHNESS_WEIGHT
        * freshness
    )
    quality_score = round(
        min(max(quality_score, 0.0), 1.0),
        4
    )
    # --------------------------------------------------------
    # Return result
    # --------------------------------------------------------
    return {
        "quality_score": quality_score,
        "quality_breakdown": {
            "metadata_completeness": (
                metadata_completeness
            ),
            "metadata_weight": (
                METADATA_WEIGHT
            ),
            "text_richness": (
                text_richness
            ),
            "text_richness_weight": (
                TEXT_RICHNESS_WEIGHT
            ),
            "hcp_sample_size": (
                hcp_sample_size
            ),
            "hcp_sample_signal": (
                hcp_sample_signal
            ),
            "hcp_sample_weight": (
                HCP_WEIGHT
            ),
            "freshness": (
                freshness
            ),
            "freshness_weight": (
                FRESHNESS_WEIGHT
            )
        }
    }

# ========================================================
# 9. TEST / DEMO
# ========================================================
def print_quality_breakdown(breakdown: Dict[str, Any]) -> None:
    """
    Print a clean, readable quality breakdown.
    """
    labels = {
        "metadata_completeness": "metadata completeness",
        "metadata_weight": "metadata weight",
        "text_richness": "text richness",
        "text_richness_weight": "text richness weight",
        "hcp_sample_size": "hcp sample size",
        "hcp_sample_signal": "hcp sample signal",
        "hcp_sample_weight": "hcp sample weight",
        "freshness": "freshness",
        "freshness_weight": "freshness weight",
    }
    print("\nQUALITY BREAKDOWN:")
    for key, value in breakdown.items():
        label = labels.get(key, key.replace("_", " "))
        print(f" - {label}: {value}")

import json
from pathlib import Path
BASE_DIR = Path(__file__).resolve().parent
STAGING_DIR = BASE_DIR / "staging"
def load_json(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)
def find_parsed_file(metadata_path):
    """
    Find the parsed JSON corresponding to a metadata JSON.
    Example:
        doc_001_meta.json
            -> staging/doc_001_parsed.json
    """
    metadata_path = Path(metadata_path)
    # doc_001_meta.json -> doc_001
    document_id = metadata_path.stem.replace("_meta", "")
    parsed_path = STAGING_DIR / f"{document_id}_parsed.json"
    if not parsed_path.exists():
        raise FileNotFoundError(
            f"No parsed JSON found: {parsed_path}"
        )
    return parsed_path
def save_quality_result(result, output_path):
    """
    Add the quality score to the input JSON document in place.
    Preserve its existing fields and update the score on reruns.
    """
    output_path = Path(output_path)
    with open(output_path, "r", encoding="utf-8") as f:
        document = json.load(f)
    if not isinstance(document, dict):
        raise ValueError("Input JSON must contain a JSON object")
    document["quality_score"] = result["quality_score"]
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(
            document,
            f,
            indent=4,
            ensure_ascii=False,
        )
    print(f"\nQuality score added to: {output_path}")

if __name__ == "__main__":
    print("=" * 60)
    print("WATSON QUALITY SCORER TEST")
    print("=" * 60)
    if len(sys.argv) < 2:
        print("Usage:")
        print("python quality_scorer.py <metadata.json>")
        sys.exit(1)
    metadata_path = Path(sys.argv[1])
    # Load metadata
    metadata = load_json(metadata_path)
    print(f"Metadata file: {metadata_path}")
    # Find corresponding parsed document
    parsed_path = find_parsed_file(metadata_path)
    print(f"Parsed file: {parsed_path}")
    # Load parsed document
    parsed = load_json(parsed_path)
    # Get actual document text
    raw_text = parsed.get("raw_text", "")
    print(f"Raw text words: {len(raw_text.split())}")

    # Calculate
    result = calculate_quality_score(
        metadata=metadata,
        raw_text=raw_text,
    )
    write_quality_audit(
        doc_uri=metadata.get("document_uri", "unknown"),
        quality_result=result,
    )
    print("\nQUALITY SCORE:")
    print(result["quality_score"])
    print_quality_breakdown(result["quality_breakdown"])

    # SAVE THE QUALITY SCORE IN THE SOURCE JSON
    save_quality_result(
        result,
        metadata_path,
    )
    print("\n" + "=" * 60)
    print("QUALITY SCORER TEST COMPLETED")
    print("=" * 60)