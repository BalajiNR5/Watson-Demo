from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from watson.governance.abac_engine import evaluate_access, load_lifecycle_store
from watson.shared.config import (
    CHUNK_URI_MAP_FILE,
    LIFECYCLE_STORE_FILE,
    STORES_DATA_DIR,
    USER_REGISTRY_FILE,
)
from watson.shared.exceptions import ABACAccessDeniedError
from watson.shared.ids import make_space_uri
from watson.shared.models import KnowledgeSpaceModel

KNOWLEDGE_SPACES_FILE = STORES_DATA_DIR / "knowledge_spaces.json"


class KnowledgeSpaceManager:
    """
    Manages Knowledge Spaces, document membership, access permissions,
    and calculates health metrics (PRD Section 5.5, Q11).
    """

    def __init__(self, store_path: Path = KNOWLEDGE_SPACES_FILE):
        self.store_path = Path(store_path)
        self.spaces: Dict[str, Dict[str, Any]] = {}
        self._load_or_seed()

    def _load_or_seed(self):
        if self.store_path.exists():
            try:
                with open(self.store_path, "r", encoding="utf-8") as f:
                    self.spaces = json.load(f)
                    return
            except Exception:
                pass

        # Seed initial standard spaces
        now = datetime.now(timezone.utc).isoformat()
        self.spaces = {
            "Space_Oncology": {
                "space_id": "Space_Oncology",
                "space_uri": make_space_uri("Oncology"),
                "name": "Oncology Global Intelligence Space",
                "therapeutic_area": "Oncology",
                "spoc_user_id": "U_SPOC",
                "description": "Collaborative intelligence space covering solid tumors, NSCLC, and melanoma research.",
                "document_uris": [
                    "watson:Doc_001",
                    "watson:Doc_002",
                    "watson:Doc_004",
                    "watson:Doc_009",
                    "watson:Doc_010",
                    "watson:Doc_015",
                ],
                "created_at": now,
            },
            "Space_Cardiology": {
                "space_id": "Space_Cardiology",
                "space_uri": make_space_uri("Cardiology"),
                "name": "Cardiology & Heart Failure Space",
                "therapeutic_area": "Cardiology",
                "spoc_user_id": "D4",
                "description": "Heart failure therapies, Entresto KOL interviews, and clinical trial data.",
                "document_uris": [
                    "watson:Doc_003",
                    "watson:Doc_005",
                    "watson:Doc_013",
                ],
                "created_at": now,
            },
            "Space_Immunology": {
                "space_id": "Space_Immunology",
                "space_uri": make_space_uri("Immunology"),
                "name": "Immunology & Respiratory Space",
                "therapeutic_area": "Immunology",
                "spoc_user_id": "D4",
                "description": "Atopic dermatitis, asthma, and rare disease market access landscapes.",
                "document_uris": [
                    "watson:Doc_006",
                    "watson:Doc_007",
                    "watson:Doc_008",
                    "watson:Doc_011",
                    "watson:Doc_012",
                    "watson:Doc_014",
                ],
                "created_at": now,
            },
        }
        self._save()

    def _save(self):
        self.store_path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.store_path, "w", encoding="utf-8") as f:
            json.dump(self.spaces, f, indent=2)

    def list_spaces(self) -> List[Dict[str, Any]]:
        return list(self.spaces.values())

    def get_space(self, space_id: str) -> Optional[Dict[str, Any]]:
        return self.spaces.get(space_id)

    def create_space(
        self,
        space_id: str,
        name: str,
        therapeutic_area: str,
        spoc_user_id: str,
        description: str,
        user_role: str,
    ) -> Dict[str, Any]:
        if user_role not in ("SPOC", "ADMIN", "COMPLIANCE_OFFICER"):
            raise ABACAccessDeniedError("Only SPOC or ADMIN roles can create knowledge spaces.")

        space = {
            "space_id": space_id,
            "space_uri": make_space_uri(space_id),
            "name": name,
            "therapeutic_area": therapeutic_area,
            "spoc_user_id": spoc_user_id,
            "description": description,
            "document_uris": [],
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
        self.spaces[space_id] = space
        self._save()
        return space

    def add_document(self, space_id: str, doc_uri: str, user_role: str) -> bool:
        if user_role not in ("SPOC", "ADMIN", "COMPLIANCE_OFFICER"):
            raise ABACAccessDeniedError("Only SPOC or ADMIN roles can modify space membership.")
        if space_id not in self.spaces:
            return False
        if doc_uri not in self.spaces[space_id]["document_uris"]:
            self.spaces[space_id]["document_uris"].append(doc_uri)
            self._save()
        return True

    def get_space_health(self, space_id: str, user_id: str) -> Dict[str, Any]:
        """
        Calculates Q11 Knowledge Space Health metrics:
        - Document count (accessible by user)
        - Active vs expired documents
        - Average quality score
        - Total chunks
        - Sentiment distribution
        """
        space = self.get_space(space_id)
        if not space:
            return {"error": "Space not found"}

        lifecycle_store = load_lifecycle_store(LIFECYCLE_STORE_FILE)
        accessible_docs = []

        for doc_uri in space.get("document_uris", []):
            allowed, _, _ = evaluate_access(
                user_id=user_id,
                document_uri=doc_uri,
                user_registry_path=USER_REGISTRY_FILE,
                lifecycle_store_path=LIFECYCLE_STORE_FILE,
            )
            if allowed and doc_uri in lifecycle_store:
                accessible_docs.append(lifecycle_store[doc_uri])

        total_docs = len(accessible_docs)
        active_docs = sum(1 for d in accessible_docs if d.get("lifecycle_state") == "ACTIVE")
        avg_quality = (
            sum(float(d.get("quality_score", 0.8)) for d in accessible_docs) / max(total_docs, 1)
            if total_docs > 0
            else 0.0
        )

        # Count chunks belonging to accessible documents
        total_chunks = 0
        if CHUNK_URI_MAP_FILE.exists():
            with open(CHUNK_URI_MAP_FILE, "r", encoding="utf-8") as f:
                cmap = json.load(f)
            doc_uris_set = {d.get("document_uri") for d in accessible_docs}
            items_dict = cmap.get("index_to_chunk", cmap)
            total_chunks = sum(
                1 for c in items_dict.values()
                if isinstance(c, dict) and c.get("document_uri") in doc_uris_set
            )

        return {
            "space_id": space_id,
            "space_name": space["name"],
            "therapeutic_area": space["therapeutic_area"],
            "accessible_documents": total_docs,
            "active_documents": active_docs,
            "total_chunks": total_chunks,
            "average_quality_score": round(avg_quality, 3),
            "freshness_rating": "HIGH" if avg_quality > 0.75 else "MEDIUM",
            "spoc_user_id": space["spoc_user_id"],
            "status": "HEALTHY" if total_docs > 0 else "EMPTY",
        }
