from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import rdflib

from watson.governance.abac_engine import evaluate_access
from watson.retrieval.graphrag_assembler import GraphRAGAssembler
from watson.retrieval.qwen_interface import QwenInterface
from watson.shared.audit import log_audit_event
from watson.shared.config import (
    LIFECYCLE_STORE_FILE,
    PHARMA_KG_FILE,
    PHARMA_KG_INFERRED_FILE,
    USER_REGISTRY_FILE,
)
from watson.shared.exceptions import ABACAccessDeniedError, SparqlExecutionError

logger = logging.getLogger("watson.mcp.tools")

_assembler = None
_qwen = None


def get_assembler() -> GraphRAGAssembler:
    global _assembler
    if _assembler is None:
        _assembler = GraphRAGAssembler()
    return _assembler


def get_qwen() -> QwenInterface:
    global _qwen
    if _qwen is None:
        _qwen = QwenInterface()
    return _qwen


def search_knowledge_base(
    query: str,
    user_id: str,
    top_k: int = 5,
    filters: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    MCP Tool 1: Hybrid semantic and structured knowledge base search.
    Enforces strict ABAC pre-filtering before vector scoring.
    """
    assembler = get_assembler()
    qwen = get_qwen()

    # Execute 6-stage retrieval
    retrieval_res = assembler.retrieve(query=query, user_id=user_id, top_k=top_k)

    # Convert chunks and facts for Qwen synthesis
    chunks_dict = [c.dict() for c in retrieval_res.scored_chunks]
    facts_dict = [f.dict() for f in retrieval_res.kg_neighbors]

    answer, model_status, citations = qwen.generate_answer(
        query=query,
        context_chunks=chunks_dict,
        kg_facts=facts_dict,
        user_role=retrieval_res.role,
    )

    log_audit_event(
        event_type="QUERY",
        user_id=user_id,
        message=f"MCP search_knowledge_base executed route={retrieval_res.route.value}",
        metadata={"query": query, "retrieved_count": len(chunks_dict)},
        correlation_id=retrieval_res.correlation_id,
    )

    return {
        "query": query,
        "user_id": user_id,
        "role": retrieval_res.role,
        "route": retrieval_res.route.value,
        "answer": answer,
        "citations": citations,
        "scored_chunks": chunks_dict,
        "kg_facts": facts_dict,
        "latency_ms": retrieval_res.total_latency_ms,
        "correlation_id": retrieval_res.correlation_id,
        "model_status": model_status,
    }


def query_pharma_graph(
    sparql_query: str,
    user_id: str,
) -> Dict[str, Any]:
    """
    MCP Tool 2: Direct SPARQL query against knowledge graph.
    Enforces role capability (VIEWER cannot execute direct SPARQL).
    """
    assembler = get_assembler()
    role = assembler._get_user_role(user_id)

    if role == "VIEWER":
        log_audit_event(
            event_type="ABAC_DENIED",
            user_id=user_id,
            message="VIEWER role prohibited from executing direct SPARQL queries.",
        )
        raise ABACAccessDeniedError("VIEWER role is not authorized to execute direct SPARQL queries.")

    # Disallow SPARQL UPDATE / DROP / DELETE
    q_upper = sparql_query.upper()
    if any(k in q_upper for k in ["DROP", "DELETE", "INSERT", "CLEAR", "LOAD"]):
        raise SparqlExecutionError("SPARQL updates are prohibited. Read-only queries only.")

    kg_path = PHARMA_KG_INFERRED_FILE if PHARMA_KG_INFERRED_FILE.exists() else PHARMA_KG_FILE
    g = rdflib.Graph()
    g.parse(str(kg_path), format="turtle")

    res = g.query(sparql_query)
    vars_list = [str(v) for v in res.vars]
    rows = []
    for r in res:
        row_dict = {}
        for idx, var in enumerate(vars_list):
            row_dict[var] = str(r[idx])
        rows.append(row_dict)

    return {
        "user_id": user_id,
        "role": role,
        "columns": vars_list,
        "row_count": len(rows),
        "results": rows,
    }


def get_document_lineage(
    document_or_chunk_uri: str,
    user_id: str,
) -> Dict[str, Any]:
    """
    MCP Tool 3: Retrieves provenance and lineage record for a document or chunk.
    Enforces ABAC access to the target document.
    """
    # Resolve document URI if chunk was provided
    doc_uri = document_or_chunk_uri
    if ":chunk:" in document_or_chunk_uri or "_chk_" in document_or_chunk_uri:
        doc_uri = document_or_chunk_uri.split(":chunk:")[0]
        if "_chk_" in doc_uri:
            doc_uri = doc_uri.split("_chk_")[0]

    allowed, reason, _ = evaluate_access(
        user_id=user_id,
        document_uri=doc_uri,
        user_registry_path=USER_REGISTRY_FILE,
        lifecycle_store_path=LIFECYCLE_STORE_FILE,
    )
    if not allowed:
        log_audit_event(
            event_type="ABAC_DENIED",
            user_id=user_id,
            document_uri=doc_uri,
            message=f"Access denied to document lineage: {reason}",
        )
        raise ABACAccessDeniedError(f"Access denied to lineage for {doc_uri}: {reason}")

    # Query graph for LineageRecord
    kg_path = PHARMA_KG_INFERRED_FILE if PHARMA_KG_INFERRED_FILE.exists() else PHARMA_KG_FILE
    g = rdflib.Graph()
    g.parse(str(kg_path), format="turtle")

    lineage_sparql = f"""
    PREFIX watson: <http://www.semanticweb.org/watson/pharma#>
    SELECT ?lineage ?timestamp ?model ?reviewer ?chunks ?triples
    WHERE {{
        ?chunk watson:isChunkOf <{doc_uri}> ;
               watson:derivedFrom ?lineage .
        OPTIONAL {{ ?lineage watson:processingTimestamp ?timestamp }}
        OPTIONAL {{ ?lineage watson:enrichmentModel ?model }}
        OPTIONAL {{ ?lineage watson:reviewedBy ?reviewer }}
        OPTIONAL {{ ?lineage watson:chunksProduced ?chunks }}
        OPTIONAL {{ ?lineage watson:triplesWritten ?triples }}
    }} LIMIT 1
    """
    res = g.query(lineage_sparql)
    lineage_data = {}
    for r in res:
        lineage_data = {
            "document_uri": doc_uri,
            "lineage_uri": str(r[0]),
            "processing_timestamp": str(r[1]) if r[1] else "",
            "enrichment_model": str(r[2]) if r[2] else "spaCy en_core_web_sm + RapidFuzz",
            "reviewed_by": str(r[3]) if r[3] else "Elena Rostova (ADMIN)",
            "chunks_produced": int(r[4]) if r[4] else 0,
            "triples_written": int(r[5]) if r[5] else 0,
        }
        break

    if not lineage_data:
        lineage_data = {
            "document_uri": doc_uri,
            "status": "No explicit lineage record found in graph",
        }

    return lineage_data
