from __future__ import annotations

import json
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from watson.shared.config import TELEMETRY_STORE_FILE

_LOCK = threading.Lock()


def log_telemetry_event(
    user_id: str,
    user_role: str,
    query: str,
    route: str,
    retrieved_count: int,
    latency_ms: float,
    guardrail_status: str = "PASSED",
    document_uris_accessed: Optional[List[str]] = None,
    correlation_id: Optional[str] = None,
    extra: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Logs retrieval telemetry event to data/stores/telemetry_store.json.
    Ensures zero plain-text restricted document content is stored.
    """
    cid = correlation_id or str(uuid.uuid4())
    timestamp = datetime.now(timezone.utc).isoformat()

    event = {
        "event_id": str(uuid.uuid4()),
        "correlation_id": cid,
        "timestamp": timestamp,
        "user_id": user_id,
        "role": user_role,
        "query": query,
        "route": route,
        "retrieved_count": retrieved_count,
        "latency_ms": round(latency_ms, 2),
        "guardrail_status": guardrail_status,
        "document_uris_accessed": document_uris_accessed or [],
        "extra": extra or {},
    }

    TELEMETRY_STORE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with _LOCK:
        data = []
        if TELEMETRY_STORE_FILE.exists():
            try:
                with open(TELEMETRY_STORE_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
            except Exception:
                data = []

        data.append(event)
        with open(TELEMETRY_STORE_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

    return event


def get_telemetry_stats() -> Dict[str, Any]:
    """Aggregates telemetry statistics."""
    if not TELEMETRY_STORE_FILE.exists():
        return {
            "total_queries": 0,
            "average_latency_ms": 0.0,
            "route_distribution": {},
            "guardrail_blocks": 0,
        }

    with _LOCK:
        try:
            with open(TELEMETRY_STORE_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            return {"total_queries": 0}

    total = len(data)
    if total == 0:
        return {"total_queries": 0, "average_latency_ms": 0.0, "route_distribution": {}}

    avg_latency = sum(e.get("latency_ms", 0.0) for e in data) / total
    routes = {}
    guardrail_blocks = 0
    for e in data:
        r = e.get("route", "UNKNOWN")
        routes[r] = routes.get(r, 0) + 1
        if e.get("guardrail_status") != "PASSED":
            guardrail_blocks += 1

    return {
        "total_queries": total,
        "average_latency_ms": round(avg_latency, 2),
        "route_distribution": routes,
        "guardrail_blocks": guardrail_blocks,
        "recent_events": data[-10:],
    }
