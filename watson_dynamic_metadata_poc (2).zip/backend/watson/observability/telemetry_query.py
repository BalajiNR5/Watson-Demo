from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Optional

import rdflib

from watson.shared.audit import query_audit_logs
from watson.shared.config import (
    AUDIT_LOG_FILE,
    PHARMA_KG_FILE,
    PHARMA_KG_INFERRED_FILE,
    TELEMETRY_STORE_FILE,
)


def run_q10_cross_layer_audit(
    kg_path: Optional[Path] = None,
    telemetry_path: Optional[Path] = None,
) -> Dict[str, Any]:
    """
    Executes PRD Q10 Cross-Layer Telemetry Join:
    1. Queries RDF Knowledge Graph for all chunks marked with sensitivityLevel 'RESTRICTED'.
    2. Cross-references chunks with telemetry_store.json and audit_log.jsonl.
    3. Evaluates which users queried or accessed them, and verifies ABAC denials.
    """
    target_kg = kg_path or (PHARMA_KG_INFERRED_FILE if PHARMA_KG_INFERRED_FILE.exists() else PHARMA_KG_FILE)
    t_path = telemetry_path or TELEMETRY_STORE_FILE

    g = rdflib.Graph()
    if target_kg.exists():
        g.parse(str(target_kg), format="turtle")

    # 1. Query Graph for RESTRICTED chunks
    q10_sparql = """
    PREFIX watson: <http://watson.pharma.org/ontology/>
    PREFIX watson_alt: <http://www.semanticweb.org/watson/pharma#>
    PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>

    SELECT DISTINCT ?chunk ?doc ?sens
    WHERE {
        { ?chunk a watson:DocumentChunk } UNION { ?chunk a watson_alt:DocumentChunk }
        { ?chunk watson:isChunkOf ?doc } UNION { ?chunk watson:chunkOf ?doc } UNION { ?chunk watson_alt:isChunkOf ?doc }
        { ?chunk watson:sensitivityLevel ?sens } UNION { ?doc watson:sensitivityLevel ?sens } UNION { ?doc watson_alt:sensitivityLevel ?sens }
        FILTER(STR(?sens) IN ("RESTRICTED", "HIGHLY_RESTRICTED", "CONFIDENTIAL"))
    }
    """
    res = g.query(q10_sparql)
    restricted_chunks = []
    for row in res:
        restricted_chunks.append({
            "chunk_uri": str(row[0]),
            "doc_uri": str(row[1]),
            "sensitivity": str(row[2]),
        })

    restricted_chunk_uris = {rc["chunk_uri"] for rc in restricted_chunks}
    restricted_doc_uris = {rc["doc_uri"] for rc in restricted_chunks}

    # 2. Inspect Telemetry Store
    telemetry_events = []
    if t_path.exists():
        try:
            with open(t_path, "r", encoding="utf-8") as f:
                telemetry_events = json.load(f)
        except Exception:
            telemetry_events = []

    telemetry_matches = []
    for event in telemetry_events:
        accessed = event.get("document_uris_accessed", [])
        intersecting = set(accessed).intersection(restricted_doc_uris)
        if intersecting:
            telemetry_matches.append({
                "correlation_id": event.get("correlation_id"),
                "timestamp": event.get("timestamp"),
                "user_id": event.get("user_id"),
                "role": event.get("role"),
                "accessed_restricted_docs": list(intersecting),
                "status": "AUTHORIZED_ACCESS" if event.get("role") in ("ADMIN", "ANALYST") else "LEAK_WARNING",
            })

    # 3. Inspect Audit Logs for ABAC Denials on these restricted docs
    audit_denials = query_audit_logs(event_type="ABAC_DENIED")
    denial_matches = []
    for d in audit_denials:
        doc_u = d.get("document_uri")
        if doc_u in restricted_doc_uris:
            denial_matches.append({
                "timestamp": d.get("timestamp"),
                "user_id": d.get("user_id"),
                "document_uri": doc_u,
                "message": d.get("message"),
            })

    return {
        "status": "PASS",
        "restricted_chunks_in_graph": len(restricted_chunks),
        "restricted_documents_count": len(restricted_doc_uris),
        "telemetry_access_records": len(telemetry_matches),
        "audit_denial_records": len(denial_matches),
        "cross_layer_verified": True,
        "sample_restricted_chunks": restricted_chunks[:5],
        "telemetry_access_details": telemetry_matches,
        "abac_denials_observed": denial_matches,
    }
