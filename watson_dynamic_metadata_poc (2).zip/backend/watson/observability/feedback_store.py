from __future__ import annotations

import json
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from watson.shared.config import FEEDBACK_STORE_FILE

_LOCK = threading.Lock()


def record_feedback(
    correlation_id: str,
    user_id: str,
    rating: int,
    comment: str = "",
) -> Dict[str, Any]:
    """Records user feedback in feedback_store.json."""
    timestamp = datetime.now(timezone.utc).isoformat()
    item = {
        "feedback_id": str(uuid.uuid4()),
        "correlation_id": correlation_id,
        "user_id": user_id,
        "rating": rating,
        "comment": comment,
        "timestamp": timestamp,
    }

    FEEDBACK_STORE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with _LOCK:
        data = []
        if FEEDBACK_STORE_FILE.exists():
            try:
                with open(FEEDBACK_STORE_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
            except Exception:
                data = []

        data.append(item)
        with open(FEEDBACK_STORE_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

    return item


def list_feedback() -> List[Dict[str, Any]]:
    """Returns all recorded feedback items."""
    if not FEEDBACK_STORE_FILE.exists():
        return []

    with _LOCK:
        try:
            with open(FEEDBACK_STORE_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return []
