from __future__ import annotations

from enum import Enum
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field


class LifecycleState(str, Enum):
    DRAFT = "DRAFT"
    UNDER_REVIEW = "UNDER_REVIEW"
    ACTIVE = "ACTIVE"
    ARCHIVED = "ARCHIVED"
    REJECTED = "REJECTED"


class SensitivityLevel(str, Enum):
    PUBLIC = "PUBLIC"
    INTERNAL = "INTERNAL"
    RESTRICTED = "RESTRICTED"


class UserRole(str, Enum):
    VIEWER = "VIEWER"
    ANALYST = "ANALYST"
    SPOC = "SPOC"
    ADMIN = "ADMIN"


class QueryRoute(str, Enum):
    SPARQL = "SPARQL"
    VECTOR = "VECTOR"
    HYBRID = "HYBRID"
    CONVERSATIONAL = "CONVERSATIONAL"


class ConversationIntent(str, Enum):
    GREETING = "GREETING"
    SMALL_TALK = "SMALL_TALK"
    CAPABILITY_HELP = "CAPABILITY_HELP"
    CLARIFICATION = "CLARIFICATION"
    RESEARCH_QUESTION = "RESEARCH_QUESTION"
    FOLLOW_UP_RESEARCH = "FOLLOW_UP_RESEARCH"
    SOURCE_LINEAGE_REQUEST = "SOURCE_LINEAGE_REQUEST"
    OUT_OF_SCOPE = "OUT_OF_SCOPE"
    AMBIGUOUS = "AMBIGUOUS"


class QuestionType(str, Enum):
    DIRECT_RESEARCH_SYNTHESIS = "DIRECT_RESEARCH_SYNTHESIS"
    DIRECT_SYNTHESIS = "DIRECT_RESEARCH_SYNTHESIS"
    MARKET_ACCESS_COMPARISON = "MARKET_ACCESS_COMPARISON"
    CLINICAL_CLAIM_VERIFICATION = "CLINICAL_CLAIM_VERIFICATION"
    CLINICAL_COMPARATIVE_EVIDENCE = "CLINICAL_CLAIM_VERIFICATION"
    QUANTITATIVE_CLINICAL_EVIDENCE = "QUANTITATIVE_CLINICAL_EVIDENCE"
    ONTOLOGY_RELATIONSHIP_TRACE = "ONTOLOGY_RELATIONSHIP_TRACE"
    TEMPORAL_SENTIMENT_ANALYSIS = "TEMPORAL_SENTIMENT_ANALYSIS"
    KNOWLEDGE_GRAPH_AGGREGATION = "KNOWLEDGE_GRAPH_AGGREGATION"
    KNOWLEDGE_GAP_ANALYSIS = "KNOWLEDGE_GAP_ANALYSIS"
    PROVENANCE_TRACE = "PROVENANCE_TRACE"
    INSUFFICIENT_EVIDENCE = "INSUFFICIENT_EVIDENCE"
    # Backward compatibility aliases
    COMPARATIVE_SYNTHESIS = "MARKET_ACCESS_COMPARISON"
    TEMPORAL_SYNTHESIS = "TEMPORAL_SENTIMENT_ANALYSIS"
    SEMANTIC_RELATIONSHIP = "ONTOLOGY_RELATIONSHIP_TRACE"
    LINEAGE_TRACE = "PROVENANCE_TRACE"


class ClaimSupportStatus(str, Enum):
    SUPPORTED = "SUPPORTED"
    PARTIALLY_SUPPORTED = "PARTIALLY_SUPPORTED"
    UNSUPPORTED = "UNSUPPORTED"
    CONTRADICTED = "CONTRADICTED"


class ClaimRecord(BaseModel):
    claim_id: str
    claim_text: str
    supporting_chunk_uris: List[str] = Field(default_factory=list)
    supporting_graph_fact_ids: List[str] = Field(default_factory=list)
    requested_entity_alignment: str = "ALIGNED"
    indication_alignment: str = "ALIGNED"
    geography_alignment: str = "ALIGNED"
    evidence_type: str = "DOCUMENT_CHUNK"  # DOCUMENT_CHUNK, GRAPH_ASSERTION, EVIDENCE_BOUNDARY_STATEMENT
    support_status: ClaimSupportStatus = ClaimSupportStatus.SUPPORTED


class SubjectEntityQuery(BaseModel):
    brand: Optional[str] = None
    drug: Optional[str] = None
    indication: Optional[str] = None
    therapeutic_area: Optional[str] = None
    geography: Optional[str] = None
    canonical_uri: Optional[str] = None
    brand_uri: Optional[str] = None
    drug_uri: Optional[str] = None
    indication_uri: Optional[str] = None
    therapeutic_area_uri: Optional[str] = None
    geography_uri: Optional[str] = None
    document_uri: Optional[str] = None
    chunk_uri: Optional[str] = None

    def to_evidence_tuple(self) -> Dict[str, Optional[str]]:
        return {
            "brand_uri": self.brand_uri or self.canonical_uri,
            "drug_uri": self.drug_uri,
            "indication_uri": self.indication_uri,
            "therapeutic_area_uri": self.therapeutic_area_uri,
            "geography_uri": self.geography_uri,
            "document_uri": self.document_uri,
            "chunk_uri": self.chunk_uri,
        }


class QueryIntent(BaseModel):
    raw_query: str
    effective_query: str = ""
    question_type: QuestionType = QuestionType.DIRECT_SYNTHESIS
    conversation_intent: ConversationIntent = ConversationIntent.RESEARCH_QUESTION
    route: QueryRoute = QueryRoute.HYBRID
    route_reason: str = ""
    is_conversational: bool = False
    clinical_superiority_claim: bool = False
    conversational_response: Optional[str] = None
    requested_subjects: List[SubjectEntityQuery] = Field(default_factory=list)
    requested_entities: List[str] = Field(default_factory=list)
    requested_indications: List[str] = Field(default_factory=list)
    requested_therapeutic_areas: List[str] = Field(default_factory=list)
    requested_geographies: List[str] = Field(default_factory=list)
    requested_evidence_categories: List[str] = Field(default_factory=list)
    requested_comparison_dimensions: List[str] = Field(default_factory=list)
    required_answer_sections: List[str] = Field(default_factory=list)
    temporal_constraints: Optional[Dict[str, Any]] = None
    minimum_evidence_coverage: float = 1.0


class QueryPlan(BaseModel):
    request_id: str = ""
    authenticated_user_id: str = "D4"
    conversation_id: str = ""
    original_question: str = ""
    conversational_intent: ConversationIntent = ConversationIntent.RESEARCH_QUESTION
    research_intent: QuestionType = QuestionType.DIRECT_RESEARCH_SYNTHESIS
    requested_entities: List[str] = Field(default_factory=list)
    canonical_entity_uris: List[str] = Field(default_factory=list)
    required_brand_drug_indication_bindings: List[SubjectEntityQuery] = Field(default_factory=list)
    requested_geographies: List[str] = Field(default_factory=list)
    requested_therapeutic_areas: List[str] = Field(default_factory=list)
    requested_document_ids: List[str] = Field(default_factory=list)
    requested_metrics: List[str] = Field(default_factory=list)
    temporal_constraints: Optional[Dict[str, Any]] = None
    comparison_dimensions: List[str] = Field(default_factory=list)
    expected_answer_structure: str = "STRUCTURED_SECTIONS"
    required_evidence_types: List[str] = Field(default_factory=list)
    evidence_scope: str = "GLOBAL"
    authorization_context: Dict[str, Any] = Field(default_factory=dict)

    # Superset fields for direct interoperability with QueryIntent
    conversation_intent: ConversationIntent = ConversationIntent.RESEARCH_QUESTION
    raw_query: str = ""
    effective_query: str = ""
    question_type: QuestionType = QuestionType.DIRECT_RESEARCH_SYNTHESIS
    route: QueryRoute = QueryRoute.HYBRID
    route_reason: str = ""
    is_conversational: bool = False
    clinical_superiority_claim: bool = False
    conversational_response: Optional[str] = None
    requested_subjects: List[SubjectEntityQuery] = Field(default_factory=list)
    requested_indications: List[str] = Field(default_factory=list)
    requested_evidence_categories: List[str] = Field(default_factory=list)
    requested_comparison_dimensions: List[str] = Field(default_factory=list)
    required_answer_sections: List[str] = Field(default_factory=list)
    minimum_evidence_coverage: float = 1.0


class SubjectEvidenceCoverage(BaseModel):
    subject_brand: str
    drug: Optional[str] = None
    indication: Optional[str] = None
    geography: Optional[str] = None
    therapeutic_area: Optional[str] = None
    authorized_docs: List[str] = Field(default_factory=list)
    chunks: List[Any] = Field(default_factory=list)
    kg_facts: List[Any] = Field(default_factory=list)
    covered_dimensions: List[str] = Field(default_factory=list)
    missing_dimensions: List[str] = Field(default_factory=list)
    coverage_status: str = "FULLY_SUPPORTED"  # FULLY_SUPPORTED, PARTIAL, INSUFFICIENT_EVIDENCE
    citation_uris: List[str] = Field(default_factory=list)


class EvidenceCoverageMatrix(BaseModel):
    question_type: QuestionType
    subjects: List[SubjectEvidenceCoverage] = Field(default_factory=list)
    common_factors: List[str] = Field(default_factory=list)
    established_differences: List[str] = Field(default_factory=list)
    total_coverage_ratio: float = 1.0


class UserContext(BaseModel):
    user_id: str
    role: UserRole
    assigned_ta: List[str] = Field(default_factory=list)
    assigned_geo: List[str] = Field(default_factory=list)
    clearance: SensitivityLevel = SensitivityLevel.INTERNAL

    def can_access_sensitivity(self, doc_sens: SensitivityLevel) -> bool:
        if self.role == UserRole.ADMIN:
            return True
        if self.role == UserRole.SPOC:
            # SPOC has access to all sensitivities within their TA
            return True
        if self.role == UserRole.ANALYST:
            # Analyst can access PUBLIC, INTERNAL, RESTRICTED if permitted by clearance
            return True
        if self.role == UserRole.VIEWER:
            # Viewer CANNOT access RESTRICTED documents
            return doc_sens in (SensitivityLevel.PUBLIC, SensitivityLevel.INTERNAL)
        return False

    def can_access_ta(self, doc_tas: List[str]) -> bool:
        if self.role == UserRole.ADMIN:
            return True
        if not self.assigned_ta or "*" in self.assigned_ta:
            return True
        if not doc_tas:
            return True
        return any(ta in self.assigned_ta for ta in doc_tas)

    def can_access_geo(self, doc_geos: List[str]) -> bool:
        if self.role == UserRole.ADMIN:
            return True
        if not self.assigned_geo or "*" in self.assigned_geo:
            return True
        if not doc_geos:
            return True
        return any(geo in self.assigned_geo for geo in doc_geos)


class ParsedSection(BaseModel):
    title: str
    level: int = 1
    content: str
    page_number: Optional[int] = None
    slide_number: Optional[int] = None
    speaker_notes: Optional[str] = None


class ParsedDocument(BaseModel):
    doc_id: str
    source_file: str
    file_format: str
    sha256: str
    page_count: int = 0
    word_count: int = 0
    text_content: str = ""
    sections: List[ParsedSection] = Field(default_factory=list)
    warnings: List[str] = Field(default_factory=list)


class DocumentChunk(BaseModel):
    chunk_id: str
    chunk_uri: str
    doc_id: str
    doc_uri: str
    content: str
    strategy: str = "B"
    page_number: Optional[int] = None
    slide_number: Optional[int] = None
    section_title: Optional[str] = None
    token_count: int = 0
    char_count: int = 0
    quality_score: float = 1.0
    sensitivity_level: SensitivityLevel = SensitivityLevel.INTERNAL
    allowed_ta: List[str] = Field(default_factory=list)
    allowed_geo: List[str] = Field(default_factory=list)


class PIIFinding(BaseModel):
    category: str
    span: str
    start: int
    end: int
    confidence: float = 1.0


class PIIResult(BaseModel):
    doc_id: str
    has_pii: bool
    findings: List[PIIFinding] = Field(default_factory=list)
    masked_text: str
    requires_review: bool = False


class MetadataResult(BaseModel):
    doc_id: str
    title: str
    doc_type: str
    therapeutic_area: str
    indication: str
    drug_name: str
    brand: str
    geography: str
    study_type: str
    study_date: str
    sample_size: int = 0
    sponsor: str = "Global Pharma"
    sensitivity_level: SensitivityLevel = SensitivityLevel.INTERNAL
    allowed_ta: List[str] = Field(default_factory=list)
    allowed_geo: List[str] = Field(default_factory=list)
    quality_score: float = 0.8
    freshness_score: float = 1.0
    extraction_confidence: float = 1.0
    expiry_date: Optional[str] = None


class ReviewDecision(BaseModel):
    doc_id: str
    reviewer: str
    decision: str  # "APPROVE", "REJECT", "HOLD"
    review_note: str = ""
    sensitivity_level: Optional[SensitivityLevel] = None
    allowed_ta: Optional[List[str]] = None
    allowed_geo: Optional[List[str]] = None
    expiry_date: Optional[str] = None
    pii_override: bool = False


class StageTraceItem(BaseModel):
    stage_number: int
    stage_name: str
    status: str = "COMPLETED"  # PENDING, RUNNING, COMPLETED, SKIPPED, BLOCKED, FAILED
    summary: str = ""
    timestamp: str = ""
    input_count: int = 0
    output_count: int = 0
    details: Dict[str, Any] = Field(default_factory=dict)
    elapsed_ms: float = 0.0


class KGNeighbor(BaseModel):
    subject: str
    predicate: str
    object: str
    assertion_type: str = "ASSERTED"  # ASSERTED, INFERRED, SEED
    source_doc_uri: Optional[str] = None
    date: Optional[str] = None
    score: Optional[float] = None


class KGFact(BaseModel):
    subject: str
    predicate: str
    object: str
    assertion_type: str = "ASSERTED"  # ASSERTED, INFERRED, SEED
    source_doc_uri: Optional[str] = None
    date: Optional[str] = None
    score: Optional[float] = None


class LineageRecord(BaseModel):
    claim_id: str
    chunk_uri: str
    document_uri: str
    source_filename: str
    page_number: Optional[int] = 1
    char_offsets: Optional[str] = None
    reviewer_id: str = "D4"
    approval_date: Optional[str] = None
    lifecycle_state: str = "ACTIVE"
    quality_score: float = 0.85
    rdf_path: Optional[str] = None
    audit_event_id: Optional[str] = None


class ScoredChunk(BaseModel):
    chunk_uri: str
    doc_uri: str
    content: str
    similarity: float
    quality_score: float
    composite_score: float
    page_number: Optional[int] = None
    section_title: Optional[str] = None
    brand: Optional[str] = None
    drug: Optional[str] = None
    indication: Optional[str] = None
    therapeutic_area: Optional[str] = None
    geography: Optional[str] = None


class RetrievalResult(BaseModel):
    query: str
    user_id: str
    role: str
    route: QueryRoute
    allowed_chunk_uris: List[str] = Field(default_factory=list)
    scored_chunks: List[ScoredChunk] = Field(default_factory=list)
    kg_neighbors: List[KGNeighbor] = Field(default_factory=list)
    kg_facts: List[KGFact] = Field(default_factory=list)
    lineage_records: List[LineageRecord] = Field(default_factory=list)
    stage_traces: List[StageTraceItem] = Field(default_factory=list)
    correlation_id: str
    active_provider: str = "DETERMINISTIC_GROUNDED_FALLBACK"
    total_latency_ms: float = 0.0


class Citation(BaseModel):
    source_uri: str
    doc_uri: str
    excerpt: str
    score: float
    page_number: Optional[int] = 1


class EvidenceItem(BaseModel):
    document_uri: str
    chunk_uri: str
    original_source_location: str = ""
    brand: Optional[str] = None
    drug: Optional[str] = None
    indication: Optional[str] = None
    therapeutic_area: Optional[str] = None
    geography: Optional[str] = None
    graph_relationships: List[str] = Field(default_factory=list)
    sparql_bindings: List[Dict[str, Any]] = Field(default_factory=list)
    exact_supporting_passage: str = ""
    retrieval_score: float = 0.0
    quality_score: float = 0.85
    authorization_result: str = "PERMITTED"
    lifecycle_status: str = "ACTIVE"
    provenance: Dict[str, Any] = Field(default_factory=dict)
    evidence_type: str = "DOCUMENT_CHUNK"  # DOCUMENT_CHUNK, GRAPH_ASSERTION, SENTIMENT_ASSERTION, LINEAGE_AUDIT
    evidence_relevance: str = "RELEVANT"
    requested_dimension_coverage: List[str] = Field(default_factory=list)


class EvidenceSet(BaseModel):
    request_id: str = ""
    items: List[EvidenceItem] = Field(default_factory=list)
    evidence_tuples: List[Dict[str, Optional[str]]] = Field(default_factory=list)
    graph_facts: List[KGFact] = Field(default_factory=list)
    missing_evidence: List[str] = Field(default_factory=list)
    coverage_ratio: float = 1.0


class AnswerPlan(BaseModel):
    request_id: str = ""
    strategy: str = "DIRECT_RESEARCH_SYNTHESIS"
    required_sections: List[str] = Field(default_factory=list)
    evidence_set: Optional[EvidenceSet] = None
    format_template: str = "STANDARD"
    synthesized_response: str = ""


class AnswerResponse(BaseModel):
    answer_id: str
    correlation_id: str
    query: str
    route: QueryRoute
    answer: str
    citations: List[Citation] = Field(default_factory=list)
    scored_chunks: List[ScoredChunk] = Field(default_factory=list)
    kg_facts: List[KGFact] = Field(default_factory=list)
    lineage_records: List[LineageRecord] = Field(default_factory=list)
    live_stages: List[StageTraceItem] = Field(default_factory=list)
    guardrail_status: str = "PASSED"
    guardrail_warnings: List[str] = Field(default_factory=list)
    model_status: str = "ONLINE"
    active_provider: str = "DETERMINISTIC_GROUNDED_FALLBACK"
    latency_ms: float = 0.0
    user_role: str = "ADMIN"
    pipeline_execution_status: str = "COMPLETED"
    answer_grounding_status: str = "GROUNDED"
    answer_relevance_status: str = "RELEVANT"
    quality_diagnostics: Dict[str, Any] = Field(default_factory=dict)
    evidence_gap_detected: bool = False
    evidence_coverage_matrix: Optional[Dict[str, Any]] = None
    claims: List[ClaimRecord] = Field(default_factory=list)
    clinical_claim_verified: Optional[str] = None
    conversation_intent: Optional[str] = None
    query_plan: Optional[QueryPlan] = None
    evidence_set: Optional[EvidenceSet] = None
    answer_plan: Optional[AnswerPlan] = None
    intent_match_status: str = "MATCHED"
    entity_coverage_status: str = "COVERED"
    geography_alignment_status: str = "ALIGNED"
    answer_completeness_status: str = "COMPLETE"
    claim_grounding_status: str = "GROUNDED"
    citation_validity_status: str = "VALID"


class FeedbackItem(BaseModel):
    feedback_id: str
    correlation_id: str
    user_id: str
    rating: int  # 1 to 5
    comment: str = ""
    timestamp: str


class KnowledgeSpaceModel(BaseModel):
    space_id: str
    space_uri: str
    name: str
    therapeutic_area: str
    spoc_user_id: str
    description: str
    document_uris: List[str] = Field(default_factory=list)
    created_at: str
