"""
Centralized, Reversible Canonical URI Mapping Utilities.
Eliminates brittle positional string splitting (.split('/'), .split(':'), .split('_')) across Watson.
"""
from __future__ import annotations

import re
from typing import Any, Dict, Optional, Tuple

ENTITY_BASE_URI = "http://watson.pharma.org/entity/"
DOCUMENT_BASE_URI = "http://watson.pharma.org/document/"
CHUNK_BASE_URI = "http://watson.pharma.org/chunk/"


def make_chunk_uri(doc_id: str, strategy: str, chunk_index: int) -> str:
    """Constructs canonical chunk URI: watson:<DocId>:chunk:<strategy>:<index:04d>"""
    clean_doc = doc_id.replace("watson:", "")
    return f"watson:{clean_doc}:chunk:{strategy.lower()}:{chunk_index:04d}"


def parse_chunk_uri(chunk_uri: str) -> Dict[str, Any]:
    """
    Robustly parses canonical chunk URI or RDF chunk URI.
    Supports both standard names (Doc_001) and complex names with underscores.
    """
    if not chunk_uri:
        return {"doc_uri": "", "strategy": "", "chunk_index": -1, "is_valid": False}

    raw = str(chunk_uri).strip()
    # Normalize RDF URI to canonical colon-separated if needed
    if raw.startswith(CHUNK_BASE_URI):
        raw = rdf_uri_to_chunk_uri(raw)

    m = re.match(r"^watson:([^:]+):chunk:([a-zA-Z0-9]+):([0-9]+)$", raw)
    if m:
        doc_part, strategy, idx_str = m.groups()
        return {
            "doc_uri": f"watson:{doc_part}",
            "doc_id": doc_part,
            "strategy": strategy,
            "chunk_index": int(idx_str),
            "formatted_index": idx_str,
            "canonical_chunk_uri": raw,
            "is_valid": True,
        }

    # Fallback for plain doc URI
    if raw.startswith("watson:"):
        return {"doc_uri": raw, "strategy": "", "chunk_index": -1, "is_valid": True}

    return {"doc_uri": raw, "strategy": "", "chunk_index": -1, "is_valid": False}


def chunk_uri_to_doc_uri(chunk_uri: str) -> str:
    """Extracts canonical document URI from chunk URI reversibly."""
    parsed = parse_chunk_uri(chunk_uri)
    return parsed.get("doc_uri", chunk_uri)


def chunk_to_rdf_uri(chunk_uri: str) -> str:
    """
    Maps canonical colon-delimited chunk URI to RDF URI.
    watson:Doc_001:chunk:b:0000 -> http://watson.pharma.org/chunk/watson_Doc_001_chunk_b_0000
    """
    parsed = parse_chunk_uri(chunk_uri)
    if parsed["is_valid"] and parsed.get("strategy"):
        safe_name = f"watson_{parsed['doc_id']}_chunk_{parsed['strategy']}_{parsed['formatted_index']}"
        return f"{CHUNK_BASE_URI}{safe_name}"
    safe_str = str(chunk_uri).replace(":", "_").replace("/", "_")
    return f"{CHUNK_BASE_URI}{safe_str}"


def rdf_uri_to_chunk_uri(rdf_uri: str) -> str:
    """
    Reversibly maps RDF chunk URI back to canonical colon-delimited chunk URI.
    http://watson.pharma.org/chunk/watson_Doc_001_chunk_b_0000 -> watson:Doc_001:chunk:b:0000
    """
    raw = str(rdf_uri).strip()
    if raw.startswith(CHUNK_BASE_URI):
        local = raw[len(CHUNK_BASE_URI):]
    else:
        local = raw.split("/")[-1]

    # Pattern matches: watson_<doc_id>_chunk_<strat>_<idx>
    # doc_id can contain arbitrary underscores
    m = re.match(r"^watson_(.+)_chunk_([a-zA-Z0-9]+)_([0-9]{4})$", local)
    if m:
        doc_part, strategy, idx_str = m.groups()
        return f"watson:{doc_part}:chunk:{strategy}:{idx_str}"

    return local


def entity_to_rdf_uri(entity_type: str, local_name: str) -> str:
    """Constructs canonical RDF entity URI."""
    clean_type = entity_type.strip().lower()
    clean_name = local_name.strip().lower().replace(" ", "_").replace("-", "_")
    return f"{ENTITY_BASE_URI}{clean_type}/{clean_name}"


def rdf_uri_to_entity(rdf_uri: str) -> Tuple[str, str]:
    """
    Reversibly extracts (entity_type, local_name) from canonical RDF URI.
    http://watson.pharma.org/entity/brand/keytruda -> ('brand', 'keytruda')
    """
    raw = str(rdf_uri).strip()
    if raw.startswith(ENTITY_BASE_URI):
        remainder = raw[len(ENTITY_BASE_URI):]
        parts = remainder.split("/", 1)
        if len(parts) == 2:
            return parts[0], parts[1]
    # Fallback
    parts = raw.rstrip("/").split("/")
    if len(parts) >= 2:
        return parts[-2], parts[-1]
    return "unknown", raw
