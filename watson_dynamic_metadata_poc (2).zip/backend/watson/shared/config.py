from __future__ import annotations

import os
from pathlib import Path

# Enforce offline mode for HuggingFace models to prevent socket retry delays
os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"

# Resolve base directories relative to file location to avoid hardcoded absolute paths
SHARED_DIR = Path(__file__).resolve().parent
WATSON_DIR = SHARED_DIR.parent
BACKEND_DIR = WATSON_DIR.parent
WORKSPACE_ROOT = BACKEND_DIR.parent

# Support override via environment variable
BASE_DIR = Path(os.environ.get("WATSON_BASE_DIR", str(WORKSPACE_ROOT))).resolve()

DATA_DIR = BASE_DIR / "data"
RAW_DATA_DIR = DATA_DIR / "raw"
STAGING_DATA_DIR = DATA_DIR / "staging"
SEED_DATA_DIR = DATA_DIR / "seed"
FIXTURES_DATA_DIR = DATA_DIR / "fixtures"
STORES_DATA_DIR = DATA_DIR / "stores"
INDEXES_DATA_DIR = DATA_DIR / "indexes"

ONTOLOGY_DIR = BASE_DIR / "ontology"
QUERIES_DIR = BASE_DIR / "queries"
QUERY_RESULTS_DIR = QUERIES_DIR / "query_results"
LOGS_DIR = BASE_DIR / "logs"
DOCS_DIR = BASE_DIR / "docs"

# Core file paths
PHARMA_ONTOLOGY_FILE = ONTOLOGY_DIR / "pharma.ttl"
PHARMA_KG_FILE = ONTOLOGY_DIR / "pharma_kg.ttl"
PHARMA_KG_INFERRED_FILE = ONTOLOGY_DIR / "pharma_kg_inferred.ttl"
SEED_VOCABULARIES_FILE = SEED_DATA_DIR / "seed_vocabularies.json"
TAXONOMY_STORE_FILE = STORES_DATA_DIR / "taxonomy_store.json"
USER_REGISTRY_FILE = STORES_DATA_DIR / "user_registry.json"
AUDIT_LOG_FILE = STORES_DATA_DIR / "audit_log.jsonl"
TELEMETRY_STORE_FILE = STORES_DATA_DIR / "telemetry_store.json"
FEEDBACK_STORE_FILE = STORES_DATA_DIR / "feedback_store.json"
PROVISIONAL_ENTITIES_FILE = STORES_DATA_DIR / "provisional_entities.json"
DEDUP_STORE_FILE = STORES_DATA_DIR / "dedup_store.json"
LIFECYCLE_STORE_FILE = STORES_DATA_DIR / "lifecycle_store.json"

FAISS_INDEX_FILE = INDEXES_DATA_DIR / "Watson.faiss"
CHUNK_URI_MAP_FILE = INDEXES_DATA_DIR / "chunk_uri_map.json"

# Embedding Model
EMBEDDING_MODEL_NAME = os.environ.get("WATSON_EMBEDDING_MODEL", "sentence-transformers/all-MiniLM-L6-v2")
EMBEDDING_DIM = 384

# LLM Configuration
QWEN_MODEL_NAME = os.environ.get("WATSON_QWEN_MODEL", "qwen3:latest")
DEVICE = os.environ.get("WATSON_DEVICE", "cpu")

def ensure_directories():
    for d in [
        DATA_DIR, RAW_DATA_DIR, STAGING_DATA_DIR, SEED_DATA_DIR,
        FIXTURES_DATA_DIR, STORES_DATA_DIR, INDEXES_DATA_DIR,
        ONTOLOGY_DIR, QUERIES_DIR, QUERY_RESULTS_DIR, LOGS_DIR, DOCS_DIR
    ]:
        d.mkdir(parents=True, exist_ok=True)
