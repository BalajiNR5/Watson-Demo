from __future__ import annotations

class WatsonError(Exception):
    """Base exception for all Watson errors."""
    pass

class ParsingError(WatsonError):
    """Raised when document parsing fails critically."""
    pass

class DedupError(WatsonError):
    """Raised on exact duplicate or dedup collision."""
    pass

class PIIValidationError(WatsonError):
    """Raised when critical PII is unredacted without approval."""
    pass

class MetadataValidationError(WatsonError):
    """Raised when mandatory PRD metadata fields are invalid or missing."""
    pass

class LifecycleViolationError(WatsonError):
    """Raised when an illegal lifecycle state transition or action is attempted."""
    pass

class ABACAccessDeniedError(WatsonError):
    """Raised when a user lacks attributes or role permissions to access an asset."""
    pass

class GuardrailViolationError(WatsonError):
    """Raised when a guardrail fails (citation check, prompt injection, etc.)."""
    pass

class RetrievalError(WatsonError):
    """Raised when vector or hybrid retrieval encounters an error."""
    pass

class SparqlExecutionError(WatsonError):
    """Raised when a SPARQL query fails to parse or execute."""
    pass
