from __future__ import annotations

import hashlib
import re
import uuid

WATSON_NS = "http://www.semanticweb.org/watson/pharma#"
WATSON_PREFIX = "watson"

def sanitize_id(val: str) -> str:
    cleaned = re.sub(r"[^a-zA-Z0-9_\-\.]", "_", val.strip())
    return re.sub(r"_+", "_", cleaned)

def make_doc_id(source_name: str, file_hash: str | None = None) -> str:
    clean_name = sanitize_id(source_name)
    if file_hash:
        short_hash = file_hash[:8]
        return f"{clean_name}_{short_hash}"
    return clean_name

def make_doc_uri(doc_id: str) -> str:
    clean = sanitize_id(doc_id)
    return f"{WATSON_PREFIX}:Doc_{clean}"

def make_chunk_id(doc_id: str, chunk_index: int) -> str:
    clean = sanitize_id(doc_id)
    return f"{clean}_chk_{chunk_index:04d}"

def make_chunk_uri(chunk_id: str) -> str:
    clean = sanitize_id(chunk_id)
    return f"{WATSON_PREFIX}:Chunk_{clean}"

def make_lineage_uri(lineage_id: str) -> str:
    clean = sanitize_id(lineage_id)
    return f"{WATSON_PREFIX}:Lineage_{clean}"

def make_sentiment_uri(brand: str, indication: str, geo: str, identifier: str) -> str:
    slug = f"{brand}_{indication}_{geo}_{identifier}"
    clean = sanitize_id(slug)
    return f"{WATSON_PREFIX}:Sentiment_{clean}"

def make_space_uri(space_id: str) -> str:
    clean = sanitize_id(space_id)
    return f"{WATSON_PREFIX}:Space_{clean}"

def make_provisional_uri(term: str) -> str:
    term_hash = hashlib.sha256(term.lower().strip().encode("utf-8")).hexdigest()[:10]
    clean = sanitize_id(term)[:20]
    return f"{WATSON_PREFIX}:Provisional_{clean}_{term_hash}"
