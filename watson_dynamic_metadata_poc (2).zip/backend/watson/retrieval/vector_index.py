from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

import faiss
import numpy as np
import torch
from transformers import AutoModel, AutoTokenizer

from watson.shared.config import (
    CHUNK_URI_MAP_FILE,
    EMBEDDING_DIM,
    EMBEDDING_MODEL_NAME,
    FAISS_INDEX_FILE,
)

logger = logging.getLogger("watson.retrieval.vector_index")


class VectorIndexManager:
    """
    Production FAISS Vector Index with strict Pre-filtering.
    Only permitted vector IDs are ever scored or compared.
    """

    def __init__(
        self,
        index_path: Path = FAISS_INDEX_FILE,
        map_path: Path = CHUNK_URI_MAP_FILE,
    ):
        self.index_path = Path(index_path)
        self.map_path = Path(map_path)
        self.index: Optional[faiss.IndexFlatIP] = None
        self.chunk_uri_map: Dict[str, Dict[str, Any]] = {}
        self.uri_to_vid: Dict[str, int] = {}
        self.tokenizer = None
        self.model = None

        self._load_index_and_map()
        self._init_encoder()

    def _init_encoder(self):
        try:
            self.tokenizer = AutoTokenizer.from_pretrained(EMBEDDING_MODEL_NAME, local_files_only=True)
            self.model = AutoModel.from_pretrained(EMBEDDING_MODEL_NAME, local_files_only=True)
            self.model.eval()
        except Exception as e:
            logger.warning(f"Could not load HuggingFace model directly: {e}. Checking fallback.")

    def _load_index_and_map(self):
        if self.map_path.exists():
            with open(self.map_path, "r", encoding="utf-8") as f:
                raw_data = json.load(f)
            if "index_to_chunk" in raw_data:
                self.chunk_uri_map = raw_data["index_to_chunk"]
                self.uri_to_vid = raw_data.get("chunk_to_index", {
                    v["chunk_uri"]: int(k) for k, v in self.chunk_uri_map.items() if isinstance(v, dict) and "chunk_uri" in v
                })
            else:
                self.chunk_uri_map = raw_data
                self.uri_to_vid = {
                    v["chunk_uri"]: int(k) for k, v in self.chunk_uri_map.items() if isinstance(v, dict) and "chunk_uri" in v
                }

        if self.index_path.exists():
            self.index = faiss.read_index(str(self.index_path))
        else:
            self.index = faiss.IndexFlatIP(EMBEDDING_DIM)

    def encode(self, texts: List[str]) -> np.ndarray:
        """Encode texts into normalized 384-dimensional dense vectors."""
        if self.tokenizer is None or self.model is None:
            self._init_encoder()

        inputs = self.tokenizer(
            texts,
            padding=True,
            truncation=True,
            max_length=512,
            return_tensors="pt",
        )
        with torch.no_grad():
            outputs = self.model(**inputs)
            # Mean pooling
            mask = inputs["attention_mask"].unsqueeze(-1).expand(outputs.last_hidden_state.size()).float()
            sum_embeddings = torch.sum(outputs.last_hidden_state * mask, 1)
            sum_mask = torch.clamp(mask.sum(1), min=1e-9)
            embeddings = sum_embeddings / sum_mask
            # Normalize for cosine similarity
            norm = torch.norm(embeddings, p=2, dim=1, keepdim=True).clamp(min=1e-9)
            normalized = embeddings / norm

        return normalized.cpu().numpy().astype(np.float32)

    def search_with_prefilter(
        self,
        query: str,
        allowed_chunk_uris: Set[str],
        top_k: int = 10,
    ) -> List[Tuple[str, float]]:
        """
        Pre-filters candidate vectors BEFORE similarity calculation.
        Restricts candidate IDs exclusively to the permitted subset.
        """
        if not allowed_chunk_uris:
            return []

        if self.index is None or self.index.ntotal == 0:
            return []

        # Find vector IDs belonging to allowed chunks
        allowed_vids = []
        vid_to_uri = {}
        for uri in allowed_chunk_uris:
            if uri in self.uri_to_vid:
                vid = self.uri_to_vid[uri]
                allowed_vids.append(vid)
                vid_to_uri[vid] = uri

        if not allowed_vids:
            return []

        # Extract vectors for allowed IDs only into a temporary sub-index
        # This guarantees default-deny before similarity computation
        sub_vectors = []
        valid_vids = []
        for vid in allowed_vids:
            if vid < self.index.ntotal:
                vec = self.index.reconstruct(int(vid))
                sub_vectors.append(vec)
                valid_vids.append(vid)

        if not sub_vectors:
            return []

        sub_matrix = np.array(sub_vectors, dtype=np.float32)
        # Create dedicated sub-index containing ONLY permitted vectors
        sub_index = faiss.IndexFlatIP(EMBEDDING_DIM)
        sub_index.add(sub_matrix)

        # Encode query
        q_vec = self.encode([query])

        # Search within permitted sub-index
        k_search = min(top_k, len(sub_vectors))
        similarities, indices = sub_index.search(q_vec, k_search)

        results: List[Tuple[str, float]] = []
        for sim, idx in zip(similarities[0], indices[0]):
            if idx >= 0 and idx < len(valid_vids):
                orig_vid = valid_vids[idx]
                chunk_uri = vid_to_uri[orig_vid]
                results.append((chunk_uri, float(sim)))
        return results

    def search_raw(self, query: str, top_k: int = 10) -> List[Tuple[str, float]]:
        """Raw FAISS search without pre-filtering (used for ablation baseline)."""
        if self.index is None or self.index.ntotal == 0:
            return []
        q_vec = self.encode([query])
        similarities, indices = self.index.search(q_vec, min(top_k, self.index.ntotal))
        results: List[Tuple[str, float]] = []
        for sim, idx in zip(similarities[0], indices[0]):
            if idx >= 0 and str(idx) in self.chunk_uri_map:
                uri = self.chunk_uri_map[str(idx)]["chunk_uri"]
                results.append((uri, float(sim)))
        return results

    def add_chunks(self, chunks: List[Dict[str, Any]]) -> int:
        """Index new chunks into FAISS index and chunk_uri_map."""
        if not chunks:
            return 0

        texts = [c.get("content", "") for c in chunks]
        embeddings = self.encode(texts)

        start_id = self.index.ntotal
        self.index.add(embeddings)

        for i, chunk in enumerate(chunks):
            vid = start_id + i
            uri = chunk["chunk_uri"]
            self.chunk_uri_map[str(vid)] = {
                "vector_id": vid,
                "chunk_uri": uri,
                "document_uri": chunk.get("doc_uri", ""),
                "source_filename": chunk.get("source_filename", ""),
                "page_number": chunk.get("page_number", 1),
                "char_start": chunk.get("char_start", 0),
                "char_end": chunk.get("char_end", len(chunk.get("content", ""))),
                "token_count": chunk.get("token_count", 0),
            }
            self.uri_to_vid[uri] = vid

        # Save to disk
        self.index_path.parent.mkdir(parents=True, exist_ok=True)
        faiss.write_index(self.index, str(self.index_path))
        with open(self.map_path, "w", encoding="utf-8") as f:
            json.dump(self.chunk_uri_map, f, indent=2)

        return len(chunks)

    def get_chunk_metadata(self, chunk_uri: str) -> Dict[str, Any]:
        """Looks up metadata dictionary for a specific chunk URI."""
        if chunk_uri in self.uri_to_vid:
            vid = str(self.uri_to_vid[chunk_uri])
            return self.chunk_uri_map.get(vid, {})
        for _, c in self.chunk_uri_map.items():
            if isinstance(c, dict) and c.get("chunk_uri") == chunk_uri:
                return c
        return {}
