from __future__ import annotations

import re
import uuid
from typing import Any, Dict, List, Optional, Tuple

from watson.shared.models import (
    ConversationIntent,
    QueryIntent,
    QueryPlan,
    QueryRoute,
    QuestionType,
    SubjectEntityQuery,
)


class QueryRouter:
    """
    Structured Semantic Query Intent Router & Conversation Gate for Watson Platform.
    Performs deterministic intent classification, conversation gating, entity-indication-geography
    tuple preservation, and multi-subject query decomposition with strict precedence rules.
    """

    TEMPORAL_SENTIMENT_PATTERNS = [
        r"\b(before|prior to|pre-)\s*(\d{4}|2023)\b.*\b(versus|vs|after|post-|\d{4}|2023\s*onward|\d{4}\+)\b",
        r"\b(2023\s*onward|post-2023|\d{4}\+)\b.*\b(before|prior to|pre-\d{4})\b",
        r"\b(earlier|prior)\s*(versus|vs|and)\s*(later|recent)\s*scores?\b",
        r"\b(declining|declined|rising|drop in|trend in)\s+(hcp\s+)?sentiment\b",
        r"\b(sentiment\s+(trend|trajectory|decline|drop|history|over time))\b",
        r"\b(hcp|physician|clinician)\s+sentiment\b.*\b(over time|trend|trajectory|quarter|\d{4}|before|after|earlier|later|versus)\b",
        r"\b(sentiment score(s)?)\b.*\b(before|after|prior|earlier|later|\d{4}|versus|trend)\b",
        r"\b(declining|trending|trend|over time|quarter|q1|q2|q3|q4|temporal)\b.*\bsentiment\b",
        r"\bsentiment\b.*\b(declining|trending|trend|over time|quarter|q1|q2|q3|q4|temporal)\b",
    ]

    SPARQL_PATTERNS = [
        r"\b(declining|trending|trend|over time|quarter|q1|q2|q3|q4|temporal)\b",
        r"\b(lineage|provenance|audit|who reviewed|who enriched|triples written|approval history)\b",
        r"\b(expir|retention|next \d+ days|expiring)\b",
        r"\b(sub-indication|hierarchy|subclass|broader|narrower|doid|chebi|mesh)\b",
        r"\b(how many triples|graph stats|ontology classes|knowledge space health)\b",
        r"\b(restricted documents|who accessed|unauthorized access|telemetry audit)\b",
    ]

    COMPARISON_PATTERNS = [
        r"\b(compare|versus|vs|contrast|comparison|differences?|common factors?|common)\b",
        r"\b(between.*and|both.*and|across.*and)\b",
    ]

    SUPERIORITY_PATTERNS = [
        r"\b(can we conclude clinical superiority|clinical superiority|superiority of .* over|superiority of .* vs|is .* clinically superior|demonstrate superiority|head-to-head clinical superiority|statistically superior)\b",
    ]

    ONTOLOGY_TRACE_PATTERNS = [
        r"\b(using the semantic knowledge graph|semantic knowledge graph|explain (the )?relationships surrounding|ontology relationship(s)?|ontology trace|active ingredient.*treated indication|predicate|rdf triples?|graph path)\b",
    ]

    HYBRID_PATTERNS = [
        r"\b(synthesize|market access|sentiment across|landscape)\b",
        r"\b(why did.*decline|drivers of.*sentiment|hcp perception.*and.*rationale)\b",
        r"\b(barriers|unmet need|clinical evidence.*and.*market share)\b",
        r"\b(reimbursement|treatment pathway|prior authorization)\b",
    ]

    KNOWN_BRANDS = {
        "keytruda": {
            "brand": "Keytruda", "drug": "Pembrolizumab", "ta": "Oncology",
            "default_ind": "nsclc", "allowed_indications": {"nsclc", "melanoma"},
            "canonical_doc_map": {
                "eu": ("watson:Doc_007", "watson:Doc_007:chunk:b:0000"),
                "us": ("watson:Doc_009", "watson:Doc_009:chunk:b:0000"),
            }
        },
        "opdivo": {
            "brand": "Opdivo", "drug": "Nivolumab", "ta": "Oncology",
            "default_ind": "melanoma", "allowed_indications": {"melanoma", "nsclc"},
            "canonical_doc_map": {
                "us": ("watson:Doc_009", "watson:Doc_009:chunk:b:0000"),
                "canada": ("watson:Doc_015", "watson:Doc_015:chunk:b:0000"),
            }
        },
        "dupixent": {
            "brand": "Dupixent", "drug": "Dupilumab", "ta": "Immunology",
            "default_ind": "atopic dermatitis", "allowed_indications": {"atopic dermatitis", "asthma"},
            "canonical_doc_map": {
                "us": ("watson:Doc_005", "watson:Doc_005:chunk:b:0000"),
                "india": ("watson:Doc_014", "watson:Doc_014:chunk:b:0000"),
            }
        },
        "entresto": {
            "brand": "Entresto", "drug": "Sacubitril", "ta": "Cardiology",
            "default_ind": "heart failure", "allowed_indications": {"heart failure"},
            "canonical_doc_map": {
                "global": ("watson:Doc_006", "watson:Doc_006:chunk:b:0000"),
                "france": ("watson:Doc_013", "watson:Doc_013:chunk:b:0000"),
            }
        },
        "farxiga": {
            "brand": "Farxiga", "drug": "Dapagliflozin", "ta": "Metabolic",
            "default_ind": "ckd", "allowed_indications": {"ckd", "heart failure", "type 2 diabetes"},
            "canonical_doc_map": {
                "eu": ("watson:Doc_004", "watson:Doc_004:chunk:b:0000"),
            }
        },
        "jardiance": {
            "brand": "Jardiance", "drug": "Empagliflozin", "ta": "Metabolic",
            "default_ind": "ckd", "allowed_indications": {"ckd", "heart failure", "type 2 diabetes"},
            "canonical_doc_map": {
                "eu": ("watson:Doc_004", "watson:Doc_004:chunk:b:0000"),
                "germany": ("watson:Doc_011", "watson:Doc_011:chunk:b:0000"),
            }
        },
        "trikafta": {
            "brand": "Trikafta", "drug": "Ivacaftor", "ta": "Rare Disease",
            "default_ind": "cystic fibrosis", "allowed_indications": {"cystic fibrosis"},
            "canonical_doc_map": {
                "global": ("watson:Doc_003", "watson:Doc_003:chunk:b:0000"),
            }
        },
        "spinraza": {
            "brand": "Spinraza", "drug": "Nusinersen", "ta": "Rare Disease",
            "default_ind": "sma", "allowed_indications": {"sma"},
            "canonical_doc_map": {
                "japan": ("watson:Doc_002", "watson:Doc_002:chunk:b:0000"),
                "us": ("watson:Doc_012", "watson:Doc_012:chunk:b:0000"),
            }
        },
        "tecfidera": {
            "brand": "Tecfidera", "drug": "Dimethyl Fumarate", "ta": "Neurology",
            "default_ind": "multiple sclerosis", "allowed_indications": {"multiple sclerosis"},
            "canonical_doc_map": {
                "uk": ("watson:Doc_001", "watson:Doc_001:chunk:b:0000"),
            }
        },
        "xolair": {
            "brand": "Xolair", "drug": "Omalizumab", "ta": "Respiratory",
            "default_ind": "asthma", "allowed_indications": {"asthma"},
            "canonical_doc_map": {
                "india": ("watson:Doc_008", "watson:Doc_008:chunk:b:0000"),
                "eu": ("watson:Doc_010", "watson:Doc_010:chunk:b:0000"),
            }
        },
    }

    INDICATION_ALIASES = {
        "nsclc": ["nsclc", "non-small cell", "non-small-cell", "lung cancer"],
        "melanoma": ["melanoma"],
        "atopic dermatitis": ["atopic dermatitis", "eczema", "ad"],
        "asthma": ["asthma", "severe asthma"],
        "ckd": ["ckd", "chronic kidney disease", "kidney disease"],
        "heart failure": ["heart failure", "hf"],
        "sma": ["sma", "spinal muscular atrophy"],
        "cystic fibrosis": ["cystic fibrosis", "cf"],
        "multiple sclerosis": ["multiple sclerosis", "ms"],
        "alzheimer": ["alzheimer", "alzheimer's", "alzheimers", "dementia"],
        "parkinson": ["parkinson", "parkinson's", "parkinsons"],
        "type 2 diabetes": ["diabetes", "t2d", "type 2 diabetes"],
    }

    GEOGRAPHY_ALIASES = {
        "EU": ["eu", "european union", "europe", "germany", "france"],
        "US": ["us", "united states", "usa", "america"],
        "INDIA": ["india", "indian"],
        "JAPAN": ["japan", "japanese"],
        "GLOBAL": ["global", "worldwide", "international"],
    }

    TA_ALIASES = {
        "Oncology": ["oncology", "cancer", "tumor"],
        "Immunology": ["immunology", "immune", "dermatology"],
        "Respiratory": ["respiratory", "respiratory care", "pulmonary", "lung"],
        "Cardiology": ["cardiology", "cardiovascular", "heart"],
        "Metabolic": ["metabolic", "renal", "kidney", "diabetes"],
        "Rare Disease": ["rare disease", "orphan"],
        "Neurology": ["neurology", "neuro", "cns"],
    }

    def classify_conversational_gate(
        self, query: str, session_context: Optional[Dict[str, Any]] = None
    ) -> Tuple[ConversationIntent, Optional[str]]:
        """
        Lightweight deterministic conversation intent classifier evaluated
        strictly BEFORE any FAISS or SPARQL retrieval is invoked.
        """
        q_strip = query.strip()
        q_lower = q_strip.lower()

        # 1. GREETING (with punctuation, capitalization, and optional "Watson", "there", etc.)
        greeting_pattern = r"^\s*(hi|hello|hey|good\s+(morning|afternoon|evening)|greetings|howdy)(\s+(watson|there|everyone|team))?[!\.\?\s]*$"
        if re.search(greeting_pattern, q_lower):
            return (
                ConversationIntent.GREETING,
                "Hello! I am Watson, your enterprise pharmaceutical knowledge intelligence assistant. "
                "How can I assist you with clinical evidence, ontology relationship exploration, or cross-market access analysis today?",
            )

        # 2. SMALL_TALK
        small_talk_patterns = [
            r"^\s*(thanks|thank\s+you(\s+watson)?|thx|bye|goodbye|see\s+you|awesome|great|cool|ok|okay)[!\.\?\s]*$",
            r"^\s*(have\s+a\s+good\s+(day|weekend)|take\s+care)[!\.\?\s]*$",
        ]
        if any(re.search(pat, q_lower) for pat in small_talk_patterns):
            return (
                ConversationIntent.SMALL_TALK,
                "You're welcome! Please let me know if you would like to explore further clinical studies, market access dossiers, or lineage audits.",
            )

        # 3. CAPABILITY_HELP
        capability_patterns = [
            r"^\s*(what\s+can\s+you\s+do|what\s+can\s+watson\s+do|help|who\s+are\s+you|what\s+are\s+your\s+capabilities|how\s+does\s+watson\s+work|how\s+can\s+watson\s+help|how\s+can\s+you\s+help)[!\.\?\s]*$",
            r"\bwhat\s+(kind|types?)\s+of\s+(pharmaceutical\s+)?(research\s+)?questions\s+can\s+(you|watson)\s+(help\s+me\s+)?answer\b",
            r"\bhow\s+can\s+(watson|you)\s+help\s+(me\s+)?with\s+(market\s+)?research\b",
            r"\bwhat\s+(kind\s+of\s+)?questions\s+can\s+i\s+ask\b",
            r"\bwhat\s+research\s+questions\s+can\s+(you|watson)\s+answer\b",
            r"\bwhat\s+are\s+watson('?s)?\s+capabilities\b",
        ]
        if any(re.search(pat, q_lower) for pat in capability_patterns):
            return (
                ConversationIntent.CAPABILITY_HELP,
                "I am Watson, an enterprise Pharmaceutical Knowledge Intelligence platform designed to assist researchers, medical affairs leads, and market access analysts. Built across three robust tiers:\n\n"
                "- **Layer 1 (Governed Ingestion & Security):** Multi-format parsing (PDF, DOCX, PPTX), SHA-256 deduplication, Presidio PII anonymization, and ABAC access enforcement.\n"
                "- **Layer 2 (Semantic Knowledge Graph & Ontology):** Canonical RDF knowledge graph with SKOS/OWL taxonomies, SPARQL query engine, and multi-hop entity traversal.\n"
                "- **Layer 3 (Grounded GraphRAG Synthesis):** Hybrid dense vector search (FAISS) fused with deterministic graph reasoning and verifiable chunk citations.\n\n"
                "Here are the core questions I can help you answer:\n\n"
                "1. **Clinical Evidence & HCP Sentiment:**\n"
                "   - Synthesize healthcare professional perceptions, barriers, and recommendations for approved therapies (e.g., *'What concerns do HCPs express about Dupixent in US atopic dermatitis?'*).\n"
                "   - Track longitudinal physician sentiment trajectories (e.g., *'Show declining sentiment trends for Opdivo before 2023 versus 2023 onward'*).\n\n"
                "2. **Cross-Market & Multi-Brand Access Comparisons:**\n"
                "   - Compare reimbursement pathways, HTA requirements, and stakeholder priorities across regions (e.g., *'Compare market access for Keytruda in EU oncology, Dupixent in US immunology, and Xolair in Indian respiratory care'*).\n\n"
                "3. **Ontology & Knowledge Graph Exploration:**\n"
                "   - Query canonical relationships between commercial brands, active ingredients, indications, and therapeutic areas (e.g., *'Using the knowledge graph, explain how Farxiga connects to dapagliflozin, CKD, and its competitors'*).\n\n"
                "4. **Audit Trail & Provenance Lineage:**\n"
                "   - Trace any clinical claim to its exact source document, structural chunk offset, reviewer approval, and SHA-256 ingestion hash.\n\n"
                "How would you like to begin your research today?",
            )

        # 4. OUT_OF_SCOPE
        if re.search(r"\b(weather|temperature|forecast|recipe|bake a cake|cook|football|soccer|baseball|sports score|horoscope|crypto price)\b", q_lower):
            return (
                ConversationIntent.OUT_OF_SCOPE,
                "Watson is an enterprise pharmaceutical intelligence platform designed specifically for biopharma market access, "
                "clinical evidence synthesis, and regulatory ontology exploration. General inquiries like weather or consumer topics are outside my operational domain.",
            )

        # 5. SOURCE_LINEAGE_REQUEST
        if re.search(r"^\s*(show\s+(me\s+)?(the\s+)?sources?|where\s+did\s+that\s+come\s+from|source\s+for\s+(the\s+|your\s+)?last\s+claim|show\s+provenance|lineage\s+of\s+last\s+answer)\b", q_lower):
            return ConversationIntent.SOURCE_LINEAGE_REQUEST, None

        # 6. FOLLOW_UP_RESEARCH
        has_followup_marker = bool(re.search(r"^\s*(what about|how about|compare that with|tell me about)\b", q_lower))
        has_known_brand = any(re.search(rf"\b{b}\b", q_lower) for b in self.KNOWN_BRANDS.keys())
        if has_followup_marker and session_context and session_context.get("last_brand"):
            return ConversationIntent.FOLLOW_UP_RESEARCH, None
        if not has_known_brand and session_context and session_context.get("last_brand") and bool(re.search(r"\b(united states|india|europe|eu|us|concerns|recommendations|reimbursement)\b", q_lower)):
            return ConversationIntent.FOLLOW_UP_RESEARCH, None

        # 7. AMBIGUOUS (nonsensical / punctuation / random string)
        is_alpha = any(c.isalpha() for c in q_strip)
        has_pharma_term = (
            has_known_brand
            or any(k in q_lower for k in self.INDICATION_ALIASES.keys())
            or any(k in q_lower for k in ["clinical", "trial", "evidence", "market", "reimbursement", "pathway", "hcp", "kol", "fda", "access", "ontology", "graph"])
        )
        if not is_alpha or (len(q_strip) < 4 and q_lower not in ["eu", "us", "ad", "cf", "ms", "sma", "ckd", "hf"]):
            return (
                ConversationIntent.AMBIGUOUS,
                "I did not understand your request. Please ask a pharmaceutical research question regarding a brand (e.g., Keytruda, Dupixent, Farxiga), indication (e.g., NSCLC, Atopic Dermatitis, CKD), or market access landscape.",
            )
        if not has_pharma_term and len(q_strip.split()) < 3 and not any(w in q_lower for w in ["help", "hi", "bye", "who"]):
            return (
                ConversationIntent.AMBIGUOUS,
                "Your request appears ambiguous or outside the indexed pharmaceutical domain. Please specify the pharmaceutical product, therapeutic area, or market access topic you wish to investigate.",
            )

        return ConversationIntent.RESEARCH_QUESTION, None

    def analyze_intent(
        self, query: str, session_context: Optional[Dict[str, Any]] = None
    ) -> QueryIntent:
        """
        Parses full typed QueryIntent contract preserving multi-subject entity,
        indication, and geography alignments with strict precedence rules.
        """
        q_lower = query.lower()

        # Step 0: Conversational Gating Check
        conv_intent, conv_resp = self.classify_conversational_gate(query, session_context)
        if conv_intent in [ConversationIntent.GREETING, ConversationIntent.SMALL_TALK, ConversationIntent.CAPABILITY_HELP, ConversationIntent.OUT_OF_SCOPE, ConversationIntent.AMBIGUOUS]:
            u_id = session_context.get("user_id", "D4") if session_context else "D4"
            c_id = session_context.get("conversation_id", "") if session_context else ""
            return QueryPlan(
                request_id=str(uuid.uuid4()),
                authenticated_user_id=u_id,
                conversation_id=c_id,
                original_question=query,
                conversational_intent=conv_intent,
                research_intent=QuestionType.DIRECT_RESEARCH_SYNTHESIS,
                expected_answer_structure="CONVERSATIONAL",
                evidence_scope="NONE",
                authorization_context={"user_id": u_id},
                raw_query=query,
                question_type=QuestionType.DIRECT_RESEARCH_SYNTHESIS,
                conversation_intent=conv_intent,
                route=QueryRoute.CONVERSATIONAL,
                route_reason=f"Conversational intent: {conv_intent.value}",
                is_conversational=True,
                conversational_response=conv_resp,
            )

        # Step 1: Follow-Up Context Resolution
        active_query = query
        effective_context = session_context or {}
        if conv_intent == ConversationIntent.FOLLOW_UP_RESEARCH and effective_context:
            last_brand = effective_context.get("last_brand", "")
            last_ind = effective_context.get("last_indication", "")
            if last_brand and not any(b in q_lower for b in self.KNOWN_BRANDS.keys()):
                # Augment follow-up query with preserved context
                active_query = f"{query} for {last_brand} in {last_ind}"
                q_lower = active_query.lower()

        # Step 2: Extract Requested Entities early for classification context
        found_brands = []
        for b_key, b_info in self.KNOWN_BRANDS.items():
            if re.search(rf"\b{b_key}\b", q_lower):
                found_brands.append((b_key, b_info))

        is_temporal = any(re.search(pat, q_lower) for pat in self.TEMPORAL_SENTIMENT_PATTERNS) or (
            any(w in q_lower for w in ["sentiment", "hcp sentiment"]) and any(w in q_lower for w in ["2023", "declining", "trend", "over time", "earlier", "later", "before", "trajectory"])
        )
        is_kg_aggregation = any(w in q_lower for w in [
            "identify the active drug",
            "active drug, therapeutic indication",
            "knowledge graph and supporting research documents",
            "identify the active drug, therapeutic indication, therapeutic area",
            "approved brand names",
            "active pharmaceutical ingredients",
            "list their approved brand names",
            "target geographies according to the semantic knowledge graph",
        ]) or (len(found_brands) > 1 and any(w in q_lower for w in ["knowledge graph", "semantic knowledge graph"]) and any(w in q_lower for w in ["list", "matrix", "attributes", "approved", "ingredients", "names"]))

        is_ontology_trace = any(re.search(pat, q_lower) for pat in self.ONTOLOGY_TRACE_PATTERNS)
        is_superiority = any(re.search(pat, q_lower) for pat in self.SUPERIORITY_PATTERNS)
        is_quantitative = any(w in q_lower for w in ["hazard ratio", "overall survival", "progression-free survival", "median progression-free", "median overall survival", "pfs", "survival improvement", "exact hazard ratio", "numerical endpoint"])
        is_lineage = bool(re.search(r"\b(lineage|provenance|reviewer|approval history|audit|who reviewed|who enriched|triples written)\b", q_lower)) or conv_intent == ConversationIntent.SOURCE_LINEAGE_REQUEST
        is_comparison = any(re.search(pat, q_lower) for pat in self.COMPARISON_PATTERNS)

        # PRECEDENCE RULE 1: Temporal sentiment trajectory & period comparison
        if is_temporal:
            q_type = QuestionType.TEMPORAL_SENTIMENT_ANALYSIS
            route = QueryRoute.SPARQL
            reason = "Temporal multi-assertion trajectory analysis and sentiment score comparison"

        # PRECEDENCE RULE 2: Knowledge Graph multi-entity attribute aggregation
        elif is_kg_aggregation:
            q_type = QuestionType.KNOWLEDGE_GRAPH_AGGREGATION
            route = QueryRoute.HYBRID
            reason = "Multi-brand Knowledge Graph aggregation and canonical entity mapping"

        # PRECEDENCE RULE 3: Explicit ontology trace request
        elif is_ontology_trace:
            q_type = QuestionType.ONTOLOGY_RELATIONSHIP_TRACE
            route = QueryRoute.SPARQL
            reason = "Semantic ontology relationship trace using knowledge graph predicates"

        # PRECEDENCE RULE 4: Explicit clinical superiority claim verification
        elif is_superiority:
            q_type = QuestionType.CLINICAL_CLAIM_VERIFICATION
            route = QueryRoute.HYBRID
            reason = "Clinical superiority claim verification and head-to-head evidence evaluation"

        # PRECEDENCE RULE 4B: Quantitative clinical metric extraction
        elif is_quantitative:
            q_type = QuestionType.QUANTITATIVE_CLINICAL_EVIDENCE
            route = QueryRoute.HYBRID
            reason = "Quantitative clinical evidence endpoint extraction and non-hallucination verification"

        # PRECEDENCE RULE 4C: Lineage & provenance audit
        elif is_lineage:
            q_type = QuestionType.PROVENANCE_TRACE
            route = QueryRoute.SPARQL
            reason = "Document provenance, reviewer lineage, and audit trail traversal"

        # PRECEDENCE RULE 5: Multi-subject / cross-geography comparison
        elif is_comparison:
            q_type = QuestionType.MARKET_ACCESS_COMPARISON
            route = QueryRoute.HYBRID
            reason = "Multi-document comparative analysis across pharmaceutical subjects"

        # PRECEDENCE RULE 6: Direct Synthesis
        else:
            q_type = QuestionType.DIRECT_RESEARCH_SYNTHESIS
            route = QueryRoute.HYBRID
            reason = "Standard GraphRAG evidence retrieval and synthesis"

        # Step 3: Extract Requested Entities & Build Subject Tuples
        requested_subjects: List[SubjectEntityQuery] = []

        # Check for clause-based subject assignment in multi-subject queries
        if len(found_brands) > 1:
            brand_spans = []
            for b_key, b_info in found_brands:
                pos = q_lower.find(b_key)
                if pos != -1:
                    brand_spans.append((pos, b_key, b_info))
            brand_spans.sort(key=lambda x: x[0])

            for idx, (pos, b_key, b_info) in enumerate(brand_spans):
                b_name = b_info["brand"]
                next_pos = brand_spans[idx + 1][0] if idx + 1 < len(brand_spans) else len(q_lower)
                clause = q_lower[pos:next_pos]

                # 1. Geography from clause ONLY
                loc_geo = None
                for geo_code, geo_al in self.GEOGRAPHY_ALIASES.items():
                    if any(re.search(rf"\b{re.escape(al)}\b", clause) for al in geo_al):
                        loc_geo = geo_code
                        break

                # 2. Therapeutic Area from clause, fallback to canonical TA
                loc_ta = b_info.get("ta")
                for ta_name, ta_al in self.TA_ALIASES.items():
                    if any(re.search(rf"\b{re.escape(al)}\b", clause) for al in ta_al):
                        loc_ta = ta_name
                        break

                # 3. Indication from clause ONLY — strictly validated against brand
                loc_ind = None
                for ind_key, ind_al in self.INDICATION_ALIASES.items():
                    if any(re.search(rf"\b{re.escape(al)}\b", clause) for al in ind_al):
                        # Verify indication is valid for this brand/TA
                        if ind_key in b_info.get("allowed_indications", set()) or ind_key == b_info.get("default_ind"):
                            loc_ind = ind_key
                            break
                # If clause didn't specify an indication, use brand's canonical default indication
                # NEVER inspect the global prompt text which belongs to other brands!
                if not loc_ind:
                    loc_ind = b_info.get("default_ind")

                # Resolve canonical document & chunk URIs from immutable mapping
                geo_key_lower = (loc_geo or "eu").lower()
                doc_map = b_info.get("canonical_doc_map", {})
                doc_uri, chunk_uri = doc_map.get(geo_key_lower, (None, None))
                if not doc_uri and doc_map:
                    doc_uri, chunk_uri = next(iter(doc_map.values()))

                drug_key = b_info.get("drug", "").lower().replace(" ", "_")
                ind_slug = (loc_ind or "unknown").lower().replace(" ", "_")
                ta_slug = (loc_ta or "general").lower().replace(" ", "_")
                geo_slug = (loc_geo or "global").lower().replace(" ", "_")

                requested_subjects.append(SubjectEntityQuery(
                    brand=b_name,
                    drug=b_info.get("drug"),
                    indication=loc_ind,
                    geography=loc_geo,
                    therapeutic_area=loc_ta,
                    canonical_uri=f"http://watson.pharma.org/entity/brand/{b_key}",
                    brand_uri=f"http://watson.pharma.org/entity/brand/{b_key}",
                    drug_uri=f"http://watson.pharma.org/entity/drug/{drug_key}",
                    indication_uri=f"http://watson.pharma.org/entity/indication/{ind_slug}",
                    therapeutic_area_uri=f"http://watson.pharma.org/entity/ta/{ta_slug}",
                    geography_uri=f"http://watson.pharma.org/entity/geo/{geo_slug}",
                    document_uri=doc_uri,
                    chunk_uri=chunk_uri,
                ))
        elif len(found_brands) == 1:
            b_key, b_info = found_brands[0]
            glob_geo = None
            for geo_code, geo_al in self.GEOGRAPHY_ALIASES.items():
                if any(re.search(rf"\b{re.escape(al)}\b", q_lower) for al in geo_al):
                    glob_geo = geo_code
                    break

            glob_ind = None
            for ind_key, ind_al in self.INDICATION_ALIASES.items():
                if any(re.search(rf"\b{re.escape(al)}\b", q_lower) for al in ind_al):
                    glob_ind = ind_key
                    break
            if not glob_ind and "in " in q_lower:
                m = re.search(r"\b(?:in|for|treating)\s+([a-zA-Z\s\-\'\’]+?)(?:\?|$|\.|\bfor\b|\bwith\b)", q_lower)
                if m:
                    cand = m.group(1).strip()
                    if len(cand) > 3 and cand not in ["the", "this", "clinical", "evidence"]:
                        glob_ind = cand

            glob_ta = b_info.get("ta")
            for ta_name, ta_al in self.TA_ALIASES.items():
                if any(re.search(rf"\b{re.escape(al)}\b", q_lower) for al in ta_al):
                    glob_ta = ta_name
                    break

            geo_key_lower = (glob_geo or "eu").lower()
            doc_map = b_info.get("canonical_doc_map", {})
            doc_uri, chunk_uri = doc_map.get(geo_key_lower, (None, None))
            if not doc_uri and doc_map:
                doc_uri, chunk_uri = next(iter(doc_map.values()))

            drug_key = b_info.get("drug", "").lower().replace(" ", "_")
            ind_slug = (glob_ind or b_info.get("default_ind", "unknown")).lower().replace(" ", "_")
            ta_slug = (glob_ta or "general").lower().replace(" ", "_")
            geo_slug = (glob_geo or "global").lower().replace(" ", "_")

            requested_subjects.append(SubjectEntityQuery(
                brand=b_info["brand"],
                drug=b_info.get("drug"),
                indication=glob_ind or b_info.get("default_ind"),
                geography=glob_geo,
                therapeutic_area=glob_ta,
                canonical_uri=f"http://watson.pharma.org/entity/brand/{b_key}",
                brand_uri=f"http://watson.pharma.org/entity/brand/{b_key}",
                drug_uri=f"http://watson.pharma.org/entity/drug/{drug_key}",
                indication_uri=f"http://watson.pharma.org/entity/indication/{ind_slug}",
                therapeutic_area_uri=f"http://watson.pharma.org/entity/ta/{ta_slug}",
                geography_uri=f"http://watson.pharma.org/entity/geo/{geo_slug}",
                document_uri=doc_uri,
                chunk_uri=chunk_uri,
            ))

        # Check for multi-geography query on single brand (e.g. "Dupixent US versus India")
        if len(requested_subjects) == 1 and is_comparison:
            found_geos = []
            for geo_code, geo_al in self.GEOGRAPHY_ALIASES.items():
                if any(re.search(rf"\b{re.escape(al)}\b", q_lower) for al in geo_al):
                    found_geos.append(geo_code)
            if len(found_geos) > 1:
                base_subj = requested_subjects[0]
                requested_subjects = []
                for g in found_geos:
                    requested_subjects.append(SubjectEntityQuery(
                        brand=base_subj.brand,
                        drug=base_subj.drug,
                        indication=base_subj.indication,
                        geography=g,
                        therapeutic_area=base_subj.therapeutic_area,
                        canonical_uri=base_subj.canonical_uri,
                    ))

        # Step 4: Extract Evidence Categories & Required Sections
        ev_categories = []
        req_sections = []

        if any(w in q_lower for w in ["reimbursement", "cost", "pricing", "coverage"]):
            ev_categories.append("reimbursement")
            req_sections.append("Reimbursement Considerations")
        if any(w in q_lower for w in ["treatment pathway", "pathway", "sequencing", "access pathway", "guidelines"]):
            ev_categories.append("treatment_pathway")
            req_sections.append("Treatment Pathway & Access")
        if any(w in q_lower for w in ["hcp concern", "concern", "perception", "physician confidence", "kol feedback", "signals"]):
            ev_categories.append("hcp_concerns")
            req_sections.append("HCP Concerns & Priorities")
        if any(w in q_lower for w in ["recommend", "improvement", "needs", "requested"]):
            ev_categories.append("recommendations")
            req_sections.append("Recommended Improvements")
        if any(w in q_lower for w in ["market access", "access"]):
            ev_categories.append("market_access")
            if "Reimbursement Considerations" not in req_sections:
                req_sections.append("Market Access Overview")

        comp_dims = []
        if q_type == QuestionType.MARKET_ACCESS_COMPARISON:
            comp_dims = ["reimbursement", "pathway_placement", "prior_authorization", "guideline_adoption", "hcp_confidence"]
            req_sections = [
                "Comparative Evaluation Matrix",
                "Evidence-Supported Common Factors",
                "Established Regional & Clinical Differences",
                "Evidence Limitations",
            ]
        elif q_type == QuestionType.CLINICAL_COMPARATIVE_EVIDENCE:
            comp_dims = ["clinical_superiority", "head_to_head_efficacy", "comparative_endpoints"]
            req_sections = [
                "Clinical Superiority Assessment",
                "Available Comparative Evidence",
                "Evidence Limitations and Boundaries",
            ]
        elif q_type == QuestionType.ONTOLOGY_RELATIONSHIP_TRACE:
            req_sections = [
                "Semantic Entity Assertions",
                "Ontology Taxonomy & Hierarchy",
                "Documented Research Evidence",
            ]
        elif q_type == QuestionType.QUANTITATIVE_CLINICAL_EVIDENCE:
            comp_dims = ["hazard_ratio", "overall_survival", "progression_free_survival"]
            req_sections = [
                "Quantitative Clinical Endpoint Assessment",
                "Documented Metrics & Reported Outcomes",
                "Non-Reported / Missing Trial Statistics",
            ]
        elif q_type == QuestionType.KNOWLEDGE_GRAPH_AGGREGATION:
            comp_dims = ["active_drug", "indication", "therapeutic_area", "geography"]
            req_sections = [
                "Knowledge Graph Canonical Entity Resolution",
                "Comparative Cross-Subject Attribute Matrix",
                "Ontology Lineage & Provenance",
            ]

        all_entities = [s.brand for s in requested_subjects if s.brand]
        all_indications = [s.indication for s in requested_subjects if s.indication]
        all_geos = [s.geography for s in requested_subjects if s.geography]
        all_tas = [s.therapeutic_area for s in requested_subjects if s.therapeutic_area]

        req_metrics = []
        if is_quantitative:
            for m in ["hazard ratio", "overall survival", "progression-free survival", "median progression-free", "median overall survival", "pfs"]:
                if m in q_lower:
                    req_metrics.append(m)

        u_id = session_context.get("user_id", "D4") if session_context else "D4"
        c_id = session_context.get("conversation_id", "") if session_context else ""
        doc_ids = list({s.document_uri for s in requested_subjects if s.document_uri})
        entity_uris = [s.canonical_uri for s in requested_subjects if s.canonical_uri]

        return QueryPlan(
            request_id=str(uuid.uuid4()),
            authenticated_user_id=u_id,
            conversation_id=c_id,
            original_question=query,
            conversational_intent=conv_intent,
            research_intent=q_type,
            requested_entities=all_entities,
            canonical_entity_uris=entity_uris,
            required_brand_drug_indication_bindings=requested_subjects,
            requested_geographies=all_geos,
            requested_therapeutic_areas=all_tas,
            requested_document_ids=doc_ids,
            requested_metrics=req_metrics,
            temporal_constraints={"period": "longitudinal_trajectory"} if is_temporal else None,
            comparison_dimensions=comp_dims,
            expected_answer_structure="STRUCTURED_SECTIONS",
            required_evidence_types=["DOCUMENT_CHUNK", "GRAPH_ASSERTION"],
            evidence_scope="REGIONAL" if all_geos else "GLOBAL",
            authorization_context={"user_id": u_id},

            raw_query=query,
            effective_query=active_query,
            question_type=q_type,
            conversation_intent=conv_intent,
            route=route,
            route_reason=reason,
            is_conversational=False,
            clinical_superiority_claim=is_superiority,
            requested_subjects=requested_subjects,
            requested_indications=all_indications,
            requested_evidence_categories=ev_categories,
            requested_comparison_dimensions=comp_dims,
            required_answer_sections=req_sections,
            minimum_evidence_coverage=1.0 if q_type in [QuestionType.MARKET_ACCESS_COMPARISON, QuestionType.KNOWLEDGE_GRAPH_AGGREGATION] else 0.8,
        )

    def route_query(self, query: str) -> Tuple[QueryRoute, str, Dict[str, Any]]:
        """Backward-compatible routing method returning (route, reason, entities_dict)."""
        intent = self.analyze_intent(query)
        raw_entities = {
            "brands": intent.requested_entities,
            "therapeutic_areas": intent.requested_therapeutic_areas,
            "geographies": intent.requested_geographies,
            "indications": intent.requested_indications,
            "question_type": intent.question_type.value,
        }
        return intent.route, intent.route_reason, raw_entities
