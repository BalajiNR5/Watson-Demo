"""Small local-only Ollama transport; no third-party Python client required."""
from __future__ import annotations

import json
import os
import urllib.request


class OllamaClient:
    def __init__(self, model=None, base_url=None):
        self.model = model or os.environ.get("WATSON_QWEN_MODEL", "qwen3:latest")
        self.base_url = (base_url or os.environ.get(
            "WATSON_OLLAMA_URL", "http://127.0.0.1:11434"
        )).rstrip("/")

    def _post(self, endpoint, payload, timeout):
        request = urllib.request.Request(
            self.base_url + endpoint,
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(request, timeout=timeout) as response:
            result = json.loads(response.read().decode("utf-8"))
        if result.get("error"):
            raise RuntimeError(result["error"])
        return result

    def check(self):
        return self._post("/api/show", {"model": self.model}, 15)

    def generate(self, prompt):
        result = self._post("/api/chat", {
            "model": self.model,
            "messages": [{"role": "user", "content": prompt}],
            "stream": False,
            "think": False,
            "keep_alive": "10m",
            "options": {"temperature": 0.1, "num_ctx": 8192, "num_predict": 600},
        }, int(os.environ.get("WATSON_LLM_TIMEOUT", "300")))
        answer = result.get("message", {}).get("content", "").strip()
        if not answer:
            raise RuntimeError("Ollama returned an empty answer")
        return answer
