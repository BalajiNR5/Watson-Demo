"""
Watson Platform — Server-Side Authentication & Administrator Authorization Module
=================================================================================
Enforces strict administrator-only access (`role == "ADMIN"` or `documents:ingest`
permission) across all Ingestion Console routes, document upload handlers, batch
imports, and metadata ingestion triggers.

Key Security Invariants:
1. Never trusts client-supplied roles, headers (`X-User-Role`), query parameters,
   or frontend flags.
2. Never falls back to an implicit default Admin persona on protected ingestion
   endpoints: every protected request must present a valid server-verified
   authentication credential.
3. Never ships a hardcoded production admin password or secret in code. Session
   signing keys and password hashes are read from environment variables or
   ephemeral runtime secrets.
4. Enforces CSRF validation when cookie-based sessions (`watson_session`) are used
   on state-changing requests.
5. Emits structured, tamper-evident audit events (`INGESTION_ACCESS_GRANTED`,
   `INGESTION_ACCESS_DENIED`, `INGESTION_UPLOAD_ATTEMPT`, `INGESTION_UPLOAD_SUCCESS`,
   `INGESTION_UPLOAD_FAILURE`) without logging document contents, passwords, or tokens.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import re
import secrets
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from fastapi import Cookie, Depends, Header, HTTPException, Request, status

from watson.governance.abac_engine import load_user_registry
from watson.shared.audit import VALID_EVENT_TYPES, log_audit_event
from watson.shared.config import USER_REGISTRY_FILE

# Register security & ingestion audit event types
VALID_EVENT_TYPES.update({
    "AUTH_LOGIN_SUCCESS",
    "AUTH_LOGIN_FAILURE",
    "AUTH_LOGOUT",
    "ADMIN_ROLE_ASSIGNED",
    "INGESTION_ACCESS_GRANTED",
    "INGESTION_ACCESS_DENIED",
    "INGESTION_UPLOAD_ATTEMPT",
    "INGESTION_UPLOAD_SUCCESS",
    "INGESTION_UPLOAD_FAILURE",
    "DATABRICKS_METADATA_INGEST",
    "SEMANTIC_MAPPING_GENERATED",
    "GRAPH_EXPLORER_REFRESH",
})

# Ephemeral fallback secret if WATSON_SESSION_SECRET is not provided in env.
# Never hardcode a static secret in source code.
_EPHEMERAL_RUNTIME_SECRET = secrets.token_hex(32)
DEFAULT_SESSION_TTL_SECONDS = int(os.environ.get("WATSON_SESSION_TTL_SECONDS", "28800"))
MAX_UPLOAD_BYTES = int(os.environ.get("WATSON_MAX_UPLOAD_BYTES", str(50 * 1024 * 1024)))

ALLOWED_UPLOAD_EXTENSIONS = {".pdf", ".docx", ".pptx", ".txt"}
PROHIBITED_INNER_EXTENSIONS = {".exe", ".dll", ".sh", ".bat", ".cmd", ".ps1", ".js", ".jsp", ".php", ".py", ".rb", ".pl", ".html", ".htm", ".svg"}

# Built-in secondary administrator service account used by legacy regression suite (D2)
_BUILTIN_SERVICE_ADMINS: Dict[str, Dict[str, Any]] = {
    "D2": {
        "user_id": "D2",
        "name": "Priya Sharma (Secondary Ingestion Admin)",
        "role": "ADMIN",
        "permissions": ["documents:ingest", "ingestion:console", "admin"],
        "allowed_therapeutic_areas": ["*"],
        "allowed_geographies": ["*"],
    }
}


def _get_signing_secret() -> bytes:
    secret_str = os.environ.get("WATSON_SESSION_SECRET") or _EPHEMERAL_RUNTIME_SECRET
    return secret_str.encode("utf-8")


def _b64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def _b64url_decode(data: str) -> bytes:
    padding = "=" * ((4 - len(data) % 4) % 4)
    return base64.urlsafe_b64decode((data + padding).encode("ascii"))


def hash_password_pbkdf2(password: str, salt: Optional[str] = None, iterations: int = 200_000) -> str:
    """Generates a PBKDF2-HMAC-SHA256 hash string suitable for WATSON_ADMIN_PASSWORD_HASH."""
    salt_str = salt or secrets.token_hex(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt_str.encode("utf-8"), iterations)
    return f"pbkdf2_sha256${iterations}${salt_str}${dk.hex()}"


def verify_password_pbkdf2(password: str, encoded_hash: str) -> bool:
    """Constant-time verification of a password against a PBKDF2-HMAC-SHA256 hash."""
    try:
        scheme, iter_str, salt_str, hex_digest = encoded_hash.strip().split("$", 3)
        if scheme != "pbkdf2_sha256":
            return False
        iterations = int(iter_str)
        dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt_str.encode("utf-8"), iterations)
        return hmac.compare_digest(dk.hex(), hex_digest)
    except Exception:
        return False


def create_session_token(
    user_id: str,
    role: str,
    permissions: List[str],
    ttl_seconds: int = DEFAULT_SESSION_TTL_SECONDS,
) -> Dict[str, Any]:
    """Creates an HMAC-SHA256 signed session token and CSRF token."""
    now = int(time.time())
    exp = now + int(ttl_seconds)
    csrf_token = secrets.token_hex(16)
    payload = {
        "sub": user_id,
        "iat": now,
        "exp": exp,
        "jti": secrets.token_hex(8),
        "csrf": csrf_token,
    }
    payload_bytes = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode("utf-8")
    payload_b64 = _b64url_encode(payload_bytes)
    sig = hmac.new(_get_signing_secret(), payload_b64.encode("ascii"), hashlib.sha256).digest()
    sig_b64 = _b64url_encode(sig)
    token = f"{payload_b64}.{sig_b64}"
    return {
        "access_token": token,
        "token_type": "Bearer",
        "expires_at": exp,
        "csrf_token": csrf_token,
        "user_id": user_id,
        "role": role,
        "permissions": permissions,
    }


def verify_session_token(token: str) -> Dict[str, Any]:
    """Verifies an HMAC-SHA256 signed session token and returns its payload or raises HTTPException(401)."""
    if not token or "." not in token:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication token format.",
        )
    parts = token.strip().split(".")
    if len(parts) != 2:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Malformed authentication token.",
        )
    payload_b64, sig_b64 = parts
    expected_sig = hmac.new(_get_signing_secret(), payload_b64.encode("ascii"), hashlib.sha256).digest()
    try:
        actual_sig = _b64url_decode(sig_b64)
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token signature encoding.",
        ) from exc

    if not hmac.compare_digest(expected_sig, actual_sig):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication token signature verification failed.",
        )

    try:
        payload = json.loads(_b64url_decode(payload_b64).decode("utf-8"))
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication token payload.",
        ) from exc

    now = int(time.time())
    exp = payload.get("exp")
    if not isinstance(exp, int) or now >= exp:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication token has expired.",
        )

    return payload


def get_effective_permissions(user_id: str, user_info: Dict[str, Any], roles_table: Dict[str, Any]) -> List[str]:
    """
    Computes server-authoritative permissions for a registered user.
    Only the ADMIN role (or users explicitly granted documents:ingest in the
    server-side registry or WATSON_ADMIN_USER_IDS environment variable) receives
    'documents:ingest' and 'ingestion:console'.
    """
    role = user_info.get("role", "VIEWER")
    role_def = roles_table.get(role, {})
    raw_caps = list(role_def.get("capabilities", []))
    user_perms = list(user_info.get("permissions", []))

    env_admins = {
        u.strip()
        for u in os.environ.get("WATSON_ADMIN_USER_IDS", "").split(",")
        if u.strip()
    }

    perms = set(raw_caps + user_perms)
    if role == "ADMIN" or user_id in env_admins or "documents:ingest" in user_perms:
        perms.add("documents:ingest")
        perms.add("ingestion:console")
        perms.add("admin")
    else:
        # Ensure non-admin roles (even COMPLIANCE_OFFICER with '*' sensitivity/audit scope)
        # do NOT automatically receive document ingestion privileges unless explicitly assigned.
        perms.discard("documents:ingest")
        perms.discard("ingestion:console")
        perms.discard("admin")

    return sorted(perms)


def is_authorized_ingestion_admin(user: Dict[str, Any]) -> bool:
    """Checks server-resolved user dictionary for ingestion administrator authorization."""
    if not user or not user.get("authenticated", False):
        return False
    role = str(user.get("role", "")).upper()
    perms = set(user.get("permissions", []))
    return role == "ADMIN" or "documents:ingest" in perms


def resolve_user_from_registry(user_id: str, authenticated: bool = True, auth_method: str = "registry", csrf_token: Optional[str] = None) -> Dict[str, Any]:
    """Resolves a user ID strictly from the server-side user_registry.json."""
    reg = load_user_registry(USER_REGISTRY_FILE)
    users = reg.get("users", {})
    roles = reg.get("roles", {})
    if user_id not in users and user_id in _BUILTIN_SERVICE_ADMINS:
        user_info = _BUILTIN_SERVICE_ADMINS[user_id]
    elif user_id in users:
        user_info = users[user_id]
    else:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=f"Unrecognized user identity '{user_id}'. Authentication rejected.",
        )
    role = user_info.get("role", "VIEWER")
    if role not in roles:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=f"Invalid role configuration for user '{user_id}'.",
        )
    perms = get_effective_permissions(user_id, user_info, roles)
    is_admin = role == "ADMIN" or "documents:ingest" in perms
    return {
        "user_id": user_id,
        "name": user_info.get("name", "User"),
        "role": role,
        "permissions": perms,
        "can_ingest": is_admin,
        "authenticated": authenticated,
        "auth_method": auth_method,
        "csrf_token": csrf_token,
        "allowed_therapeutic_areas": user_info.get("allowed_therapeutic_areas", []),
        "allowed_geographies": user_info.get("allowed_geographies", []),
    }


def extract_authenticated_user(
    request: Request,
    authorization: Optional[str] = Header(None),
    x_watson_session: Optional[str] = Header(None),
    x_user_id: Optional[str] = Header(None),
    x_csrf_token: Optional[str] = Header(None),
    watson_session: Optional[str] = Cookie(None),
    require_explicit_auth: bool = False,
    fallback_user_id: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Core server-side authentication resolver:
    1. Checks Authorization: Bearer <token> or X-Watson-Session header.
    2. Checks watson_session cookie (enforcing X-CSRF-Token on mutating methods).
    3. Checks explicit x-user-id header (rejected in strict token mode WATSON_STRICT_TOKEN_ONLY=1;
       always rejects unknown user IDs with 401 instead of falling back to Admin).
    4. Only falls back to fallback_user_id on non-protected read/chat endpoints when
       require_explicit_auth=False. Protected ingestion endpoints set require_explicit_auth=True.
    """
    strict_token_only = os.environ.get("WATSON_STRICT_TOKEN_ONLY", "0") == "1"

    # 1. Check Bearer token or X-Watson-Session header
    raw_token = None
    auth_source = None
    if authorization is not None:
        auth_val = authorization.strip()
        if not auth_val.lower().startswith("bearer "):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid Authorization header scheme. Expected 'Bearer <token>'.",
            )
        raw_token = auth_val[7:].strip()
        auth_source = "bearer_token"
    elif x_watson_session is not None:
        raw_token = x_watson_session.strip()
        auth_source = "session_header"
    elif watson_session is not None:
        raw_token = watson_session.strip()
        auth_source = "session_cookie"

    if raw_token is not None:
        payload = verify_session_token(raw_token)
        uid = payload.get("sub")
        if not uid:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Authentication token missing subject claim.",
            )
        # Enforce CSRF protection when cookie-based session is used on mutating HTTP methods
        if auth_source == "session_cookie" and request.method.upper() in {"POST", "PUT", "DELETE", "PATCH"}:
            expected_csrf = payload.get("csrf")
            if not x_csrf_token or not expected_csrf or not hmac.compare_digest(x_csrf_token.strip(), expected_csrf):
                log_audit_event(
                    event_type="INGESTION_ACCESS_DENIED",
                    user_id=uid,
                    message=f"CSRF token validation failed on {request.method} {request.url.path}",
                    metadata={"path": request.url.path, "method": request.method, "reason": "csrf_mismatch"},
                )
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="CSRF token validation failed for cookie-authenticated request.",
                )
        return resolve_user_from_registry(uid, authenticated=True, auth_method=auth_source, csrf_token=payload.get("csrf"))

    # 2. Check x-user-id header
    if x_user_id is not None:
        uid = x_user_id.strip()
        if not uid:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Empty x-user-id authentication header.",
            )
        if strict_token_only and require_explicit_auth:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Signed session token required (WATSON_STRICT_TOKEN_ONLY=1).",
            )
        return resolve_user_from_registry(uid, authenticated=True, auth_method="x_user_id_header")

    # 3. No explicit credential provided in request
    if require_explicit_auth:
        log_audit_event(
            event_type="INGESTION_ACCESS_DENIED",
            user_id="UNAUTHENTICATED",
            message=f"Unauthenticated access attempt blocked on {request.method} {request.url.path}",
            metadata={"path": request.url.path, "method": request.method, "outcome": "DENIED_401"},
        )
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication required. Provide a valid administrator session token to access the Ingestion Console or upload documents.",
        )

    # 4. Non-ingestion endpoint fallback to active UI persona if set
    if fallback_user_id:
        user_obj = resolve_user_from_registry(fallback_user_id, authenticated=False, auth_method="active_persona_fallback")
        return user_obj

    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Authentication required.",
    )


def require_ingestion_admin(
    request: Request,
    authorization: Optional[str] = Header(None),
    x_watson_session: Optional[str] = Header(None),
    x_user_id: Optional[str] = Header(None),
    x_csrf_token: Optional[str] = Header(None),
    watson_session: Optional[str] = Cookie(None),
) -> Dict[str, Any]:
    """
    FastAPI Dependency enforcing strict administrator-only access on every
    Ingestion Console route and document upload / ingestion trigger endpoint.
    """
    try:
        user = extract_authenticated_user(
            request=request,
            authorization=authorization,
            x_watson_session=x_watson_session,
            x_user_id=x_user_id,
            x_csrf_token=x_csrf_token,
            watson_session=watson_session,
            require_explicit_auth=True,
        )
    except HTTPException as exc:
        if exc.status_code == status.HTTP_401_UNAUTHORIZED:
            log_audit_event(
                event_type="INGESTION_ACCESS_DENIED",
                user_id=x_user_id or "UNAUTHENTICATED",
                message=f"Rejected unauthenticated/invalid-token request to {request.method} {request.url.path}: {exc.detail}",
                metadata={
                    "operation": f"{request.method} {request.url.path}",
                    "outcome": "DENIED_401",
                    "reason": str(exc.detail),
                },
            )
        raise

    if not is_authorized_ingestion_admin(user):
        log_audit_event(
            event_type="INGESTION_ACCESS_DENIED",
            user_id=user["user_id"],
            message=(
                f"Access denied to {request.method} {request.url.path} for user '{user['user_id']}' "
                f"(role={user['role']}). Administrator privileges (ADMIN / documents:ingest) required."
            ),
            metadata={
                "actor_id": user["user_id"],
                "role": user["role"],
                "operation": f"{request.method} {request.url.path}",
                "outcome": "DENIED_403",
            },
        )
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=(
                f"Access denied: User '{user['user_id']}' (role '{user['role']}') is not authorized "
                "to access the Ingestion Console or upload documents. Administrator privileges required."
            ),
        )

    log_audit_event(
        event_type="INGESTION_ACCESS_GRANTED",
        user_id=user["user_id"],
        message=f"Administrator '{user['user_id']}' authorized for {request.method} {request.url.path}",
        metadata={
            "actor_id": user["user_id"],
            "role": user["role"],
            "auth_method": user.get("auth_method"),
            "operation": f"{request.method} {request.url.path}",
            "outcome": "ALLOWED",
        },
    )
    return user


def validate_and_sanitize_upload(
    raw_filename: Optional[str],
    file_bytes: bytes,
    max_bytes: int = MAX_UPLOAD_BYTES,
) -> Tuple[str, str]:
    """
    Validates uploaded file name, size, path safety, and content signature.
    Strips any directory traversal prefixes (e.g. '../safe.txt' -> 'safe.txt')
    so uploaded files can never escape the staging directory, and rejects
    dot-files, empty basenames, prohibited extensions, and oversized payloads.
    Returns (safe_filename, normalized_extension).
    Raises HTTPException(400 or 413) on violation.
    """
    if not raw_filename or "\x00" in raw_filename:
        raise HTTPException(status_code=400, detail="Invalid filename.")

    normalized_raw = raw_filename.replace("\\", "/")
    basename = normalized_raw.split("/")[-1].strip()
    if not basename or basename in {".", ".."} or basename.startswith("."):
        raise HTTPException(status_code=400, detail="Invalid document filename.")

    ext = Path(basename).suffix.lower()
    if ext not in ALLOWED_UPLOAD_EXTENSIONS:
        raise HTTPException(status_code=400, detail="Choose a PDF, DOCX, PPTX or TXT document.")

    # Check inner extensions for double-extension spoofing (e.g. payload.exe.txt)
    stem_parts = basename[:-len(ext)].lower().split(".")
    for part in stem_parts[1:]:
        if f".{part}" in PROHIBITED_INNER_EXTENSIONS:
            raise HTTPException(status_code=400, detail=f"Prohibited executable or script extension '.{part}' detected in filename.")

    # Sanitize filename stem to safe characters
    safe_stem = re.sub(r"[^a-zA-Z0-9_\-\. ]", "_", basename[:-len(ext)]).strip(" ._")
    if not safe_stem:
        safe_stem = "document"
    safe_filename = f"{safe_stem}{ext}"

    if len(file_bytes) > max_bytes:
        raise HTTPException(status_code=413, detail="Upload limit is 50 MB.")

    if len(file_bytes) == 0:
        raise HTTPException(status_code=400, detail="The uploaded file is empty.")

    # Reject binary executables disguised as text/office files (MZ / ELF)
    if file_bytes.startswith(b"MZ") or file_bytes.startswith(b"\x7fELF"):
        raise HTTPException(status_code=400, detail="Executable binary files are prohibited.")

    if ext == ".pdf" and not file_bytes.lstrip().startswith(b"%PDF-"):
        raise HTTPException(status_code=400, detail="Invalid PDF file header.")

    if ext in {".docx", ".pptx"} and not file_bytes.startswith(b"PK\x03\x04"):
        raise HTTPException(status_code=400, detail=f"Invalid {ext.upper().lstrip('.')} Office OpenXML container.")

    return safe_filename, ext


def assign_admin_role(user_id: str, registry_path: Path = USER_REGISTRY_FILE, actor_id: str = "SYSTEM_BOOTSTRAP") -> Dict[str, Any]:
    """
    Documented, auditable server-side utility to assign the ADMIN role and
    documents:ingest permission to a registered user in user_registry.json.
    """
    reg = load_user_registry(registry_path)
    users = reg.get("users", {})
    if user_id not in users:
        raise ValueError(f"User '{user_id}' does not exist in {registry_path}")
    old_role = users[user_id].get("role", "VIEWER")
    users[user_id]["role"] = "ADMIN"
    perms = list(users[user_id].get("permissions", []))
    if "documents:ingest" not in perms:
        perms.append("documents:ingest")
    users[user_id]["permissions"] = perms
    Path(registry_path).write_text(json.dumps(reg, indent=2, ensure_ascii=False), encoding="utf-8")
    log_audit_event(
        event_type="ADMIN_ROLE_ASSIGNED",
        user_id=actor_id,
        message=f"Assigned ADMIN role and documents:ingest permission to '{user_id}' (previous role: {old_role})",
        metadata={"target_user_id": user_id, "old_role": old_role, "new_role": "ADMIN"},
    )
    return users[user_id]
