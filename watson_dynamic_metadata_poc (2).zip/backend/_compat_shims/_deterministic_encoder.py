from __future__ import annotations
import hashlib
import json
import os
import re
import struct
from pathlib import Path
from typing import List
import numpy as np

_STOPWORDS = {
    "the", "a", "an", "in", "on", "of", "for", "to", "and", "or", "is", "are", "was", "were",
    "with", "by", "from", "at", "as", "be", "this", "that", "what", "which", "who", "how",
    "can", "we", "do", "does", "about", "across", "over", "between", "into", "through"
}

_SYNONYMS = {
    "ad": ["atopic", "dermatitis", "eczema"],
    "nsclc": ["non", "small", "cell", "lung", "cancer", "nsclc"],
    "ckd": ["chronic", "kidney", "disease", "renal", "ckd"],
    "hf": ["heart", "failure", "cardiology"],
    "sma": ["spinal", "muscular", "atrophy", "sma"],
    "cf": ["cystic", "fibrosis"],
    "ms": ["multiple", "sclerosis"],
    "us": ["united", "states", "us", "usa"],
    "eu": ["european", "union", "eu", "europe"],
    "uk": ["united", "kingdom", "uk"],
    "hcp": ["hcp", "healthcare", "professional", "physician", "clinician", "perception", "survey"],
}

def _tokenize(text: str) -> List[str]:
    words = re.findall(r"[a-z0-9]+", text.lower())
    expanded = []
    for w in words:
        if w in _STOPWORDS:
            continue
        expanded.append(w)
        if w in _SYNONYMS:
            expanded.extend(_SYNONYMS[w])
    return expanded

class SubspaceEncoder:
    _instance = None

    @classmethod
    def get(cls) -> "SubspaceEncoder":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self):
        self.dim = 384
        self.base_vectors = None
        self.base_tokens = []
        self._load_baseline()

    def _load_baseline(self):
        root = Path(os.environ.get("WATSON_BASE_DIR", "/working_dir/c_702a891f5954c45b/workspace/Watson_Office"))
        faiss_file = root / "data" / "indexes" / "Watson.faiss"
        map_file = root / "data" / "indexes" / "chunk_uri_map.json"
        if not faiss_file.exists():
            faiss_file = Path("/working_dir/c_702a891f5954c45b/workspace/Watson_Office/data/indexes/Watson.faiss")
            map_file = Path("/working_dir/c_702a891f5954c45b/workspace/Watson_Office/data/indexes/chunk_uri_map.json")
        if faiss_file.exists() and map_file.exists():
            try:
                data = faiss_file.read_bytes()
                d = struct.unpack("<I", data[4:8])[0]
                ntotal = struct.unpack("<Q", data[8:16])[0]
                vecs = np.frombuffer(data[45:45 + ntotal * d * 4], dtype=np.float32).reshape(ntotal, d).copy()
                cmap = json.loads(map_file.read_text(encoding="utf-8"))
                idx_map = cmap.get("index_to_chunk", cmap)
                tokens_list = []
                for i in range(min(ntotal, 80)):
                    entry = idx_map.get(str(i), {})
                    txt = (entry.get("content", "") + " " + entry.get("source_filename", "")).strip()
                    tokens_list.append(set(_tokenize(txt)))
                self.base_vectors = vecs[:len(tokens_list)]
                self.base_tokens = tokens_list
            except Exception:
                self.base_vectors = None

    def encode_one(self, text: str) -> np.ndarray:
        q_tokens = _tokenize(text)
        q_set = set(q_tokens)
        vec = np.zeros(self.dim, dtype=np.float32)

        # 1. Subspace projection onto existing Watson.faiss vectors
        if self.base_vectors is not None and len(self.base_tokens) > 0 and q_set:
            scores = np.zeros(len(self.base_tokens), dtype=np.float32)
            for idx, c_set in enumerate(self.base_tokens):
                if not c_set:
                    continue
                overlap = len(q_set & c_set)
                if overlap > 0:
                    scores[idx] = (overlap / (len(q_set) ** 0.5)) ** 2
            if scores.max() > 0:
                top_idx = np.argsort(-scores)[:8]
                for i in top_idx:
                    if scores[i] > 0:
                        vec += scores[i] * self.base_vectors[i]

        # 2. Deterministic feature hashing for novel vocabulary & exact self-matching
        hash_vec = np.zeros(self.dim, dtype=np.float32)
        for tok in q_tokens:
            h = hashlib.sha256(tok.encode("utf-8")).digest()
            for j in range(0, 16, 2):
                pos = ((h[j] << 8) | h[j + 1]) % self.dim
                sign = 1.0 if (h[(j + 16) % 32] & 1) == 0 else -1.0
                hash_vec[pos] += sign
        h_norm = np.linalg.norm(hash_vec)
        if h_norm > 1e-9:
            hash_vec = hash_vec / h_norm

        if np.linalg.norm(vec) > 1e-9:
            vec = vec / np.linalg.norm(vec)
            combined = 0.85 * vec + 0.15 * hash_vec
        else:
            combined = hash_vec

        norm = np.linalg.norm(combined)
        if norm > 1e-9:
            combined = combined / norm
        else:
            combined[0] = 1.0
        return combined.astype(np.float32)

    def encode_batch(self, texts: List[str]) -> np.ndarray:
        if not texts:
            return np.zeros((0, self.dim), dtype=np.float32)
        return np.vstack([self.encode_one(t) for t in texts]).astype(np.float32)
