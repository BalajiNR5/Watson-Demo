from __future__ import annotations
import struct
from pathlib import Path
import numpy as np

class IndexFlatIP:
    def __init__(self, d: int = 384):
        self.d = int(d)
        self.is_trained = True
        self.metric_type = 0
        self._vectors = np.zeros((0, self.d), dtype=np.float32)

    @property
    def ntotal(self) -> int:
        return int(self._vectors.shape[0])

    def add(self, x: np.ndarray) -> None:
        arr = np.asarray(x, dtype=np.float32)
        if arr.ndim == 1:
            arr = arr.reshape(1, -1)
        if arr.shape[1] != self.d:
            raise ValueError(f"Expected dim {self.d}, got {arr.shape[1]}")
        if self.ntotal == 0:
            self._vectors = arr.copy()
        else:
            self._vectors = np.vstack([self._vectors, arr])

    def reconstruct(self, idx: int) -> np.ndarray:
        return self._vectors[int(idx)].copy()

    def search(self, x: np.ndarray, k: int):
        q = np.asarray(x, dtype=np.float32)
        if q.ndim == 1:
            q = q.reshape(1, -1)
        k = int(k)
        if self.ntotal == 0 or k <= 0:
            return np.zeros((q.shape[0], 0), dtype=np.float32), np.zeros((q.shape[0], 0), dtype=np.int64)
        k_eff = min(k, self.ntotal)
        scores = np.matmul(q, self._vectors.T)
        idx_part = np.argsort(-scores, axis=1)[:, :k_eff]
        sim_part = np.take_along_axis(scores, idx_part, axis=1)
        return sim_part.astype(np.float32), idx_part.astype(np.int64)

def read_index(path: str) -> IndexFlatIP:
    data = Path(path).read_bytes()
    if len(data) >= 45 and data[:4] == b"IxFI":
        d = struct.unpack("<I", data[4:8])[0]
        ntotal = struct.unpack("<Q", data[8:16])[0]
        vec_bytes = data[45:45 + ntotal * d * 4]
        idx = IndexFlatIP(d)
        if ntotal > 0 and len(vec_bytes) == ntotal * d * 4:
            idx._vectors = np.frombuffer(vec_bytes, dtype=np.float32).reshape(ntotal, d).copy()
        return idx
    raise ValueError(f"Unsupported FAISS index format in {path}")

def write_index(index: IndexFlatIP, path: str) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    d = index.d
    ntotal = index.ntotal
    header = bytearray(45)
    header[0:4] = b"IxFI"
    struct.pack_into("<I", header, 4, d)
    struct.pack_into("<Q", header, 8, ntotal)
    struct.pack_into("<Q", header, 16, 0x100000)
    struct.pack_into("<Q", header, 24, 0x100000)
    header[32] = 1  # is_trained
    struct.pack_into("<I", header, 33, 0)  # metric_type
    struct.pack_into("<Q", header, 37, ntotal * d)
    payload = bytes(header) + index._vectors.astype(np.float32).tobytes()
    p.write_bytes(payload)
