from __future__ import annotations
from typing import List
import numpy as np
import torch
from _deterministic_encoder import SubspaceEncoder

__version__ = "4.45.0"

class _ModelOutput:
    def __init__(self, last_hidden_state: torch.Tensor):
        self.last_hidden_state = last_hidden_state

class AutoTokenizer:
    @classmethod
    def from_pretrained(cls, model_name_or_path: str, local_files_only: bool = False, **kwargs):
        return cls()

    def __call__(self, texts: List[str], padding: bool = True, truncation: bool = True, max_length: int = 512, return_tensors: str = "pt"):
        if isinstance(texts, str):
            texts = [texts]
        n = len(texts)
        return {
            "_raw_texts": texts,
            "input_ids": torch.Tensor(np.ones((n, 4), dtype=np.float32)),
            "attention_mask": torch.Tensor(np.ones((n, 4), dtype=np.float32)),
        }

class AutoModel:
    @classmethod
    def from_pretrained(cls, model_name_or_path: str, local_files_only: bool = False, **kwargs):
        return cls()

    def eval(self):
        return self

    def __call__(self, _raw_texts=None, input_ids=None, attention_mask=None, **kwargs):
        texts = _raw_texts or [""]
        vecs = SubspaceEncoder.get().encode_batch(texts)
        # Expand (N, 384) to (N, 4, 384) so mean pooling over seq_len=4 yields exact vecs
        hidden = np.repeat(vecs[:, np.newaxis, :], 4, axis=1)
        return _ModelOutput(torch.Tensor(hidden))
