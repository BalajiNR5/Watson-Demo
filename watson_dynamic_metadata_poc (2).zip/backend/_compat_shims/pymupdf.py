from __future__ import annotations
from pathlib import Path
from pypdf import PdfReader
from reportlab.pdfgen import canvas

class _Rect:
    def __init__(self, width: float = 612.0, height: float = 792.0):
        self.width = float(width)
        self.height = float(height)

class _Page:
    def __init__(self, page_obj=None, number: int = 0):
        self._page = page_obj
        self.number = number
        self._text_boxes = []
        if page_obj is not None:
            try:
                mb = page_obj.mediabox
                self.rect = _Rect(float(mb.width), float(mb.height))
            except Exception:
                self.rect = _Rect()
        else:
            self.rect = _Rect()

    def insert_textbox(self, rect, text: str, fontsize: int = 11):
        self._text_boxes.append(str(text))

    def get_text(self, mode: str = "text"):
        if self._page is None:
            txt = "\n\n".join(self._text_boxes)
        else:
            try:
                txt = self._page.extract_text() or ""
            except Exception:
                txt = ""
        if mode == "blocks":
            paras = [p.strip() for p in txt.split("\n\n") if p.strip()]
            if not paras and txt.strip():
                paras = [txt.strip()]
            blocks = []
            for idx, p in enumerate(paras):
                y0 = float(idx * 24)
                blocks.append((50.0, y0, 550.0, y0 + 20.0, p, idx, 0))
            return blocks
        return txt

    def get_images(self, full: bool = False):
        if self._page is None:
            return []
        try:
            return list(getattr(self._page, "images", []) or [])
        except Exception:
            return []

class _Document:
    def __init__(self, path: str | Path | None = None):
        if path is not None:
            self._reader = PdfReader(str(path))
            meta = self._reader.metadata or {}
            self.metadata = {
                "title": getattr(meta, "title", None) or (meta.get("/Title") if hasattr(meta, "get") else None),
                "author": getattr(meta, "author", None) or (meta.get("/Author") if hasattr(meta, "get") else None),
                "creationDate": str(getattr(meta, "creation_date", None) or (meta.get("/CreationDate") if hasattr(meta, "get") else "") or ""),
            }
            self._pages = [_Page(p, i) for i, p in enumerate(self._reader.pages)]
        else:
            self._reader = None
            self.metadata = {}
            self._pages = []

    def new_page(self) -> _Page:
        p = _Page(None, len(self._pages))
        self._pages.append(p)
        return p

    def save(self, path: str | Path):
        c = canvas.Canvas(str(path))
        for p in self._pages:
            y = 740
            for tb in p._text_boxes:
                for line in tb.splitlines():
                    c.drawString(50, y, line)
                    y -= 15
            c.showPage()
        c.save()

    def __len__(self):
        return len(self._pages)

    def __iter__(self):
        return iter(self._pages)

    def __getitem__(self, idx: int):
        return self._pages[idx]

    def close(self):
        pass

def open(path: str | Path | None = None) -> _Document:
    return _Document(path)
