from __future__ import annotations
from typing import List
import numpy as np
from _deterministic_encoder import SubspaceEncoder

__version__ = "3.4.0"

class SentenceTransformer:
    def __init__(self, model_name_or_path: str = "", local_files_only: bool = False, **kwargs):
        self.model_name = model_name_or_path

    def encode(self, sentences: List[str] | str, convert_to_numpy: bool = True, normalize_embeddings: bool = True, **kwargs) -> np.ndarray:
        if isinstance(sentences, str):
            sentences = [sentences]
        return SubspaceEncoder.get().encode_batch(list(sentences))
