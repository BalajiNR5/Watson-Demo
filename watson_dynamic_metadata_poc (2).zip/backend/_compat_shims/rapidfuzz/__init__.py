from __future__ import annotations
from difflib import SequenceMatcher

class fuzz:
    @staticmethod
    def ratio(s1: str, s2: str) -> float:
        if not s1 and not s2:
            return 100.0
        if not s1 or not s2:
            return 0.0
        return SequenceMatcher(None, str(s1), str(s2)).ratio() * 100.0

    @staticmethod
    def partial_ratio(s1: str, s2: str) -> float:
        return fuzz.ratio(s1, s2)

    @staticmethod
    def token_sort_ratio(s1: str, s2: str) -> float:
        t1 = " ".join(sorted(str(s1).lower().split()))
        t2 = " ".join(sorted(str(s2).lower().split()))
        return fuzz.ratio(t1, t2)
