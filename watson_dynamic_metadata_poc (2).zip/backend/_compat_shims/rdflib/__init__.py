from __future__ import annotations
import math
import re
from pathlib import Path
from typing import Any, Dict, Iterable, Iterator, List, Optional, Set, Tuple

__version__ = "7.1.0"

class Identifier(str):
    def __new__(cls, value: Any):
        return super().__new__(cls, str(value))

class URIRef(Identifier):
    def __new__(cls, value: Any):
        return super().__new__(cls, str(value))

    def n3(self) -> str:
        return f"<{str(self)}>"

class BNode(Identifier):
    def __new__(cls, value: Any = "bnode"):
        return super().__new__(cls, str(value))

class Literal(Identifier):
    def __new__(cls, value: Any, datatype: Any = None, lang: Optional[str] = None):
        s = str(value)
        obj = super().__new__(cls, s)
        obj._raw_value = value
        obj.datatype = URIRef(str(datatype)) if datatype else None
        obj.language = lang
        return obj

    def toPython(self) -> Any:
        dt = str(self.datatype or "")
        if dt.endswith("#integer") or dt.endswith("#int") or dt.endswith("#long"):
            try:
                return int(float(str(self)))
            except Exception:
                return str(self)
        if dt.endswith("#float") or dt.endswith("#double") or dt.endswith("#decimal"):
            try:
                return float(str(self))
            except Exception:
                return str(self)
        if dt.endswith("#boolean"):
            return str(self).lower() == "true"
        return self._raw_value

    def n3(self) -> str:
        escaped = str(self).replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n").replace("\r", "\\r")
        if self.datatype:
            return f'"{escaped}"^^<{self.datatype}>'
        if self.language:
            return f'"{escaped}"@{self.language}'
        return f'"{escaped}"'

class Namespace(str):
    def __new__(cls, value: str):
        return super().__new__(cls, str(value))

    def __getattr__(self, name: str) -> URIRef:
        if name.startswith("__") and name.endswith("__"):
            raise AttributeError(name)
        return URIRef(str(self) + name)

    def __getitem__(self, key: str) -> URIRef:
        return URIRef(str(self) + str(key))

RDF = Namespace("http://www.w3.org/1999/02/22-rdf-syntax-ns#")
RDFS = Namespace("http://www.w3.org/2000/01/rdf-schema#")
OWL = Namespace("http://www.w3.org/2002/07/owl#")
XSD = Namespace("http://www.w3.org/2001/XMLSchema#")
SKOS = Namespace("http://www.w3.org/2004/02/skos/core#")
DC = Namespace("http://purl.org/dc/elements/1.1/")

# ---------------------------------------------------------------------------
# Fast & Faithful Turtle Parser
# ---------------------------------------------------------------------------

_TOKEN_RE = re.compile(
    r"""(?P<comment>#[^\n]*)|(?P<ws>\s+)|(?P<directive>@prefix|@base|PREFIX|BASE)|(?P<uri><[^>]*>)|(?P<mlstr>\x22\x22\x22(?:.|\n)*?\x22\x22\x22|\x27\x27\x27(?:.|\n)*?\x27\x27\x27)|(?P<str>\x22(?:\\.|[^\x22\\])*\x22|\x27(?:\\.|[^\x27\\])*\x27)|(?P<dtype>\^\^)|(?P<lang>@[a-zA-Z\-]+)|(?P<punct>[.;,\[\]\(\)])|(?P<word>[^\s#<>\x22{}|^`\\.;,\[\]\(\)]+)""",
    re.DOTALL,
)

def _unescape_turtle_str(s: str) -> str:
    return (
        s.replace('\\"', '"')
         .replace("\\'", "'")
         .replace("\\n", "\n")
         .replace("\\r", "\r")
         .replace("\\t", "\t")
         .replace("\\\\", "\\")
    )

def parse_turtle(text: str, prefixes: Dict[str, str]) -> List[Tuple[Identifier, Identifier, Identifier]]:
    tokens = []
    for m in _TOKEN_RE.finditer(text):
        kind = m.lastgroup
        if kind in ("comment", "ws"):
            continue
        tokens.append((kind, m.group(0)))

    triples: List[Tuple[Identifier, Identifier, Identifier]] = []
    n = len(tokens)
    i = 0
    bnode_counter = 0

    def resolve_term() -> Identifier:
        nonlocal i, bnode_counter
        if i >= n:
            return Literal("")
        kind, val = tokens[i]
        if kind == "uri":
            i += 1
            return URIRef(val[1:-1])
        if kind in ("mlstr", "str"):
            raw = val[3:-3] if kind == "mlstr" else val[1:-1]
            s_val = _unescape_turtle_str(raw)
            i += 1
            dt = None
            lang = None
            if i < n and tokens[i][0] == "dtype":
                i += 1
                dt_term = resolve_term()
                dt = str(dt_term)
            elif i < n and tokens[i][0] == "lang":
                lang = tokens[i][1][1:]
                i += 1
            return Literal(s_val, datatype=dt, lang=lang)
        if kind == "word":
            i += 1
            if val == "a":
                return RDF.type
            if val in ("true", "false"):
                return Literal(val, datatype=str(XSD.boolean))
            if re.match(r"^[+-]?\d+$", val):
                return Literal(int(val), datatype=str(XSD.integer))
            if re.match(r"^[+-]?(?:\d+\.\d*|\.\d+)(?:[eE][+-]?\d+)?$", val):
                return Literal(float(val), datatype=str(XSD.double))
            if ":" in val:
                pfx, local = val.split(":", 1)
                base = prefixes.get(pfx, "")
                return URIRef(base + local)
            return Literal(val)
        if kind == "punct" and val == "(":
            i += 1
            bnode_counter += 1
            bnode = BNode(f"list_{bnode_counter}")
            while i < n and not (tokens[i][0] == "punct" and tokens[i][1] == ")"):
                resolve_term()
            if i < n and tokens[i][0] == "punct" and tokens[i][1] == ")":
                i += 1
            return bnode
        if kind == "punct" and val == "[":
            i += 1
            bnode_counter += 1
            bnode = BNode(f"bnode_{bnode_counter}")
            while i < n and not (tokens[i][0] == "punct" and tokens[i][1] == "]"):
                pred = resolve_term()
                while i < n:
                    obj = resolve_term()
                    triples.append((bnode, pred, obj))
                    if i < n and tokens[i][0] == "punct" and tokens[i][1] == ",":
                        i += 1
                        continue
                    break
                if i < n and tokens[i][0] == "punct" and tokens[i][1] == ";":
                    i += 1
            if i < n and tokens[i][0] == "punct" and tokens[i][1] == "]":
                i += 1
            return bnode
        i += 1
        return Literal(val)

    while i < n:
        kind, val = tokens[i]
        if kind == "directive":
            d_upper = val.upper()
            i += 1
            if "PREFIX" in d_upper:
                if i < n:
                    pfx_tok = tokens[i][1]
                    pfx = pfx_tok.rstrip(":")
                    i += 1
                else:
                    pfx = ""
                if i < n and tokens[i][0] == "uri":
                    uri_val = tokens[i][1][1:-1]
                    i += 1
                    prefixes[pfx] = uri_val
                if i < n and tokens[i][0] == "punct" and tokens[i][1] == ".":
                    i += 1
            else:
                # BASE
                if i < n and tokens[i][0] == "uri":
                    i += 1
                if i < n and tokens[i][0] == "punct" and tokens[i][1] == ".":
                    i += 1
            continue

        if kind == "punct" and val == ".":
            i += 1
            continue

        subj = resolve_term()
        while i < n:
            if tokens[i][0] == "punct" and tokens[i][1] == ".":
                i += 1
                break
            pred = resolve_term()
            while i < n:
                obj = resolve_term()
                triples.append((subj, pred, obj))
                if i < n and tokens[i][0] == "punct" and tokens[i][1] == ",":
                    i += 1
                    continue
                break
            if i < n and tokens[i][0] == "punct" and tokens[i][1] == ";":
                i += 1
                if i < n and tokens[i][0] == "punct" and tokens[i][1] == ".":
                    i += 1
                    break
                continue
            if i < n and tokens[i][0] == "punct" and tokens[i][1] == ".":
                i += 1
                break
            break

    return triples


# ---------------------------------------------------------------------------
# SPARQL 1.1 Result Row & Query Engine
# ---------------------------------------------------------------------------

class ResultRow:
    def __init__(self, vars_list: List[str], values_dict: Dict[str, Any]):
        self._vars = vars_list
        self._dict = values_dict
        self._tuple = tuple(values_dict.get(v) for v in vars_list)

    def __getitem__(self, idx: int | str) -> Any:
        if isinstance(idx, int):
            return self._tuple[idx]
        return self._dict.get(idx)

    def __getattr__(self, name: str) -> Any:
        if name.startswith("_"):
            raise AttributeError(name)
        return self._dict.get(name)

    def __len__(self) -> int:
        return len(self._tuple)

    def __iter__(self):
        return iter(self._tuple)

class QueryResult:
    def __init__(self, vars_list: List[str], rows: List[ResultRow]):
        self.vars = [Identifier(v) for v in vars_list]
        self._rows = rows

    def __iter__(self) -> Iterator[ResultRow]:
        return iter(self._rows)

    def __len__(self) -> int:
        return len(self._rows)


def _split_top_level(text: str, sep: str = ".") -> List[str]:
    parts = []
    depth_brace = 0
    depth_paren = 0
    in_str = False
    str_char = ""
    cur = []
    i = 0
    n = len(text)
    while i < n:
        ch = text[i]
        if in_str:
            cur.append(ch)
            if ch == "\\" and i + 1 < n:
                i += 1
                cur.append(text[i])
            elif ch == str_char:
                in_str = False
            i += 1
            continue
        if ch in ('"', "'"):
            in_str = True
            str_char = ch
            cur.append(ch)
            i += 1
            continue
        if ch == "<":
            m_u = re.match(r"^<[^>\s]+>", text[i:])
            if m_u:
                cur.append(m_u.group(0))
                i += len(m_u.group(0))
                continue
        if ch == "{":
            depth_brace += 1
        elif ch == "}":
            depth_brace = max(0, depth_brace - 1)
        elif ch == "(":
            depth_paren += 1
        elif ch == ")":
            depth_paren = max(0, depth_paren - 1)

        if depth_brace == 0 and depth_paren == 0 and text.startswith(sep, i):
            # Make sure "." is not inside a decimal number like 0.4
            if sep == "." and i > 0 and i + 1 < n and text[i - 1].isdigit() and text[i + 1].isdigit():
                cur.append(ch)
                i += 1
                continue
            parts.append("".join(cur).strip())
            cur = []
            i += len(sep)
            continue
        cur.append(ch)
        i += 1
    tail = "".join(cur).strip()
    if tail:
        parts.append(tail)
    return [p for p in parts if p]


def _resolve_sparql_token(tok: str, prefixes: Dict[str, str]) -> Any:
    tok = tok.strip()
    if not tok:
        return None
    if tok.startswith("?") or tok.startswith("$"):
        return ("VAR", tok[1:])
    if tok == "a":
        return RDF.type
    if tok.startswith("<") and tok.endswith(">"):
        return URIRef(tok[1:-1])
    if (tok.startswith('"') and tok.endswith('"')) or (tok.startswith("'") and tok.endswith("'")):
        return Literal(tok[1:-1])
    if "^^" in tok:
        lit_part, _ = tok.split("^^", 1)
        return Literal(lit_part.strip('"\''))
    if re.match(r"^[+-]?\d+$", tok):
        return Literal(int(tok), datatype=str(XSD.integer))
    if re.match(r"^[+-]?(?:\d+\.\d*|\.\d+)$", tok):
        return Literal(float(tok), datatype=str(XSD.double))
    if ":" in tok:
        pfx, local = tok.split(":", 1)
        if pfx in prefixes:
            return URIRef(prefixes[pfx] + local)
    return Literal(tok)


def _to_num(val: Any) -> Optional[float]:
    if val is None:
        return None
    if isinstance(val, (int, float)):
        return float(val)
    try:
        return float(str(val))
    except Exception:
        return None


def _eval_sparql_expr(expr: str, binding: Dict[str, Any], prefixes: Dict[str, str]) -> Any:
    expr = expr.strip()
    while expr.startswith("(") and expr.endswith(")"):
        # Check if outer parens match
        depth = 0
        matched = True
        in_s = False
        sc = ""
        for idx, ch in enumerate(expr):
            if in_s:
                if ch == sc and expr[idx - 1] != "\\":
                    in_s = False
                continue
            if ch in ('"', "'"):
                in_s = True
                sc = ch
                continue
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
                if depth == 0 and idx < len(expr) - 1:
                    matched = False
                    break
        if matched:
            expr = expr[1:-1].strip()
        else:
            break

    # Logical OR (||)
    or_parts = _split_top_level(expr, "||")
    if len(or_parts) > 1:
        return any(bool(_eval_sparql_expr(p, binding, prefixes)) for p in or_parts)

    # Logical AND (&&)
    and_parts = _split_top_level(expr, "&&")
    if len(and_parts) > 1:
        return all(bool(_eval_sparql_expr(p, binding, prefixes)) for p in and_parts)

    # Unary NOT (!)
    if expr.startswith("!") and not expr.startswith("!="):
        return not bool(_eval_sparql_token_or_expr(expr[1:].strip(), binding, prefixes))

    # IN (...)
    m_in = re.match(r"^(.*?)\s+IN\s*\((.*)\)$", expr, re.IGNORECASE | re.DOTALL)
    if m_in:
        lhs = str(_eval_sparql_expr(m_in.group(1), binding, prefixes) or "")
        items = [_eval_sparql_expr(x, binding, prefixes) for x in _split_top_level(m_in.group(2), ",")]
        return lhs in [str(it) for it in items]

    # Comparison operators: !=, <=, >=, =, <, > (only at top level outside parens)
    for op in ("!=", "<=", ">=", "=", "<", ">"):
        parts = _split_top_level(expr, op)
        if len(parts) == 2:
            lhs = _eval_sparql_expr(parts[0], binding, prefixes)
            rhs = _eval_sparql_expr(parts[1], binding, prefixes)
            if lhs is None or rhs is None:
                return False
            n1 = _to_num(lhs)
            n2 = _to_num(rhs)
            lhs_is_str_fn = parts[0].strip().upper().startswith("STR(")
            rhs_is_str_fn = parts[1].strip().upper().startswith("STR(")
            if n1 is not None and n2 is not None and not lhs_is_str_fn and not rhs_is_str_fn:
                a, b = n1, n2
            else:
                a, b = str(lhs), str(rhs)
            if op == "=":
                return a == b
            if op == "!=":
                return a != b
            if op == "<":
                return a < b
            if op == ">":
                return a > b
            if op == "<=":
                return a <= b
            if op == ">=":
                return a >= b

    # IF(cond, then_expr, else_expr)
    m_if = re.match(r"^IF\s*\((.*)\)$", expr, re.IGNORECASE | re.DOTALL)
    if m_if:
        args = _split_top_level(m_if.group(1), ",")
        if len(args) == 3:
            cond = bool(_eval_sparql_expr(args[0], binding, prefixes))
            return _eval_sparql_expr(args[1] if cond else args[2], binding, prefixes)

    # CONTAINS(a, b)
    m_cont = re.match(r"^CONTAINS\s*\((.*)\)$", expr, re.IGNORECASE | re.DOTALL)
    if m_cont:
        args = _split_top_level(m_cont.group(1), ",")
        if len(args) == 2:
            v1 = str(_eval_sparql_expr(args[0], binding, prefixes) or "")
            v2 = str(_eval_sparql_expr(args[1], binding, prefixes) or "")
            return v2 in v1

    # STRSTARTS(a, b)
    m_starts = re.match(r"^STRSTARTS\s*\((.*)\)$", expr, re.IGNORECASE | re.DOTALL)
    if m_starts:
        args = _split_top_level(m_starts.group(1), ",")
        if len(args) == 2:
            v1 = str(_eval_sparql_expr(args[0], binding, prefixes) or "")
            v2 = str(_eval_sparql_expr(args[1], binding, prefixes) or "")
            return v1.startswith(v2)

    # LCASE(a) / UCASE(a) / STR(a)
    m_fn = re.match(r"^(LCASE|UCASE|STR)\s*\((.*)\)$", expr, re.IGNORECASE | re.DOTALL)
    if m_fn:
        fn_name = m_fn.group(1).upper()
        inner = str(_eval_sparql_expr(m_fn.group(2), binding, prefixes) or "")
        if fn_name == "LCASE":
            return inner.lower()
        if fn_name == "UCASE":
            return inner.upper()
        return inner

    # Base token
    if expr.startswith("?") or expr.startswith("$"):
        return binding.get(expr[1:])
    resolved = _resolve_sparql_token(expr, prefixes)
    if isinstance(resolved, Literal):
        return resolved.toPython()
    return resolved

def _eval_sparql_token_or_expr(expr: str, binding: Dict[str, Any], prefixes: Dict[str, str]) -> Any:
    return _eval_sparql_expr(expr, binding, prefixes)


class Graph:
    def __init__(self):
        self._triples: Set[Tuple[Identifier, Identifier, Identifier]] = set()
        self._spo: Dict[Identifier, List[Tuple[Identifier, Identifier]]] = {}
        self._pos: Dict[Identifier, List[Tuple[Identifier, Identifier]]] = {}
        self._osp: Dict[Identifier, List[Tuple[Identifier, Identifier]]] = {}
        self.namespaces_map: Dict[str, str] = {
            "rdf": str(RDF),
            "rdfs": str(RDFS),
            "owl": str(OWL),
            "xsd": str(XSD),
            "skos": str(SKOS),
            "dc": str(DC),
        }

    def bind(self, prefix: str, namespace: Any) -> None:
        self.namespaces_map[str(prefix)] = str(namespace)

    def add(self, triple: Tuple[Any, Any, Any]) -> None:
        s, p, o = triple
        s_id = s if isinstance(s, Identifier) else URIRef(str(s))
        p_id = p if isinstance(p, Identifier) else URIRef(str(p))
        o_id = o if isinstance(o, Identifier) else Literal(o)
        t = (s_id, p_id, o_id)
        if t not in self._triples:
            self._triples.add(t)
            self._spo.setdefault(s_id, []).append((p_id, o_id))
            self._pos.setdefault(p_id, []).append((o_id, s_id))
            self._osp.setdefault(o_id, []).append((s_id, p_id))

    def remove(self, triple: Tuple[Any, Any, Any]) -> None:
        s, p, o = triple
        if s is None and p is None and o is None:
            self._triples.clear()
            self._spo.clear()
            self._pos.clear()
            self._osp.clear()
            return
        if s is not None and p is not None and o is not None:
            s_id = s if isinstance(s, Identifier) else URIRef(str(s))
            p_id = p if isinstance(p, Identifier) else URIRef(str(p))
            o_id = o if isinstance(o, Identifier) else Literal(o)
            t = (s_id, p_id, o_id)
            if t in self._triples:
                self._triples.remove(t)
                if s_id in self._spo:
                    try:
                        self._spo[s_id].remove((p_id, o_id))
                    except ValueError:
                        pass
                if p_id in self._pos:
                    try:
                        self._pos[p_id].remove((o_id, s_id))
                    except ValueError:
                        pass
                if o_id in self._osp:
                    try:
                        self._osp[o_id].remove((s_id, p_id))
                    except ValueError:
                        pass
            return
        to_remove = [t for t in self._triples if (s is None or t[0] == s) and (p is None or t[1] == p) and (o is None or t[2] == o)]
        for t in to_remove:
            self._triples.remove(t)
        # Rebuild indices
        self._spo.clear()
        self._pos.clear()
        self._osp.clear()
        for ts, tp, to in self._triples:
            self._spo.setdefault(ts, []).append((tp, to))
            self._pos.setdefault(tp, []).append((to, ts))
            self._osp.setdefault(to, []).append((ts, tp))

    def __len__(self) -> int:
        return len(self._triples)

    def __iter__(self):
        return iter(self._triples)

    def __contains__(self, triple: Tuple[Any, Any, Any]) -> bool:
        s, p, o = triple
        if s is not None and p is not None and o is not None:
            return (s, p, o) in self._triples
        return any(True for _ in self.triples(triple))

    def triples(self, pattern: Tuple[Any, Any, Any]) -> Iterator[Tuple[Identifier, Identifier, Identifier]]:
        s, p, o = pattern
        if s is not None:
            s_id = s if isinstance(s, Identifier) else URIRef(str(s))
            for tp, to in self._spo.get(s_id, []):
                if (p is None or tp == p) and (o is None or to == o):
                    yield (s_id, tp, to)
            return
        if p is not None:
            p_id = p if isinstance(p, Identifier) else URIRef(str(p))
            for to, ts in self._pos.get(p_id, []):
                if o is None or to == o:
                    yield (ts, p_id, to)
            return
        if o is not None:
            o_id = o if isinstance(o, Identifier) else (Literal(o) if not str(o).startswith("http") else URIRef(str(o)))
            for ts, tp in self._osp.get(o_id, []):
                yield (ts, tp, o_id)
            return
        yield from self._triples

    def predicate_objects(self, subject: Any = None) -> Iterator[Tuple[Identifier, Identifier]]:
        for _, p, o in self.triples((subject, None, None)):
            yield (p, o)

    def subject_predicates(self, object: Any = None) -> Iterator[Tuple[Identifier, Identifier]]:
        for s, p, _ in self.triples((None, None, object)):
            yield (s, p)

    def subjects(self, predicate: Any = None, object: Any = None) -> Iterator[Identifier]:
        for s, _, _ in self.triples((None, predicate, object)):
            yield s

    def objects(self, subject: Any = None, predicate: Any = None) -> Iterator[Identifier]:
        for _, _, o in self.triples((subject, predicate, None)):
            yield o

    def parse(self, source: Optional[str] = None, data: Optional[str] = None, format: str = "turtle", **kwargs) -> "Graph":
        text = data
        if text is None and source is not None:
            text = Path(source).read_text(encoding="utf-8")
        if text:
            parsed = parse_turtle(text, self.namespaces_map)
            for t in parsed:
                self.add(t)
        return self

    def serialize(self, destination: Optional[str] = None, format: str = "turtle", **kwargs) -> str:
        lines = []
        for pfx, ns_uri in sorted(self.namespaces_map.items()):
            lines.append(f"@prefix {pfx}: <{ns_uri}> .")
        lines.append("")
        for s, p, o in sorted(self._triples, key=lambda x: (str(x[0]), str(x[1]), str(x[2]))):
            s_str = s.n3() if hasattr(s, "n3") else f"<{s}>"
            p_str = "a" if str(p) == str(RDF.type) else (p.n3() if hasattr(p, "n3") else f"<{p}>")
            o_str = o.n3() if hasattr(o, "n3") else f'"{o}"'
            lines.append(f"{s_str} {p_str} {o_str} .")
        out = "\n".join(lines) + "\n"
        if destination:
            Path(destination).parent.mkdir(parents=True, exist_ok=True)
            Path(destination).write_text(out, encoding="utf-8")
        return out

    # -----------------------------------------------------------------------
    # SPARQL 1.1 SELECT Query Evaluator
    # -----------------------------------------------------------------------
    def query(self, query_object: str) -> QueryResult:
        q = query_object.strip()
        prefixes = dict(self.namespaces_map)

        # 1. Extract PREFIX declarations
        for m in re.finditer(r"PREFIX\s+([a-zA-Z0-9_\-]*)\s*:\s*<([^>]+)>", q, re.IGNORECASE):
            prefixes[m.group(1)] = m.group(2)
        q_body = re.sub(r"PREFIX\s+[a-zA-Z0-9_\-]*\s*:\s*<[^>]+>", "", q, flags=re.IGNORECASE).strip()

        # 2. Extract SELECT clause, WHERE block, and trailing modifiers (GROUP BY, HAVING, ORDER BY, LIMIT)
        m_select = re.search(r"SELECT\s+(DISTINCT\s+)?(.*?)\s*WHERE\s*\{", q_body, re.IGNORECASE | re.DOTALL)
        if not m_select:
            raise ValueError(f"Invalid SPARQL SELECT query: {q[:120]}")
        is_distinct = bool(m_select.group(1))
        select_expr_str = m_select.group(2).strip()

        # Find matching closing brace for WHERE { ... }
        where_start = m_select.end() - 1
        depth = 0
        where_end = len(q_body) - 1
        in_s = False
        sc = ""
        for idx in range(where_start, len(q_body)):
            ch = q_body[idx]
            if in_s:
                if ch == sc and q_body[idx - 1] != "\\":
                    in_s = False
                continue
            if ch in ('"', "'"):
                in_s = True
                sc = ch
                continue
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    where_end = idx
                    break

        where_block = q_body[where_start + 1:where_end].strip()
        modifiers_str = q_body[where_end + 1:].strip()

        # Parse SELECT items: either ?var or (EXPR AS ?var)
        select_items = []
        i = 0
        while i < len(select_expr_str):
            while i < len(select_expr_str) and select_expr_str[i].isspace():
                i += 1
            if i >= len(select_expr_str):
                break
            if select_expr_str[i] == "(":
                d = 0
                start_p = i
                while i < len(select_expr_str):
                    if select_expr_str[i] == "(":
                        d += 1
                    elif select_expr_str[i] == ")":
                        d -= 1
                        if d == 0:
                            i += 1
                            break
                    i += 1
                chunk = select_expr_str[start_p + 1:i - 1].strip()
                m_as = re.match(r"^(.*?)\s+AS\s+\?([a-zA-Z0-9_]+)$", chunk, re.IGNORECASE | re.DOTALL)
                if m_as:
                    select_items.append(("EXPR", m_as.group(1).strip(), m_as.group(2).strip()))
            elif select_expr_str[i] in ("?", "$"):
                start_v = i + 1
                i += 1
                while i < len(select_expr_str) and (select_expr_str[i].isalnum() or select_expr_str[i] == "_"):
                    i += 1
                vname = select_expr_str[start_v:i]
                select_items.append(("VAR", vname, vname))
            elif select_expr_str[i] == "*":
                select_items.append(("STAR", "*", "*"))
                i += 1
            else:
                i += 1

        # Evaluate WHERE block into list of binding dicts
        bindings = self._eval_where_block(where_block, [{}], prefixes)

        # Parse modifiers: GROUP BY, HAVING, ORDER BY, LIMIT
        group_vars = []
        having_expr = None
        order_specs = []
        limit_val = None

        m_group = re.search(r"GROUP\s+BY\s+(.*?)(?=HAVING|ORDER\s+BY|LIMIT|$)", modifiers_str, re.IGNORECASE | re.DOTALL)
        if m_group:
            group_vars = [v[1:] for v in re.findall(r"\?[a-zA-Z0-9_]+", m_group.group(1))]

        m_having = re.search(r"HAVING\s*\((.*)\)(?=\s*ORDER\s+BY|\s*LIMIT|$)", modifiers_str, re.IGNORECASE | re.DOTALL)
        if m_having:
            having_expr = m_having.group(1).strip()

        m_order = re.search(r"ORDER\s+BY\s+(.*?)(?=LIMIT|$)", modifiers_str, re.IGNORECASE | re.DOTALL)
        if m_order:
            ord_str = m_order.group(1).strip()
            for m_o in re.finditer(r"(DESC|ASC)\s*\(\s*\?([a-zA-Z0-9_]+)\s*\)|\?([a-zA-Z0-9_]+)", ord_str, re.IGNORECASE):
                if m_o.group(1):
                    order_specs.append((m_o.group(2), m_o.group(1).upper() == "DESC"))
                else:
                    order_specs.append((m_o.group(3), False))

        m_limit = re.search(r"LIMIT\s+(\d+)", modifiers_str, re.IGNORECASE)
        if m_limit:
            limit_val = int(m_limit.group(1))

        # Apply GROUP BY & Aggregations if present
        has_agg = any(kind == "EXPR" for kind, _, _ in select_items) or bool(group_vars)
        if has_agg:
            groups: Dict[Tuple[Any, ...], List[Dict[str, Any]]] = {}
            for b in bindings:
                g_key = tuple(str(b.get(gv, "")) for gv in group_vars)
                groups.setdefault(g_key, []).append(b)
            agg_rows: List[Dict[str, Any]] = []
            for g_key, g_list in groups.items():
                row_b = dict(g_list[0]) if g_list else {}
                for kind, expr, alias in select_items:
                    if kind == "EXPR":
                        row_b[alias] = self._eval_aggregate(expr, g_list, prefixes)
                if having_expr:
                    if not self._eval_having(having_expr, g_list, row_b, prefixes):
                        continue
                agg_rows.append(row_b)
            bindings = agg_rows

        # Determine output variable list
        if select_items and select_items[0][0] == "STAR":
            all_v = []
            for b in bindings:
                for k in b.keys():
                    if k not in all_v:
                        all_v.append(k)
            vars_list = all_v
        else:
            vars_list = [alias for _, _, alias in select_items]

        # Project bindings to vars_list (Apply ORDER BY before projecting or using full binding)
        if order_specs:
            def _sort_key_for_spec(b: Dict[str, Any], var_name: str):
                val = b.get(var_name)
                num = _to_num(val)
                if num is not None:
                    return (0, num, "")
                return (1, 0.0, str(val or ""))

            for var_name, is_desc in reversed(order_specs):
                bindings.sort(key=lambda b, vn=var_name: _sort_key_for_spec(b, vn), reverse=is_desc)

        final_rows: List[ResultRow] = []
        seen_tuples = set()
        for b in bindings:
            proj = {v: b.get(v) for v in vars_list}
            if is_distinct:
                t_key = tuple(str(proj.get(v, "")) for v in vars_list)
                if t_key in seen_tuples:
                    continue
                seen_tuples.add(t_key)
            final_rows.append(ResultRow(vars_list, proj))
            if limit_val is not None and len(final_rows) >= limit_val:
                break

        return QueryResult(vars_list, final_rows)

    def _eval_aggregate(self, expr: str, group_list: List[Dict[str, Any]], prefixes: Dict[str, str]) -> Any:
        expr = expr.strip()
        m_cnt_dist = re.match(r"^COUNT\s*\(\s*DISTINCT\s+\?([a-zA-Z0-9_]+)\s*\)$", expr, re.IGNORECASE)
        if m_cnt_dist:
            v = m_cnt_dist.group(1)
            vals = {str(b[v]) for b in group_list if b.get(v) is not None and str(b.get(v)) != ""}
            return Literal(len(vals), datatype=str(XSD.integer))

        m_cnt = re.match(r"^COUNT\s*\(\s*\?([a-zA-Z0-9_]+)\s*\)$", expr, re.IGNORECASE)
        if m_cnt:
            v = m_cnt.group(1)
            vals = [b[v] for b in group_list if b.get(v) is not None and str(b.get(v)) != ""]
            return Literal(len(vals), datatype=str(XSD.integer))

        m_avg = re.match(r"^AVG\s*\(\s*\?([a-zA-Z0-9_]+)\s*\)$", expr, re.IGNORECASE)
        if m_avg:
            v = m_avg.group(1)
            nums = [_to_num(b.get(v)) for b in group_list if b.get(v) is not None]
            nums = [x for x in nums if x is not None]
            if not nums:
                return Literal(0.0, datatype=str(XSD.double))
            return Literal(sum(nums) / len(nums), datatype=str(XSD.double))

        m_max = re.match(r"^MAX\s*\(\s*\?([a-zA-Z0-9_]+)\s*\)$", expr, re.IGNORECASE)
        if m_max:
            v = m_max.group(1)
            vals = [str(b[v]) for b in group_list if b.get(v) is not None and str(b.get(v)) != ""]
            return Literal(max(vals) if vals else "", datatype=str(XSD.string))

        m_sum = re.match(r"^SUM\s*\((.*)\)$", expr, re.IGNORECASE | re.DOTALL)
        if m_sum:
            inner = m_sum.group(1).strip()
            total = 0.0
            for b in group_list:
                val = _eval_sparql_expr(inner, b, prefixes)
                n = _to_num(val)
                if n is not None:
                    total += n
            if total.is_integer():
                return Literal(int(total), datatype=str(XSD.integer))
            return Literal(total, datatype=str(XSD.double))

        return Literal("")

    def _eval_having(self, having_expr: str, group_list: List[Dict[str, Any]], row_b: Dict[str, Any], prefixes: Dict[str, str]) -> bool:
        # Substitute aggregate calls in having_expr with their evaluated values
        def _repl(m):
            agg_call = m.group(0)
            val = self._eval_aggregate(agg_call, group_list, prefixes)
            return str(val)
        replaced = re.sub(r"(COUNT|AVG|MAX|MIN|SUM)\s*\([^\)]+\)", _repl, having_expr, flags=re.IGNORECASE)
        return bool(_eval_sparql_expr(replaced, row_b, prefixes))

    def _eval_where_block(self, block: str, current_bindings: List[Dict[str, Any]], prefixes: Dict[str, str]) -> List[Dict[str, Any]]:
        # Parse top-level elements inside block: VALUES, OPTIONAL, UNION, FILTER, or triple statements
        elements = self._tokenize_where_elements(block)
        bindings = current_bindings

        i = 0
        while i < len(elements):
            el_type, payload = elements[i]
            if el_type == "VALUES":
                var_name, val_tokens = payload
                resolved_vals = [_resolve_sparql_token(vt, prefixes) for vt in val_tokens]
                new_b = []
                for b in bindings:
                    for rv in resolved_vals:
                        if var_name in b and str(b[var_name]) != str(rv):
                            continue
                        nb = dict(b)
                        nb[var_name] = rv
                        new_b.append(nb)
                bindings = new_b
            elif el_type == "UNION":
                left_block, right_block = payload
                b_left = self._eval_where_block(left_block, [dict(b) for b in bindings], prefixes)
                b_right = self._eval_where_block(right_block, [dict(b) for b in bindings], prefixes)
                bindings = b_left + b_right
            elif el_type == "OPTIONAL":
                opt_block = payload
                new_b = []
                for b in bindings:
                    ext = self._eval_where_block(opt_block, [dict(b)], prefixes)
                    if ext:
                        new_b.extend(ext)
                    else:
                        new_b.append(b)
                bindings = new_b
            elif el_type == "FILTER":
                f_expr = payload
                bindings = [b for b in bindings if bool(_eval_sparql_expr(f_expr, b, prefixes))]
            elif el_type == "TRIPLE":
                s_tok, p_tok, o_tok = payload
                bindings = self._match_triple_pattern(s_tok, p_tok, o_tok, bindings, prefixes)
            i += 1

        return bindings

    def _tokenize_where_elements(self, block: str) -> List[Tuple[str, Any]]:
        elements: List[Tuple[str, Any]] = []
        s = block.strip()
        i = 0
        n = len(s)

        def read_balanced(open_ch: str, close_ch: str) -> str:
            nonlocal i
            while i < n and s[i] != open_ch:
                i += 1
            if i >= n:
                return ""
            start = i + 1
            depth = 0
            in_str = False
            sc = ""
            while i < n:
                ch = s[i]
                if in_str:
                    if ch == sc and s[i - 1] != "\\":
                        in_str = False
                    i += 1
                    continue
                if ch in ('"', "'"):
                    in_str = True
                    sc = ch
                    i += 1
                    continue
                if ch == open_ch:
                    depth += 1
                elif ch == close_ch:
                    depth -= 1
                    if depth == 0:
                        res = s[start:i]
                        i += 1
                        return res
                i += 1
            return s[start:]

        triple_buf = []
        while i < n:
            # Skip whitespace
            while i < n and s[i].isspace():
                i += 1
            if i >= n:
                break

            rem = s[i:]
            m_val = re.match(r"^VALUES\s+\?([a-zA-Z0-9_]+)\s*", rem, re.IGNORECASE)
            if m_val:
                if triple_buf:
                    elements.extend(self._parse_bgp(" ".join(triple_buf)))
                    triple_buf = []
                vname = m_val.group(1)
                i += m_val.end()
                vals_inner = read_balanced("{", "}")
                val_toks = re.findall(r"<[^>]+>|\"[^\"]*\"|'[^']*'|\S+", vals_inner)
                elements.append(("VALUES", (vname, val_toks)))
                continue

            m_opt = re.match(r"^OPTIONAL\s*(?=\{)", rem, re.IGNORECASE)
            if m_opt:
                if triple_buf:
                    elements.extend(self._parse_bgp(" ".join(triple_buf)))
                    triple_buf = []
                i += m_opt.end()
                opt_inner = read_balanced("{", "}")
                elements.append(("OPTIONAL", opt_inner))
                continue

            m_filt = re.match(r"^FILTER\s*(?=\()", rem, re.IGNORECASE)
            if m_filt:
                if triple_buf:
                    elements.extend(self._parse_bgp(" ".join(triple_buf)))
                    triple_buf = []
                i += m_filt.end()
                filt_inner = read_balanced("(", ")")
                elements.append(("FILTER", filt_inner))
                # Skip optional trailing dot after FILTER(...)
                while i < n and s[i].isspace():
                    i += 1
                if i < n and s[i] == ".":
                    i += 1
                continue

            if s[i] == "{":
                if triple_buf:
                    elements.extend(self._parse_bgp(" ".join(triple_buf)))
                    triple_buf = []
                first_block = read_balanced("{", "}")
                while i < n and s[i].isspace():
                    i += 1
                m_un = re.match(r"^UNION\s*(?=\{)", s[i:], re.IGNORECASE)
                if m_un:
                    i += m_un.end()
                    second_block = read_balanced("{", "}")
                    # Handle chained UNIONs
                    while True:
                        while i < n and s[i].isspace():
                            i += 1
                        m_un2 = re.match(r"^UNION\s*(?=\{)", s[i:], re.IGNORECASE)
                        if m_un2:
                            i += m_un2.end()
                            next_b = read_balanced("{", "}")
                            second_block = f"{{ {second_block} }} UNION {{ {next_b} }}"
                        else:
                            break
                    elements.append(("UNION", (first_block, second_block)))
                else:
                    elements.extend(self._tokenize_where_elements(first_block))
                continue

            # Read next token into triple_buf
            if s[i] == "<":
                end_u = s.find(">", i)
                if end_u != -1:
                    triple_buf.append(s[i:end_u + 1])
                    i = end_u + 1
                    continue
            if s[i] in ('"', "'"):
                sc = s[i]
                start_q = i
                i += 1
                while i < n:
                    if s[i] == "\\":
                        i += 2
                        continue
                    if s[i] == sc:
                        i += 1
                        break
                    i += 1
                triple_buf.append(s[start_q:i])
                continue

            # Regular character chunk until whitespace or special block
            start_c = i
            while i < n and not s[i].isspace() and s[i] not in ("{", "}", "<", '"', "'"):
                i += 1
            tok = s[start_c:i]
            triple_buf.append(tok)

        if triple_buf:
            elements.extend(self._parse_bgp(" ".join(triple_buf)))
        return elements

    def _parse_bgp(self, bgp_str: str) -> List[Tuple[str, Any]]:
        out: List[Tuple[str, Any]] = []
        for stmt in _split_top_level(bgp_str, "."):
            semi_parts = _split_top_level(stmt, ";")
            if not semi_parts:
                continue
            first_tokens = self._split_bgp_tokens(semi_parts[0])
            if len(first_tokens) < 3:
                continue
            subj = first_tokens[0]
            pred = first_tokens[1]
            obj_str = " ".join(first_tokens[2:])
            for obj_tok in _split_top_level(obj_str, ","):
                out.append(("TRIPLE", (subj, pred, obj_tok.strip())))
            for sp in semi_parts[1:]:
                sp_tokens = self._split_bgp_tokens(sp)
                if len(sp_tokens) >= 2:
                    p2 = sp_tokens[0]
                    o2_str = " ".join(sp_tokens[1:])
                    for obj_tok in _split_top_level(o2_str, ","):
                        out.append(("TRIPLE", (subj, p2, obj_tok.strip())))
        return out

    def _split_bgp_tokens(self, text: str) -> List[str]:
        return re.findall(r"<[^>]+>|\"[^\"]*\"|'[^']*'|\S+", text.strip())

    def _match_triple_pattern(self, s_tok: str, p_tok: str, o_tok: str, bindings: List[Dict[str, Any]], prefixes: Dict[str, str]) -> List[Dict[str, Any]]:
        s_res = _resolve_sparql_token(s_tok, prefixes)
        p_res = _resolve_sparql_token(p_tok, prefixes)
        o_res = _resolve_sparql_token(o_tok, prefixes)

        out_bindings: List[Dict[str, Any]] = []
        for b in bindings:
            s_val = b.get(s_res[1]) if (isinstance(s_res, tuple) and s_res[0] == "VAR") else s_res
            p_val = b.get(p_res[1]) if (isinstance(p_res, tuple) and p_res[0] == "VAR") else p_res
            o_val = b.get(o_res[1]) if (isinstance(o_res, tuple) and o_res[0] == "VAR") else o_res

            for ts, tp, to in self.triples((s_val, p_val, o_val)):
                nb = dict(b)
                ok = True
                if isinstance(s_res, tuple) and s_res[0] == "VAR":
                    vn = s_res[1]
                    if vn in nb and str(nb[vn]) != str(ts):
                        ok = False
                    nb[vn] = ts
                if ok and isinstance(p_res, tuple) and p_res[0] == "VAR":
                    vn = p_res[1]
                    if vn in nb and str(nb[vn]) != str(tp):
                        ok = False
                    nb[vn] = tp
                if ok and isinstance(o_res, tuple) and o_res[0] == "VAR":
                    vn = o_res[1]
                    if vn in nb and str(nb[vn]) != str(to):
                        ok = False
                    nb[vn] = to
                if ok:
                    out_bindings.append(nb)
        return out_bindings
