from __future__ import annotations
from . import Namespace, RDF, RDFS, OWL, XSD, SKOS, DC
__all__ = ["Namespace", "RDF", "RDFS", "OWL", "XSD", "SKOS", "DC"]
