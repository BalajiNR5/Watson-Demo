from __future__ import annotations
from typing import Any, Dict, List
from .pipeline import EntityRuler, Doc, Span

class Language:
    def __init__(self, name: str = "en"):
        self.name = name
        self._rulers: List[EntityRuler] = []

    def add_pipe(self, factory_name: str, config: Dict[str, Any] | None = None) -> Any:
        if factory_name == "entity_ruler":
            ruler = EntityRuler(self, config=config)
            self._rulers.append(ruler)
            return ruler
        return None

    def __call__(self, text: str) -> Doc:
        ents: List[Span] = []
        for ruler in self._rulers:
            ents.extend(ruler.match(text))
        return Doc(text, ents)

def load(name: str, disable: List[str] | None = None) -> Language:
    return Language(name)

def blank(name: str) -> Language:
    return Language(name)
