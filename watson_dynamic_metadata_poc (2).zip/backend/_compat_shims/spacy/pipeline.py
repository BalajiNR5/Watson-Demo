from __future__ import annotations
import re
from typing import Any, Dict, List

class Span:
    def __init__(self, text: str, label: str, start_char: int, end_char: int, ent_id: str = ""):
        self.text = text
        self.label_ = label
        self.start_char = start_char
        self.end_char = end_char
        self.ent_id_ = ent_id

class Doc:
    def __init__(self, text: str, ents: List[Span]):
        self.text = text
        self.ents = ents

class EntityRuler:
    def __init__(self, nlp=None, config: Dict[str, Any] | None = None):
        self.config = config or {}
        self.patterns: List[Dict[str, Any]] = []
        self._compiled: List[tuple] = []

    def add_patterns(self, patterns: List[Dict[str, Any]]) -> None:
        for pat in patterns:
            self.patterns.append(pat)
            phrase = pat.get("pattern", "")
            if isinstance(phrase, str) and phrase.strip():
                regex = re.compile(rf"(?<!\w){re.escape(phrase.strip())}(?!\w)", re.IGNORECASE)
                self._compiled.append((regex, pat.get("label", ""), pat.get("id", "")))

    def match(self, text: str) -> List[Span]:
        matches: List[Span] = []
        occupied = set()
        # Sort longer patterns first
        sorted_comp = sorted(self._compiled, key=lambda x: len(x[0].pattern), reverse=True)
        for regex, label, ent_id in sorted_comp:
            for m in regex.finditer(text):
                s, e = m.start(), m.end()
                if any( pos in occupied for pos in range(s, e) ):
                    continue
                for pos in range(s, e):
                    occupied.add(pos)
                matches.append(Span(m.group(0), label, s, e, ent_id))
        matches.sort(key=lambda sp: sp.start_char)
        return matches
