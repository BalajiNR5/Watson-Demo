from __future__ import annotations
from contextlib import contextmanager
import numpy as np

class Tensor:
    def __init__(self, arr):
        self._arr = np.asarray(arr, dtype=np.float32)

    @property
    def shape(self):
        return self._arr.shape

    def size(self, dim=None):
        return self._arr.shape if dim is None else self._arr.shape[dim]

    def unsqueeze(self, dim: int):
        return Tensor(np.expand_dims(self._arr, axis=dim))

    def expand(self, shape):
        return Tensor(np.broadcast_to(self._arr, shape))

    def float(self):
        return Tensor(self._arr.astype(np.float32))

    def sum(self, dim=None):
        return Tensor(np.sum(self._arr, axis=dim))

    def clamp(self, min: float = 1e-9, max: float | None = None):
        arr = np.maximum(self._arr, min)
        if max is not None:
            arr = np.minimum(arr, max)
        return Tensor(arr)

    def cpu(self):
        return self

    def numpy(self):
        return self._arr

    def __mul__(self, other):
        o = other._arr if isinstance(other, Tensor) else other
        return Tensor(self._arr * o)

    def __truediv__(self, other):
        o = other._arr if isinstance(other, Tensor) else other
        return Tensor(self._arr / o)

@contextmanager
def no_grad():
    yield

def sum(tensor: Tensor, dim: int):
    return Tensor(np.sum(tensor._arr, axis=dim))

def clamp(tensor: Tensor, min: float = 1e-9):
    return Tensor(np.maximum(tensor._arr, min))

def norm(tensor: Tensor, p: int = 2, dim: int = 1, keepdim: bool = True):
    return Tensor(np.linalg.norm(tensor._arr, ord=p, axis=dim, keepdims=keepdim))
