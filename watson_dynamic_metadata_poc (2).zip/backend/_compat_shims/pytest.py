from __future__ import annotations
import importlib.util
import inspect
import shutil
import sys
import tempfile
import traceback
import unittest
from pathlib import Path
from typing import Any, Callable

def fixture(func: Callable | None = None, *, autouse: bool = False, scope: str = "function"):
    def decorator(f: Callable):
        f._is_pytest_fixture = True
        f._autouse = autouse
        f._scope = scope
        return f
    if func is not None:
        return decorator(func)
    return decorator

class _Mark:
    @staticmethod
    def parametrize(argnames: str, argvalues: list):
        def decorator(f: Callable):
            params = getattr(f, "_parametrize", [])
            params.append((argnames, list(argvalues)))
            f._parametrize = params
            return f
        return decorator

mark = _Mark()

class _RaisesContext:
    def __init__(self, expected_exc, match: str | None = None):
        self.expected_exc = expected_exc
        self.match = match
        self.value = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type is None:
            raise AssertionError(f"DID NOT RAISE {self.expected_exc}")
        if issubclass(exc_type, self.expected_exc):
            if self.match and self.match not in str(exc_val):
                raise AssertionError(f'Regex {self.match!r} did not match {str(exc_val)!r}')
            self.value = exc_val
            return True
        return False

def raises(expected_exception, match: str | None = None):
    return _RaisesContext(expected_exception, match=match)

class MonkeyPatch:
    def __init__(self):
        self._undo = []

    def setattr(self, target, name, value=None, raising=True):
        if isinstance(target, str):
            mod_path, attr = target.rsplit(".", 1)
            mod = importlib.import_module(mod_path)
            old = getattr(mod, attr, None)
            setattr(mod, attr, name)
            self._undo.append((mod, attr, old))
        else:
            old = getattr(target, name, None)
            setattr(target, name, value)
            self._undo.append((target, name, old))

    def setenv(self, name: str, value: str):
        import os
        old = os.environ.get(name)
        os.environ[name] = str(value)
        self._undo.append(("ENV", name, old))

    def delenv(self, name: str, raising: bool = True):
        import os
        old = os.environ.pop(name, None)
        self._undo.append(("ENV", name, old))

    def undo(self):
        import os
        for item in reversed(self._undo):
            if item[0] == "ENV":
                _, k, old = item
                if old is None:
                    os.environ.pop(k, None)
                else:
                    os.environ[k] = old
            else:
                obj, attr, old = item
                setattr(obj, attr, old)
        self._undo.clear()

def main(args=None) -> int:
    argv = args if args is not None else sys.argv[1:]
    files = [a for a in argv if not a.startswith("-")]
    if not files:
        files = ["tests"]
    test_paths = []
    for f in files:
        p = Path(f)
        if p.is_dir():
            test_paths.extend(sorted(p.glob("test_*.py")))
        elif p.is_file():
            test_paths.append(p)

    passed = 0
    failed = 0
    for tp in test_paths:
        spec = importlib.util.spec_from_file_location(tp.stem, str(tp))
        mod = importlib.util.module_from_spec(spec)
        sys.modules[tp.stem] = mod
        spec.loader.exec_module(mod)

        fixtures = {}
        autouse_fixtures = []
        for name, obj in inspect.getmembers(mod):
            if getattr(obj, "_is_pytest_fixture", False):
                fixtures[name] = obj
                if getattr(obj, "_autouse", False):
                    autouse_fixtures.append(obj)

        for name, obj in inspect.getmembers(mod, inspect.isclass):
            if issubclass(obj, unittest.TestCase) and obj is not unittest.TestCase:
                suite = unittest.defaultTestLoader.loadTestsFromTestCase(obj)
                res = unittest.TextTestRunner(verbosity=0).run(suite)
                passed += res.testsRun - len(res.failures) - len(res.errors)
                failed += len(res.failures) + len(res.errors)
                for tc, tb in res.failures + res.errors:
                    print(f"FAIL: {tp.name}::{tc}:\n{tb}")

        for name, obj in inspect.getmembers(mod, inspect.isfunction):
            if name.startswith("test_"):
                param_specs = getattr(obj, "_parametrize", [])
                if param_specs:
                    argnames_str, argvalues = param_specs[0]
                    argnames = [a.strip() for a in argnames_str.split(",")]
                    call_sets = []
                    for val in argvalues:
                        if len(argnames) == 1:
                            call_sets.append({argnames[0]: val})
                        else:
                            call_sets.append(dict(zip(argnames, val)))
                else:
                    call_sets = [{}]

                for p_kwargs in call_sets:
                    gens = []
                    mp = MonkeyPatch()
                    tmp_dir = Path(tempfile.mkdtemp(prefix="pytest-tmp-"))
                    try:
                        for af in autouse_fixtures:
                            r = af()
                            if inspect.isgenerator(r):
                                next(r)
                                gens.append(r)
                        sig = inspect.signature(obj)
                        kwargs = dict(p_kwargs)
                        for pname in sig.parameters:
                            if pname in kwargs:
                                continue
                            if pname == "tmp_path":
                                kwargs[pname] = tmp_dir
                            elif pname == "monkeypatch":
                                kwargs[pname] = mp
                            elif pname in fixtures:
                                r = fixtures[pname]()
                                if inspect.isgenerator(r):
                                    kwargs[pname] = next(r)
                                    gens.append(r)
                                else:
                                    kwargs[pname] = r
                        obj(**kwargs)
                        passed += 1
                    except Exception as exc:
                        failed += 1
                        print(f"FAIL: {tp.name}::{name}({p_kwargs}): {exc}")
                        traceback.print_exc()
                    finally:
                        mp.undo()
                        for g in reversed(gens):
                            try:
                                next(g)
                            except StopIteration:
                                pass
                            except Exception:
                                pass
                        shutil.rmtree(tmp_dir, ignore_errors=True)

    print(f"\nSummary: {passed} passed, {failed} failed")
    return 0 if failed == 0 else 1

if __name__ == "__main__":
    raise SystemExit(main())
