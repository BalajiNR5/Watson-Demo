"""Offline application settings. Does not change Windows settings or policy."""
from __future__ import annotations

import os
from pathlib import Path
from urllib.parse import urlsplit


def configure(root: Path):
    os.environ["HF_HUB_OFFLINE"] = "1"
    os.environ["TRANSFORMERS_OFFLINE"] = "1"
    os.environ["HF_HUB_DISABLE_TELEMETRY"] = "1"
    os.environ["DO_NOT_TRACK"] = "1"
    os.environ["WATSON_ALLOW_CLOUD"] = "0"
    os.environ["WATSON_BASE_DIR"] = str(root)
    os.environ.setdefault("WATSON_QWEN_MODEL", "qwen3:latest")
    os.environ.setdefault("WATSON_OLLAMA_URL", "http://127.0.0.1:11434")
    address = urlsplit(os.environ["WATSON_OLLAMA_URL"])
    if address.scheme not in ("http", "https") or address.hostname not in (
        "127.0.0.1", "localhost", "::1"
    ) or address.username or address.password:
        raise ValueError("The office package requires a local Ollama URL (localhost only).")
    supplied_model = root / "approved_models" / "all-MiniLM-L6-v2"
    if supplied_model.is_dir():
        os.environ["WATSON_EMBEDDING_MODEL"] = str(supplied_model)


def disable_tokenizer_downloads():
    """Allow a valid existing tiktoken cache, never fetch missing BPE files."""
    try:
        import tiktoken.load
    except ImportError:
        return
    previous = tiktoken.load.read_file
    if getattr(previous, "_watson_offline", False):
        return

    def local_read_file(blobpath):
        if urlsplit(str(blobpath)).scheme in ("http", "https", "gs", "s3"):
            raise RuntimeError("Tokenizer download disabled in Watson Office mode")
        return previous(blobpath)

    local_read_file._watson_offline = True
    tiktoken.load.read_file = local_read_file
