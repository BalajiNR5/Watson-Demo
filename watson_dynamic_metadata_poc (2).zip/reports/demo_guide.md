# Watson Intelligence Platform — End-to-End Reproducible Demo Guide

This guide walks through a complete, reproducible demonstration of the **Watson Dynamic Metadata & Administrator-Only Ingestion POC** across all 13 verification checkpoints.

---

## Step 1: Environment Setup & Starting the Application

1. Extract `watson_dynamic_metadata_poc.zip` and change into the project root:
   ```bash
   unzip watson_dynamic_metadata_poc.zip -d watson_poc
   cd watson_poc
   ```
2. (Optional) Copy `.env.example` to `.env` to customize `WATSON_SESSION_SECRET`, `WATSON_ADMIN_PASSWORD_HASH`, or `WATSON_STRICT_TOKEN_ONLY`:
   ```bash
   cp .env.example .env
   ```
3. Start the FastAPI backend and React production UI on `http://127.0.0.1:8000`:
   ```bash
   PYTHONPATH=.:backend:backend/_compat_shims python3 -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8000
   ```
4. Open `http://127.0.0.1:8000/` in your browser (or verify health via CLI):
   ```bash
   curl -s http://127.0.0.1:8000/api/health | python3 -m json.tool
   ```

---

## Step 2: Non-Admin User Blocked from the Ingestion Console

1. In the top-right **Persona** switcher, select **`Dr. Sarah Chen (Viewer) (VIEWER)`** (`D3`) or **`Marcus Vance (Analyst) (ANALYST)`** (`U_ANALYST`).
2. Observe that:
   - The topbar badge changes to **`🔒 Read/Query Only`**.
   - The **`📥 Ingestion Console`** navigation button is removed from the left sidebar.
   - If you were previously on the Ingestion Console tab when switching to a non-admin persona, the main pane immediately renders **`🔒 Access Denied — Administrator Privileges Required (HTTP 403)`** with zero file-upload controls rendered (see `reports/screenshots/08_ingestion_console_non_admin_denied.png`).
3. Verify via CLI that direct backend access to the console route is rejected with `HTTP 403 Forbidden`:
   ```bash
   curl -i http://127.0.0.1:8000/api/ingestion/console -H "x-user-id: D3"
   ```

---

## Step 3: Non-Admin Upload Blocked at the API Level

1. Attempt to bypass the UI by sending a direct `POST /api/ingestion/upload` request as non-admin user `D3` (even while spoofing `X-User-Role: ADMIN` and `X-Permissions: documents:ingest`):
   ```bash
   curl -i -X POST http://127.0.0.1:8000/api/ingestion/upload \
     -H "x-user-id: D3" \
     -H "X-User-Role: ADMIN" \
     -H "X-Permissions: documents:ingest" \
     -F "file=@data/raw/HCP_Perception_Oncology_NSCLC_Keytruda_US.docx"
   ```
2. Observe that the server rejects the request with **`HTTP/1.1 403 Forbidden`** and records an `INGESTION_ACCESS_DENIED` event in `data/stores/audit_log.jsonl`.
3. Also verify that unauthenticated requests (no header or token) return **`HTTP/1.1 401 Unauthorized`**:
   ```bash
   curl -i -X POST http://127.0.0.1:8000/api/ingestion/upload \
     -F "file=@data/raw/HCP_Perception_Oncology_NSCLC_Keytruda_US.docx"
   ```

---

## Step 4: Administrator Authentication & Ingestion Console Access

1. In the top-right **Persona** switcher, select **`Elena Rostova (Admin) (ADMIN)`** (`D4`).
2. Observe that the topbar badge displays **`🔓 documents:ingest`** and **`📥 Ingestion Console`** appears in the left sidebar.
3. Click **`📥 Ingestion Console`** to open the administrator console (see `reports/screenshots/07_ingestion_console_admin_allowed.png`).
4. Or authenticate via the login API to obtain a signed HMAC-SHA256 Bearer token and CSRF token:
   ```bash
   curl -s -X POST http://127.0.0.1:8000/api/auth/login \
     -H "Content-Type: application/json" \
     -d '{"user_id": "D4"}' | python3 -m json.tool
   ```

---

## Step 5: Administrator Document Upload

1. Inside the **Ingestion Console** (`D4` Admin), under **📄 Upload New Clinical or Commercial Study Document**, select a `.pdf`, `.docx`, `.pptx`, or `.txt` study document and click **`Stage Document for HITL Review`**.
2. Or run a governed upload via CLI:
   ```bash
   printf "HCP Perception Survey\nTherapeutic Area: Oncology\nKeytruda pembrolizumab treats NSCLC in US clinical practice.\n" > /tmp/demo_study.txt
   curl -s -X POST http://127.0.0.1:8000/api/ingestion/upload \
     -H "x-user-id: D4" \
     -F "file=@/tmp/demo_study.txt" | python3 -m json.tool
   ```
3. Observe that the document passes Layer 1 validation, path sanitization, SHA-256 deduplication, and PII scanning, and transitions to `UNDER_REVIEW` in the **⚖️ HITL Workbench**.

---

## Step 6: Running Databricks Pharmaceuticals Product MVM Ingestion

1. In the **Ingestion Console** (`D4` Admin), under **🧬 Databricks Pharmaceuticals Product MVM Schema Ingestion**, click **`▶ Run Authoritative v1 MVM Ingestion`**.
2. Or execute the ingestion module from the CLI:
   ```bash
   PYTHONPATH=.:backend:backend/_compat_shims python3 -c "
   from watson.ingestion.databricks_metadata_ingestor import DatabricksProductMetadataIngestor
   summary = DatabricksProductMetadataIngestor().ingest(actor_id='D4')
   print('Status:', summary['status'], 'Counts:', summary['counts'])
   "
   ```
3. Verify the generated artifacts:
   - `outputs/databricks_pharma_product_catalog.json`
   - `outputs/ingestion_summary.json`
   - `reports/ingestion_report.md`
   - Extracted counts: **2 subdomains** (`market authorization` with 7 tables, `product identity` with 8 tables), **15 Product tables**, **594 attributes**, **15 primary keys**, and **83 foreign keys** (`37` intra-domain, `46` cross-domain).

---

## Step 7: Running Semantic Compatibility & Layer 2/3 Integration

1. Generate the compatibility matrix and sync the Layer 2 RDF overlay (`ontology/databricks_product_mvm_overlay.ttl`):
   ```bash
   PYTHONPATH=.:backend:backend/_compat_shims python3 -c "
   from watson.semantics.metadata_compatibility import SemanticCompatibilityEngine
   eng = SemanticCompatibilityEngine()
   rep = eng.generate_mappings(actor_id='D4')
   sync = eng.sync_layer2_graph_overlay()
   print('Mapping counts:', rep['summary_counts'])
   print('Layer 2 overlay sync:', sync)
   "
   ```
2. Verify that `data/seed/seed_vocabularies.json` is 100% untouched (`preserved: true`, SHA-256 `0f21702f3da1adb1d0c22cca3ba85a650303aed02938b5b924aed254b5fceac7`) and inspect `outputs/semantic_mapping_report.json` and `reports/compatibility_report.md`.

---

## Step 8: Opening the Interactive Visual Graph Explorer (Views C, A, B, Data Catalog & Mappings)

1. Click **`🕸️ KG Explorer`** in the left sidebar.
2. **View C: Integrated Mapping View (Default)** opens automatically (see `reports/screenshots/01_kg_explorer_view_c_integrated.png`), showing:
   - Databricks Product MVM tables on the left (`market authorization` and `product identity`),
   - Watson OWL classes in the center (`TherapeuticArea`, `Brand`, `Drug`, `Indication`, etc.),
   - Watson curated entities on the right (`Keytruda`, `Pembrolizumab`, `NSCLC`, `Oncology`, etc.),
   - Cross-model `MAPPED_TO` edges colored by status (`EXACT` green solid, `PROPOSED` amber dashed, `CONFLICT` red dashed).
3. Click **`View A: Databricks Product Model`** to inspect the 15 Databricks Product tables and their `FOREIGN_KEY_TO` / `CONTAINS_ATTRIBUTE` relationships (`reports/screenshots/02_kg_explorer_view_a_databricks.png`).
4. Click **`View B: Watson Semantic Model`** to inspect Watson's OWL classes and curated entities (`reports/screenshots/03_kg_explorer_view_b_watson.png`).
5. Click **`📘 Interactive Node Data Catalog (15 Products / 594 Cols)`** to browse every table, primary key, foreign key badge, and all 594 column definitions (`reports/screenshots/04_kg_explorer_data_catalog.png`).
6. Click **`🔗 Entity Mapping & Compatibility Explorer (19 Records)`** to inspect all 19 product/concept mappings (`reports/screenshots/05_kg_explorer_entity_mappings.png`).

---

## Step 9: Filtering & Searching the Graph

1. In **`🕸️ Visual Graph Canvas`** mode:
   - Type `ndc` or `indication` or `Keytruda` into the search box (`Search products, attributes...`) to filter nodes in real time.
   - Use the **All Node Types**, **All Subdomains / Families**, **All Relationships**, and **All Mapping Statuses** dropdowns to isolate specific subsets (e.g., `MAPPED_TO` relationships or `CONFLICT` nodes).
   - Check **`Isolate 1-Hop Neighbourhood of Selected Node`** to isolate the selected node and its immediate 1-hop neighbours.
   - Check **`Show Key Attribute Nodes on Canvas (PK/FK)`** to render primary-key and foreign-key attribute nodes around their parent tables.

---

## Step 10: Selecting Nodes & Inspecting Provenance and Mappings

1. Click the **`medicinal_product`** node (or **`indication`** / **`therapeutic_area`** / **`drug_substance`**) on the canvas.
2. In the right-hand **Node Details Side Panel**, inspect:
   - Node type badge (`DATABRICKS_PRODUCT`) and Mapping Status badge (`CONFLICT` for `medicinal_product`, `EXACT` for `indication`, `therapeutic_area`, and `drug_substance`),
   - Source Model & Version (`Databricks Pharmaceuticals Product MVM (v1)`) and Subdomain (`product identity` / `market authorization`),
   - **Semantic Compatibility Status & Rationale** box explaining why `medicinal_product` maps at the schema level to `watson:Brand` / `watson:Drug` with a granularity conflict and is never equated to a specific brand instance like `Keytruda`,
   - **Connected Relationships** list (click any edge to jump to the connected node),
   - **Product Schema Attributes** table (with live column filter),
   - **Provenance** footer with authoritative URL.

---

## Step 11: Triggering a Graph Refresh & Observing the Live Diff

1. At the top-right of the **KG Explorer** banner, click **`⚡ Simulate v1.1 Schema Update`**.
2. Observe the green **Live Refresh Diff (`v1.1-fixture`)** banner appear immediately (see `reports/screenshots/06_kg_explorer_v1_1_live_diff.png`):
   - `Added Products: 0 | Changed Products: 1 (indication: +[real_world_evidence_score]) | Removed Products: 0 | Unchanged: 14 | Last-Known-Good Fallback: STANDBY (HEALTHY)`
   - Total schema attributes counter updates from `594` to `595`.
3. Click **`⟳ Refresh Graph (v1 MVM)`** to restore the authoritative `v1` baseline (`594` columns).

---

## Step 12: Running SPARQL Studio Queries

1. Click **`🔍 SPARQL Studio`** in the left sidebar.
2. Observe the updated triple badge **`🌐 14,169 Triples (Base + MVM Overlay)`** (`10,349` base Watson triples + `3,820` Databricks MVM overlay triples).
3. Select template **`Q01`** (*Clinical Biomarker Target Discovery*), **`Q10`** (*Cross-Layer Access & Governance Audit*), or **`EXP_DBX_MAPPINGS`** (*Databricks Product MVM Schema & Watson Mappings*) and click **`▶ Execute Query`**.
4. Observe the sub-50ms execution latency and tabular results.

---

## Step 13: Running Research Copilot Queries with Citations

1. Click **`💬 Research Copilot`** in the left sidebar.
2. Click the quick-prompt **`Keytruda in NSCLC`** (or ask `"What is the clinical evidence for Keytruda in NSCLC?"`) and click **`Send`**.
3. Observe:
   - Grounded clinical & market access synthesis with clickable inline citations (`[Doc_007:chunk:b:0000]`, `[Doc_009:chunk:b:0000]`),
   - Status badges: **`HYBRID ROUTE`**, **`RELEVANT`**, **`GROUNDED`**,
   - Coordinated right-hand inspector tabs: **⚡ Pipeline Trace (15 Stages)**, **🕸️ Semantic KG Evidence**, **🔍 Source & Lineage**, **🎯 Quality Diagnostics**, and **💡 Why This Answer?**.
