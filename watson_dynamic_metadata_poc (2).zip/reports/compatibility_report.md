# Watson Semantic Vocabulary & Databricks Product MVM Compatibility Report

## 1. Executive Summary & Separation of Concerns

This report documents the compatibility analysis and explicit semantic mappings between **Watson's curated Layer 2 vocabulary & OWL ontology** (`data/seed/seed_vocabularies.json`, `ontology/pharma.ttl`) and the dynamically ingested **Databricks Pharmaceuticals Product MVM schema** (`outputs/databricks_pharma_product_catalog.json`).

### Strict Architectural Separation Enforced
1. **Watson Curated Vocabulary (`data/seed/seed_vocabularies.json`):** Preserved byte-for-byte (`SHA-256: 0f21702f3da1adb1d0c22cca3ba85a650303aed02938b5b924aed254b5fceac7`, 52 canonical concepts). Never overwritten or regenerated from the Databricks schema.
2. **Imported Databricks Product Catalog (`outputs/databricks_pharma_product_catalog.json`):** Stored as an independent schema metadata catalog (15 tables, 594 attributes, 83 foreign keys).
3. **Explicit Mapping & Compatibility Records (`outputs/semantic_mapping_report.json`):** Records explicit mapping status (`EXACT`, `PROPOSED`, `CONFLICT`, `UNRESOLVED`), rationale, provenance, and instance-vs-schema guardrails.
4. **Layer 2 Semantic Graph (`ontology/databricks_product_mvm_overlay.ttl`):** Schema nodes (`dbx:DataProduct`, `dbx:DataAttribute`) and mapping assertions (`dbxmap:SemanticMapping`) are isolated in dedicated namespaces (`dbx:` / `dbxmap:`) so curated business predicates (`watson:treatsIndication`, `watson:isBrandOf`, `watson:competesWith`) remain uncontaminated.
5. **Layer 3 Retrieval & FAISS Indexes (`data/indexes/Watson.faiss`):** Schema metadata ingestion does not alter document chunks or trigger unnecessary FAISS re-embedding.

## 2. Seed Vocabulary Preservation Audit

| Vocabulary Family | Curated Concept Count | Canonical ID Prefix | Preservation Status |
| :--- | ---: | :--- | :--- |
| `therapeutic_areas` | 7 | `ta:*` | **PRESERVED (UNCHANGED)** |
| `brands` | 10 | `brand:*` | **PRESERVED (UNCHANGED)** |
| `drugs` | 10 | `drug:*` | **PRESERVED (UNCHANGED)** |
| `indications` | 10 | `indication:*` | **PRESERVED (UNCHANGED)** |
| `geographies` | 9 | `geo:*` | **PRESERVED (UNCHANGED)** |
| `study_templates` | 6 | `study:*` | **PRESERVED (UNCHANGED)** |
| **Total Curated Concepts** | **52** | — | **100% INTACT** |

## 3. Mapping Status Distribution

| Mapping Status | Databricks Product Tables (15) | Total Mapping Records (19) | Semantics |
| :--- | ---: | ---: | :--- |
| **`EXACT`** | 3 | 3 | Verified class/schema-level alignment with explicit attribute correspondences |
| **`PROPOSED`** | 4 | 4 | Candidate mapping requiring architect/HITL governance review |
| **`CONFLICT`** | 2 | 3 | Granularity, cardinality, or homonym conflict requiring projection rules |
| **`UNRESOLVED`** | 6 | 9 | No justified counterpart in target model; kept visible as unmapped |

## 4. Product-Level Compatibility Matrix

| Databricks Product (`product.*`) | Subdomain | Status | Target Watson Concept | Aligned Instances | Rationale & Conflict Notes |
| :--- | :--- | :--- | :--- | ---: | :--- |
| `product.combination_product` | `product identity` | **PROPOSED** | `watson:Drug` | 10 | Watson's curated vocabulary includes fixed-dose combination therapies such as Entresto (drug:sacubitril_valsartan) and Trikafta (drug:elexacaftor_tezacaftor_ivacaftor). Databricks 'product.combination_product' captures fixed-dose drug combinations ('fixed_dose_combination_flag') and drug-device delivery systems (autoinjectors/syringes). Proposed as a candidate subclass extension (watson:CombinationProduct rdfs:subClassOf watson:Drug) pending ontology governance review. |
| `product.drug_product` | `product identity` | **CONFLICT** | `watson:Drug` | 10 | Databricks 'product.drug_product' models the manufactured Finished Dosage Form (FDF) with specific dosage form, route of administration, and strength (e.g., 100 mg/4 mL vial vs. 200 mg tablet), positioned between 'drug_substance' (API) and 'medicinal_product'/'sku'. **Conflict:** CARDINALITY & GRANULARITY CONFLICT: Watson's ontology has a 2-tier product model (watson:Drug -> watson:Brand) and lacks an intermediate Finished Dosage Form (FDF) class. Many-to-one collapse of drug_product into watson:Drug or watson:Brand would overwrite dosage-form-specific attributes. |
| `product.drug_substance` | `product identity` | **EXACT** | `watson:Drug` | 10 | Databricks 'product.drug_substance' represents the Active Pharmaceutical Ingredient (API) per ICH Q7, directly matching Watson's 'watson:Drug' class and its 'BiologicDrug' / 'SmallMoleculeDrug' subclasses (governed via 'is_biologic' and 'drug_substance_type'). Canonical Watson drug entities (e.g., drug:pembrolizumab, drug:dupilumab) are instance-level records of this schema. |
| `product.excipient` | `product identity` | **UNRESOLVED** | *(None — Unmapped)* | 0 | Databricks 'product.excipient' models inactive pharmaceutical ingredients (binders, diluents, lubricants, preservatives) and USP/Ph.Eur. compendial grades. Watson's ontology only models active drugs (watson:Drug) and does not model inactive excipients. |
| `product.formulation` | `product identity` | **UNRESOLVED** | *(None — Unmapped)* | 0 | Databricks 'product.formulation' captures CMC manufacturing Master Batch Record (MBR) recipes, scale-up factors, osmolality, viscosity, and Karl Fischer moisture specs. Out of scope for Watson's current market research ontology. |
| `product.formulation_ingredient` | `product identity` | **UNRESOLVED** | *(None — Unmapped)* | 0 | Databricks 'product.formulation_ingredient' models quantitative Bill of Materials (BOM) line items, weight-in-weight percentages, and manufacturing overages. No counterpart exists in Watson's ontology. |
| `product.indication` | `market authorization` | **EXACT** | `watson:Indication` | 10 | Databricks 'product.indication' and Watson 'watson:Indication' both capture approved and investigational disease indications linked to a primary therapeutic area and external clinical terminologies (MedDRA, ICD-10, MeSH/SNOMED). Canonical Watson instances (indication:nsclc, indication:atopic_dermatitis, etc.) correspond to row-level records of this schema concept. |
| `product.labeling` | `market authorization` | **PROPOSED** | `watson:Document` | 0 | Databricks 'product.labeling' represents structured regulatory product labels (USPI, SmPC, PIL, SPL XML). In Watson, 'watson:Document' is the root document class (currently specialized into 'watson:MarketResearchDocument'). 'labeling' is proposed as a sibling subclass under 'watson:Document' rather than conflating regulatory prescribing labels with market research studies. |
| `product.lifecycle` | `market authorization` | **PROPOSED** | `watson:Brand` | 10 | Databricks 'product.lifecycle' tracks R&D phase transitions, NDA/BLA filings, commercial launch dates, and Loss of Exclusivity (LOE) for a medicinal product. Proposed as temporal milestone properties linked to watson:Brand. IMPORTANT: Never map Databricks 'lifecycle_stage' to 'watson:lifecycleState', which exclusively governs Layer 1 document review states (DRAFT, UNDER_REVIEW, ACTIVE, ARCHIVED, REJECTED). **Conflict:** Homonym warning: product commercial lifecycle != Watson document governance lifecycle_state. |
| `product.medicinal_product` | `product identity` | **CONFLICT** | `watson:Brand` | 10 | Databricks 'product.medicinal_product' is an ISO IDMP master table that combines commercial brand attributes ('product_name', 'trademark_id', 'tactical_brand_plan') with active substance identifiers ('usan', 'inn_registry_id', 'moa', 'target_expression') and finished dosage form links ('drug_product_id'). Furthermore, a schema table such as 'medicinal_product' is a meta-level class and is NEVER equivalent to a specific canonical brand instance such as 'brand:keytruda' or drug instance 'drug:pembrolizumab'. **Conflict:** STRUCTURAL & SEMANTIC CONFLICT: Watson's OWL ontology strictly separates commercial 'watson:Brand' (e.g., brand:keytruda) from active ingredient 'watson:Drug' (e.g., drug:pembrolizumab) linked via 'watson:isBrandOf'. Mapping 'medicinal_product' 1:1 to 'watson:Brand' conflates USAN/INN substance properties with brand properties. Resolution requires a projection rule splitting brand attributes to watson:Brand and substance attributes to watson:Drug. |
| `product.packaging_configuration` | `market authorization` | **UNRESOLVED** | *(None — Unmapped)* | 0 | Databricks 'product.packaging_configuration' models physical container closure systems, blister foil/pocket materials, carton dimensions, pallet patterns, and serialization flags. Watson's clinical/commercial market research ontology has no physical packaging or supply-chain container domain classes. |
| `product.product_ndc_code` | `market authorization` | **UNRESOLVED** | *(None — Unmapped)* | 0 | Databricks 'product.product_ndc_code' models US FDA 10-digit/11-digit National Drug Code segments (Labeler, Product, Package code) and DRLS listings. While NDC codes relate to US commercial packages, Watson's ontology does not currently model package-level NDC billing units. |
| `product.regulatory_identifier` | `market authorization` | **PROPOSED** | `watson:Brand` | 10 | Watson's seed knowledge graph links canonical brands and indications to external identifiers (RxNorm, ChEMBL, Wikidata, MeSH, SNOMED) via rdfs:seeAlso and skos:exactMatch. Databricks 'product.regulatory_identifier' provides FDA NDA/BLA/ANDA and EMA MAA registration numbers that can enrich Brand provenance annotations after review. |
| `product.sku` | `market authorization` | **UNRESOLVED** | *(None — Unmapped)* | 0 | Databricks 'product.sku' models ERP Stock Keeping Units, GTIN/EAN/PZN barcodes, order multiples, minimum order quantities, and cubic volumes. No equivalent supply-chain SKU concept exists in Watson's Layer 2 ontology. |
| `product.therapeutic_area` | `product identity` | **EXACT** | `watson:TherapeuticArea` | 7 | Databricks 'product.therapeutic_area' and Watson 'watson:TherapeuticArea' both model the formal medical therapeutic area hierarchy (e.g., Oncology, Immunology, Cardiology, Neurology, Rare Disease, Respiratory, Metabolic). Note: the table maps to the OWL class watson:TherapeuticArea, while Watson's 7 canonical instances (ta:oncology, etc.) represent row-level instances of this schema. |

## 5. Cross-Domain & Watson-Native Unmapped Concepts

| Concept | Source Model | Status | Target | Details |
| :--- | :--- | :--- | :--- | :--- |
| `dbx:product:masterdata.country` | Databricks Pharmaceuticals MVM | **CONFLICT** | `watson:Geography` | Databricks Product tables reference 'masterdata.country' via ISO country IDs, whereas Watson's 'watson:Geography' vocabulary combines supranational regions (geo:eu, geo:global) with country-level entities (geo:us, geo:india, geo:japan, geo:germany, geo:uk, geo:france, geo:canada). **Conflict:** SCOPE & AGGREGATION CONFLICT: Direct equality mapping between 'masterdata.country' and 'watson:Geography' fails for supranational ABAC scopes ('geo:eu', 'geo:global'). Requires a hierarchical roll-up rule (e.g., Germany/France -> EU -> Global) rather than 1:1 country equivalence. |
| `watson:MarketResearchDocument` | Watson Semantic Foundation | **UNRESOLVED** | *(None)* | Governed market research study documents and HCP perception surveys belong to Watson's unstructured knowledge layer and have no table equivalent in the Databricks Product schema. |
| `watson:StudyType` | Watson Semantic Foundation | **UNRESOLVED** | *(None)* | Watson's 6 controlled market research study templates (Therapy Area Landscape, Competitive Landscape Report, Indication Deep Dive, KOL Interview Summary, Market Access Insight, HCP Perception Survey) govern document retention/expiry and have no Product MVM counterpart. |
| `watson:SentimentAssertion` | Watson Semantic Foundation | **UNRESOLVED** | *(None)* | Layer 2 NLP extraction artifacts (DocumentChunk, SentimentAssertion, LineageRecord, KnowledgeSpace) are native to Watson's GraphRAG architecture. |
