# Watson Intelligence Platform — Comprehensive Automated Test Results Report

## 1. Executive Summary

All **8 automated test suites** comprising **100 test cases** across security/access control, Databricks Pharmaceuticals Product MVM ingestion, vocabulary compatibility, Layer 2 RDF graph overlay, Layer 3 FAISS non-regression, SPARQL Studio, Research Copilot GraphRAG synthesis, and document upload transactionality executed and passed with **0 failures** (`100 / 100 PASS`).

---

## 2. Test Suite Execution Breakdown

| Test Suite File | Scope & Coverage | Tests Run | Passed | Failed | Status |
| :--- | :--- | :---: | :---: | :---: | :---: |
| `tests/test_poc_dynamic_metadata_and_security.py` | Phase 2 Admin-Only Access Control (11 tests), Phase 3 Databricks Product MVM Ingestion & LKG Fallback (1 test), Phase 4 Vocabulary Compatibility & Layer 2/3 Preservation (2 tests), Phase 5 Visual Graph Explorer Views A/B/C & Live v1→v1.1 Diff Refresh (1 test) | 15 | 15 | 0 | **PASS** |
| `tests/test_upload_regression.py` | Layer 1 Upload Transactionality, PDF/DOCX/PPTX/TXT Parsing, SHA-256 Deduplication, PII Redaction, Crash Journal Recovery, Slow Upload Concurrency, Rollback on Indexing Failure | 26 | 26 | 0 | **PASS** |
| `tests/test_question_answering_regression.py` | End-to-End GraphRAG Question Answering (Keytruda EU NSCLC, Dupixent US Atopic Dermatitis, 3-Market Comparison, Farxiga vs Jardiance CKD, Temporal HCP Sentiment, Lineage Provenance, Evidence Gap Detection for Keytruda in Alzheimer's, ABAC Viewer vs Admin Isolation) | 11 | 11 | 0 | **PASS** |
| `tests/test_semantic_graphrag.py` | 15-Stage Monitored Semantic GraphRAG Pipeline, Hybrid & SPARQL Routing, ABAC Zero-Leakage Verification | 1 | 1 | 0 | **PASS** |
| `tests/test_semantic_invariants_and_routing.py` | Canonical Vocabulary Resolution, Multi-Entity Disambiguation, Query Intent Classification, Ontology Invariants | 10 | 10 | 0 | **PASS** |
| `tests/test_systemic_architecture_repair.py` | Cross-Layer Architecture Integrity, Citation Validity, Indication Alignment, Grounding Verification | 11 | 11 | 0 | **PASS** |
| `tests/test_targeted_qa_and_conversation.py` | Conversational Gate, Multi-Turn Follow-Ups, Targeted Brand/Drug/Indication Queries, Reviewer Lineage | 22 | 22 | 0 | **PASS** |
| `tests/test_live_conversational_http.py` | Live FastAPI HTTP Conversational & Grounded Query Endpoints | 4 | 4 | 0 | **PASS** |
| **TOTAL** | **All Platform & POC Test Suites** | **100** | **100** | **0** | **100% PASS** |

---

## 3. Detailed POC Test Scenarios Verified (`tests/test_poc_dynamic_metadata_and_security.py`)

1. **`test_01_unauthenticated_users_cannot_access_ingestion_console_or_upload`**:
   - Verifies that unauthenticated requests to `GET /api/ingestion/console`, `POST /api/ingestion/upload`, `POST /api/ingestion/upload/batch`, `POST /api/ingestion/import`, `POST /api/ingestion/retry`, and `POST /api/ingestion/databricks/ingest` all return `HTTP 401 Unauthorized`.
2. **`test_02_non_admin_users_cannot_access_ingestion_console`**:
   - Verifies that every non-admin persona (`D3` Viewer, `U_ANALYST` Analyst, `U_SPOC` SPOC, `U_COMPLIANCE` Compliance Officer, `U_COMMERCIAL` Commercial Lead, `U_EXTERNAL` External Partner) receives `HTTP 403 Forbidden` on `GET /api/ingestion/console`.
3. **`test_03_frontend_ui_hides_and_guards_ingestion_console_for_non_admins`**:
   - Verifies that `frontend/src/App.tsx` gates the sidebar `📥 Ingestion Console` button on `isAdminUser` and renders the `🔒 Access Denied — Administrator Privileges Required (HTTP 403)` screen without rendering `<input type="file">` controls for non-admin sessions.
4. **`test_04_non_admin_users_cannot_bypass_ui_via_direct_upload_api`**:
   - Verifies that direct `POST /api/ingestion/upload` calls by non-admin users fail with `HTTP 403 Forbidden`, even when supplying spoofed `X-User-Role: ADMIN`, `X-Permissions: documents:ingest`, or `?role=ADMIN` query parameters, across both header and signed Bearer token sessions.
5. **`test_05_non_admin_users_cannot_trigger_alternate_ingestion_endpoints`**:
   - Verifies that `POST /api/ingestion/upload/batch`, `POST /api/ingestion/import`, `POST /api/ingestion/retry`, and `POST /api/ingestion/databricks/ingest` all return `HTTP 403 Forbidden` for non-admin users.
6. **`test_06_administrators_can_access_console_and_perform_valid_uploads`**:
   - Verifies that authenticated administrator `D4` receives `HTTP 200 OK` on `GET /api/ingestion/console` and successfully stages new study documents via `POST /api/ingestion/upload`.
7. **`test_07_invalid_expired_and_csrf_missing_authentication_rejected`**:
   - Verifies that tampered token signatures, expired tokens (`ttl_seconds=-10`), and unknown user IDs return `HTTP 401 Unauthorized`, and cookie-authenticated `POST` requests without a matching `X-CSRF-Token` header return `HTTP 403 Forbidden`.
8. **`test_08_unauthorized_requests_do_not_mutate_files_corpus_or_graph`**:
   - Verifies that rejected `401`/`403` upload attempts create zero files in `data/staging/` or `data/raw/`, do not modify `lifecycle_store.json`, and do not alter the Layer 2 RDF graph triple count.
9. **`test_09_existing_non_ingestion_features_remain_accessible_to_ordinary_users`**:
   - Verifies that `D3`, `U_ANALYST`, and `U_SPOC` receive `HTTP 200 OK` on `/api/documents`, `/api/search`, `/api/chat`, `/api/graph/sparql/templates`, `/api/graph/sparql`, `/api/graph/explorer`, `/api/graph/catalog`, and `/api/graph/mappings`.
10. **`test_10_audit_events_recorded_without_sensitive_leaks`**:
    - Verifies that `INGESTION_ACCESS_DENIED`, `INGESTION_ACCESS_GRANTED`, `INGESTION_UPLOAD_ATTEMPT`, and `INGESTION_UPLOAD_SUCCESS` events are recorded in `data/stores/audit_log.jsonl` and that neither document text nor session tokens appear in the audit log.
11. **`test_11_upload_safeguards_and_admin_assignment_utility`**:
    - Verifies rejection of double-extension spoofing (`exploit.exe.txt` -> `400`) and executable binary headers (`MZ` -> `400`), plus PBKDF2 password hashing and `assign_admin_role`.
12. **`test_12_databricks_product_mvm_ingestion_and_validation`**:
    - Verifies extraction of 2 subdomains (`market authorization`, `product identity`), 15 products, 594 attributes, 15 primary keys, and 83 foreign keys (37 intra-domain, 46 cross-domain), deterministic idempotency on repeated runs, and preservation of last-known-good catalog on corrupt JSON input.
13. **`test_13_vocabulary_compatibility_and_seed_vocabularies_invariance`**:
    - Verifies that `data/seed/seed_vocabularies.json` is byte-for-byte unchanged (SHA-256 `0f21702f3da1adb1d0c22cca3ba85a650303aed02938b5b924aed254b5fceac7`), verifies status breakdown (`3 EXACT`, `4 PROPOSED`, `3 CONFLICT`, `9 UNRESOLVED`), and confirms `medicinal_product` is never equated to a specific brand instance (`Keytruda`).
14. **`test_14_layer2_rdf_overlay_and_layer3_faiss_preservation`**:
    - Verifies that all 15 `dbx:DataProduct` tables are queryable via SPARQL 1.1 in `POST /api/graph/sparql` while `data/indexes/Watson.faiss` and `data/indexes/chunk_uri_map.json` remain byte-for-byte untouched during metadata-only updates.
15. **`test_15_graph_explorer_views_catalog_mappings_and_live_refresh_diff`**:
    - Verifies View A (`databricks`), View B (`watson`), View C (`integrated`), and live schema refresh diffing from `v1` to `v1.1-fixture` (detecting `indication.real_world_evidence_score` addition and restoring `v1`).

---

## 4. Reproducible Command to Run All Tests

```bash
PYTHONPATH=.:backend:backend/_compat_shims python3 -m pytest tests/test_poc_dynamic_metadata_and_security.py tests/test_upload_regression.py tests/test_question_answering_regression.py tests/test_semantic_graphrag.py tests/test_semantic_invariants_and_routing.py tests/test_systemic_architecture_repair.py tests/test_targeted_qa_and_conversation.py tests/test_live_conversational_http.py -v
```
