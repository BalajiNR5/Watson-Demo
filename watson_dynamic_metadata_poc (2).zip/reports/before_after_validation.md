# Watson Intelligence Platform — Before vs. After Validation Report

## 1. Architectural & Functional Comparison

| Dimension | Baseline State (`Watson_Office_Ingestion_Fixed.zip` @ `2f4c499`) | Improved POC State (`watson_dynamic_metadata_poc.zip`) | Verification Evidence |
| :--- | :--- | :--- | :--- |
| **Ingestion Console & Upload Access Control** | Open to all personas and unauthenticated callers; missing/unknown `x-user-id` silently defaulted to `D4` (`ADMIN`); UI showed `📥 Ingestion Console` and file upload form to all users. | Strictly restricted to authenticated administrators (`role == "ADMIN"` / `documents:ingest`); HMAC-SHA256 session tokens, CSRF verification for cookie sessions, server-side role resolution, upload magic-byte/double-extension safeguards, and tamper-evident audit logging. Non-admin UI hides nav item and shows HTTP 403 Access Denied screen. | `reports/ingestion_access_control.md`, `tests/test_poc_dynamic_metadata_and_security.py` (`test_01`–`test_11`), `reports/screenshots/07_*.png`, `08_*.png` |
| **Databricks Pharmaceuticals Product MVM Ingestion** | Not present. | Reusable `DatabricksProductMetadataIngestor` supporting remote GitHub JSON fetch + offline local fixture (`data/fixtures/databricks_pharmaceuticals_v1_mvm_model.json`), extracting 2 subdomains (`market authorization`, `product identity`), **15 products**, **594 attributes**, **15 primary keys**, and **83 foreign keys** with endpoint validation, diff tracking, and last-known-good fallback. | `outputs/databricks_pharma_product_catalog.json`, `outputs/ingestion_summary.json`, `reports/ingestion_report.md` |
| **Curated Vocabulary (`seed_vocabularies.json`)** | 52 curated concepts across 6 families (`therapeutic_areas`, `brands`, `drugs`, `indications`, `geographies`, `study_templates`), SHA-256 `0f21702f...ceac7`. | **100% preserved byte-for-byte** (SHA-256 `0f21702f...ceac7`). All 52 canonical IDs and aliases untouched. | `test_13_vocabulary_compatibility_and_seed_vocabularies_invariance` |
| **Semantic Compatibility & Mapping Layer** | No external schema mapping layer. | `SemanticCompatibilityEngine` producing 19 product/concept mappings (`3 EXACT`, `4 PROPOSED`, `3 CONFLICT`, `9 UNRESOLVED`) and 33 attribute mappings with explicit provenance, confidence scores, rationale, and instance-vs-schema guardrails (`medicinal_product` never equated to `Keytruda`). | `outputs/semantic_mapping_report.json`, `reports/compatibility_report.md` |
| **Layer 2 Semantic Graph (`ontology/`)** | `pharma.ttl` (230 triples), `pharma_kg.ttl` (3,795 triples), `pharma_kg_inferred.ttl` (10,047 triples). Total runtime graph: `10,349` triples. | Base files preserved intact; incremental RDF overlay `ontology/databricks_product_mvm_overlay.ttl` adds `3,820` schema & mapping triples in `dbx:` and `dbxmap:` namespaces (`14,169` total runtime triples). | `test_14_layer2_rdf_overlay_and_layer3_faiss_preservation` |
| **Layer 3 Vector Index (`Watson.faiss`)** | 70 governed chunks across 14 documents (`Watson.faiss` + `chunk_uri_map.json`). | Preserved byte-for-byte during metadata-only ingestion (no unnecessary or destructive vector rebuilds). | `test_14_layer2_rdf_overlay_and_layer3_faiss_preservation` |
| **KG Explorer UI (`activeTab === 'kg'`)** | Static 4-metric card (`Total Triples: 10,047`, `Ontology Classes: 14`, `Deductive Ratio: 2.65x`, `Restricted Chunks: 14`) with no interactive graph, no node inspection, no catalog, and no mappings. | Full interactive SVG **Visual Graph Explorer** with **View C (Integrated Mapping View — default)**, **View A (Databricks Product Model)**, **View B (Watson Semantic Model)**, **Interactive Node Data Catalog (15 tables / 594 cols)**, **Entity Mapping & Compatibility Explorer (19 records)**, zoom/pan/drag, search, multi-axis filters, 1-hop neighbourhood isolation, details inspector, and live `v1` ↔ `v1.1` diff refresh. | `reports/graph_explorer_validation.md`, `reports/screenshots/01_*.png`–`06_*.png` |
| **SPARQL Studio (`activeTab === 'sparql'`)** | 13 templates (`Q01`–`Q11`, `EXP_BRANDS`, `EXP_CLASSES`). | All 13 baseline templates preserved and verified + new `EXP_DBX_MAPPINGS` template querying Databricks Product MVM tables and Watson OWL mappings (`14` total templates). | `backend/app/main.py`, `test_14` |
| **Research Copilot (`activeTab === 'copilot'`)** | 15-stage Semantic GraphRAG pipeline with ABAC pre-filtering and citations. | 100% preserved with zero regressions across single-hop, multi-hop, comparative, temporal sentiment, conversational, and out-of-scope evidence-gap queries. | `tests/test_question_answering_regression.py` (`11/11 PASS`) |

---

## 2. Quantitative Metrics Before vs. After

| Metric | Before (Baseline) | After (POC) | Delta / Notes |
| :--- | :---: | :---: | :--- |
| **Curated Seed Vocabulary Concepts** | 52 | 52 | `0` changes (SHA-256 identical) |
| **Active Governed Documents / Chunks** | 14 docs / 70 chunks | 14 docs / 70 chunks | `0` regressions (ABAC 20 Viewer / 70 Admin chunks) |
| **Databricks Product MVM Tables Ingested** | 0 | 15 | `+15` (`7` Market Authorization, `8` Product Identity) |
| **Databricks Schema Attributes Ingested** | 0 | 594 | `+594` columns (`15` PKs, `83` FKs) |
| **Explicit Semantic Mapping Records** | 0 | 52 | `19` product/concept records + `33` attribute records |
| **Layer 2 Runtime RDF Triples** | 10,349 | 14,169 | `+3,820` triples in `dbx:` / `dbxmap:` overlay |
| **SPARQL Studio Built-In Templates** | 13 | 14 | `+1` (`EXP_DBX_MAPPINGS`) |
| **Protected Ingestion Endpoints Enforcing Admin Auth** | 0 / 1 | 6 / 6 | `100%` server-side enforcement (`401` / `403`) |
| **Automated Test Suites / Passing Tests** | 7 suites (85 tests) | 8 suites (100 tests) | `+15` new security, metadata, compatibility & graph tests (`100% PASS`) |
