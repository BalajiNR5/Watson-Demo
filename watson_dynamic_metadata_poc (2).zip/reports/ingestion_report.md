# Databricks Pharmaceuticals Product MVM — Dynamic Metadata Ingestion Report

## 1. Model Identity & Provenance

| Field | Verified Value |
| :--- | :--- |
| **Industry** | `pharmaceuticals` (Pharmaceuticals) |
| **Division** | `Business` (`BIZ`) |
| **Domain** | `product` (Product) |
| **Flavour** | `mvm` (Minimum Viable Model) |
| **Model Version** | `v1` |
| **Authoritative Source URL** | `https://github.com/databricks-industry-solutions/lakehouse-industry-data-models/blob/main/data-models/pharmaceuticals/v1/mvm/model.json` |
| **Model Explorer URL** | `https://databricks-industry-solutions.github.io/lakehouse-industry-data-models/?industry=pharmaceuticals&flavour=mvm` |
| **Ingestion Source Mode** | `local_fixture` (`databricks_pharmaceuticals_v1_mvm_model.json`) |
| **Source SHA-256** | `4da8db2bdfccfc7430c2f2a4dc5361882403883be16befe4206361c21d3b907c` |
| **Catalog Fingerprint SHA-256** | `bb948957995bc21fb117a85655a6adfd9ac00ec0f37f05acbaa974fd91da52c0` |
| **Ingested Timestamp (UTC)** | `2026-10-28T20:56:10.857369+00:00` |
| **Ingested By (Actor ID)** | `D4` |

## 2. Extracted Counts Summary

| Metric | Extracted Count |
| :--- | ---: |
| **Subdomains Included** | 2 |
| **Data Products (Tables)** | 15 |
| **Total Attributes (Columns)** | 594 |
| **Primary Keys** | 15 |
| **Total Foreign Keys** | 83 |
| **Intra-Domain Foreign Keys (`product.*`)** | 37 |
| **Cross-Domain Foreign Keys (`masterdata.*`, `intellectual.*`, etc.)** | 46 |
| **`CONTAINS_ATTRIBUTE` Edges** | 594 |
| **Total Schema Graph Edges** | 677 |

## 3. Subdomain Breakdown

| Subdomain | Products Count | Attributes Count | Foreign Keys Count | Member Products |
| :--- | ---: | ---: | ---: | :--- |
| **Market Authorization** (`market authorization`) | 7 | 268 | 39 | `indication`, `labeling`, `lifecycle`, `packaging_configuration`, `product_ndc_code`, `regulatory_identifier`, `sku` |
| **Product Identity** (`product identity`) | 8 | 326 | 44 | `combination_product`, `drug_product`, `drug_substance`, `excipient`, `formulation`, `formulation_ingredient`, `medicinal_product`, `therapeutic_area` |

## 4. Product Catalog Inventory

| Product (Table) | Subdomain | Primary Key | Attributes | Total FKs | Intra-Domain FKs | Cross-Domain FKs | Description |
| :--- | :--- | :--- | ---: | ---: | ---: | ---: | :--- |
| `combination_product` | `product identity` | `combination_product_id` | 43 | 5 | 4 | 1 | Master entity for fixed-dose combination drugs, drug-device combination products (pre-filled syringes, auto-in... |
| `drug_product` | `product identity` | `drug_product_id` | 47 | 7 | 3 | 4 | Master entity representing the finished dosage form (FDF) drug product containing active pharmaceutical ingred... |
| `drug_substance` | `product identity` | `drug_substance_id` | 42 | 5 | 1 | 4 | Master record for the active pharmaceutical ingredient (API) or drug substance (DS) as defined in ICH Q7. Capt... |
| `excipient` | `product identity` | `excipient_id` | 41 | 1 | 1 | 0 | Master record for pharmaceutical excipients used in drug product formulations, capturing functional category, ... |
| `formulation` | `product identity` | `formulation_id` | 43 | 5 | 1 | 4 | Quantitative formulation master record defining the complete bill of materials (BOM) for a finished pharmaceut... |
| `formulation_ingredient` | `product identity` | `formulation_ingredient_id` | 30 | 5 | 4 | 1 | Component line items within a formulation bill of materials, specifying exact quantities, percentages, functio... |
| `indication` | `market authorization` | `indication_id` | 37 | 7 | 2 | 5 | Association record linking a medicinal product to its approved or investigational therapeutic indications, cap... |
| `labeling` | `market authorization` | `labeling_id` | 40 | 7 | 3 | 4 | Approved product labeling and prescribing information master record, covering Structured Product Labeling (SPL... |
| `lifecycle` | `market authorization` | `lifecycle_id` | 35 | 4 | 2 | 2 | Strategic and operational product lifecycle milestone record, tracking key events from candidate selection thr... |
| `medicinal_product` | `product identity` | `medicinal_product_id` | 41 | 12 | 3 | 9 | Master entity representing a marketable pharmaceutical product line, capturing product identity, brand name, U... |
| `packaging_configuration` | `market authorization` | `packaging_configuration_id` | 41 | 4 | 1 | 3 | Master specification for primary, secondary, and tertiary packaging components, materials, dimensions, fill qu... |
| `product_ndc_code` | `market authorization` | `product_ndc_code_id` | 34 | 4 | 3 | 1 | National Drug Code (NDC) mapping record for US market drug products, managing 10-digit and 11-digit NDC format... |
| `regulatory_identifier` | `market authorization` | `regulatory_identifier_id` | 43 | 7 | 4 | 3 | Cross-border regulatory identifier catalog tracking product registration numbers, Marketing Authorization numb... |
| `sku` | `market authorization` | `sku_id` | 38 | 6 | 4 | 2 | Stock Keeping Unit (SKU) master record representing specific saleable and inventory-tracked commercial finishe... |
| `therapeutic_area` | `product identity` | `therapeutic_area_id` | 39 | 4 | 1 | 3 | Hierarchical classification tree for medical disease domains and therapeutic areas (Oncology, Cardiology, Immu... |

## 5. Validation & Integrity Checks

- **Validation Status:** `PASS`
- **Structural Errors:** `0`
- **Validation Warnings:** `0`
- **Executed Integrity Gates:**
  - `root_json_object_check`: **PASS**
  - `industry_pharmaceuticals_check`: **PASS**
  - `flavour_mvm_check`: **PASS**
  - `domain_product_presence_check`: **PASS**
  - `subdomains_membership_check`: **PASS**
  - `non_empty_products_and_attributes_check`: **PASS**
  - `primary_key_existence_in_attributes_check`: **PASS**
  - `intra_domain_foreign_key_endpoint_integrity_check`: **PASS**
  - `duplicate_product_and_attribute_deduplication_check`: **PASS**

## 6. Idempotency & Refresh Diff Status

- **Initial Ingest:** `True`
- **Catalog Content Changed:** `True`
- **Products Diff:** `15` added, `0` changed, `0` removed, `0` unchanged
- **Attributes Diff:** `594` added, `0` changed, `0` removed, `0` unchanged
- **Foreign Keys Diff:** `83` added, `0` removed, `0` unchanged
