# Watson Intelligence Platform — Administrator-Only Ingestion Console & Upload Access Control Report

## 1. Executive Summary

Document upload, staging, and dynamic metadata ingestion operations in the Watson Intelligence Platform are strictly restricted to authenticated administrators holding the server-verified `ADMIN` role and `documents:ingest` permission. Ordinary users (`VIEWER`, `ANALYST`, `SPOC`, `COMPLIANCE_OFFICER`, `COMMERCIAL_LEAD`, `EXTERNAL_PARTNER`) and unauthenticated visitors are blocked at both the UI layer and the backend API layer while retaining full permitted access to non-ingestion workflows (Research Copilot, Document Library, HITL Workbench per role scope, Knowledge Spaces, SPARQL Studio, and KG Explorer).

---

## 2. Authentication & Authorization Architecture

### 2.1 Existing Baseline Gap Identified
In the baseline repository (`backend/app/main.py`, lines 105–120):
1. `CURRENT_USER_ID` defaulted globally to `"D4"` (Elena Rostova, `ADMIN`).
2. `get_current_user` accepted an unverified `x-user-id` header and silently fell back to `"D4"` (`ADMIN`) whenever the header was omitted or contained an unrecognized user ID (`if uid not in users: uid = "D4"`).
3. `POST /api/ingestion/upload` did not check `user["role"] == "ADMIN"` or `documents:ingest` permission, allowing any persona or unauthenticated caller to upload documents into `data/staging/` and `data/raw/`.
4. `frontend/src/App.tsx` unconditionally rendered the `📥 Ingestion Console` navigation item and `<input type="file">` upload form for every persona.

### 2.2 Implemented Server-Side Security Architecture (`backend/app/security/auth.py`)
1. **HMAC-SHA256 Signed Session Tokens (`create_session_token` / `verify_session_token`)**:
   - Issued by `POST /api/auth/login` and `POST /api/auth/switch`.
   - Signed using `WATSON_SESSION_SECRET` (or a cryptographically random 256-bit runtime secret if unset — never a hardcoded static secret in source code).
   - Embeds `sub` (user ID), `iat` (issued-at timestamp), `exp` (expiration timestamp), `jti` (unique token nonce), and `csrf` (128-bit CSRF token).
2. **Server-Authoritative Role & Permission Resolution (`resolve_user_from_registry` / `get_effective_permissions`)**:
   - Resolves user roles and permissions strictly from the server-side `data/stores/user_registry.json` (and optional `WATSON_ADMIN_USER_IDS` environment variable).
   - Never trusts client-supplied role headers (`X-User-Role`), permission headers (`X-Permissions`), query parameters (`?role=ADMIN`), or browser flags.
   - Unknown user IDs are immediately rejected with `HTTP 401 Unauthorized` (never falling back to `D4` Admin).
   - Only users with `role == "ADMIN"` or explicit server-side `documents:ingest` permission receive `can_ingest = True` and `permissions = ["admin", "documents:ingest", "ingestion:console", ...]`. Non-admin roles (including `COMPLIANCE_OFFICER` and `SPOC`) have `documents:ingest` explicitly stripped unless assigned administrator status.
3. **Reusable FastAPI Authorization Guard (`require_ingestion_admin`)**:
   - Enforces explicit authentication (`require_explicit_auth=True`) on every protected ingestion route. Unauthenticated requests (missing `Authorization: Bearer <token>`, `X-Watson-Session`, `watson_session` cookie, or `x-user-id`) are rejected with `HTTP 401 Unauthorized`.
   - Enforces CSRF protection (`X-CSRF-Token` constant-time match against token `csrf` claim) whenever a cookie-authenticated session (`watson_session`) performs a mutating request (`POST`, `PUT`, `DELETE`, `PATCH`).
   - Enforces `is_authorized_ingestion_admin(user)`: authenticated non-admin users are rejected with `HTTP 403 Forbidden`.
   - Supports strict token-only production mode via `WATSON_STRICT_TOKEN_ONLY=1`, which disables `x-user-id` header authentication on protected ingestion routes and requires a signed Bearer or cookie token.

---

## 3. Protected Routes & Entry Points

| Entry Point / Endpoint | Method | Purpose | Unauthenticated | Authenticated Non-Admin (`D3`, `U_ANALYST`, `U_SPOC`, `U_COMPLIANCE`, `U_COMMERCIAL`, `U_EXTERNAL`) | Authenticated Administrator (`D4`) |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `GET /api/ingestion/console` | `GET` | Ingestion Console status, upload limits & metadata snapshot | `401 Unauthorized` | `403 Forbidden` | `200 OK` |
| `POST /api/ingestion/upload` | `POST` | Single-file governed document upload & Layer 1 staging | `401 Unauthorized` | `403 Forbidden` | `200 OK` |
| `POST /api/ingestion/upload/batch` | `POST` | Multi-file batch document upload (up to 20 files) | `401 Unauthorized` | `403 Forbidden` | `200 OK` |
| `POST /api/ingestion/import` | `POST` | Server-side approved corpus file import | `401 Unauthorized` | `403 Forbidden` | `200 OK` |
| `POST /api/ingestion/retry` | `POST` | Reopen/retry staged pending document ingestion | `401 Unauthorized` | `403 Forbidden` | `200 OK` |
| `POST /api/ingestion/databricks/ingest` | `POST` | Trigger dynamic Databricks Product MVM metadata ingestion | `401 Unauthorized` | `403 Forbidden` | `200 OK` |
| `POST /api/graph/explorer/refresh` (with fixture/URL) | `POST` | Trigger schema re-ingestion during Graph Explorer refresh | `403 Forbidden` | `403 Forbidden` | `200 OK` |
| Frontend Sidebar (`frontend/src/App.tsx`) | UI | `📥 Ingestion Console` navigation item | Hidden | Hidden (`!isAdminUser`) | Visible & Active |
| Frontend Ingestion View (`frontend/src/App.tsx`) | UI | Document upload & Databricks ingestion forms | Blocked | Renders HTTP 403 Access Denied card; zero `<input type="file">` controls rendered | Full upload & metadata controls |

---

## 4. Upload Safeguards & Audit Logging

1. **Extension & Double-Extension Validation (`validate_and_sanitize_upload`)**:
   - Only `.pdf`, `.docx`, `.pptx`, and `.txt` files are accepted.
   - Inner extensions are inspected to block double-extension spoofing (e.g., `exploit.exe.txt`, `payload.sh.pdf` -> `HTTP 400`).
2. **Magic-Byte / Binary Signature Inspection**:
   - Rejects Windows PE (`MZ`) and Linux `ELF` (`\x7fELF`) binaries disguised with document extensions (`HTTP 400`).
   - Validates `%PDF-` header for `.pdf` uploads and `PK\x03\x04` ZIP/OpenXML container signature for `.docx` and `.pptx` uploads.
3. **Path Traversal Protection & Safe Storage Paths**:
   - Strips directory components from multipart filenames (`../safe.txt` -> `safe.txt`), rejects dot-files or empty basenames (`.env`, `..`), and confines `POST /api/ingestion/import` strictly to `RAW_DATA_DIR` via `Path.resolve().is_relative_to(RAW_DATA_DIR.resolve())`.
4. **Request Size Limits**:
   - Enforces `MAX_UPLOAD_BYTES` (default 50 MB, configurable via `WATSON_MAX_UPLOAD_BYTES`) during streaming read, returning `HTTP 413 Payload Too Large` before disk staging.
5. **Tamper-Evident Audit Logging (`data/stores/audit_log.jsonl`)**:
   - Records `INGESTION_ACCESS_GRANTED`, `INGESTION_ACCESS_DENIED`, `INGESTION_UPLOAD_ATTEMPT`, `INGESTION_UPLOAD_SUCCESS`, `INGESTION_UPLOAD_FAILURE`, and `ADMIN_ROLE_ASSIGNED` with SHA-256 hash chaining (`prev_hash` -> `event_hash`).
   - Includes `user_id`, `timestamp`, `operation`, `outcome`, and `document_uri` while never logging raw document contents, passwords, or session tokens.

---

## 5. Administrator Bootstrap & Assignment Instructions

### 5.1 Assigning an Administrator Role
To grant administrator ingestion privileges to an existing registered user in `data/stores/user_registry.json`, run:
```bash
PYTHONPATH=.:backend python3 -c "from app.security.auth import assign_admin_role; print(assign_admin_role('U_SPOC', actor_id='SYSTEM_BOOTSTRAP'))"
```
Or configure environment variables prior to starting the server (see `.env.example`):
- `WATSON_SESSION_SECRET`: High-entropy 64-character hex signing key for HMAC-SHA256 tokens.
- `WATSON_ADMIN_PASSWORD_HASH`: PBKDF2-HMAC-SHA256 hash generated via `hash_password_pbkdf2(password)`.
- `WATSON_ADMIN_BOOTSTRAP_TOKEN`: One-time or emergency bootstrap token accepted by `POST /api/auth/login`.
- `WATSON_ADMIN_USER_IDS`: Comma-separated list of user IDs granted `documents:ingest` permission at runtime.
- `WATSON_STRICT_TOKEN_ONLY=1`: Enforces signed Bearer/cookie tokens on all ingestion endpoints.

---

## 6. Automated Security Test Results

All 11 security and access-control tests in `tests/test_poc_dynamic_metadata_and_security.py` and all 26 upload regression tests in `tests/test_upload_regression.py` pass (`37 / 37 PASS`):
- `test_01_unauthenticated_users_cannot_access_ingestion_console_or_upload`: **PASS** (`401 Unauthorized` across all 6 endpoints)
- `test_02_non_admin_users_cannot_access_ingestion_console`: **PASS** (`403 Forbidden` for `D3`, `U_ANALYST`, `U_SPOC`, `U_COMPLIANCE`, `U_COMMERCIAL`, `U_EXTERNAL`)
- `test_03_frontend_ui_hides_and_guards_ingestion_console_for_non_admins`: **PASS** (UI nav guard & HTTP 403 screen verified; screenshot `reports/screenshots/08_ingestion_console_non_admin_denied.png`)
- `test_04_non_admin_users_cannot_bypass_ui_via_direct_upload_api`: **PASS** (`403 Forbidden` even with spoofed `X-User-Role: ADMIN` and `X-Permissions: documents:ingest`)
- `test_05_non_admin_users_cannot_trigger_alternate_ingestion_endpoints`: **PASS** (`403 Forbidden` on batch, import, retry, and Databricks ingest)
- `test_06_administrators_can_access_console_and_perform_valid_uploads`: **PASS** (`200 OK` for `D4` Admin; screenshot `reports/screenshots/07_ingestion_console_admin_allowed.png`)
- `test_07_invalid_expired_and_csrf_missing_authentication_rejected`: **PASS** (`401` on tampered/expired/unknown tokens; `403` on missing CSRF token for cookie sessions)
- `test_08_unauthorized_requests_do_not_mutate_files_corpus_or_graph`: **PASS** (zero files, staging records, lifecycle mutations, or graph triples created)
- `test_09_existing_non_ingestion_features_remain_accessible_to_ordinary_users`: **PASS** (`200 OK` on Documents, Search, Chat, SPARQL, and Graph Explorer)
- `test_10_audit_events_recorded_without_sensitive_leaks`: **PASS** (audit events logged; zero document text or token leakage)
- `test_11_upload_safeguards_and_admin_assignment_utility`: **PASS** (`400` on `exploit.exe.txt` and `MZ` binary header; `assign_admin_role` verified)
