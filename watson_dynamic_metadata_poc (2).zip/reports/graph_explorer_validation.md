# Watson Intelligence Platform — Interactive Visual Graph Explorer & Data Catalog Validation Report

## 1. Executive Summary

The static placeholder in the **KG Explorer** tab (`frontend/src/App.tsx`, formerly a 4-card static counter block) has been replaced by a full, artifact-driven **Interactive Visual Graph Explorer, Data Catalog, and Entity Mapping UI** (`frontend/src/components/GraphExplorer.tsx` + `backend/watson/semantics/graph_explorer_service.py`). Every node, attribute, relationship, and mapping badge is dynamically populated from the generated Databricks Pharmaceuticals Product MVM artifacts (`outputs/databricks_pharma_product_catalog.json`, `outputs/ingestion_summary.json`, `outputs/semantic_mapping_report.json`) and Watson's live Layer 2 semantic foundation (`data/seed/seed_vocabularies.json`, `ontology/pharma.ttl`, `ontology/pharma_kg_inferred.ttl`, `ontology/databricks_product_mvm_overlay.ttl`).

---

## 2. Validated Views & Explorer Sub-Modes

### 2.1 Three Coordinated Graph Views (Visual Graph Canvas Mode)
1. **View C: Integrated Semantic Mapping View (`integrated` — Default Demonstration View)**:
   - Displays all **15 Databricks Product MVM tables** (`market authorization` and `product identity`), **cross-domain schema endpoints**, **14 Watson OWL 2 RL classes**, and **52 curated Watson entities** (`104` total nodes without expanded non-key attributes, `190` edges).
   - Renders cross-model `MAPPED_TO` edges color-coded and styled by compatibility status (`EXACT` solid green `#16a34a`, `PROPOSED` dashed amber `#d97706`, `CONFLICT` dashed red `#dc2626`, `UNRESOLVED` dotted slate `#64748b`).
   - Verified in live headless Chromium screenshot: `reports/screenshots/01_kg_explorer_view_c_integrated.png`.
2. **View A: Databricks Pharmaceuticals Product MVM Model (`databricks`)**:
   - Displays the 15 Product domain tables organized by `market authorization` (7 tables) and `product identity` (8 tables), their key attributes (`CONTAINS_ATTRIBUTE`), intra-domain foreign keys (`FOREIGN_KEY_TO`), and cross-domain reference endpoints (`masterdata.country`, `masterdata.atc_classification`, etc.).
   - Verified in live headless Chromium screenshot: `reports/screenshots/02_kg_explorer_view_a_databricks.png`.
3. **View B: Watson Curated Semantic Model (`watson`)**:
   - Displays Watson's 14 OWL ontology classes (`TherapeuticArea`, `Brand`, `Drug`, `BiologicDrug`, `SmallMoleculeDrug`, `Indication`, `Geography`, `StudyType`, `Document`, `MarketResearchDocument`, `EvidenceChunk`, `Finding`, `ClinicalFinding`, `CommercialFinding`) and 52 curated entities with `INSTANCE_OF`, `SUBCLASS_OF`, `IS_BRAND_OF`, `TREATS_INDICATION`, `IN_THERAPEUTIC_AREA`, and `COMPETES_WITH` relationships.
   - Verified in live headless Chromium screenshot: `reports/screenshots/03_kg_explorer_view_b_watson.png`.

### 2.2 Interactive Node Data Catalog Sub-Mode (`📘 Interactive Node Data Catalog`)
- Provides a searchable, interactive directory of all **15 Databricks Product MVM tables** and their **594 columns**.
- Selecting any table displays its canonical ID, subdomain badge, description, Primary Key(s), clickable Foreign Key relationship badges (distinguishing intra-domain FKs from cross-domain FKs), and a complete column specification table showing data type, `PK`/`FK`/`NULL`/`NOT NULL` constraints, mapped Watson ontology property (`EXACT`/`PROPOSED`), and column description.
- Includes a `🎯 Focus Node in Graph Canvas` button that jumps directly to the selected table in the interactive SVG graph canvas.
- Verified in live headless Chromium screenshot: `reports/screenshots/04_kg_explorer_data_catalog.png`.

### 2.3 Entity Mapping & Compatibility Explorer Sub-Mode (`🔗 Entity Mapping & Compatibility Explorer`)
- Displays all **19 product/concept compatibility records** (`3 EXACT`, `4 PROPOSED`, `3 CONFLICT`, `9 UNRESOLVED`) with search and status filters, confidence percentages, detailed semantic rationale, conflict/granularity warnings, and one-click `View in Graph` navigation.
- Explicitly enforces and explains why schema tables (`product.medicinal_product`, `product.drug_substance`) map to OWL classes (`watson:Brand`, `watson:Drug`) and are never falsely equated to individual brand/drug instances (`brand:keytruda`, `drug:pembrolizumab`).
- Verified in live headless Chromium screenshot: `reports/screenshots/05_kg_explorer_entity_mappings.png`.

---

## 3. Interactive Graph Capabilities Verified

| Requirement | Implementation Detail | Verification Status |
| :--- | :--- | :--- |
| **Zoom & Pan** | Mouse-drag canvas panning, `＋ Zoom In`, `－ Zoom Out`, and `⊡ Fit to Screen` controls (`40%`–`220%` scale) | **VERIFIED** |
| **Node Dragging** | Individual SVG nodes can be dragged and repositioned interactively on the canvas | **VERIFIED** |
| **Node Selection & Side Panel** | Clicking any node opens its full specification in the right-hand Inspector Side Panel (ID, source model, version, subdomain, mapping status/rationale/conflict notes, connected relationships, filterable attributes table, and provenance) | **VERIFIED** |
| **Connected-Neighbour Highlighting** | Selecting a node highlights all incident edges and 1-hop neighbours while dimming non-connected nodes/edges | **VERIFIED** |
| **Neighbourhood Isolation** | `Isolate 1-Hop Neighbourhood of Selected Node` checkbox filters the canvas to the selected node and its immediate 1-hop subgraph | **VERIFIED** |
| **Search & Multi-Axis Filtering** | Live search across table names, column names (e.g. `ndc_11_digit`), OWL classes, and brand/drug aliases, plus dropdown filters for Node Type, Subdomain/Family, Relationship Type, and Mapping Status | **VERIFIED** |
| **Visual Legend & Status Honesty** | Dedicated bottom legend distinguishing all 5 node types and 4 mapping statuses; `PROPOSED` uses dashed amber lines (`#d97706`) labeled `PROPOSED (Unverified)` so candidate mappings are never visually implied as verified | **VERIFIED** |
| **Live Refresh & Schema Diff** | `⟳ Refresh Graph (v1 MVM)` and `⚡ Simulate v1.1 Schema Update` buttons re-run ingestion/mapping, update the graph in place, and display the live diff banner (`Changed Products: 1 (indication: +[real_world_evidence_score]) | Unchanged: 14`) while preserving the last-known-good graph on error | **VERIFIED** (`reports/screenshots/06_kg_explorer_v1_1_live_diff.png`) |
