# Watson Intelligence Platform — Dependency & Architecture Map

## 1. Executive Summary & Baseline Verification

This document maps the verified baseline architecture of the **Watson Pharma Knowledge Intelligence Platform** (`Watson_Office` / v2.0.0) prior to implementing dynamic Databricks Pharmaceuticals Product MVM metadata ingestion, semantic vocabulary compatibility mapping, administrator-only Ingestion Console access control, and the interactive Visual Graph Explorer.

- **Baseline Git Commit:** Recorded on `master` branch (`Baseline: Watson_Office_Ingestion_Fixed initial state`, 184 files).
- **Verified vs. Assumed vs. Blocked Distinction:**
  - **Verified Findings:** Derived directly from inspecting source files in `backend/`, `frontend/`, `data/`, `ontology/`, `queries/`, `scripts/`, and `tests/`.
  - **Assumptions:** Explicit design assumptions where upstream or environment conventions require compatibility bridges.
  - **Environment / Deployment Blockers & Mitigations:** Documented in Section 12.

---

## 2. Frontend & Backend Frameworks and Entry Points

| Layer | Technology / Framework | Entry Point File | Key Responsibilities |
| :--- | :--- | :--- | :--- |
| **Launcher / Runtime Policy** | Python 3.10–3.12 (`office_launcher.py`, `office_policy.py`) | `office_launcher.py` (`main()`) | Configures offline environment variables (`HF_HUB_OFFLINE=1`, `TRANSFORMERS_OFFLINE=1`, `WATSON_ALLOW_CLOUD=0`, `WATSON_BASE_DIR`), verifies prerequisites (`check()`), and launches `uvicorn.run("app.main:app", host="127.0.0.1", port=8000)`. |
| **Backend API** | FastAPI + Starlette (`TrustedHostMiddleware`) | `backend/app/main.py` (`app`) | Instantiates global services (`IngestionCoordinator`, `GraphRAGAssembler`, `QwenInterface`, `WatsonGuardrails`, `KnowledgeSpaceManager`), exposes `/api/*` REST & SSE endpoints, and mounts compiled frontend static assets from `frontend/dist` at `/`. |
| **Frontend UI (Source)** | React 18.3.1 + TypeScript 5.2 + Vite 5.2 | `frontend/src/main.tsx` $\rightarrow$ `frontend/src/App.tsx` | Single-page application with 9 navigation tabs (`copilot`, `ingestion`, `hitl`, `library`, `kg`, `spaces`, `sparql`, `governance`, `health`), topbar persona switcher, and REST client in `frontend/src/services/api.ts`. |
| **Frontend UI (Production Bundle)** | Pre-built Vite bundle | `frontend/dist/index.html`, `frontend/dist/assets/index-G7ZawakF.js`, `frontend/dist/assets/index-DKFsLm6f.css` | Served directly by FastAPI `StaticFiles` at `/` so target office machines do not require Node.js at runtime. |

---

## 3. Existing Authentication, Authorization, Roles, Sessions & Identity Sources

### 3.1 Verified Identity Source (`data/stores/user_registry.json`)
- **File Path:** `data/stores/user_registry.json` (loaded via `watson.governance.abac_engine.load_user_registry`).
- **Defined Roles (8):**
  - `ADMIN`: `allowed_sensitivity_levels`: `["PUBLIC", "INTERNAL", "RESTRICTED", "CONFIDENTIAL"]`, `capabilities`: `["*"]`.
  - `COMPLIANCE_OFFICER`: `allowed_sensitivity_levels`: `["PUBLIC", "INTERNAL", "RESTRICTED", "CONFIDENTIAL"]`, `capabilities`: `["*"]`.
  - `SPOC`: `allowed_sensitivity_levels`: `["PUBLIC", "INTERNAL", "RESTRICTED", "CONFIDENTIAL"]`, `capabilities`: `["VECTOR_SEARCH", "SPARQL_SELECT", "HYBRID_SEARCH", "MANAGE_SPACE", "TAXONOMY_EDIT"]`.
  - `ANALYST`: `allowed_sensitivity_levels`: `["PUBLIC", "INTERNAL", "RESTRICTED"]`, `capabilities`: `["VECTOR_SEARCH", "SPARQL_SELECT", "HYBRID_SEARCH"]`.
  - `VIEWER`: `allowed_sensitivity_levels`: `["PUBLIC", "INTERNAL"]`, `capabilities`: `["VECTOR_SEARCH", "VIEW_PUBLIC"]`.
  - `RESEARCHER`, `COMMERCIAL_LEAD`, `EXTERNAL_PARTNER`: Restricted to `PUBLIC`/`INTERNAL` or `PUBLIC` with `VECTOR_SEARCH`.
- **Defined User Personas (7):**
  - `D4`: Elena Rostova (`ADMIN`, TAs: `["*"]`, Geos: `["*"]`)
  - `D3`: Dr. Sarah Chen (`VIEWER`, TAs: `["Oncology", "Cardiology", "Diabetes"]`, Geos: `["EU", "US", "Global"]`)
  - `U_ANALYST`: Marcus Vance (`ANALYST`)
  - `U_SPOC`: Dr. Aris Thorne (`SPOC`, Oncology)
  - `U_COMPLIANCE`: Compliance Lead (`COMPLIANCE_OFFICER`)
  - `U_COMMERCIAL`: Commercial Analyst (`COMMERCIAL_LEAD`)
  - `U_EXTERNAL`: External Auditor (`EXTERNAL_PARTNER`)

### 3.2 Verified Baseline Authentication & Session Mechanism (Security Gap Identified)
- **File Path:** `backend/app/main.py` (`CURRENT_USER_ID = "D4"`, `get_current_user()`, `/api/auth/current`, `/api/auth/personas`, `/api/auth/switch`).
- **Baseline Behavior (Verified Vulnerability):**
  1. `get_current_user(x_user_id: Optional[str] = Header(None))` reads the unverified `x-user-id` HTTP header or falls back to global process variable `CURRENT_USER_ID = "D4"` (Admin).
  2. If an unknown `x-user-id` is passed, lines 114–116 silently fall back to `"D4"` (`ADMIN`)!
  3. `/api/ingestion/upload` (`upload_document`) calls `Depends(get_current_user)` without any role or permission check—meaning any persona (`D3` Viewer, `U_ANALYST`, `U_EXTERNAL`, or unauthenticated caller) can upload and stage documents into `data/raw/`, `data/staging/`, `data/stores/lifecycle_store.json`, and `dedup_store.json`.
  4. `/api/documents/{doc_id}/archive` and `/api/documents/{doc_id}/reinstate` also lack role checks.
  5. In `frontend/src/App.tsx`, the `📥 Ingestion Console` sidebar tab is visible and accessible to every persona, and `frontend/src/services/api.ts` does not attach session tokens or CSRF tokens.

---

## 4. Ingestion Console, HITL Workbench & Document Library

| Component / Route | File Path & Function | Data Flow & Stores Touched |
| :--- | :--- | :--- |
| **Ingestion Console UI** | `frontend/src/App.tsx` (`activeTab === 'ingestion'`, `handleFileUpload`) | Calls `api.uploadDocument(file)` $\rightarrow$ `POST /api/ingestion/upload`. Transitions UI to `hitl` tab on success. |
| **Upload Endpoint** | `backend/app/main.py` (`POST /api/ingestion/upload` $\rightarrow$ `upload_document`) | Validates extension (`.pdf`, `.docx`, `.pptx`, `.txt`) and size ($\le 50\text{ MB}$), writes temp file, and invokes `coordinator.stage_file(target, actor_id=user["user_id"])`. |
| **Ingestion Coordinator** | `backend/watson/ingestion/ingestion_coordinator.py` (`IngestionCoordinator.stage_file`) | 1. Parses file via `watson.ingestion.parser.parse_document` (`parser.py`).<br>2. Checks SHA-256 deduplication via `watson.ingestion.dedup_detector.check_deduplication` (`dedup_store.json`).<br>3. Chunks document via `watson.ingestion.chunker.chunk_parsed_document` (Strategy B).<br>4. Scans and masks PII via `watson.ingestion.pii_detector` (`detect_pii_entities`, `mask_pii_text`).<br>5. Extracts 15-field metadata via `MetadataExtractor` (`metadata_extractor.py`) and scores quality (`quality_scorer.py`) + expiry (`expiry_manager.py`).<br>6. Atomically commits raw file (`data/raw/<doc_id>/<filename>`), staging JSON (`data/staging/<doc_id>_staged.json`), `data/stores/lifecycle_store.json` (`UNDER_REVIEW`), and `dedup_store.json` via `staging_state.commit_files`. |
| **Pending Documents API** | `backend/app/main.py` (`GET /api/ingestion/pending` $\rightarrow$ `coordinator.pending_documents`) | Reads `data/staging/*_staged.json` and `lifecycle_store.json` for `UNDER_REVIEW` records. |
| **HITL Workbench UI & API** | `frontend/src/App.tsx` (`activeTab === 'hitl'`, `handleApproveDocument`), `frontend/src/components/ReviewDocument.tsx`, `POST /api/ingestion/review` | Calls `coordinator.review_and_activate()`. Enforces `reviewer_role in ("ADMIN", "SPOC", "COMPLIANCE_OFFICER")` and `pii_override` if critical PII is present. On `APPROVE`, transitions state to `ACTIVE` and triggers `Layer2EnrichmentPipeline.enrich_document_package()`, then reloads FAISS index and RDF graph in `assembler`. |
| **Document Library UI & API** | `frontend/src/App.tsx` (`activeTab === 'library'`), `GET /api/documents`, `POST /api/documents/{doc_id}/archive`, `POST /api/documents/{doc_id}/reinstate` | Filters `lifecycle_store.json` through `abac_engine.evaluate_access()` per user and allows archiving/reinstating documents. |

---

## 5. `seed_vocabularies.json` and All Curated Vocabulary Consumers

- **Source File:** `data/seed/seed_vocabularies.json` (Schema v1.0, Vocabulary v0.1-poc, 7 `therapeutic_areas`, 10 `brands`, 10 `drugs`, 10 `indications`, 9 `geographies`, 6 `study_templates` = 52 canonical concepts).
- **Verified Consumers Across Repository:**
  1. `backend/watson/shared/config.py`: Defines `SEED_VOCABULARIES_FILE = SEED_DATA_DIR / "seed_vocabularies.json"`.
  2. `backend/watson/ingestion/metadata_extractor.py` (`MetadataExtractor`, `_load_vocab_file`): Loads `brands`, `indications`, `therapeutic_areas`, and `geographies` from `seed_vocabularies.json` for Layer 1 document metadata extraction.
  3. `backend/watson/ingestion/pii_detector.py` (`_load_pharma_exclusions`): Loads canonical names and aliases from `seed_vocabularies.json` so drug/brand/indication names are never falsely flagged as `PERSON` PII.
  4. `backend/watson/semantics/entity_resolver.py` (`EntityResolver._load_knowledge`): Loads all 6 vocabulary families (`Brand`, `Drug`, `Indication`, `TherapeuticArea`, `Geography`, `StudyType`) with canonical IDs (`brand:keytruda`, `drug:pembrolizumab`, etc.), URIs (`http://watson.pharma.org/entity/<prefix>/<local_name>`), and aliases for 4-tier entity resolution.
  5. `backend/watson/semantics/enrichment_pipeline.py` (`Layer2EnrichmentPipeline._init_spacy_pipeline`): Seeds spaCy `EntityRuler` patterns from `seed_vocabularies.json`.
  6. `backend/watson/semantics/taxonomy_manager.py` (`init_taxonomy_from_seed`): Initializes `data/stores/taxonomy_store.json` from `therapeutic_areas`, `indications`, and `study_templates`.
  7. `backend/watson/semantics/populate_graph.py` (`build_seed_kg`): Generates static canonical RDF triples in `ontology/pharma_kg.ttl` from `seed_vocabularies.json` and `ontology/pharma.ttl`.

---

## 6. Layer 2 Graph, Ontology Construction & SPARQL Studio

- **Ontology & Graph Artifacts:**
  - `ontology/pharma.ttl`: Base OWL 2 RL / RDFS domain ontology (`http://watson.pharma.org/ontology/`, 488 lines, 14 classes including `PharmaEntity`, `Drug`, `BiologicDrug`, `SmallMoleculeDrug`, `Brand`, `Indication`, `TherapeuticArea`, `Geography`, `HCP`, `KeyOpinionLeader`, `StudyType`, `Document`, `MarketResearchDocument`, `HCPSentimentStudy`, `DocumentChunk`, `KnowledgeSpace`, `LineageRecord`).
  - `ontology/pharma_kg.ttl`: Asserted knowledge graph (4,784 lines) containing canonical entities, document/chunk nodes, sentiment assertions, and lineage records.
  - `ontology/pharma_kg_inferred.ttl`: Materialized OWL 2 RL inferred graph (13,008 lines, ~10,047–10,151 triples).
- **Graph Construction & Enrichment:**
  - Static seed generation: `backend/watson/semantics/populate_graph.py` (`build_seed_kg`).
  - Runtime incremental enrichment: `backend/watson/semantics/enrichment_pipeline.py` (`Layer2EnrichmentPipeline.generate_rdf_triples`), which adds document, chunk, entity mention, sentiment assertion, knowledge space, and lineage triples and serializes back to `ontology/pharma_kg.ttl`.
- **SPARQL Studio & Query Execution:**
  - Backend routes: `GET /api/graph/sparql/templates` and `POST /api/graph/sparql` in `backend/app/main.py` (lines 412–782).
  - Standalone service: `backend/watson/semantics/sparql_service.py` and `queries/queries.sparql` + `queries/query_results/Q01..Q11*.json`.
  - Enforces read-only guard (`DROP`, `DELETE`, `INSERT`, `CLEAR`, `LOAD`, `CREATE` blocked with HTTP 403) and executes against `assembler.graph` (`rdflib.Graph`), logging `SPARQL_QUERY` audit events.

---

## 7. Layer 3 Retrieval, FAISS Indexes, Embeddings & Research Copilot

- **Vector Store & Embeddings (`backend/watson/retrieval/vector_index.py`):**
  - `VectorIndexManager` loads `data/indexes/Watson.faiss` (80 vectors, 384-dim `IndexFlatIP`) and `data/indexes/chunk_uri_map.json`.
  - Uses `sentence-transformers/all-MiniLM-L6-v2` (384-dim normalized cosine similarity embeddings).
  - `search_with_prefilter(query, allowed_chunk_uris, top_k)` strictly reconstructs a temporary FAISS sub-index containing *only* ABAC-authorized vector IDs before scoring similarity.
- **15-Stage GraphRAG Pipeline & Research Copilot (`backend/watson/retrieval/graphrag_assembler.py`):**
  - `GraphRAGAssembler.retrieve_and_synthesize(query, user_id, top_k)` orchestrates:
    - Stages 1–3: Query registration, ABAC user clearance (`get_allowed_chunk_uris`), and deterministic intent/route classification via `QueryRouter` (`backend/watson/retrieval/query_router.py`). Conversational queries (`GREETING`, `SMALL_TALK`, `CAPABILITY_HELP`) short-circuit at Stage 3 (`CONVERSATIONAL_GATE`).
    - Stages 4–7: Entity recognition, 4-tier resolution via `EntityResolver`, taxonomy traversal via `TaxonomyManager`, and route selection (`SPARQL`, `VECTOR`, `HYBRID`).
    - Stages 8–11: Bounded RDF graph traversal (`_query_semantic_graph_facts`), ABAC pre-filtered FAISS vector search, indication/geography-aligned reranking, and construction of `EvidenceCoverageMatrix`.
    - Stages 12–15: Synthesis via `QwenInterface.generate_answer` (`backend/watson/retrieval/qwen_interface.py` — local Ollama `qwen3:latest` with deterministic citation-grounded synthesis fallback `_deterministic_grounded_synthesis`), 11-axis guardrail validation (`WatsonGuardrails` in `backend/watson/retrieval/guardrails.py`), claim extraction, and lineage binding.
  - Exposed via `POST /api/search`, `POST /api/chat`, and `GET /api/chat/stream` (SSE).

---

## 8. Current KG Explorer & Visualization Dependencies

- **Current Implementation (`frontend/src/App.tsx`, lines 1229–1257):**
  - Currently a static summary card (`activeTab === 'kg'`) showing 4 hardcoded metric boxes (`Total Triples: 10,047`, `Ontology Classes: 14`, `Deductive Ratio: 2.65x`, `Restricted Chunks: 14`) with no interactive graph canvas, no nodes/edges rendering, no data catalog, and no entity mapping inspection.
- **Frontend Dependencies (`frontend/package.json`):**
  - Only `react` (`^18.3.1`), `react-dom` (`^18.3.1`), and `lucide-react` (`^0.378.0`) are installed. No third-party graph library (e.g., Cytoscape, D3, ReactFlow) is bundled in `package.json`.
  - Therefore, building an interactive HTML5 SVG/Canvas force-directed & hierarchical graph explorer directly in React + TypeScript (with pan, zoom, node dragging, selection, details side panel, search, filters, neighbourhood isolation, legend, and live refresh diffing) integrates cleanly with zero external npm dependencies required.

---

## 9. Existing Tests, Synthetic Corpus & Known-Answer Queries

- **Synthetic Corpus (`data/raw/` & `data/stores/lifecycle_store.json`):**
  - 15 governed synthetic documents (`watson:Doc_001` through `watson:Doc_015`, 80 chunks in `chunk_uri_map.json`) spanning PDF, DOCX, PPTX, and TXT across Oncology (Keytruda, Opdivo), Immunology (Dupixent), Cardiology (Entresto), Metabolic (Farxiga, Jardiance), Rare Disease (Spinraza, Trikafta), Neurology (Tecfidera), and Respiratory (Xolair).
  - Verified Dupixent documents:
    - `watson:Doc_005`: `HCP_Perception_Immunology_Dupixent_AD_US.pdf` (US Atopic Dermatitis HCP perception survey).
    - `watson:Doc_014`: `Market_Access_Immunology_Dupixent_AD_India.txt` (India Atopic Dermatitis market access insight).
- **Existing Test Suite (`tests/`):**
  - `tests/test_live_conversational_http.py`: FastAPI `TestClient` tests for conversational gate and Dupixent US HCP grounded synthesis (`POST /api/chat`).
  - `tests/test_question_answering_regression.py`: 8 question-type regression tests (Keytruda NSCLC, Farxiga vs Jardiance CKD, Farxiga temporal sentiment, Keytruda lineage, etc.).
  - `tests/test_semantic_graphrag.py`: 15-stage pipeline trace and ABAC isolation (`D3` Viewer vs `D4` Admin).
  - `tests/test_semantic_invariants_and_routing.py`: Invariants A–J (Keytruda never inherits Asthma, Dupixent US cites `Doc_005` not `Doc_014`, Xolair India cites `Doc_008`, etc.).
  - `tests/test_systemic_architecture_repair.py`: T01–T10 mandatory regression suite + ablation evaluation.
  - `tests/test_targeted_qa_and_conversation.py`: G1–G10 targeted QA and C1–C12 multi-turn conversational tests.
  - `tests/test_upload_regression.py`: Layer 1 upload, deduplication, rollback, and HITL activation tests.

---

## 10. Verified Environment Constraints & Compatibility Strategy

1. **Sandbox VM Offline Execution:**
   - Outbound network access from the VM shell and `pip install` / `npm install` are disabled by environment policy.
   - The authoritative Databricks Pharmaceuticals v1 MVM schema metadata (`data-models/pharmaceuticals/v1/mvm/model.json` and `schemas/pharmaceuticals_product_schema_v1_mvm.sql`, comprising 15 products, 594 attributes, and 141 foreign keys across `market authorization` and `product identity` subdomains) was inspected from the official GitHub repository and saved as a verified local fixture (`data/fixtures/databricks_pharmaceuticals_v1_mvm_model.json`) while the ingestion module (`backend/watson/ingestion/databricks_metadata_ingestor.py`) supports both live HTTP fetching from the authoritative GitHub URL and deterministic local fixture ingestion.
2. **Runtime Library Compatibility Bridge:**
   - In the target Office environment, `rdflib`, `faiss-cpu`, `spacy`, `sentence-transformers`, `pymupdf`, and `rapidfuzz` are installed. In this sandbox test container, Python 3.11 has `fastapi`, `uvicorn`, `pydantic`, `httpx`, `numpy`, `scipy`, `pypdf`, `pdfplumber`, `python-docx`, and `python-pptx`, while C/NLP wheels (`rdflib`, `faiss`, `spacy`, `pymupdf`, `rapidfuzz`, `torch`, `sentence_transformers`) are not pre-installed.
   - To ensure all backend code and automated tests execute against the real FastAPI app, real Turtle files (`pharma.ttl`, `pharma_kg.ttl`, `pharma_kg_inferred.ttl`), and real binary `Watson.faiss` index in both environments, lightweight local fallback shims are provided ONLY when `ImportError` occurs, preserving native library usage whenever installed.
