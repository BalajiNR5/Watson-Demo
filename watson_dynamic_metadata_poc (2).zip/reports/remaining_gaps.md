# Watson Intelligence Platform — Remaining Gaps & Production Recommendations

## 1. Verified Scope Completion

All requirements specified for the proof of concept have been implemented, tested (`100 / 100` automated tests passing across 8 suites), and verified in the live application:
- Administrator-only access control (`ADMIN` / `documents:ingest`) across all UI and backend ingestion entry points.
- Dynamic ingestion of the Databricks Pharmaceuticals Product MVM (`v1`) schema (**15 products**, **594 attributes**, **83 foreign keys** across *Market Authorization* and *Product Identity*).
- Non-destructive compatibility and mapping engine preserving `data/seed/seed_vocabularies.json` byte-for-byte (`3 EXACT`, `4 PROPOSED`, `3 CONFLICT`, `9 UNRESOLVED`).
- Incremental Layer 2 RDF overlay (`ontology/databricks_product_mvm_overlay.ttl`) and non-destructive Layer 3 preservation.
- Interactive Visual Graph Explorer (Views A, B, C), Interactive Node Data Catalog, and Entity Mapping Explorer with live refresh diffing.

---

## 2. Remaining Production Gaps & Next-Phase Recommendations

1. **External Enterprise IdP (OIDC / SAML 2.0) Integration**:
   - *Current POC State*: Authentication uses server-side HMAC-SHA256 signed tokens (`WATSON_SESSION_SECRET`), PBKDF2-HMAC-SHA256 password verification (`WATSON_ADMIN_PASSWORD_HASH`), and the local `data/stores/user_registry.json` role registry. In demo mode (`WATSON_STRICT_TOKEN_ONLY=0`), the topbar Persona Switcher allows switching between registered personas to demonstrate Admin vs. Non-Admin behavior interactively.
   - *Production Recommendation*: Set `WATSON_STRICT_TOKEN_ONLY=1` in production and integrate `extract_authenticated_user` in `backend/app/security/auth.py` with an enterprise OIDC provider (e.g., Okta, Azure AD / Entra ID, or Keycloak) validating RS256/ES256 JWTs and mapping IdP group claims directly to `documents:ingest`.

2. **Governance Workflow for Promoting `PROPOSED` and Resolving `CONFLICT` Mappings**:
   - *Current POC State*: Candidate mappings (`combination_product`, `regulatory_identifier`, `lifecycle`, `labeling` -> `PROPOSED`) and granularity/scope conflicts (`medicinal_product`, `drug_product`, `masterdata.country` -> `CONFLICT`) are explicitly surfaced in `outputs/semantic_mapping_report.json` and the Graph Explorer UI with dashed amber/red styling so they are never treated as verified equivalences.
   - *Production Recommendation*: Add an ontology-steward approval action in the HITL Workbench allowing authorized ontology governors to promote a `PROPOSED` mapping to `EXACT` or define a formal OWL property-chain / country-to-region roll-up rule (`masterdata.country` -> `geo:eu` / `geo:global`).

3. **Cross-Domain MVM Ingestion Beyond the `Product` Domain**:
   - *Current POC State*: The 46 cross-domain foreign keys originating from the `Product` domain (referencing `masterdata.country`, `masterdata.atc_classification`, `masterdata.legal_entity`, `clinical.clinical_study`, `manufacturing.manufacturing_site`, etc.) are captured and rendered as `EXTERNAL_SCHEMA_ENDPOINT` nodes.
   - *Production Recommendation*: Extend `DatabricksProductMetadataIngestor` to optionally ingest the full `Masterdata` and `Clinical` domains when full cross-domain table schemas are required.

4. **Local Ollama LLM (`qwen3:latest`) vs. Deterministic Grounded Synthesis**:
   - *Current POC State*: When a local Ollama daemon (`http://127.0.0.1:11434`) is not running in an air-gapped container, `GraphRAGAssembler` automatically falls back to its built-in `DETERMINISTIC_GROUNDED_SYNTHESIS` engine, which produces citation-backed answers verified by all 11 QA regression tests.
   - *Production Recommendation*: Connect a local GPU-backed Ollama instance serving `qwen3:latest` for generative natural-language phrasing while retaining the existing post-generation citation and indication-alignment guardrails.
