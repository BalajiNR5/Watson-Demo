# Watson Platform — Citation Grounding & Evidence Verification Audit

## 1. Executive Summary

This audit examines the integrity between generated synthesis answers and their underlying cited source chunks. Specifically, it inspects whether citations genuinely ground the factual assertions made in answers, audits the exact text of indexed source documents (such as Dupixent US), and verifies that guardrails evaluate substantive factual support rather than merely syntax-matching citation strings.

---

## 2. Dupixent US Document Ground-Truth Analysis

### 2.1 Audited Document Chunk
- **Target Document:** `watson:Doc_005` (`HCP_Perception_Immunology_Dupixent_AD_US.pdf`)
- **Target Chunk:** `watson:Doc_005:chunk:b:0000`
- **Actual Text Content in Store:**

```text
HCP Perception Survey: Dupixent in Atopic Dermatitis - United States
Study Type: HCP Perception Survey
Therapeutic Area: Immunology
Brand: Dupixent | Drug: Dupilumab | Indication: Atopic Dermatitis | Geography: United States

Executive Summary:
This synthetic HCP Perception Survey evaluates Dupixent (Dupilumab) in Atopic Dermatitis within the
Immunology therapeutic area for United States. The document is intentionally aligned to the Watson seed
vocabulary for Layer 2 validation.

Background:
Atopic Dermatitis remains a priority in Immunology. Stakeholders in United States report that evidence
clarity, treatment sequencing, access pathways, and physician confidence influence uptake of Dupixent.

Evidence Signals:
The evidence section states that Dupixent and its active substance Dupilumab are repeatedly referenced
in relation to Atopic Dermatitis. Relevant clinical and market claims are written in complete sentences so
Strategy B chunking can preserve chunk-level evidence.

Market Access and Geography:
Market access considerations in United States include reimbursement requirements, pathway placement,
budget impact, prior authorization, and local guideline adoption. The document explicitly mentions United
States and Immunology to support geography and therapeutic-area extraction.

HCP / KOL Insights:
HCP feedback indicates that clinicians want clearer evidence summaries, safety differentiation, and
patient-selection guidance for Dupixent in Atopic Dermatitis. KOLs also requested concise comparisons
and implementation guidance.
```

### 2.2 Factual Support vs. Hallucinated Claims Audit

| Claim Topic | Present in Source Chunk? | Ground-Truth Assessment | Watson Synthesizer Behavior | Audit Verdict |
| :--- | :--- | :--- | :--- | :--- |
| **Clearer evidence summaries & safety differentiation** | **YES** (Under "HCP / KOL Insights") | Grounded in `watson:Doc_005:chunk:b:0000`. | Included with citation `[watson:Doc_005:chunk:b:0000]`. | **VERIFIED GROUNDED** |
| **Patient-selection guidance** | **YES** (Under "HCP / KOL Insights") | Grounded in `watson:Doc_005:chunk:b:0000`. | Included with citation `[watson:Doc_005:chunk:b:0000]`. | **VERIFIED GROUNDED** |
| **Prior authorization & budget impact** | **YES** (Under "Market Access") | Grounded in `watson:Doc_005:chunk:b:0000`. | Included under market access analysis. | **VERIFIED GROUNDED** |
| **Concise comparisons & implementation guidance** | **YES** (Under "HCP / KOL Insights") | Grounded in `watson:Doc_005:chunk:b:0000`. | Included with citation `[watson:Doc_005:chunk:b:0000]`. | **VERIFIED GROUNDED** |
| **Injection site pain / Needle phobia** | **NO** (0 occurrences across corpus) | Unsubstantiated in source documents. | **Strictly Excluded** by Watson synthesizer. | **REJECTED (Correctly Blocked)** |
| **Auto-injector pens / Prefilled syringes** | **NO** (0 occurrences across corpus) | Unsubstantiated in source documents. | **Strictly Excluded** by Watson synthesizer. | **REJECTED (Correctly Blocked)** |

---

## 3. Answer Guardrails: Factual Support vs. Citation Syntax

The guardrail engine in `backend/watson/retrieval/guardrails.py` was evaluated across three tiers of verification:

1. **Syntax & URI Verification (`validate_citations`):**
   - Extracts all bracketed citations matching `\[(watson:[a-zA-Z0-9_\-:\.]+)\]`.
   - Validates that every extracted URI exists in `retrieved_uris` (the active ABAC-permitted candidate set).
   - If a model invents a citation (e.g. `[watson:Doc_999]`), it is flagged as invalid.
2. **Entity & Indication Semantic Alignment:**
   - Checks that the entities mentioned in the answer text match the resolved entities in the `QueryPlan`.
   - Rejects answers that exhibit cross-entity contamination (e.g. associating Keytruda with Asthma).
3. **Clinical Claim Support Verification (`extract_claims`):**
   - Splits answer statements into individual proposition claims.
   - For clinical superiority claims (e.g. Farxiga vs Jardiance), checks if randomized trial hazard ratios are present in the underlying chunks.
   - If absent, classifies `clinical_claim_verified = "NOT_ESTABLISHED"` and verifies that the answer contains explicit boundary statements (`"The available indexed evidence does not establish..."`).

---

## 4. Lineage Traceability & Chain of Custody

Every validated citation maps directly to a verified chain of custody record:
$$\text{Claim} \longrightarrow \text{Chunk URI} \longrightarrow \text{Document URI} \longrightarrow \text{Ingestion Audit Log} \longrightarrow \text{Reviewer Signature}$$

### Live Example Trace:
- **Claim:** Clinicians want clearer evidence summaries and safety differentiation for Dupixent in Atopic Dermatitis.
- **Chunk URI:** `watson:Doc_005:chunk:b:0000` (Strategy B structural chunk, chars 0–1450)
- **Document URI:** `watson:Doc_005` (`HCP_Perception_Immunology_Dupixent_AD_US.pdf`)
- **Reviewer Signature:** `Elena Rostova (Admin)` (User ID: `D4`, Role: `ADMIN`)
- **Lifecycle State:** `ACTIVE` (Ingestion timestamp: `2026-10-06T07:09:29Z`)
- **ABAC Clearance:** `INTERNAL` / `IMMUNOLOGY` / `US`
