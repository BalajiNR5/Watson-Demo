# Ingestion correction: validation results

**Result: 49 checks passed.**

## Pipeline and HTTP API: 26 passed

The real FastAPI application ran against temporary copies of the document
stores, ontology and FAISS index, using actual local MiniLM embeddings, spaCy,
RDFLib and parsers. No user working data was used as test output.

Covered: valid staging; pending duplicate idempotency; metadata/quality failure
and retry; injected commit failure and rollback; legacy orphan registration;
legacy expiry objects; simultaneous duplicate uploads; two different files with
the same name; empty/unsupported files and filename traversal; corrupt registry
preservation; PII detection/redaction; failed indexing and successful retry;
approval with immediate retrieval; approved/rejected duplicate rejection;
pending-review isolation; PDF/DOCX/PPTX/TXT parsing; read-only dedup checks;
interrupted-journal recovery; health responsiveness during a slow upload;
audit-write failure followed by recovery; backup-backed legacy date migration;
nested seed vocabulary and metadata; reopening an unowned legacy attempt; and
recovery from a truncated legacy staging file.

The runnable suite is `tests/test_upload_regression.py`. It uses temporary
state and requires an approved test environment with pytest/httpx, runtime
packages, and local MiniLM/spaCy model files. It does not install missing items.

## Built React application: 6 passed

The production JavaScript bundle ran in jsdom against a live local FastAPI
server. There were **zero React rendering errors** in these workflows:

1. Upload opens the review screen.
2. Page reload recovers pending review from disk.
3. Repeated pending upload reopens the existing review.
4. Legacy object-shaped expiry and absent hash render safely.
5. Approval completes and the document library renders.
6. An approved duplicate displays an error while the app stays usable.

## Existing Office-mode regression checks: 17 passed

Offline settings, removed cloud transports, no installer/child-process calls in
the Office launcher, local-only server binding, missing-dependency reporting,
tokenizer-download blocking, Ollama transport behavior and unchanged seed data.

## Build and integrity

- TypeScript check and Vite production build: passed.
- Python syntax checks: passed.
- Original supplied data/ontology/query files: unchanged in the delivery.
- Update folder excludes documents, indexes, ontology and dedup/audit stores.
- ZIP CRC and referenced production asset checks: passed.

## Environment and limits

Tests ran on Linux with Python 3.12.14, CPU PyTorch 2.14.1, Transformers 4.57.6,
Sentence Transformers 3.4.1, spaCy 3.8.16/en_core_web_sm 3.8.0, FAISS 1.15.1,
FastAPI 0.162.0 and RDFLib 7.6.0. The test dependency set is validation evidence,
not an instruction to replace packages on a managed laptop.

Native Chromium could not be launched successfully in this build environment;
the UI checks above are explicitly DOM workflow checks, not a Windows browser
certification. Actual Qwen3 generation was not part of these ingestion tests.
The Office Ollama connection remains local; no cloud provider was introduced.
The JSON-backed demo remains intended for a single local server process.
