export interface UserProfile {
  user_id: string;
  name: string;
  role: string;
  permissions?: string[];
  can_ingest?: boolean;
  authenticated?: boolean;
  auth_method?: string;
  allowed_therapeutic_areas: string[];
  allowed_geographies: string[];
  access_token?: string;
  csrf_token?: string;
}

export interface DocumentRecord {
  document_uri: string;
  source_filename: string;
  format: string;
  lifecycle_state: string;
  sensitivity_level: string;
  allowed_therapeutic_areas: string[];
  allowed_geographies: string[];
  quality_score: number;
  expiry_date?: string;
  ingest_timestamp: string;
}

export interface SearchResponse {
  query: string;
  user_id: string;
  role: string;
  route: string;
  allowed_chunk_uris: string[];
  scored_chunks: Array<{
    chunk_uri: string;
    doc_uri: string;
    content: string;
    similarity: number;
    quality_score: number;
    composite_score: number;
    page_number?: number;
    section_title?: string;
  }>;
  kg_neighbors: Array<{
    subject: string;
    predicate: string;
    object: string;
  }>;
  stage_traces: Array<{
    stage_number: number;
    stage_name: string;
    input_count: number;
    output_count: number;
    elapsed_ms: number;
  }>;
  correlation_id: string;
  total_latency_ms: number;
}

export interface StageTraceItem {
  stage_number: number;
  stage_name: string;
  status: 'PENDING' | 'RUNNING' | 'COMPLETED' | 'SKIPPED' | 'BLOCKED' | 'FAILED';
  summary: string;
  timestamp: string;
  input_count: number;
  output_count: number;
  details: Record<string, any>;
  elapsed_ms: number;
}

export interface KGFact {
  subject: string;
  predicate: string;
  object: string;
  assertion_type: 'ASSERTED' | 'INFERRED' | 'SEED';
  source_doc_uri?: string;
  date?: string;
  score?: number;
}

export interface LineageRecord {
  claim_id: string;
  chunk_uri: string;
  document_uri: string;
  source_filename: string;
  page_number: number;
  char_offsets?: string;
  reviewer_id: string;
  approval_date?: string;
  lifecycle_state: string;
  quality_score: number;
  rdf_path?: string;
  audit_event_id?: string;
}

export interface ChatResponse {
  answer_id: string;
  correlation_id: string;
  query: string;
  route: string;
  answer: string;
  citations: Array<{
    source_uri: string;
    doc_uri: string;
    excerpt: string;
    score: number;
    page_number?: number;
  }>;
  scored_chunks: any[];
  kg_facts: KGFact[];
  lineage_records: LineageRecord[];
  live_stages: StageTraceItem[];
  guardrail_status: string;
  model_status: string;
  active_provider: string;
  latency_ms: number;
  user_role: string;
  pipeline_execution_status?: string;
  answer_grounding_status?: string;
  answer_relevance_status?: string;
  quality_diagnostics?: Record<string, any>;
  evidence_gap_detected?: boolean;
  query_plan?: any;
  evidence_set?: any;
  answer_plan?: any;
  intent_match_status?: string;
  entity_coverage_status?: string;
  geography_alignment_status?: string;
  answer_completeness_status?: string;
  claim_grounding_status?: string;
  citation_validity_status?: string;
  conversation_intent?: string;
}

export interface SparqlTemplate {
  id: string;
  name: string;
  category: string;
  description: string;
  sparql: string;
}

export interface SparqlResponse {
  status: string;
  query: string;
  latency_ms: number;
  triple_count: number;
  columns: string[];
  row_count: number;
  results: Array<Record<string, string>>;
  user_id: string;
  user_role: string;
}

const API_BASE = '/api';

let activeAccessToken: string | null = null;
let activeCsrfToken: string | null = null;
let activeUserId: string | null = null;

function buildAuthHeaders(extra: Record<string, string> = {}): Record<string, string> {
  const headers: Record<string, string> = { ...extra };
  if (activeAccessToken) {
    headers['Authorization'] = `Bearer ${activeAccessToken}`;
  }
  if (activeCsrfToken) {
    headers['X-CSRF-Token'] = activeCsrfToken;
  }
  if (activeUserId) {
    headers['x-user-id'] = activeUserId;
  }
  return headers;
}

function captureSessionTokens(data: any) {
  if (!data) return;
  const target = data.current_user || data;
  if (target.access_token) {
    activeAccessToken = target.access_token;
  }
  if (target.csrf_token) {
    activeCsrfToken = target.csrf_token;
  }
  if (target.user_id) {
    activeUserId = target.user_id;
  }
}

async function handleResponse<T = any>(res: Response, fallbackMsg: string): Promise<T> {
  if (!res.ok) {
    let detail = fallbackMsg;
    try {
      const err = await res.json();
      detail = err.detail || err.message || fallbackMsg;
    } catch {
      try {
        const text = await res.text();
        if (text) detail = `${fallbackMsg} (${res.status}): ${text.slice(0, 150)}`;
      } catch {
        detail = `${fallbackMsg} (${res.status}: ${res.statusText})`;
      }
    }
    throw new Error(detail);
  }
  return res.json();
}

export const api = {
  async getHealth() {
    const res = await fetch(`${API_BASE}/health`, { headers: buildAuthHeaders() });
    return handleResponse(res, 'Health check failed');
  },

  async getCurrentUser(): Promise<UserProfile> {
    const res = await fetch(`${API_BASE}/auth/current`, { headers: buildAuthHeaders() });
    const data = await handleResponse<UserProfile>(res, 'Fetch current user failed');
    captureSessionTokens(data);
    return data;
  },

  async getPersonas(): Promise<UserProfile[]> {
    const res = await fetch(`${API_BASE}/auth/personas`, { headers: buildAuthHeaders() });
    return handleResponse(res, 'Fetch personas failed');
  },

  async switchPersona(user_id: string) {
    const res = await fetch(`${API_BASE}/auth/switch`, {
      method: 'POST',
      headers: buildAuthHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify({ user_id }),
    });
    const data = await handleResponse(res, 'Switch persona failed');
    captureSessionTokens(data);
    return data;
  },

  async login(user_id: string, password?: string, bootstrap_token?: string) {
    const res = await fetch(`${API_BASE}/auth/login`, {
      method: 'POST',
      headers: buildAuthHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify({ user_id, password, bootstrap_token }),
    });
    const data = await handleResponse(res, 'Authentication failed');
    captureSessionTokens(data);
    return data;
  },

  async logout() {
    const res = await fetch(`${API_BASE}/auth/logout`, {
      method: 'POST',
      headers: buildAuthHeaders(),
    });
    activeAccessToken = null;
    activeCsrfToken = null;
    return handleResponse(res, 'Logout failed');
  },

  async getIngestionConsole() {
    const res = await fetch(`${API_BASE}/ingestion/console`, {
      headers: buildAuthHeaders(),
    });
    return handleResponse(res, 'Ingestion console authorization check failed');
  },

  async getDocuments(): Promise<DocumentRecord[]> {
    const res = await fetch(`${API_BASE}/documents`, { headers: buildAuthHeaders() });
    return handleResponse(res, 'Fetch documents failed');
  },

  async getPendingDocuments(): Promise<any[]> {
    const res = await fetch(`${API_BASE}/ingestion/pending`, { headers: buildAuthHeaders() });
    return handleResponse(res, 'Fetch pending documents failed');
  },

  async uploadDocument(file: File) {
    const data = new FormData();
    data.append('file', file);
    const res = await fetch(`${API_BASE}/ingestion/upload`, {
      method: 'POST',
      headers: buildAuthHeaders(),
      body: data,
    });
    return handleResponse(res, 'Upload failed');
  },

  async uploadBatchDocuments(files: File[]) {
    const data = new FormData();
    files.forEach((f) => data.append('files', f));
    const res = await fetch(`${API_BASE}/ingestion/upload/batch`, {
      method: 'POST',
      headers: buildAuthHeaders(),
      body: data,
    });
    return handleResponse(res, 'Batch upload failed');
  },

  async importDocument(source_filename: string) {
    const res = await fetch(`${API_BASE}/ingestion/import`, {
      method: 'POST',
      headers: buildAuthHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify({ source_filename }),
    });
    return handleResponse(res, 'Document import failed');
  },

  async retryIngestion(document_uri: string) {
    const res = await fetch(`${API_BASE}/ingestion/retry`, {
      method: 'POST',
      headers: buildAuthHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify({ document_uri }),
    });
    return handleResponse(res, 'Retry ingestion failed');
  },

  async ingestDatabricksMetadata(payload: { fixture_path?: string; source_url?: string; prefer_remote?: boolean } = {}) {
    const res = await fetch(`${API_BASE}/ingestion/databricks/ingest`, {
      method: 'POST',
      headers: buildAuthHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify(payload),
    });
    return handleResponse(res, 'Databricks metadata ingestion failed');
  },

  async reviewDocument(payload: {
    document_uri: string;
    decision: 'APPROVE' | 'REJECT';
    review_note?: string;
    pii_override?: boolean;
    sensitivity_level?: string;
    allowed_therapeutic_areas?: string[];
    allowed_geographies?: string[];
    expiry_date?: string;
  }) {
    const res = await fetch(`${API_BASE}/ingestion/review`, {
      method: 'POST',
      headers: buildAuthHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify(payload),
    });
    return handleResponse(res, 'Review failed');
  },

  async archiveDocument(doc_id: string) {
    const res = await fetch(`${API_BASE}/documents/${doc_id}/archive`, {
      method: 'POST',
      headers: buildAuthHeaders(),
    });
    return handleResponse(res, 'Archive document failed');
  },

  async reinstateDocument(doc_id: string) {
    const res = await fetch(`${API_BASE}/documents/${doc_id}/reinstate`, {
      method: 'POST',
      headers: buildAuthHeaders(),
    });
    return handleResponse(res, 'Reinstate document failed');
  },

  async search(query: string, top_k: number = 5): Promise<SearchResponse> {
    const res = await fetch(`${API_BASE}/search`, {
      method: 'POST',
      headers: buildAuthHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify({ query, top_k }),
    });
    return handleResponse(res, 'Search request failed');
  },

  async chat(query: string, top_k: number = 5): Promise<ChatResponse> {
    const res = await fetch(`${API_BASE}/chat`, {
      method: 'POST',
      headers: buildAuthHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify({ query, top_k }),
    });
    return handleResponse(res, 'Chat request failed');
  },

  async getSpaces() {
    const res = await fetch(`${API_BASE}/spaces`, { headers: buildAuthHeaders() });
    return res.json();
  },

  async getSpaceHealth(space_id: string) {
    const res = await fetch(`${API_BASE}/spaces/${space_id}/health`, { headers: buildAuthHeaders() });
    return res.json();
  },

  async getAuditLogs(eventType?: string) {
    const url = eventType ? `${API_BASE}/audit/logs?event_type=${eventType}` : `${API_BASE}/audit/logs`;
    const res = await fetch(url, { headers: buildAuthHeaders() });
    return res.json();
  },

  async getTelemetryStats() {
    const res = await fetch(`${API_BASE}/telemetry/stats`, { headers: buildAuthHeaders() });
    return res.json();
  },

  async getQ10Audit() {
    const res = await fetch(`${API_BASE}/telemetry/q10-audit`, { headers: buildAuthHeaders() });
    return res.json();
  },

  async submitFeedback(correlation_id: string, rating: number, comment: string) {
    const res = await fetch(`${API_BASE}/feedback`, {
      method: 'POST',
      headers: buildAuthHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify({ correlation_id, rating, comment }),
    });
    return res.json();
  },

  async getSparqlTemplates(): Promise<{ templates: SparqlTemplate[] }> {
    const res = await fetch(`${API_BASE}/graph/sparql/templates`, { headers: buildAuthHeaders() });
    return handleResponse(res, 'Fetch SPARQL templates failed');
  },

  async executeSparql(query: string): Promise<SparqlResponse> {
    const res = await fetch(`${API_BASE}/graph/sparql`, {
      method: 'POST',
      headers: buildAuthHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify({ query }),
    });
    return handleResponse(res, 'SPARQL execution failed');
  },

  async getGraphExplorer() {
    const res = await fetch(`${API_BASE}/graph/explorer`, { headers: buildAuthHeaders() });
    return handleResponse(res, 'Fetch Graph Explorer payload failed');
  },

  async refreshGraphExplorer(payload: { fixture_path?: string; source_url?: string } = {}) {
    const res = await fetch(`${API_BASE}/graph/explorer/refresh`, {
      method: 'POST',
      headers: buildAuthHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify(payload),
    });
    return handleResponse(res, 'Refresh Graph Explorer failed');
  },

  async getDatabricksCatalog() {
    const res = await fetch(`${API_BASE}/graph/catalog`, { headers: buildAuthHeaders() });
    return handleResponse(res, 'Fetch Databricks Product Catalog failed');
  },

  async getSemanticMappings() {
    const res = await fetch(`${API_BASE}/graph/mappings`, { headers: buildAuthHeaders() });
    return handleResponse(res, 'Fetch Semantic Mapping Report failed');
  },
};
