import React from 'react';

export class ErrorBoundary extends React.Component<{ children: React.ReactNode }, { failed: boolean }> {
  state = { failed: false };
  static getDerivedStateFromError() { return { failed: true }; }
  componentDidCatch(error: Error) { console.error('Watson screen error', error); }
  render() {
    if (this.state.failed) return <main style={{ padding: 32, fontFamily: 'sans-serif' }}>
      <h2>This screen could not be displayed.</h2>
      <p>Reload Watson and open the HITL Workbench to recover pending documents. Do not upload the same file repeatedly.</p>
      <button onClick={() => window.location.reload()}>Reload Watson</button>
    </main>;
    return this.props.children;
  }
}
