import React from 'react';

export function displayExpiry(value: any): string {
  const date = value && typeof value === 'object' ? value.expiry_date : value;
  return typeof date === 'string' && date ? date : 'Not set';
}

export function displayValue(value: any, fallback = 'Not set'): string {
  if (value === null || value === undefined || value === '') return fallback;
  if (Array.isArray(value)) return value.map(v => displayValue(v, '')).filter(Boolean).join(', ') || fallback;
  return typeof value === 'object' ? fallback : String(value);
}

export function ReviewDocument({ document: doc, onReview, busy = false }: {
  document: any; onReview: (decision: 'APPROVE' | 'REJECT') => void; busy?: boolean;
}) {
  return <div className="card">
    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 16 }}>
      <h3>Review Document: {displayValue(doc.doc_id, doc.source_filename || 'Document')}</h3>
      <span className="badge badge-review">{displayValue(doc.lifecycle_state)}</span>
    </div>
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 20 }}>
      <div>
        <p>Filename: <strong>{displayValue(doc.source_filename)}</strong></p>
        <p>Format: <strong>{displayValue(doc.format)}</strong></p>
        <p>SHA-256: <code>{typeof doc.sha256 === 'string' ? doc.sha256.slice(0, 16) + '…' : 'Not available'}</code></p>
      </div>
      <div>
        <p>Therapeutic Area: <strong>{displayValue(doc.metadata?.therapeutic_area)}</strong></p>
        <p>Calculated Quality Score: <strong>{displayValue(doc.metadata?.quality_score)}</strong></p>
        <p>Default Expiry: <strong>{displayExpiry(doc.metadata?.expiry_date)}</strong></p>
      </div>
    </div>
    {doc.has_pii && <div role="note" style={{ padding: 12, background: '#fee2e2', marginBottom: 16 }}>
      <strong>PII detected during the governed scan.</strong>
      <p>{Array.isArray(doc.pii_findings) ? doc.pii_findings.length : 0} sensitive mentions were detected. Governed chunks are redacted. Critical findings require an explicit review override.</p>
    </div>}
    <div style={{ display: 'flex', gap: 12 }}>
      <button className="btn btn-primary" disabled={busy} onClick={() => onReview('APPROVE')}>
        {busy ? 'Processing review…' : 'Approve & Activate'}
      </button>
      <button className="btn btn-danger" disabled={busy} onClick={() => onReview('REJECT')}>Reject Document</button>
    </div>
  </div>;
}
