import React from 'react';

interface SafeMarkdownRendererProps {
  content: string;
  onCitationClick?: (uri: string) => void;
}

export const SafeMarkdownRenderer: React.FC<SafeMarkdownRendererProps> = ({
  content,
  onCitationClick,
}) => {
  if (!content) return null;

  // Helper to render inline elements (bold, code, citations)
  const renderInline = (text: string): React.ReactNode[] => {
    // Split by citations: [watson:...]
    const citationRegex = /\[(watson:[a-zA-Z0-9_\-:\.]+)\]/g;
    const parts: React.ReactNode[] = [];
    let lastIndex = 0;
    let match: RegExpExecArray | null;

    const processTextFormatting = (raw: string, keyPrefix: string): React.ReactNode[] => {
      const subParts: React.ReactNode[] = [];
      // Bold regex: \*\*(.+?)\*\*
      const boldRegex = /\*\*(.+?)\*\*/g;
      let bLastIdx = 0;
      let bMatch: RegExpExecArray | null;

      while ((bMatch = boldRegex.exec(raw)) !== null) {
        if (bMatch.index > bLastIdx) {
          subParts.push(raw.substring(bLastIdx, bMatch.index));
        }
        subParts.push(
          <strong key={`${keyPrefix}-b-${bMatch.index}`} style={{ fontWeight: 600, color: '#0f172a' }}>
            {bMatch[1]}
          </strong>
        );
        bLastIdx = boldRegex.lastIndex;
      }
      if (bLastIdx < raw.length) {
        subParts.push(raw.substring(bLastIdx));
      }
      return subParts;
    };

    while ((match = citationRegex.exec(text)) !== null) {
      if (match.index > lastIndex) {
        const textSegment = text.substring(lastIndex, match.index);
        parts.push(...processTextFormatting(textSegment, `t-${lastIndex}`));
      }
      const uri = match[1];
      parts.push(
        <button
          key={`cite-${match.index}`}
          type="button"
          onClick={() => onCitationClick && onCitationClick(uri)}
          title={`Inspect provenance for ${uri}`}
          style={{
            display: 'inline-flex',
            alignItems: 'center',
            fontSize: '11px',
            fontFamily: 'monospace',
            fontWeight: 500,
            padding: '1px 6px',
            margin: '0 3px',
            borderRadius: '4px',
            background: '#e0f2fe',
            color: '#0369a1',
            border: '1px solid #bae6fd',
            cursor: onCitationClick ? 'pointer' : 'default',
            verticalAlign: 'baseline',
          }}
        >
          [{uri.split(':').slice(-2).join(':')}]
        </button>
      );
      lastIndex = citationRegex.lastIndex;
    }
    if (lastIndex < text.length) {
      parts.push(...processTextFormatting(text.substring(lastIndex), `t-${lastIndex}`));
    }
    return parts;
  };

  // Split into blocks: code blocks, tables, headings, lists, paragraphs
  const lines = content.split('\n');
  const blocks: React.ReactNode[] = [];
  let i = 0;

  while (i < lines.length) {
    const line = lines[i];
    const trimmed = line.trim();

    // 1. Code Block: ```
    if (trimmed.startsWith('```')) {
      const codeLines: string[] = [];
      i++;
      while (i < lines.length && !lines[i].trim().startsWith('```')) {
        codeLines.push(lines[i]);
        i++;
      }
      i++; // skip closing ```
      blocks.push(
        <pre
          key={`code-${i}`}
          style={{
            background: '#f8fafc',
            border: '1px solid #e2e8f0',
            borderRadius: '8px',
            padding: '12px 14px',
            fontSize: '12px',
            fontFamily: 'monospace',
            color: '#334155',
            overflowX: 'auto',
            margin: '10px 0',
            lineHeight: 1.5,
          }}
        >
          {codeLines.join('\n')}
        </pre>
      );
      continue;
    }

    // 2. Markdown Table: line starts with |
    if (trimmed.startsWith('|') && trimmed.endsWith('|')) {
      const tableLines: string[] = [];
      while (i < lines.length && lines[i].trim().startsWith('|') && lines[i].trim().endsWith('|')) {
        tableLines.push(lines[i].trim());
        i++;
      }

      if (tableLines.length >= 2) {
        const headerRow = tableLines[0].split('|').map((c) => c.trim()).filter((_, idx, arr) => idx > 0 && idx < arr.length - 1);
        const dataRows = tableLines.slice(2).map((r) =>
          r.split('|').map((c) => c.trim()).filter((_, idx, arr) => idx > 0 && idx < arr.length - 1)
        );

        blocks.push(
          <div key={`tbl-${i}`} style={{ overflowX: 'auto', margin: '14px 0', borderRadius: '8px', border: '1px solid #e2e8f0' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '12px', textAlign: 'left' }}>
              <thead>
                <tr style={{ background: '#f8fafc', borderBottom: '2px solid #e2e8f0' }}>
                  {headerRow.map((h, hi) => (
                    <th key={hi} style={{ padding: '8px 12px', fontWeight: 600, color: '#334155' }}>
                      {renderInline(h)}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {dataRows.map((row, ri) => (
                  <tr key={ri} style={{ borderBottom: '1px solid #f1f5f9', background: ri % 2 === 0 ? '#ffffff' : '#fafafa' }}>
                    {row.map((cell, ci) => (
                      <td key={ci} style={{ padding: '8px 12px', color: '#1e293b', verticalAlign: 'top', lineHeight: 1.5 }}>
                        {renderInline(cell)}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        );
        continue;
      }
    }

    // 3. Headings: ###, ##, #
    if (trimmed.startsWith('### ')) {
      blocks.push(
        <h3 key={`h3-${i}`} style={{ fontSize: '15px', fontWeight: 700, color: '#0f172a', margin: '16px 0 8px 0', borderBottom: '1px solid #f1f5f9', paddingBottom: '4px' }}>
          {renderInline(trimmed.substring(4))}
        </h3>
      );
      i++;
      continue;
    }
    if (trimmed.startsWith('## ')) {
      blocks.push(
        <h2 key={`h2-${i}`} style={{ fontSize: '17px', fontWeight: 700, color: '#0f172a', margin: '18px 0 10px 0', borderBottom: '1px solid #e2e8f0', paddingBottom: '4px' }}>
          {renderInline(trimmed.substring(3))}
        </h2>
      );
      i++;
      continue;
    }
    if (trimmed.startsWith('# ')) {
      blocks.push(
        <h1 key={`h1-${i}`} style={{ fontSize: '19px', fontWeight: 700, color: '#0f172a', margin: '20px 0 12px 0' }}>
          {renderInline(trimmed.substring(2))}
        </h1>
      );
      i++;
      continue;
    }

    // 4. Bullet lists: - or *
    if (trimmed.startsWith('- ') || trimmed.startsWith('* ')) {
      const listItems: string[] = [];
      while (i < lines.length && (lines[i].trim().startsWith('- ') || lines[i].trim().startsWith('* '))) {
        listItems.push(lines[i].trim().substring(2));
        i++;
      }
      blocks.push(
        <ul key={`ul-${i}`} style={{ margin: '8px 0 12px 20px', padding: 0, fontSize: '13px', lineHeight: 1.6, color: '#1e293b' }}>
          {listItems.map((item, liIdx) => (
            <li key={liIdx} style={{ marginBottom: '4px' }}>
              {renderInline(item)}
            </li>
          ))}
        </ul>
      );
      continue;
    }

    // 5. Empty lines
    if (!trimmed) {
      i++;
      continue;
    }

    // 6. Regular Paragraph
    blocks.push(
      <p key={`p-${i}`} style={{ margin: '6px 0 10px 0', fontSize: '13px', lineHeight: 1.6, color: '#1e293b' }}>
        {renderInline(trimmed)}
      </p>
    );
    i++;
  }

  return <div className="safe-markdown-container">{blocks}</div>;
};
