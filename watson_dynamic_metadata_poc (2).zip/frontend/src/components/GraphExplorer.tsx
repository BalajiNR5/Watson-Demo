import React, { useState, useEffect, useMemo, useRef } from 'react';
import { api, UserProfile } from '../services/api';

interface GraphExplorerProps {
  currentUser: UserProfile | null;
}

type ViewKey = 'integrated' | 'databricks' | 'watson';
type SubMode = 'graph' | 'catalog' | 'mappings';

const NODE_TYPE_STYLES: Record<string, { fill: string; stroke: string; badgeBg: string; badgeColor: string; label: string; radius: number }> = {
  DATABRICKS_PRODUCT: {
    fill: '#eff6ff',
    stroke: '#2563eb',
    badgeBg: '#dbeafe',
    badgeColor: '#1d4ed8',
    label: 'Databricks Product Table',
    radius: 26,
  },
  DATABRICKS_ATTRIBUTE: {
    fill: '#f0fdfa',
    stroke: '#0d9488',
    badgeBg: '#ccfbf1',
    badgeColor: '#0f766e',
    label: 'Databricks Attribute (PK/FK)',
    radius: 17,
  },
  EXTERNAL_SCHEMA_ENDPOINT: {
    fill: '#fef2f2',
    stroke: '#dc2626',
    badgeBg: '#fee2e2',
    badgeColor: '#b91c1c',
    label: 'Cross-Domain Schema Endpoint',
    radius: 21,
  },
  WATSON_CLASS: {
    fill: '#faf5ff',
    stroke: '#7c3aed',
    badgeBg: '#f3e8ff',
    badgeColor: '#6d28d9',
    label: 'Watson OWL Ontology Class',
    radius: 25,
  },
  WATSON_ENTITY: {
    fill: '#f0fdf4',
    stroke: '#16a34a',
    badgeBg: '#dcfce7',
    badgeColor: '#15803d',
    label: 'Watson Curated Entity',
    radius: 22,
  },
};

const MAPPING_STATUS_STYLES: Record<string, { stroke: string; bg: string; text: string; dash?: string; label: string }> = {
  EXACT: {
    stroke: '#16a34a',
    bg: '#dcfce7',
    text: '#15803d',
    label: 'EXACT (Verified Schema-to-Class Alignment)',
  },
  PROPOSED: {
    stroke: '#d97706',
    bg: '#fef3c7',
    text: '#b45309',
    dash: '6,4',
    label: 'PROPOSED (Candidate Alignment — Unverified)',
  },
  CONFLICT: {
    stroke: '#dc2626',
    bg: '#fee2e2',
    text: '#b91c1c',
    dash: '4,3',
    label: 'CONFLICT (Granularity / Cross-Domain Mismatch)',
  },
  UNRESOLVED: {
    stroke: '#64748b',
    bg: '#f1f5f9',
    text: '#475569',
    dash: '2,3',
    label: 'UNRESOLVED (Schema-Only / No Direct Counterpart)',
  },
};

const EDGE_STYLES: Record<string, { stroke: string; dash?: string; width: number }> = {
  MAPPED_TO: { stroke: '#16a34a', width: 2.6 },
  FOREIGN_KEY_TO: { stroke: '#2563eb', width: 1.8 },
  CONTAINS_ATTRIBUTE: { stroke: '#94a3b8', dash: '3,3', width: 1.2 },
  INSTANCE_OF: { stroke: '#7c3aed', dash: '4,3', width: 1.6 },
  SUBCLASS_OF: { stroke: '#6d28d9', width: 1.8 },
  IS_BRAND_OF: { stroke: '#0d9488', width: 2.0 },
  TREATS_INDICATION: { stroke: '#16a34a', width: 1.8 },
  IN_THERAPEUTIC_AREA: { stroke: '#0284c7', width: 1.6 },
  COMPETES_WITH: { stroke: '#ea580c', dash: '5,3', width: 1.6 },
};

export const GraphExplorer: React.FC<GraphExplorerProps> = ({ currentUser }) => {
  const [payload, setPayload] = useState<any | null>(null);
  const [catalogData, setCatalogData] = useState<any | null>(null);
  const [mappingReport, setMappingReport] = useState<any | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Primary View & Sub-Mode State
  const [activeView, setActiveView] = useState<ViewKey>('integrated');
  const [subMode, setSubMode] = useState<SubMode>('graph');

  // Filter & Search State
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [nodeTypeFilter, setNodeTypeFilter] = useState<string>('ALL');
  const [subdomainFilter, setSubdomainFilter] = useState<string>('ALL');
  const [relationshipFilter, setRelationshipFilter] = useState<string>('ALL');
  const [mappingStatusFilter, setMappingStatusFilter] = useState<string>('ALL');
  const [showAttributeNodes, setShowAttributeNodes] = useState<boolean>(false);
  const [isolateNeighborhood, setIsolateNeighborhood] = useState<boolean>(false);

  // Selection & Inspector State
  const [selectedNodeId, setSelectedNodeId] = useState<string>('dbx:product:product.medicinal_product');
  const [attrSearch, setAttrSearch] = useState<string>('');
  const [catalogSelectedProduct, setCatalogSelectedProduct] = useState<string>('medicinal_product');
  const [catalogSearch, setCatalogSearch] = useState<string>('');
  const [mappingFilterStatus, setMappingFilterStatus] = useState<string>('ALL');
  const [mappingSearch, setMappingSearch] = useState<string>('');

  // Refresh & Diff State
  const [refreshing, setRefreshing] = useState<boolean>(false);
  const [refreshStatus, setRefreshStatus] = useState<any | null>(null);
  const [refreshError, setRefreshError] = useState<string | null>(null);

  // Interactive Canvas State (Zoom, Pan, Node Coordinates, Dragging)
  const [zoom, setZoom] = useState<number>(0.92);
  const [pan, setPan] = useState<{ x: number; y: number }>({ x: 30, y: 20 });
  const [nodePositions, setNodePositions] = useState<Record<string, { x: number; y: number }>>({});
  const [draggingNodeId, setDraggingNodeId] = useState<string | null>(null);
  const [isPanning, setIsPanning] = useState<boolean>(false);
  const panStartRef = useRef<{ x: number; y: number; panX: number; panY: number }>({ x: 0, y: 0, panX: 0, panY: 0 });
  const svgRef = useRef<SVGSVGElement | null>(null);

  useEffect(() => {
    loadAllData();
  }, []);

  const loadAllData = async () => {
    setLoading(true);
    setError(null);
    try {
      const [explorerRes, catalogRes, mappingsRes] = await Promise.all([
        api.getGraphExplorer(),
        api.getDatabricksCatalog(),
        api.getSemanticMappings(),
      ]);
      setPayload(explorerRes);
      setCatalogData(catalogRes);
      setMappingReport(mappingsRes);
      if (explorerRes?.refresh_state) {
        setRefreshStatus(explorerRes.refresh_state);
      }
    } catch (err: any) {
      setError(err.message || 'Failed to load Graph Explorer data');
    } finally {
      setLoading(false);
    }
  };

  // Compute deterministic layout whenever activeView or payload changes
  const viewData = useMemo(() => {
    if (!payload?.views) return { nodes: [], edges: [], title: '', description: '' };
    return payload.views[activeView] || payload.views.integrated || { nodes: [], edges: [], title: '', description: '' };
  }, [payload, activeView]);

  useEffect(() => {
    if (!viewData.nodes || viewData.nodes.length === 0) return;
    const positions: Record<string, { x: number; y: number }> = {};

    const dbxProducts = viewData.nodes.filter((n: any) => n.node_type === 'DATABRICKS_PRODUCT');
    const dbxMarket = dbxProducts.filter((n: any) => n.subdomain === 'market authorization');
    const dbxIdentity = dbxProducts.filter((n: any) => n.subdomain !== 'market authorization');
    const extNodes = viewData.nodes.filter((n: any) => n.node_type === 'EXTERNAL_SCHEMA_ENDPOINT');
    const watsonClasses = viewData.nodes.filter((n: any) => n.node_type === 'WATSON_CLASS');
    const watsonEntities = viewData.nodes.filter((n: any) => n.node_type === 'WATSON_ENTITY');
    const dbxAttrs = viewData.nodes.filter((n: any) => n.node_type === 'DATABRICKS_ATTRIBUTE');

    if (activeView === 'databricks') {
      // Two columns of product tables (Market Authorization on left, Product Identity on right) + attributes around them
      dbxMarket.forEach((n: any, idx: number) => {
        positions[n.id] = { x: 240, y: 95 + idx * 92 };
      });
      dbxIdentity.forEach((n: any, idx: number) => {
        positions[n.id] = { x: 670, y: 80 + idx * 85 };
      });
      extNodes.forEach((n: any, idx: number) => {
        positions[n.id] = { x: 455, y: 690 + idx * 70 };
      });
      dbxAttrs.forEach((n: any, idx: number) => {
        const parentId = n.parent_product_id || `dbx:product:product.${n.parent_product}`;
        const pPos = positions[parentId] || { x: 450, y: 350 };
        const angle = ((idx % 8) / 8) * Math.PI * 2;
        positions[n.id] = {
          x: pPos.x + Math.cos(angle) * 105,
          y: pPos.y + Math.sin(angle) * 44,
        };
      });
    } else if (activeView === 'watson') {
      // Watson classes on left/top arc, entities grouped by family on right columns
      watsonClasses.forEach((n: any, idx: number) => {
        const col = idx % 2;
        const row = Math.floor(idx / 2);
        positions[n.id] = { x: 180 + col * 200, y: 90 + row * 105 };
      });
      const brands = watsonEntities.filter((n: any) => n.subdomain === 'brands');
      const drugs = watsonEntities.filter((n: any) => n.subdomain === 'drugs');
      const indications = watsonEntities.filter((n: any) => n.subdomain === 'indications');
      const tas = watsonEntities.filter((n: any) => n.subdomain === 'therapeutic_areas');
      const others = watsonEntities.filter(
        (n: any) => !['brands', 'drugs', 'indications', 'therapeutic_areas'].includes(n.subdomain)
      );

      brands.forEach((n: any, idx: number) => {
        positions[n.id] = { x: 560, y: 85 + idx * 82 };
      });
      drugs.forEach((n: any, idx: number) => {
        positions[n.id] = { x: 770, y: 85 + idx * 82 };
      });
      indications.forEach((n: any, idx: number) => {
        positions[n.id] = { x: 970, y: 80 + idx * 65 };
      });
      tas.forEach((n: any, idx: number) => {
        positions[n.id] = { x: 1150, y: 110 + idx * 95 };
      });
      others.forEach((n: any, idx: number) => {
        positions[n.id] = { x: 770 + (idx % 3) * 170, y: 660 + Math.floor(idx / 3) * 65 };
      });
    } else {
      // Integrated Mapping View (Default C):
      // Column 1 (x=150): Databricks Market Authorization Products
      // Column 2 (x=370): Databricks Product Identity Products + External Endpoint
      // Column 3 (x=670): Watson OWL Ontology Classes (bridge targets of MAPPED_TO)
      // Column 4 (x=940): Watson Curated Brands & Drugs
      // Column 5 (x=1160): Watson Curated Indications & Therapeutic Areas
      dbxMarket.forEach((n: any, idx: number) => {
        positions[n.id] = { x: 145, y: 85 + idx * 92 };
      });
      dbxIdentity.forEach((n: any, idx: number) => {
        positions[n.id] = { x: 375, y: 75 + idx * 84 };
      });
      extNodes.forEach((n: any, idx: number) => {
        positions[n.id] = { x: 260, y: 735 + idx * 60 };
      });
      watsonClasses.forEach((n: any, idx: number) => {
        positions[n.id] = { x: 675, y: 70 + idx * 66 };
      });
      const brandsAndDrugs = watsonEntities.filter((n: any) => ['brands', 'drugs'].includes(n.subdomain));
      const indAndTa = watsonEntities.filter((n: any) => !['brands', 'drugs'].includes(n.subdomain));
      brandsAndDrugs.forEach((n: any, idx: number) => {
        positions[n.id] = { x: 945, y: 65 + idx * 52 };
      });
      indAndTa.forEach((n: any, idx: number) => {
        positions[n.id] = { x: 1165, y: 65 + idx * 44 };
      });
      dbxAttrs.forEach((n: any, idx: number) => {
        const parentId = n.parent_product_id || `dbx:product:product.${n.parent_product}`;
        const pPos = positions[parentId] || { x: 260, y: 360 };
        const angle = ((idx % 6) / 6) * Math.PI * 2;
        positions[n.id] = {
          x: pPos.x + Math.cos(angle) * 78,
          y: pPos.y + Math.sin(angle) * 35,
        };
      });
    }

    setNodePositions(positions);
  }, [viewData, activeView]);

  // Available filter options from current view
  const subdomains = useMemo(() => {
    const s = new Set<string>();
    (viewData.nodes || []).forEach((n: any) => {
      if (n.subdomain) s.add(n.subdomain);
    });
    return Array.from(s).sort();
  }, [viewData]);

  const relationshipTypes = useMemo(() => {
    const r = new Set<string>();
    (viewData.edges || []).forEach((e: any) => {
      if (e.relationship_type) r.add(e.relationship_type);
    });
    return Array.from(r).sort();
  }, [viewData]);

  // Filtered nodes and edges
  const { filteredNodes, filteredEdges, neighborNodeIds } = useMemo(() => {
    const allNodes: any[] = viewData.nodes || [];
    const allEdges: any[] = viewData.edges || [];

    // 1. Determine base candidate nodes
    const q = searchQuery.trim().toLowerCase();
    let candidateNodes = allNodes.filter((n: any) => {
      if (!showAttributeNodes && n.node_type === 'DATABRICKS_ATTRIBUTE' && n.id !== selectedNodeId) {
        // Still show attribute node if user explicitly searched for it or filtered for DATABRICKS_ATTRIBUTE
        if (nodeTypeFilter !== 'DATABRICKS_ATTRIBUTE' && (!q || !n.label.toLowerCase().includes(q))) {
          return false;
        }
      }
      if (nodeTypeFilter !== 'ALL' && n.node_type !== nodeTypeFilter) return false;
      if (subdomainFilter !== 'ALL' && n.subdomain !== subdomainFilter) return false;
      if (mappingStatusFilter !== 'ALL' && n.mapping_status !== mappingStatusFilter) return false;
      if (q) {
        const matchLabel = (n.label || '').toLowerCase().includes(q);
        const matchId = (n.id || '').toLowerCase().includes(q);
        const matchDesc = (n.description || '').toLowerCase().includes(q);
        const matchAttr = Array.isArray(n.attributes) && n.attributes.some((a: any) => (a.name || '').toLowerCase().includes(q));
        const matchAlias = Array.isArray(n.aliases) && n.aliases.some((al: string) => al.toLowerCase().includes(q));
        if (!matchLabel && !matchId && !matchDesc && !matchAttr && !matchAlias) return false;
      }
      return true;
    });

    const candidateNodeSet = new Set(candidateNodes.map((n: any) => n.id));

    // 2. Compute 1-hop neighbors of selectedNodeId across active edges
    const neighbors = new Set<string>();
    if (selectedNodeId) {
      neighbors.add(selectedNodeId);
      allEdges.forEach((e: any) => {
        if (relationshipFilter !== 'ALL' && e.relationship_type !== relationshipFilter) return;
        if (e.source === selectedNodeId) neighbors.add(e.target);
        if (e.target === selectedNodeId) neighbors.add(e.source);
      });
    }

    // 3. If isolateNeighborhood is enabled and we have a selected node, restrict to 1-hop neighborhood
    if (isolateNeighborhood && selectedNodeId) {
      candidateNodes = allNodes.filter((n: any) => neighbors.has(n.id));
    }

    const finalNodeIds = new Set(candidateNodes.map((n: any) => n.id));

    // 4. Filter edges connecting visible nodes
    const candidateEdges = allEdges.filter((e: any) => {
      if (!finalNodeIds.has(e.source) || !finalNodeIds.has(e.target)) return false;
      if (relationshipFilter !== 'ALL' && e.relationship_type !== relationshipFilter) return false;
      return true;
    });

    // If relationshipFilter is active (not ALL), optionally prune isolated nodes that have no matching edges unless selected
    if (relationshipFilter !== 'ALL' && !q) {
      const edgeConnected = new Set<string>();
      candidateEdges.forEach((e: any) => {
        edgeConnected.add(e.source);
        edgeConnected.add(e.target);
      });
      if (selectedNodeId) edgeConnected.add(selectedNodeId);
      candidateNodes = candidateNodes.filter((n: any) => edgeConnected.has(n.id) || candidateNodeSet.size <= 5);
    }

    return {
      filteredNodes: candidateNodes,
      filteredEdges: candidateEdges,
      neighborNodeIds: neighbors,
    };
  }, [
    viewData,
    searchQuery,
    nodeTypeFilter,
    subdomainFilter,
    relationshipFilter,
    mappingStatusFilter,
    showAttributeNodes,
    isolateNeighborhood,
    selectedNodeId,
  ]);

  const selectedNode = useMemo(() => {
    if (!payload?.views) return null;
    for (const vKey of ['integrated', 'databricks', 'watson']) {
      const found = (payload.views[vKey]?.nodes || []).find((n: any) => n.id === selectedNodeId);
      if (found) return found;
    }
    return null;
  }, [payload, selectedNodeId]);

  const selectedNodeEdges = useMemo(() => {
    if (!selectedNodeId || !viewData.edges) return [];
    return viewData.edges.filter((e: any) => e.source === selectedNodeId || e.target === selectedNodeId);
  }, [viewData, selectedNodeId]);

  // Handlers for Refresh
  const handleRefreshGraph = async (useEvolutionFixture: boolean = false) => {
    setRefreshing(true);
    setRefreshError(null);
    try {
      const reqPayload = useEvolutionFixture
        ? { fixture_path: 'data/fixtures/databricks_pharmaceuticals_v1_1_mvm_fixture.json' }
        : {};
      const res = await api.refreshGraphExplorer(reqPayload);
      if (res.explorer) {
        setPayload(res.explorer);
      }
      setRefreshStatus({
        last_successful_refresh: res.last_successful_refresh,
        source_version: res.source_version,
        diff_summary: res.diff_summary,
        used_last_known_good: res.used_last_known_good,
      });
      // Also reload catalog & mappings so Catalog/Mappings sub-modes reflect the refreshed state
      const [catRes, mapRes] = await Promise.all([api.getDatabricksCatalog(), api.getSemanticMappings()]);
      setCatalogData(catRes);
      setMappingReport(mapRes);
    } catch (err: any) {
      setRefreshError(err.message || 'Graph refresh failed — Last-known-good graph preserved.');
    } finally {
      setRefreshing(false);
    }
  };

  // Handlers for Canvas Interaction
  const handleMouseDownCanvas = (e: React.MouseEvent<SVGSVGElement>) => {
    if ((e.target as HTMLElement).tagName === 'svg' || (e.target as HTMLElement).getAttribute('data-bg') === 'true') {
      setIsPanning(true);
      panStartRef.current = { x: e.clientX, y: e.clientY, panX: pan.x, panY: pan.y };
    }
  };

  const handleMouseMoveCanvas = (e: React.MouseEvent<SVGSVGElement>) => {
    if (draggingNodeId && svgRef.current) {
      const rect = svgRef.current.getBoundingClientRect();
      const rawX = (e.clientX - rect.left - pan.x) / zoom;
      const rawY = (e.clientY - rect.top - pan.y) / zoom;
      setNodePositions((prev) => ({
        ...prev,
        [draggingNodeId]: { x: Math.max(40, Math.min(1320, rawX)), y: Math.max(40, Math.min(820, rawY)) },
      }));
    } else if (isPanning) {
      const dx = e.clientX - panStartRef.current.x;
      const dy = e.clientY - panStartRef.current.y;
      setPan({ x: panStartRef.current.panX + dx, y: panStartRef.current.panY + dy });
    }
  };

  const handleMouseUpCanvas = () => {
    setDraggingNodeId(null);
    setIsPanning(false);
  };

  const handleFitToScreen = () => {
    setZoom(0.92);
    setPan({ x: 30, y: 20 });
  };

  const handleResetFilters = () => {
    setSearchQuery('');
    setNodeTypeFilter('ALL');
    setSubdomainFilter('ALL');
    setRelationshipFilter('ALL');
    setMappingStatusFilter('ALL');
    setIsolateNeighborhood(false);
    setShowAttributeNodes(false);
    handleFitToScreen();
  };

  const focusNodeInGraph = (nodeId: string, targetView: ViewKey = 'integrated') => {
    setActiveView(targetView);
    setSubMode('graph');
    setSelectedNodeId(nodeId);
    const pos = nodePositions[nodeId];
    if (pos) {
      setZoom(1.05);
      setPan({ x: 420 - pos.x * 1.05, y: 280 - pos.y * 1.05 });
    }
  };

  if (loading) {
    return (
      <div className="card" style={{ padding: '48px', textAlign: 'center' }}>
        <h3 style={{ fontSize: '18px', fontWeight: 700, color: '#1e293b', marginBottom: '8px' }}>
          Loading Interactive Knowledge Graph & Databricks Product MVM Explorer...
        </h3>
        <p style={{ fontSize: '13px', color: '#64748b' }}>
          Assembling View A (Databricks Product Model), View B (Watson Semantic Model), View C (Integrated Mapping View), and the 594-attribute Data Catalog.
        </p>
      </div>
    );
  }

  if (error || !payload) {
    return (
      <div className="card" style={{ padding: '32px', borderLeft: '4px solid #dc2626', background: '#fef2f2' }}>
        <h3 style={{ fontSize: '16px', fontWeight: 700, color: '#991b1b', marginBottom: '8px' }}>
          Graph Explorer Error
        </h3>
        <p style={{ fontSize: '13px', color: '#b91c1c', marginBottom: '16px' }}>
          {error || 'Graph metadata payload is unavailable.'}
        </p>
        <button className="btn btn-primary" onClick={loadAllData}>
          Retry Loading Graph Explorer
        </button>
      </div>
    );
  }

  const catalogProducts: any[] = catalogData?.products || [];
  const activeCatalogProduct = catalogProducts.find((p: any) => p.name === catalogSelectedProduct) || catalogProducts[0];
  const productMappings: any[] = mappingReport?.product_mappings || [];
  const attributeMappings: any[] = mappingReport?.attribute_mappings || [];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
      {/* TOP HEADER BANNER & KPI SUMMARY */}
      <div
        className="card"
        style={{
          padding: '16px 20px',
          background: 'linear-gradient(135deg, #f8fafc 0%, #eff6ff 100%)',
          borderLeft: '4px solid #2563eb',
        }}
      >
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '12px' }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px', flexWrap: 'wrap' }}>
              <h2 style={{ fontSize: '19px', fontWeight: 700, color: '#0f172a', margin: 0 }}>
                🕸️ Interactive Knowledge Graph, Schema Mapping & Data Catalog Explorer
              </h2>
              <span
                style={{
                  fontSize: '11px',
                  fontWeight: 700,
                  padding: '3px 8px',
                  borderRadius: '999px',
                  background: '#dbeafe',
                  color: '#1d4ed8',
                }}
              >
                {payload.model_identity?.industry?.toUpperCase()} • {payload.model_identity?.domain} ({payload.model_identity?.flavour?.toUpperCase()} {refreshStatus?.source_version || payload.model_identity?.version})
              </span>
            </div>
            <p style={{ fontSize: '12px', color: '#475569', marginTop: '4px', marginBottom: 0 }}>
              Dynamic ingestion of authoritative Databricks Pharmaceuticals Product MVM schema integrated with Watson Layer 2 OWL Ontology & Curated Entities.
            </p>
          </div>

          {/* Live Refresh Controls */}
          <div style={{ display: 'flex', gap: '8px', alignItems: 'center', flexWrap: 'wrap' }}>
            <button
              className="btn btn-outline"
              disabled={refreshing}
              onClick={() => handleRefreshGraph(false)}
              style={{ fontSize: '12px', padding: '6px 12px', background: '#ffffff' }}
              title="Re-ingest authoritative v1 MVM schema and compute diff"
            >
              {refreshing ? 'Refreshing...' : '⟳ Refresh Graph (v1 MVM)'}
            </button>
            <button
              className="btn btn-primary"
              disabled={refreshing}
              onClick={() => handleRefreshGraph(true)}
              style={{ fontSize: '12px', padding: '6px 12px' }}
              title="Simulate upstream schema evolution (v1.1-fixture) and inspect live graph diff"
            >
              ⚡ Simulate v1.1 Schema Update
            </button>
          </div>
        </div>

        {/* Metrics Strip */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: '10px', marginTop: '12px' }}>
          <div style={{ background: '#ffffff', padding: '8px 12px', borderRadius: '6px', border: '1px solid #e2e8f0' }}>
            <div style={{ fontSize: '10px', color: '#64748b', fontWeight: 600, textTransform: 'uppercase' }}>Databricks Products</div>
            <div style={{ fontSize: '17px', fontWeight: 700, color: '#2563eb' }}>
              {payload.summary?.databricks_products_count || 15}{' '}
              <span style={{ fontSize: '11px', fontWeight: 500, color: '#64748b' }}>tables</span>
            </div>
          </div>
          <div style={{ background: '#ffffff', padding: '8px 12px', borderRadius: '6px', border: '1px solid #e2e8f0' }}>
            <div style={{ fontSize: '10px', color: '#64748b', fontWeight: 600, textTransform: 'uppercase' }}>Schema Attributes</div>
            <div style={{ fontSize: '17px', fontWeight: 700, color: '#0d9488' }}>
              {payload.summary?.databricks_attributes_count || 594}{' '}
              <span style={{ fontSize: '11px', fontWeight: 500, color: '#64748b' }}>columns ({payload.summary?.databricks_foreign_keys_count || 83} FKs)</span>
            </div>
          </div>
          <div style={{ background: '#ffffff', padding: '8px 12px', borderRadius: '6px', border: '1px solid #e2e8f0' }}>
            <div style={{ fontSize: '10px', color: '#64748b', fontWeight: 600, textTransform: 'uppercase' }}>Watson Ontology & KG</div>
            <div style={{ fontSize: '17px', fontWeight: 700, color: '#7c3aed' }}>
              {payload.summary?.watson_classes_count || 11} Classes{' '}
              <span style={{ fontSize: '11px', fontWeight: 500, color: '#64748b' }}>/ {payload.summary?.watson_entities_count || 27} Entities</span>
            </div>
          </div>
          <div style={{ background: '#ffffff', padding: '8px 12px', borderRadius: '6px', border: '1px solid #e2e8f0' }}>
            <div style={{ fontSize: '10px', color: '#64748b', fontWeight: 600, textTransform: 'uppercase' }}>EXACT / PROPOSED</div>
            <div style={{ fontSize: '17px', fontWeight: 700, color: '#16a34a' }}>
              {payload.summary?.mapping_status_counts?.EXACT || 3} Exact{' '}
              <span style={{ fontSize: '12px', fontWeight: 600, color: '#d97706' }}>/ {payload.summary?.mapping_status_counts?.PROPOSED || 4} Proposed</span>
            </div>
          </div>
          <div style={{ background: '#ffffff', padding: '8px 12px', borderRadius: '6px', border: '1px solid #e2e8f0' }}>
            <div style={{ fontSize: '10px', color: '#64748b', fontWeight: 600, textTransform: 'uppercase' }}>CONFLICT / UNRESOLVED</div>
            <div style={{ fontSize: '17px', fontWeight: 700, color: '#dc2626' }}>
              {payload.summary?.mapping_status_counts?.CONFLICT || 2} Conflict{' '}
              <span style={{ fontSize: '12px', fontWeight: 600, color: '#64748b' }}>/ {payload.summary?.mapping_status_counts?.UNRESOLVED || 6} Unresolved</span>
            </div>
          </div>
          <div style={{ background: '#ffffff', padding: '8px 12px', borderRadius: '6px', border: '1px solid #e2e8f0' }}>
            <div style={{ fontSize: '10px', color: '#64748b', fontWeight: 600, textTransform: 'uppercase' }}>Last Graph Sync</div>
            <div style={{ fontSize: '11px', fontWeight: 700, color: '#0f172a', marginTop: '2px' }}>
              {(refreshStatus?.last_successful_refresh || payload.generated_at || '').replace('T', ' ').slice(0, 19)} UTC
            </div>
            {refreshStatus?.diff_summary && (
              <div style={{ fontSize: '10px', color: '#15803d', fontWeight: 600 }}>
                +{refreshStatus.diff_summary.added_products?.length || 0}P / ~{refreshStatus.diff_summary.changed_products?.length || 0}Δ / {refreshStatus.diff_summary.unchanged_products_count ?? 15}=
              </div>
            )}
          </div>
        </div>

        {/* Live Diff Callout when Refresh Triggered */}
        {refreshStatus?.diff_summary && (
          <div
            style={{
              marginTop: '10px',
              padding: '8px 12px',
              borderRadius: '6px',
              background: '#f0fdf4',
              border: '1px solid #bbf7d0',
              fontSize: '12px',
              color: '#166534',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              flexWrap: 'wrap',
              gap: '8px',
            }}
          >
            <div>
              <strong>Live Refresh Diff ({refreshStatus.source_version}):</strong>{' '}
              Added Products: <strong>{refreshStatus.diff_summary.added_products?.length || 0}</strong> | Changed Products:{' '}
              <strong>
                {refreshStatus.diff_summary.changed_products?.length || 0}
                {refreshStatus.diff_summary.changed_products?.length > 0
                  ? ` (${refreshStatus.diff_summary.changed_products.map((c: any) => `${c.product}: +[${c.added_attributes?.join(', ')}]`).join('; ')})`
                  : ''}
              </strong>{' '}
              | Removed Products: <strong>{refreshStatus.diff_summary.removed_products?.length || 0}</strong> | Unchanged:{' '}
              <strong>{refreshStatus.diff_summary.unchanged_products_count ?? 15}</strong>
            </div>
            <span style={{ fontSize: '11px', fontWeight: 600 }}>
              Last-Known-Good Fallback: {refreshStatus.used_last_known_good ? 'ACTIVATED' : 'STANDBY (HEALTHY)'}
            </span>
          </div>
        )}

        {refreshError && (
          <div
            style={{
              marginTop: '10px',
              padding: '8px 12px',
              borderRadius: '6px',
              background: '#fef2f2',
              border: '1px solid #fecaca',
              fontSize: '12px',
              color: '#991b1b',
            }}
          >
            ⚠️ <strong>Refresh Failed (Last-Known-Good Graph Preserved):</strong> {refreshError}
          </div>
        )}
      </div>

      {/* PRIMARY MODE BAR: 3 GRAPH VIEWS + INTERACTIVE DATA CATALOG + ENTITY MAPPING MATRIX */}
      <div
        className="card"
        style={{
          padding: '10px 14px',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          flexWrap: 'wrap',
          gap: '10px',
        }}
      >
        {/* Left: Sub-Mode Switcher (Visual Graph vs Interactive Data Catalog vs Entity Mapping Explorer) */}
        <div style={{ display: 'flex', gap: '6px', alignItems: 'center', flexWrap: 'wrap' }}>
          <span style={{ fontSize: '11px', fontWeight: 700, color: '#475569', textTransform: 'uppercase', marginRight: '4px' }}>
            Explorer Mode:
          </span>
          <button
            className="btn"
            onClick={() => setSubMode('graph')}
            style={{
              fontSize: '12px',
              padding: '6px 12px',
              borderRadius: '6px',
              background: subMode === 'graph' ? '#0f172a' : '#f1f5f9',
              color: subMode === 'graph' ? '#ffffff' : '#334155',
              fontWeight: 600,
            }}
          >
            🕸️ Visual Graph Canvas
          </button>
          <button
            className="btn"
            onClick={() => setSubMode('catalog')}
            style={{
              fontSize: '12px',
              padding: '6px 12px',
              borderRadius: '6px',
              background: subMode === 'catalog' ? '#0f172a' : '#f1f5f9',
              color: subMode === 'catalog' ? '#ffffff' : '#334155',
              fontWeight: 600,
            }}
          >
            📘 Interactive Node Data Catalog (15 Products / 594 Cols)
          </button>
          <button
            className="btn"
            onClick={() => setSubMode('mappings')}
            style={{
              fontSize: '12px',
              padding: '6px 12px',
              borderRadius: '6px',
              background: subMode === 'mappings' ? '#0f172a' : '#f1f5f9',
              color: subMode === 'mappings' ? '#ffffff' : '#334155',
              fontWeight: 600,
            }}
          >
            🔗 Entity Mapping & Compatibility Explorer (19 Records)
          </button>
        </div>

        {/* Right: View A / View B / View C Selector (when in Visual Graph mode) */}
        {subMode === 'graph' && (
          <div style={{ display: 'flex', gap: '6px', alignItems: 'center', flexWrap: 'wrap' }}>
            <span style={{ fontSize: '11px', fontWeight: 700, color: '#475569', textTransform: 'uppercase', marginRight: '4px' }}>
              Graph View:
            </span>
            <button
              className="btn"
              onClick={() => setActiveView('integrated')}
              style={{
                fontSize: '12px',
                padding: '6px 12px',
                borderRadius: '6px',
                background: activeView === 'integrated' ? '#2563eb' : '#eff6ff',
                color: activeView === 'integrated' ? '#ffffff' : '#1d4ed8',
                border: activeView === 'integrated' ? 'none' : '1px solid #bfdbfe',
                fontWeight: 600,
              }}
            >
              View C: Integrated Mapping View (Default)
            </button>
            <button
              className="btn"
              onClick={() => setActiveView('databricks')}
              style={{
                fontSize: '12px',
                padding: '6px 12px',
                borderRadius: '6px',
                background: activeView === 'databricks' ? '#2563eb' : '#f8fafc',
                color: activeView === 'databricks' ? '#ffffff' : '#334155',
                border: '1px solid #cbd5e1',
                fontWeight: 600,
              }}
            >
              View A: Databricks Product Model
            </button>
            <button
              className="btn"
              onClick={() => setActiveView('watson')}
              style={{
                fontSize: '12px',
                padding: '6px 12px',
                borderRadius: '6px',
                background: activeView === 'watson' ? '#2563eb' : '#f8fafc',
                color: activeView === 'watson' ? '#ffffff' : '#334155',
                border: '1px solid #cbd5e1',
                fontWeight: 600,
              }}
            >
              View B: Watson Semantic Model
            </button>
          </div>
        )}
      </div>

      {/* =====================================================================
          SUB-MODE 1: INTERACTIVE VISUAL GRAPH EXPLORER (VIEW A, B, C)
         ===================================================================== */}
      {subMode === 'graph' && (
        <>
          {/* FILTER & SEARCH TOOLBAR */}
          <div className="card" style={{ padding: '12px 14px', display: 'flex', flexDirection: 'column', gap: '10px' }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1.6fr 1fr 1fr 1fr 1fr auto', gap: '8px', alignItems: 'center' }}>
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search products, attributes (e.g. ndc_code), classes, or brands (e.g. Keytruda)..."
                aria-label="Search graph nodes and attributes"
                style={{
                  padding: '7px 12px',
                  borderRadius: '6px',
                  border: '1px solid #cbd5e1',
                  fontSize: '12px',
                }}
              />

              <select
                value={nodeTypeFilter}
                onChange={(e) => setNodeTypeFilter(e.target.value)}
                aria-label="Filter by Node Type"
                style={{ padding: '7px 8px', borderRadius: '6px', border: '1px solid #cbd5e1', fontSize: '12px' }}
              >
                <option value="ALL">All Node Types</option>
                <option value="DATABRICKS_PRODUCT">Databricks Product Table</option>
                <option value="DATABRICKS_ATTRIBUTE">Databricks Key Attribute</option>
                <option value="EXTERNAL_SCHEMA_ENDPOINT">External Schema Endpoint</option>
                <option value="WATSON_CLASS">Watson Ontology Class</option>
                <option value="WATSON_ENTITY">Watson Curated Entity</option>
              </select>

              <select
                value={subdomainFilter}
                onChange={(e) => setSubdomainFilter(e.target.value)}
                aria-label="Filter by Subdomain"
                style={{ padding: '7px 8px', borderRadius: '6px', border: '1px solid #cbd5e1', fontSize: '12px' }}
              >
                <option value="ALL">All Subdomains / Families</option>
                {subdomains.map((sd) => (
                  <option key={sd} value={sd}>
                    {sd}
                  </option>
                ))}
              </select>

              <select
                value={relationshipFilter}
                onChange={(e) => setRelationshipFilter(e.target.value)}
                aria-label="Filter by Relationship Type"
                style={{ padding: '7px 8px', borderRadius: '6px', border: '1px solid #cbd5e1', fontSize: '12px' }}
              >
                <option value="ALL">All Relationships</option>
                {relationshipTypes.map((rt) => (
                  <option key={rt} value={rt}>
                    {rt}
                  </option>
                ))}
              </select>

              <select
                value={mappingStatusFilter}
                onChange={(e) => setMappingStatusFilter(e.target.value)}
                aria-label="Filter by Mapping Status"
                style={{ padding: '7px 8px', borderRadius: '6px', border: '1px solid #cbd5e1', fontSize: '12px' }}
              >
                <option value="ALL">All Mapping Statuses</option>
                <option value="EXACT">EXACT (Verified)</option>
                <option value="PROPOSED">PROPOSED (Unverified)</option>
                <option value="CONFLICT">CONFLICT</option>
                <option value="UNRESOLVED">UNRESOLVED</option>
              </select>

              <button className="btn btn-outline" onClick={handleResetFilters} style={{ fontSize: '11px', padding: '7px 10px' }}>
                Reset Filters
              </button>
            </div>

            {/* Secondary Controls: Neighbourhood Isolation, Attribute Toggle, Zoom Controls */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '8px', fontSize: '12px' }}>
              <div style={{ display: 'flex', gap: '16px', alignItems: 'center', flexWrap: 'wrap' }}>
                <label style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer', color: '#334155', fontWeight: 500 }}>
                  <input
                    type="checkbox"
                    checked={isolateNeighborhood}
                    onChange={(e) => setIsolateNeighborhood(e.target.checked)}
                  />
                  Isolate 1-Hop Neighbourhood of Selected Node
                </label>
                <label style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer', color: '#334155', fontWeight: 500 }}>
                  <input
                    type="checkbox"
                    checked={showAttributeNodes}
                    onChange={(e) => setShowAttributeNodes(e.target.checked)}
                  />
                  Show Key Attribute Nodes on Canvas (PK/FK)
                </label>
                <span style={{ color: '#64748b', fontSize: '11px' }}>
                  Showing <strong>{filteredNodes.length}</strong> nodes &amp; <strong>{filteredEdges.length}</strong> edges
                </span>
              </div>

              <div style={{ display: 'flex', gap: '6px', alignItems: 'center' }}>
                <button
                  className="btn btn-outline"
                  onClick={() => setZoom((z) => Math.min(2.2, Number((z + 0.15).toFixed(2))))}
                  style={{ padding: '4px 8px', fontSize: '11px' }}
                >
                  ＋ Zoom In
                </button>
                <button
                  className="btn btn-outline"
                  onClick={() => setZoom((z) => Math.max(0.4, Number((z - 0.15).toFixed(2))))}
                  style={{ padding: '4px 8px', fontSize: '11px' }}
                >
                  － Zoom Out
                </button>
                <button className="btn btn-outline" onClick={handleFitToScreen} style={{ padding: '4px 8px', fontSize: '11px' }}>
                  ⊡ Fit to Screen ({Math.round(zoom * 100)}%)
                </button>
              </div>
            </div>
          </div>

          {/* MAIN GRAPH WORKSPACE: LEFT CANVAS + RIGHT NODE DETAILS SIDE PANEL */}
          <div style={{ display: 'grid', gridTemplateColumns: '1.65fr 1fr', gap: '14px', minHeight: '640px' }}>
            {/* INTERACTIVE SVG GRAPH CANVAS */}
            <div
              className="card"
              style={{
                padding: 0,
                display: 'flex',
                flexDirection: 'column',
                overflow: 'hidden',
                position: 'relative',
                background: '#f8fafc',
              }}
            >
              {/* View Title Overlay Bar */}
              <div
                style={{
                  padding: '10px 14px',
                  background: '#ffffff',
                  borderBottom: '1px solid #e2e8f0',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                }}
              >
                <div>
                  <span style={{ fontSize: '13px', fontWeight: 700, color: '#0f172a' }}>{viewData.title}</span>
                  <span style={{ fontSize: '11px', color: '#64748b', marginLeft: '10px' }}>{viewData.description}</span>
                </div>
                <span style={{ fontSize: '11px', color: '#64748b' }}>Drag nodes to rearrange • Scroll/buttons to zoom</span>
              </div>

              {filteredNodes.length === 0 ? (
                <div style={{ padding: '80px 24px', textAlign: 'center', color: '#64748b' }}>
                  <h4 style={{ fontSize: '15px', color: '#1e293b', marginBottom: '6px' }}>No Matching Graph Nodes</h4>
                  <p style={{ fontSize: '12px', marginBottom: '14px' }}>
                    No products, attributes, classes, or entities match the current filter combination.
                  </p>
                  <button className="btn btn-primary" onClick={handleResetFilters} style={{ fontSize: '12px' }}>
                    Reset Graph Filters
                  </button>
                </div>
              ) : (
                <svg
                  ref={svgRef}
                  width="100%"
                  height="560"
                  viewBox="0 0 1320 760"
                  onMouseDown={handleMouseDownCanvas}
                  onMouseMove={handleMouseMoveCanvas}
                  onMouseUp={handleMouseUpCanvas}
                  style={{
                    cursor: draggingNodeId ? 'grabbing' : isPanning ? 'grabbing' : 'grab',
                    userSelect: 'none',
                    background: 'radial-gradient(#cbd5e1 1px, transparent 1px)',
                    backgroundSize: '22px 22px',
                  }}
                >
                  <defs>
                    <marker id="arrow-fk" markerWidth="8" markerHeight="8" refX="22" refY="4" orient="auto">
                      <path d="M0,0 L8,4 L0,8 Z" fill="#2563eb" />
                    </marker>
                    <marker id="arrow-map-exact" markerWidth="8" markerHeight="8" refX="22" refY="4" orient="auto">
                      <path d="M0,0 L8,4 L0,8 Z" fill="#16a34a" />
                    </marker>
                    <marker id="arrow-map-proposed" markerWidth="8" markerHeight="8" refX="22" refY="4" orient="auto">
                      <path d="M0,0 L8,4 L0,8 Z" fill="#d97706" />
                    </marker>
                    <marker id="arrow-watson" markerWidth="8" markerHeight="8" refX="20" refY="4" orient="auto">
                      <path d="M0,0 L8,4 L0,8 Z" fill="#7c3aed" />
                    </marker>
                  </defs>

                  <rect width="1320" height="760" fill="transparent" data-bg="true" />

                  <g transform={`translate(${pan.x}, ${pan.y}) scale(${zoom})`}>
                    {/* Column Headers in Integrated View */}
                    {activeView === 'integrated' && (
                      <g>
                        <rect x="45" y="15" width="445" height="32" rx="6" fill="#dbeafe" opacity="0.65" />
                        <text x="267" y="35" textAnchor="middle" fontSize="12" fontWeight="700" fill="#1e40af">
                          DATABRICKS PHARMACEUTICALS PRODUCT MVM (v1 SCHEMA)
                        </text>
                        <rect x="575" y="15" width="210" height="32" rx="6" fill="#f3e8ff" opacity="0.75" />
                        <text x="680" y="35" textAnchor="middle" fontSize="12" fontWeight="700" fill="#6b21a8">
                          WATSON OWL CLASSES
                        </text>
                        <rect x="855" y="15" width="415" height="32" rx="6" fill="#dcfce7" opacity="0.7" />
                        <text x="1062" y="35" textAnchor="middle" fontSize="12" fontWeight="700" fill="#15803d">
                          WATSON CURATED ENTITIES (BRANDS, DRUGS, INDICATIONS)
                        </text>
                      </g>
                    )}

                    {/* Render Edges */}
                    {filteredEdges.map((edge: any) => {
                      const srcPos = nodePositions[edge.source];
                      const tgtPos = nodePositions[edge.target];
                      if (!srcPos || !tgtPos) return null;

                      const isConnectedToSelected =
                        selectedNodeId && (edge.source === selectedNodeId || edge.target === selectedNodeId);
                      const isDimmed = selectedNodeId && !isConnectedToSelected;

                      const baseStyle = EDGE_STYLES[edge.relationship_type] || { stroke: '#94a3b8', width: 1.5 };
                      let strokeColor = baseStyle.stroke;
                      let dashArray = baseStyle.dash;

                      if (edge.relationship_type === 'MAPPED_TO') {
                        const mStatus = edge.mapping_status || 'PROPOSED';
                        strokeColor = MAPPING_STATUS_STYLES[mStatus]?.stroke || '#16a34a';
                        dashArray = MAPPING_STATUS_STYLES[mStatus]?.dash;
                      }

                      const midX = (srcPos.x + tgtPos.x) / 2;
                      const midY = (srcPos.y + tgtPos.y) / 2;

                      return (
                        <g key={edge.id} opacity={isDimmed ? 0.22 : 0.92}>
                          <line
                            x1={srcPos.x}
                            y1={srcPos.y}
                            x2={tgtPos.x}
                            y2={tgtPos.y}
                            stroke={strokeColor}
                            strokeWidth={isConnectedToSelected ? baseStyle.width + 1.2 : baseStyle.width}
                            strokeDasharray={dashArray}
                            markerEnd={
                              edge.relationship_type === 'MAPPED_TO'
                                ? edge.mapping_status === 'EXACT'
                                  ? 'url(#arrow-map-exact)'
                                  : 'url(#arrow-map-proposed)'
                                : edge.relationship_type === 'FOREIGN_KEY_TO'
                                ? 'url(#arrow-fk)'
                                : 'url(#arrow-watson)'
                            }
                          />
                          {(isConnectedToSelected || edge.relationship_type === 'MAPPED_TO') && (
                            <g transform={`translate(${midX}, ${midY})`}>
                              <rect
                                x="-46"
                                y="-9"
                                width="92"
                                height="16"
                                rx="4"
                                fill="#ffffff"
                                stroke={strokeColor}
                                strokeWidth="0.8"
                                opacity="0.92"
                              />
                              <text
                                x="0"
                                y="2"
                                textAnchor="middle"
                                fontSize="8.5"
                                fontWeight="700"
                                fill={strokeColor}
                              >
                                {edge.relationship_type === 'MAPPED_TO'
                                  ? `MAPPED (${edge.mapping_status})`
                                  : edge.relationship_type}
                              </text>
                            </g>
                          )}
                        </g>
                      );
                    })}

                    {/* Render Nodes */}
                    {filteredNodes.map((node: any) => {
                      const pos = nodePositions[node.id] || { x: 400, y: 300 };
                      const typeStyle = NODE_TYPE_STYLES[node.node_type] || NODE_TYPE_STYLES.DATABRICKS_PRODUCT;
                      const isSelected = node.id === selectedNodeId;
                      const isNeighbor = neighborNodeIds.has(node.id);
                      const isDimmed = selectedNodeId && !isNeighbor;

                      const mStatus = node.mapping_status;
                      const statusRing = mStatus ? MAPPING_STATUS_STYLES[mStatus] : null;

                      return (
                        <g
                          key={node.id}
                          transform={`translate(${pos.x}, ${pos.y})`}
                          opacity={isDimmed ? 0.32 : 1}
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedNodeId(node.id);
                          }}
                          onMouseDown={(e) => {
                            e.stopPropagation();
                            setSelectedNodeId(node.id);
                            setDraggingNodeId(node.id);
                          }}
                          style={{ cursor: 'pointer' }}
                        >
                          {/* Selection Halo */}
                          {isSelected && (
                            <circle
                              r={typeStyle.radius + 7}
                              fill="none"
                              stroke="#0f172a"
                              strokeWidth="2.5"
                              strokeDasharray="4,2"
                            />
                          )}

                          {/* Mapping Status Outer Ring for Databricks Products */}
                          {statusRing && node.node_type === 'DATABRICKS_PRODUCT' && (
                            <circle
                              r={typeStyle.radius + 3.5}
                              fill="none"
                              stroke={statusRing.stroke}
                              strokeWidth="2.2"
                              strokeDasharray={statusRing.dash}
                            />
                          )}

                          {/* Main Node Circle */}
                          <circle
                            r={typeStyle.radius}
                            fill={typeStyle.fill}
                            stroke={typeStyle.stroke}
                            strokeWidth={isSelected ? 3 : 2}
                          />

                          {/* Node Icon / Short Code */}
                          <text
                            x="0"
                            y="4"
                            textAnchor="middle"
                            fontSize={typeStyle.radius > 20 ? '10' : '8.5'}
                            fontWeight="700"
                            fill={typeStyle.badgeColor}
                          >
                            {node.node_type === 'DATABRICKS_PRODUCT'
                              ? `DBX (${node.attribute_count || 0})`
                              : node.node_type === 'WATSON_CLASS'
                              ? 'OWL'
                              : node.node_type === 'WATSON_ENTITY'
                              ? 'ENT'
                              : node.node_type === 'EXTERNAL_SCHEMA_ENDPOINT'
                              ? 'EXT'
                              : 'KEY'}
                          </text>

                          {/* Node Label Pill Below Circle */}
                          <g transform={`translate(0, ${typeStyle.radius + 13})`}>
                            <rect
                              x={-Math.max(46, Math.min(88, (node.label?.length || 8) * 3.4))}
                              y="-10"
                              width={Math.max(92, Math.min(176, (node.label?.length || 8) * 6.8))}
                              height="18"
                              rx="4"
                              fill={isSelected ? '#0f172a' : '#ffffff'}
                              stroke={isSelected ? '#0f172a' : '#cbd5e1'}
                              strokeWidth="1"
                            />
                            <text
                              x="0"
                              y="2"
                              textAnchor="middle"
                              fontSize="10"
                              fontWeight={isSelected ? '700' : '600'}
                              fill={isSelected ? '#ffffff' : '#0f172a'}
                            >
                              {node.label?.length > 25 ? node.label.slice(0, 23) + '…' : node.label}
                            </text>
                          </g>
                        </g>
                      );
                    })}
                  </g>
                </svg>
              )}

              {/* VISUAL LEGEND BAR AT BOTTOM OF CANVAS */}
              <div
                style={{
                  padding: '10px 14px',
                  background: '#ffffff',
                  borderTop: '1px solid #e2e8f0',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  flexWrap: 'wrap',
                  gap: '10px',
                  fontSize: '11px',
                }}
              >
                <div style={{ display: 'flex', gap: '12px', alignItems: 'center', flexWrap: 'wrap' }}>
                  <span style={{ fontWeight: 700, color: '#334155' }}>Node Types:</span>
                  {Object.entries(NODE_TYPE_STYLES).map(([k, st]) => (
                    <span key={k} style={{ display: 'inline-flex', alignItems: 'center', gap: '5px', color: '#475569' }}>
                      <span
                        style={{
                          width: '10px',
                          height: '10px',
                          borderRadius: '50%',
                          background: st.fill,
                          border: `2px solid ${st.stroke}`,
                          display: 'inline-block',
                        }}
                      />
                      {st.label}
                    </span>
                  ))}
                </div>

                <div style={{ display: 'flex', gap: '12px', alignItems: 'center', flexWrap: 'wrap' }}>
                  <span style={{ fontWeight: 700, color: '#334155' }}>Mapping Status:</span>
                  <span style={{ display: 'inline-flex', alignItems: 'center', gap: '4px', color: '#15803d', fontWeight: 600 }}>
                    <span style={{ width: '14px', height: '3px', background: '#16a34a', display: 'inline-block' }} />
                    EXACT (Verified)
                  </span>
                  <span style={{ display: 'inline-flex', alignItems: 'center', gap: '4px', color: '#b45309', fontWeight: 600 }}>
                    <span style={{ width: '14px', height: '0px', borderTop: '2.5px dashed #d97706', display: 'inline-block' }} />
                    PROPOSED (Unverified)
                  </span>
                  <span style={{ display: 'inline-flex', alignItems: 'center', gap: '4px', color: '#b91c1c', fontWeight: 600 }}>
                    <span style={{ width: '14px', height: '0px', borderTop: '2.5px dashed #dc2626', display: 'inline-block' }} />
                    CONFLICT
                  </span>
                  <span style={{ display: 'inline-flex', alignItems: 'center', gap: '4px', color: '#475569', fontWeight: 600 }}>
                    <span style={{ width: '14px', height: '0px', borderTop: '2px dotted #64748b', display: 'inline-block' }} />
                    UNRESOLVED
                  </span>
                </div>
              </div>
            </div>

            {/* NODE DETAILS & DATA CATALOG SIDE PANEL */}
            <div
              className="card"
              style={{
                padding: '16px',
                display: 'flex',
                flexDirection: 'column',
                gap: '12px',
                maxHeight: '645px',
                overflowY: 'auto',
              }}
            >
              {!selectedNode ? (
                <div style={{ textAlign: 'center', padding: '40px 16px', color: '#64748b' }}>
                  <h4 style={{ fontSize: '14px', color: '#1e293b', marginBottom: '6px' }}>Select a Graph Node</h4>
                  <p style={{ fontSize: '12px' }}>
                    Click any Databricks Product table, attribute, Watson ontology class, or curated pharmaceutical entity to inspect its schema, relationships, provenance, and mapping rationale.
                  </p>
                </div>
              ) : (
                <>
                  {/* Node Header & Type Badge */}
                  <div style={{ borderBottom: '1px solid #e2e8f0', paddingBottom: '10px' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: '8px' }}>
                      <div>
                        <span
                          style={{
                            fontSize: '10px',
                            fontWeight: 700,
                            padding: '2px 8px',
                            borderRadius: '4px',
                            background: NODE_TYPE_STYLES[selectedNode.node_type]?.badgeBg || '#e2e8f0',
                            color: NODE_TYPE_STYLES[selectedNode.node_type]?.badgeColor || '#334155',
                            textTransform: 'uppercase',
                          }}
                        >
                          {selectedNode.node_type}
                        </span>
                        <h3 style={{ fontSize: '17px', fontWeight: 700, color: '#0f172a', marginTop: '6px', marginBottom: '2px' }}>
                          {selectedNode.label}
                        </h3>
                        <div style={{ fontSize: '11px', fontFamily: 'var(--font-mono)', color: '#64748b' }}>
                          ID: {selectedNode.id} {selectedNode.uri ? `| URI: ${selectedNode.uri}` : ''}
                        </div>
                      </div>

                      {selectedNode.mapping_status && (
                        <span
                          style={{
                            fontSize: '11px',
                            fontWeight: 700,
                            padding: '3px 8px',
                            borderRadius: '6px',
                            background: MAPPING_STATUS_STYLES[selectedNode.mapping_status]?.bg || '#f1f5f9',
                            color: MAPPING_STATUS_STYLES[selectedNode.mapping_status]?.text || '#475569',
                            border: `1px solid ${MAPPING_STATUS_STYLES[selectedNode.mapping_status]?.stroke || '#cbd5e1'}`,
                          }}
                        >
                          {selectedNode.mapping_status}
                        </span>
                      )}
                    </div>

                    {selectedNode.description && (
                      <p style={{ fontSize: '12px', color: '#334155', marginTop: '8px', marginBottom: 0, lineHeight: 1.5 }}>
                        {selectedNode.description}
                      </p>
                    )}
                  </div>

                  {/* Metadata & Provenance Grid */}
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', fontSize: '11px' }}>
                    <div style={{ padding: '8px', background: '#f8fafc', borderRadius: '6px', border: '1px solid #e2e8f0' }}>
                      <div style={{ color: '#64748b' }}>Source Model &amp; Version</div>
                      <div style={{ fontWeight: 600, color: '#0f172a', marginTop: '2px' }}>
                        {selectedNode.source_model || 'Watson Semantic'} ({selectedNode.version || 'v1'})
                      </div>
                    </div>
                    <div style={{ padding: '8px', background: '#f8fafc', borderRadius: '6px', border: '1px solid #e2e8f0' }}>
                      <div style={{ color: '#64748b' }}>Subdomain / Family</div>
                      <div style={{ fontWeight: 600, color: '#0f172a', marginTop: '2px' }}>
                        {selectedNode.subdomain || 'core'}
                      </div>
                    </div>
                  </div>

                  {/* Compatibility & Mapping Rationale Box (if present) */}
                  {(selectedNode.mapping_status || selectedNode.mapping_rationale) && (
                    <div
                      style={{
                        padding: '10px 12px',
                        borderRadius: '8px',
                        background: MAPPING_STATUS_STYLES[selectedNode.mapping_status]?.bg || '#f8fafc',
                        border: `1px solid ${MAPPING_STATUS_STYLES[selectedNode.mapping_status]?.stroke || '#cbd5e1'}`,
                        fontSize: '11.5px',
                      }}
                    >
                      <div style={{ fontWeight: 700, color: MAPPING_STATUS_STYLES[selectedNode.mapping_status]?.text || '#0f172a', marginBottom: '4px' }}>
                        🔗 Semantic Compatibility Status: {MAPPING_STATUS_STYLES[selectedNode.mapping_status]?.label || selectedNode.mapping_status}
                      </div>
                      {selectedNode.mapping_rationale && (
                        <div style={{ color: '#1e293b', lineHeight: 1.45, marginBottom: '6px' }}>
                          <strong>Rationale:</strong> {selectedNode.mapping_rationale}
                        </div>
                      )}
                      {selectedNode.conflict_notes && (
                        <div style={{ color: '#991b1b', background: 'rgba(255,255,255,0.65)', padding: '6px', borderRadius: '4px', marginBottom: '4px' }}>
                          <strong>Conflict / Granularity Note:</strong> {selectedNode.conflict_notes}
                        </div>
                      )}
                      {selectedNode.validation_notes && (
                        <div style={{ color: '#475569', fontSize: '11px' }}>
                          <strong>Validation:</strong> {selectedNode.validation_notes}
                        </div>
                      )}
                    </div>
                  )}

                  {/* Aliases & Linked Attributes for Watson Entities */}
                  {Array.isArray(selectedNode.aliases) && selectedNode.aliases.length > 0 && (
                    <div style={{ padding: '8px 10px', background: '#f8fafc', borderRadius: '6px', border: '1px solid #e2e8f0', fontSize: '11px' }}>
                      <div style={{ fontWeight: 600, color: '#334155', marginBottom: '4px' }}>
                        Curated Vocabulary Aliases (seed_vocabularies.json):
                      </div>
                      <div style={{ display: 'flex', gap: '4px', flexWrap: 'wrap' }}>
                        {selectedNode.aliases.map((al: string, idx: number) => (
                          <span
                            key={idx}
                            style={{
                              padding: '2px 6px',
                              background: '#e0f2fe',
                              color: '#0369a1',
                              borderRadius: '4px',
                              fontFamily: 'var(--font-mono)',
                            }}
                          >
                            {al}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Connected Relationships in Current Graph View */}
                  <div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
                      <span style={{ fontSize: '12px', fontWeight: 700, color: '#1e293b' }}>
                        Connected Relationships ({selectedNodeEdges.length})
                      </span>
                      {selectedNode.node_type === 'DATABRICKS_PRODUCT' && (
                        <button
                          className="btn btn-outline"
                          onClick={() => {
                            const pName = selectedNode.label || selectedNode.id.replace('dbx:product:product.', '');
                            setCatalogSelectedProduct(pName);
                            setSubMode('catalog');
                          }}
                          style={{ fontSize: '10px', padding: '2px 8px' }}
                        >
                          Open Full Table in Data Catalog &rarr;
                        </button>
                      )}
                    </div>
                    <div
                      style={{
                        display: 'flex',
                        flexDirection: 'column',
                        gap: '4px',
                        maxHeight: '155px',
                        overflowY: 'auto',
                        border: '1px solid #e2e8f0',
                        borderRadius: '6px',
                        padding: '6px',
                        background: '#f8fafc',
                      }}
                    >
                      {selectedNodeEdges.length === 0 ? (
                        <div style={{ fontSize: '11px', color: '#64748b', fontStyle: 'italic', padding: '8px' }}>
                          No edges in active view.
                        </div>
                      ) : (
                        selectedNodeEdges.map((edge: any) => {
                          const isOutgoing = edge.source === selectedNode.id;
                          const otherId = isOutgoing ? edge.target : edge.source;
                          return (
                            <div
                              key={edge.id}
                              onClick={() => setSelectedNodeId(otherId)}
                              style={{
                                padding: '5px 8px',
                                background: '#ffffff',
                                borderRadius: '4px',
                                border: '1px solid #e2e8f0',
                                fontSize: '11px',
                                cursor: 'pointer',
                                display: 'flex',
                                justifyContent: 'space-between',
                                alignItems: 'center',
                              }}
                            >
                              <div>
                                <span style={{ fontWeight: 700, color: '#2563eb' }}>{edge.relationship_type}</span>{' '}
                                <span style={{ color: '#64748b' }}>{isOutgoing ? '→' : '←'}</span>{' '}
                                <span style={{ fontFamily: 'var(--font-mono)', fontWeight: 600, color: '#0f172a' }}>
                                  {otherId.split(':').slice(-1)[0]}
                                </span>
                              </div>
                              {edge.mapping_status && (
                                <span
                                  style={{
                                    fontSize: '9.5px',
                                    padding: '1px 5px',
                                    borderRadius: '4px',
                                    background: MAPPING_STATUS_STYLES[edge.mapping_status]?.bg,
                                    color: MAPPING_STATUS_STYLES[edge.mapping_status]?.text,
                                    fontWeight: 700,
                                  }}
                                >
                                  {edge.mapping_status}
                                </span>
                              )}
                            </div>
                          );
                        })
                      )}
                    </div>
                  </div>

                  {/* Attributes Table for Databricks Product Node */}
                  {Array.isArray(selectedNode.attributes) && selectedNode.attributes.length > 0 && (
                    <div>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
                        <span style={{ fontSize: '12px', fontWeight: 700, color: '#1e293b' }}>
                          Product Schema Attributes ({selectedNode.attributes.length} columns)
                        </span>
                        <input
                          type="text"
                          value={attrSearch}
                          onChange={(e) => setAttrSearch(e.target.value)}
                          placeholder="Filter columns..."
                          style={{
                            padding: '3px 8px',
                            fontSize: '11px',
                            borderRadius: '4px',
                            border: '1px solid #cbd5e1',
                            width: '130px',
                          }}
                        />
                      </div>
                      <div
                        style={{
                          maxHeight: '190px',
                          overflowY: 'auto',
                          border: '1px solid #e2e8f0',
                          borderRadius: '6px',
                        }}
                      >
                        <table style={{ fontSize: '11px' }}>
                          <thead>
                            <tr>
                              <th style={{ padding: '6px 8px' }}>Column</th>
                              <th style={{ padding: '6px 8px' }}>Type</th>
                              <th style={{ padding: '6px 8px' }}>Key</th>
                            </tr>
                          </thead>
                          <tbody>
                            {selectedNode.attributes
                              .filter(
                                (a: any) =>
                                  !attrSearch.trim() ||
                                  a.name.toLowerCase().includes(attrSearch.toLowerCase()) ||
                                  (a.description || '').toLowerCase().includes(attrSearch.toLowerCase())
                              )
                              .map((attr: any, i: number) => (
                                <tr key={i}>
                                  <td style={{ padding: '5px 8px', fontFamily: 'var(--font-mono)', fontWeight: 600, color: '#0f172a' }}>
                                    {attr.name}
                                  </td>
                                  <td style={{ padding: '5px 8px', color: '#475569' }}>{attr.data_type}</td>
                                  <td style={{ padding: '5px 8px' }}>
                                    {attr.is_primary_key && (
                                      <span style={{ background: '#dbeafe', color: '#1d4ed8', padding: '1px 5px', borderRadius: '4px', fontSize: '9.5px', fontWeight: 700, marginRight: '3px' }}>
                                        PK
                                      </span>
                                    )}
                                    {attr.is_foreign_key && (
                                      <span style={{ background: '#fef3c7', color: '#b45309', padding: '1px 5px', borderRadius: '4px', fontSize: '9.5px', fontWeight: 700 }}>
                                        FK
                                      </span>
                                    )}
                                  </td>
                                </tr>
                              ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}

                  {/* Provenance Footer */}
                  {selectedNode.provenance && (
                    <div style={{ padding: '8px 10px', background: '#f8fafc', borderRadius: '6px', border: '1px solid #e2e8f0', fontSize: '10.5px', color: '#64748b' }}>
                      <div>
                        <strong>Provenance:</strong> {selectedNode.provenance.source_type || 'databricks_mvm'}
                      </div>
                      {selectedNode.provenance.authoritative_url && (
                        <div style={{ wordBreak: 'break-all', marginTop: '2px' }}>
                          <strong>Source URL:</strong> {selectedNode.provenance.authoritative_url}
                        </div>
                      )}
                    </div>
                  )}
                </>
              )}
            </div>
          </div>
        </>
      )}

      {/* =====================================================================
          SUB-MODE 2: INTERACTIVE DATA CATALOG OF EACH NODE
         ===================================================================== */}
      {subMode === 'catalog' && (
        <div style={{ display: 'grid', gridTemplateColumns: '320px 1fr', gap: '14px', minHeight: '620px' }}>
          {/* Left: Product Tables Directory */}
          <div className="card" style={{ padding: '14px', display: 'flex', flexDirection: 'column', gap: '10px', maxHeight: '650px', overflowY: 'auto' }}>
            <h3 style={{ fontSize: '14px', fontWeight: 700, color: '#0f172a', margin: 0 }}>
              📘 Databricks Product Catalog ({catalogProducts.length} Tables)
            </h3>
            <input
              type="text"
              value={catalogSearch}
              onChange={(e) => setCatalogSearch(e.target.value)}
              placeholder="Filter tables or columns..."
              style={{ padding: '6px 10px', borderRadius: '6px', border: '1px solid #cbd5e1', fontSize: '12px' }}
            />
            <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
              {catalogProducts
                .filter((p: any) => {
                  if (!catalogSearch.trim()) return true;
                  const q = catalogSearch.toLowerCase();
                  return (
                    p.name.toLowerCase().includes(q) ||
                    p.subdomain.toLowerCase().includes(q) ||
                    (p.attributes || []).some((a: any) => a.name.toLowerCase().includes(q))
                  );
                })
                .map((prod: any) => {
                  const pMap = productMappings.find((m: any) => m.databricks_product === prod.name);
                  const isActive = prod.name === activeCatalogProduct?.name;
                  return (
                    <div
                      key={prod.name}
                      onClick={() => setCatalogSelectedProduct(prod.name)}
                      style={{
                        padding: '10px 12px',
                        borderRadius: '6px',
                        border: isActive ? '2px solid #2563eb' : '1px solid #e2e8f0',
                        background: isActive ? '#eff6ff' : '#ffffff',
                        cursor: 'pointer',
                      }}
                    >
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <span style={{ fontSize: '12.5px', fontWeight: 700, color: '#0f172a', fontFamily: 'var(--font-mono)' }}>
                          {prod.name}
                        </span>
                        {pMap && (
                          <span
                            style={{
                              fontSize: '9.5px',
                              fontWeight: 700,
                              padding: '1px 6px',
                              borderRadius: '4px',
                              background: MAPPING_STATUS_STYLES[pMap.mapping_status]?.bg,
                              color: MAPPING_STATUS_STYLES[pMap.mapping_status]?.text,
                            }}
                          >
                            {pMap.mapping_status}
                          </span>
                        )}
                      </div>
                      <div style={{ fontSize: '11px', color: '#64748b', marginTop: '3px', display: 'flex', justifyContent: 'space-between' }}>
                        <span>{prod.subdomain}</span>
                        <span>
                          <strong>{prod.attribute_count}</strong> cols • <strong>{prod.foreign_keys?.length || 0}</strong> FKs
                        </span>
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>

          {/* Right: Selected Product Table Schema, Foreign Keys & Attribute-Level Semantic Mappings */}
          <div className="card" style={{ padding: '18px', display: 'flex', flexDirection: 'column', gap: '14px', maxHeight: '650px', overflowY: 'auto' }}>
            {activeCatalogProduct && (
              <>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '10px', borderBottom: '1px solid #e2e8f0', paddingBottom: '12px' }}>
                  <div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <span style={{ fontSize: '11px', fontWeight: 700, padding: '2px 8px', borderRadius: '4px', background: '#dbeafe', color: '#1d4ed8', textTransform: 'uppercase' }}>
                        {activeCatalogProduct.subdomain}
                      </span>
                      <span style={{ fontSize: '11px', fontFamily: 'var(--font-mono)', color: '#64748b' }}>
                        {activeCatalogProduct.canonical_id}
                      </span>
                    </div>
                    <h3 style={{ fontSize: '20px', fontWeight: 700, color: '#0f172a', marginTop: '6px', marginBottom: '4px', fontFamily: 'var(--font-mono)' }}>
                      {activeCatalogProduct.name}
                    </h3>
                    <p style={{ fontSize: '12.5px', color: '#475569', margin: 0 }}>{activeCatalogProduct.description}</p>
                  </div>

                  <button
                    className="btn btn-primary"
                    onClick={() => focusNodeInGraph(activeCatalogProduct.id || `dbx:product:product.${activeCatalogProduct.name}`, 'integrated')}
                    style={{ fontSize: '12px', padding: '6px 12px' }}
                  >
                    🎯 Focus Node in Graph Canvas
                  </button>
                </div>

                {/* Primary Key & Foreign Key Summary */}
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: '12px' }}>
                  <div style={{ padding: '10px 12px', background: '#f8fafc', borderRadius: '6px', border: '1px solid #e2e8f0', fontSize: '12px' }}>
                    <div style={{ fontWeight: 700, color: '#334155', marginBottom: '4px' }}>Primary Key(s)</div>
                    <div style={{ fontFamily: 'var(--font-mono)', color: '#1d4ed8', fontWeight: 600 }}>
                      {(activeCatalogProduct.primary_key || activeCatalogProduct.primary_keys || []).join(', ') || 'None'}
                    </div>
                  </div>
                  <div style={{ padding: '10px 12px', background: '#f8fafc', borderRadius: '6px', border: '1px solid #e2e8f0', fontSize: '12px' }}>
                    <div style={{ fontWeight: 700, color: '#334155', marginBottom: '4px' }}>
                      Foreign Key Relationships ({activeCatalogProduct.foreign_keys?.length || 0})
                    </div>
                    <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
                      {(activeCatalogProduct.foreign_keys || []).map((fk: any, idx: number) => (
                        <span
                          key={idx}
                          onClick={() => {
                            if (fk.is_in_scope_target) setCatalogSelectedProduct(fk.target_product);
                          }}
                          style={{
                            padding: '2px 7px',
                            borderRadius: '4px',
                            background: fk.is_in_scope_target ? '#eff6ff' : '#fef2f2',
                            color: fk.is_in_scope_target ? '#1d4ed8' : '#b91c1c',
                            border: `1px solid ${fk.is_in_scope_target ? '#bfdbfe' : '#fecaca'}`,
                            fontSize: '11px',
                            fontFamily: 'var(--font-mono)',
                            cursor: fk.is_in_scope_target ? 'pointer' : 'default',
                          }}
                        >
                          {fk.source_columns?.join(',')} &rarr; {fk.target_product}.{fk.target_columns?.join(',')}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Full Column Catalog Table */}
                <div>
                  <h4 style={{ fontSize: '13px', fontWeight: 700, color: '#1e293b', marginBottom: '8px' }}>
                    Complete Column Specification ({activeCatalogProduct.attributes?.length || 0} Attributes)
                  </h4>
                  <div className="table-container" style={{ maxHeight: '380px', overflowY: 'auto' }}>
                    <table>
                      <thead>
                        <tr>
                          <th>#</th>
                          <th>Column Name</th>
                          <th>Data Type</th>
                          <th>Key / Nullable</th>
                          <th>Watson Property Mapping</th>
                          <th>Description</th>
                        </tr>
                      </thead>
                      <tbody>
                        {(activeCatalogProduct.attributes || []).map((col: any, idx: number) => {
                          const attrMap = attributeMappings.find(
                            (am: any) =>
                              am.databricks_product === activeCatalogProduct.name && am.databricks_attribute === col.name
                          );
                          return (
                            <tr key={col.name}>
                              <td style={{ fontSize: '11px', color: '#94a3b8' }}>{idx + 1}</td>
                              <td style={{ fontFamily: 'var(--font-mono)', fontWeight: 600, color: '#0f172a', fontSize: '12px' }}>
                                {col.name}
                              </td>
                              <td style={{ fontFamily: 'var(--font-mono)', fontSize: '11.5px', color: '#0369a1' }}>
                                {col.data_type}
                              </td>
                              <td style={{ fontSize: '11px' }}>
                                {col.is_primary_key && (
                                  <span style={{ background: '#dbeafe', color: '#1d4ed8', padding: '1px 5px', borderRadius: '4px', fontWeight: 700, marginRight: '4px' }}>
                                    PK
                                  </span>
                                )}
                                {col.is_foreign_key && (
                                  <span style={{ background: '#fef3c7', color: '#b45309', padding: '1px 5px', borderRadius: '4px', fontWeight: 700, marginRight: '4px' }}>
                                    FK
                                  </span>
                                )}
                                <span style={{ color: '#64748b' }}>{col.nullable ? 'NULL' : 'NOT NULL'}</span>
                              </td>
                              <td style={{ fontSize: '11px' }}>
                                {attrMap ? (
                                  <div>
                                    <span style={{ fontFamily: 'var(--font-mono)', fontWeight: 600, color: '#7c3aed' }}>
                                      {attrMap.watson_Target}
                                    </span>{' '}
                                    <span
                                      style={{
                                        fontSize: '9.5px',
                                        padding: '1px 4px',
                                        borderRadius: '3px',
                                        background: MAPPING_STATUS_STYLES[attrMap.mapping_status]?.bg,
                                        color: MAPPING_STATUS_STYLES[attrMap.mapping_status]?.text,
                                        fontWeight: 700,
                                      }}
                                    >
                                      {attrMap.mapping_status}
                                    </span>
                                  </div>
                                ) : (
                                  <span style={{ color: '#94a3b8' }}>—</span>
                                )}
                              </td>
                              <td style={{ fontSize: '11.5px', color: '#475569' }}>{col.description}</td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* =====================================================================
          SUB-MODE 3: ENTITY MAPPING & COMPATIBILITY EXPLORER
         ===================================================================== */}
      {subMode === 'mappings' && (
        <div className="card" style={{ padding: '18px', display: 'flex', flexDirection: 'column', gap: '14px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '10px' }}>
            <div>
              <h3 style={{ fontSize: '16px', fontWeight: 700, color: '#0f172a', margin: 0 }}>
                🔗 Databricks Product MVM ↔ Watson Semantic Compatibility Matrix
              </h3>
              <p style={{ fontSize: '12px', color: '#64748b', marginTop: '2px', marginBottom: 0 }}>
                Explicit separation between Databricks schema-level tables (`dbx:`) and Watson curated domain entities (`entity:` / `seed_vocabularies.json`). Schema tables map to OWL classes, never directly equating `medicinal_product` to a specific brand instance like `Keytruda`.
              </p>
            </div>

            <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
              <input
                type="text"
                value={mappingSearch}
                onChange={(e) => setMappingSearch(e.target.value)}
                placeholder="Search mappings..."
                style={{ padding: '6px 10px', borderRadius: '6px', border: '1px solid #cbd5e1', fontSize: '12px' }}
              />
              <select
                value={mappingFilterStatus}
                onChange={(e) => setMappingFilterStatus(e.target.value)}
                style={{ padding: '6px 10px', borderRadius: '6px', border: '1px solid #cbd5e1', fontSize: '12px' }}
              >
                <option value="ALL">All Statuses (19)</option>
                <option value="EXACT">EXACT (3)</option>
                <option value="PROPOSED">PROPOSED (4)</option>
                <option value="CONFLICT">CONFLICT (3)</option>
                <option value="UNRESOLVED">UNRESOLVED (9)</option>
              </select>
            </div>
          </div>

          <div className="table-container" style={{ maxHeight: '480px', overflowY: 'auto' }}>
            <table>
              <thead>
                <tr>
                  <th>Mapping ID</th>
                  <th>Databricks Product / Source</th>
                  <th>Subdomain</th>
                  <th>Status</th>
                  <th>Watson Target Class / Concept</th>
                  <th>Confidence</th>
                  <th>Mapping Rationale &amp; Conflict Notes</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {productMappings
                  .filter((m: any) => {
                    if (mappingFilterStatus !== 'ALL' && m.mapping_status !== mappingFilterStatus) return false;
                    if (!mappingSearch.trim()) return true;
                    const q = mappingSearch.toLowerCase();
                    return (
                      (m.databricks_product || '').toLowerCase().includes(q) ||
                      (m.watson_target_label || '').toLowerCase().includes(q) ||
                      (m.rationale || '').toLowerCase().includes(q)
                    );
                  })
                  .map((m: any) => (
                    <tr key={m.mapping_id}>
                      <td style={{ fontFamily: 'var(--font-mono)', fontSize: '11px', fontWeight: 700, color: '#2563eb' }}>
                        {m.mapping_id}
                      </td>
                      <td style={{ fontFamily: 'var(--font-mono)', fontWeight: 600, fontSize: '12px', color: '#0f172a' }}>
                        {m.databricks_product || <span style={{ color: '#94a3b8' }}>(Watson-Native Only)</span>}
                      </td>
                      <td style={{ fontSize: '11.5px', color: '#475569' }}>{m.databricks_subdomain || 'watson_core'}</td>
                      <td>
                        <span
                          style={{
                            fontSize: '10.5px',
                            fontWeight: 700,
                            padding: '2px 7px',
                            borderRadius: '4px',
                            background: MAPPING_STATUS_STYLES[m.mapping_status]?.bg,
                            color: MAPPING_STATUS_STYLES[m.mapping_status]?.text,
                            border: `1px solid ${MAPPING_STATUS_STYLES[m.mapping_status]?.stroke}`,
                          }}
                        >
                          {m.mapping_status}
                        </span>
                      </td>
                      <td style={{ fontFamily: 'var(--font-mono)', fontSize: '11.5px', color: '#7c3aed', fontWeight: 600 }}>
                        {m.watson_target_uri || <span style={{ color: '#94a3b8' }}>Unmapped</span>}
                      </td>
                      <td style={{ fontSize: '12px', fontWeight: 600, color: '#0f172a' }}>
                        {(m.confidence * 100).toFixed(0)}%
                      </td>
                      <td style={{ fontSize: '11.5px', color: '#334155', maxWidth: '380px', lineHeight: 1.45 }}>
                        <div>{m.rationale}</div>
                        {m.conflict_notes && (
                          <div style={{ color: '#b91c1c', marginTop: '3px', fontWeight: 500 }}>
                            ⚠️ {m.conflict_notes}
                          </div>
                        )}
                      </td>
                      <td>
                        {m.databricks_product && m.databricks_product !== 'masterdata.country' ? (
                          <button
                            className="btn btn-outline"
                            onClick={() => focusNodeInGraph(m.source_concept_id || `dbx:product:product.${m.databricks_product}`, 'integrated')}
                            style={{ fontSize: '11px', padding: '3px 8px' }}
                          >
                            View in Graph
                          </button>
                        ) : m.watson_target_uri ? (
                          <button
                            className="btn btn-outline"
                            onClick={() => focusNodeInGraph(m.watson_target_uri, 'integrated')}
                            style={{ fontSize: '11px', padding: '3px 8px' }}
                          >
                            View Class
                          </button>
                        ) : null}
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
