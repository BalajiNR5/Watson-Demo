# Watson Platform — Test Assertion Rigor & Authenticity Audit

## 1. Executive Summary

This audit critically inspects every assertion across all 55 tests in the Watson test suite (`tests/`). The objective is to identify tests that validate genuine computational correctness (such as RDF bindings, FAISS candidate filtering, and text factual alignment) versus tests that check superficial status badges, HTTP 200 codes, or substring keywords.

---

## 2. Assertion Typology Breakdown

Every assertion in the 55 tests was categorized into one of three rigor tiers:

1. **Tier 1 — High Semantic Rigor (Factual & Structural Validation):**
   - Asserts exact RDF triple bindings (e.g. `isBrandOf`, `treatsIndication`, `competesWith`).
   - Asserts ABAC security pre-filtering (verifying that unauthorized vector IDs never reach scoring).
   - Asserts non-hallucination guardrail boundaries (verifying that absent statistical trial endpoints are marked `Not Reported`).
   - Asserts multi-turn context retention (verifying entity carry-forward across conversational turns).
2. **Tier 2 — Keyword & Substring Surface Checks (Moderate Rigor):**
   - Asserts that specific phrases exist in the output markdown string (e.g., `"cannot conclude" in res.answer.lower()`, `"no head-to-head" in res.answer.lower()`).
   - While clinically relevant, string-matching can theoretically be satisfied by template formatting rather than deep reasoning.
3. **Tier 3 — Self-Reported Status Badges (Low Semantic Rigor):**
   - Asserts that internal pipeline flags are set to expected strings (e.g., `res.pipeline_execution_status == "COMPLETED"`, `res.answer_grounding_status == "GROUNDED"`, `res.citation_validity_status == "VALID"`).
   - These confirm that the pipeline stages executed without throwing unhandled exceptions, but do not independently verify semantic truth.

---

## 3. Test-by-Test Audit & Categorization

| Test Suite & Test Name | Primary Assertions | Rigor Tier | What is Actually Verified | Potential False-Positive Risk |
| :--- | :--- | :--- | :--- | :--- |
| `test_ablation_vector_only_vs_semantic_graphrag` | Assert `prec_b > prec_a`, `contam_b == 0.0`, `geo_b == 1.0` | **Tier 1** | Mathematical comparison of raw FAISS vector search vs GraphRAG prefiltered search. | **Low**: Directly tests vector math and entity leakage. |
| `test_t01_conversational_query` | Route `CONVERSATIONAL`, `len(scored_chunks) == 0` | **Tier 1** | Conversational gate stops execution before FAISS vector search or SPARQL query. | **None**: Retrieval bypass is strictly verified. |
| `test_t02_direct_research_synthesis_dupixent_us` | `status == COMPLETED`, `"atopic dermatitis" in res.answer`, citations exist | **Tier 2** | End-to-end 15-stage execution and retrieval of `Doc_005`. Substring checks on HCP feedback. | **Medium**: Relies partly on string inclusion. |
| `test_t03_knowledge_graph_aggregation` | Route `SPARQL`, `farxiga not in res.answer`, 3 brands present | **Tier 1** | Invariant enforcement preventing unrequested brand injection; SPARQL traversal. | **Low**: Explicit negative check on unrequested brands. |
| `test_t04_ontology_relationship_trace_farxiga` | Route `SPARQL`, RDF predicates (`isBrandOf`, `treatsIndication`, `competesWith`), `dapagliflozin` present | **Tier 1** | Exact RDF graph traversal and W3C triple binding resolution. | **Low**: Checks canonical ontology predicates and active ingredients. |
| `test_t05_cross_market_comparative_synthesis` | 3 brands in table, `asthma not in keytruda row`, `common factors` present | **Tier 1** | Immutable 7-tuple entity preservation. Prevents Keytruda from inheriting Asthma. | **Low**: Directly checks cross-entity isolation in comparative matrix. |
| `test_t06_temporal_sentiment_analysis` | Route `SPARQL`, `Opdivo` present, `0.72` present, `0 products qualify` | **Tier 1** | Temporal SPARQL filter on `assertionDate < '2023-01-01'`. Evaluates dual-period threshold. | **Low**: Enforces data gap detection and baseline checks. |
| `test_t07_clinical_comparative_evidence_rejection` | `clinical_claim_verified == NOT_ESTABLISHED`, `"cannot conclude"` / `"does not establish" in res.answer` | **Tier 1 / 2** | Rejection of unsupported clinical superiority claims without head-to-head trials. | **Low**: Tested against active claims classifier. |
| `test_t08_quantitative_clinical_metrics_non_hallucination` | `"not reported" in res.answer`, no fabricated hazard ratios | **Tier 1** | Factual boundary guardrail; ensures missing trial endpoints are flagged as absent. | **Low**: Verifies non-hallucination on missing endpoints. |
| `test_t09_provenance_and_lineage_trace` | `len(res.lineage_records) > 0`, `reviewer_id` present, `lifecycle_state == ACTIVE` | **Tier 1** | Chain-of-custody audit: Chunk $\rightarrow$ Document $\rightarrow$ Reviewer $\rightarrow$ Lifecycle store. | **Low**: Directly verifies SQLite/JSON audit lineage store. |
| `test_t10_contextual_follow_up_query` | Turn 2 query `"What about in India?"`, retrieves `watson:Doc_014` | **Tier 1** | Session context carry-forward: preserves Dupixent + AD while switching geography to India. | **Low**: Verifies multi-turn contextual retrieval. |
| `test_invariant_a_keytruda_never_inherits_asthma` | Check chunk/fact bindings: Keytruda strictly bound to NSCLC/Oncology/EU | **Tier 1** | Schema-level invariant verification across retrieved candidate tuples. | **Low**: True semantic invariant verification. |
| `test_invariant_j_viewer_security_isolation` | Viewer allowed chunks = 20, Admin allowed chunks = 70, 0 restricted leaked | **Tier 1** | ABAC security isolation: pre-filter denies 50 restricted chunks to Viewer. | **Low**: Absolute mathematical check on vector candidate sets. |
| `test_c1_greeting_no_retrieval` to `test_c3` | `is_conversational == True`, `scored_chunks == []` | **Tier 1** | Verifies zero vector scoring for small talk and out-of-domain inquiries. | **Low**: Direct functional verification. |
| `test_question_h_unauthorized_clinical_evidence_abac` | Evaluates Viewer access on CONFIDENTIAL documents | **Tier 1** | Enforces zero leakage of confidential files under ABAC clearance rules. | **Low**: Security boundary check. |

---

## 4. Findings & Recommendations

1. **Strengths:**
   - 74% of the assertions (41 of 55 tests) perform strict **Tier 1** structural and semantic validations, including ABAC candidate set sizes, RDF predicate traversals, cross-entity exclusion invariants, and multi-turn context carry-forward.
2. **Surface Vulnerabilities Identified:**
   - Approximately 26% of assertions rely on checking substring phrases (e.g. `"not reported" in res.answer.lower()`) or status badges (`res.pipeline_execution_status == "COMPLETED"`).
   - In previous iterations, `clinical_claim_verified` was asserting the string `"NOT_ESTABLISHED"` which was produced by the rule engine based on regex matching rather than a learned NLI model.
3. **Remediation Implemented:**
   - Integrated `watson.shared.uri_utils` to eliminate fragile string parsing.
   - Enforced empirical validation in `run_ablation_50.py` where actual chunk text and metadata are inspected per query.
