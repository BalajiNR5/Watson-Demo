from __future__ import annotations

import hashlib
import json
import os
import shutil
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SUBMISSION_DIR = ROOT / "submission" / "Watson"
DIST_DIR = ROOT / "dist"
ZIP_FILE = DIST_DIR / "Watson_Submission.zip"
DOCS_DIR = ROOT / "docs"

# 24 Root Python modules mapped to their watson package equivalent
MODULE_MAPPINGS = {
    "parser.py": "watson.ingestion.parser",
    "chunker.py": "watson.ingestion.chunker",
    "pii_detector.py": "watson.ingestion.pii_detector",
    "dedup_detector.py": "watson.ingestion.dedup_detector",
    "metadata_extractor.py": "watson.ingestion.metadata_extractor",
    "lifecycle_manager.py": "watson.governance.lifecycle_manager",
    "abac_engine.py": "watson.governance.abac_engine",
    "expiry_manager.py": "watson.governance.expiry_manager",
    "expiry_scanner.py": "watson.governance.expiry_scanner",
    "quality_scorer.py": "watson.governance.quality_scorer",
    "audit_query.py": "watson.governance.audit_query",
    "populate_graph.py": "watson.semantics.populate_graph",
    "taxonomy_manager.py": "watson.semantics.taxonomy_manager",
    "entity_resolver.py": "watson.semantics.entity_resolver",
    "enrichment_pipeline.py": "watson.semantics.enrichment_pipeline",
    "vector_index.py": "watson.retrieval.vector_index",
    "query_router.py": "watson.retrieval.query_router",
    "graphrag_assembler.py": "watson.retrieval.graphrag_assembler",
    "guardrails.py": "watson.retrieval.guardrails",
    "mcp_tools.py": "watson.mcp.mcp_tools",
    "qwen_interface.py": "watson.retrieval.qwen_interface",
    "knowledge_space.py": "watson.spaces.knowledge_space",
    "telemetry.py": "watson.observability.telemetry",
    "telemetry_query.py": "watson.observability.telemetry_query",
}

# 14 Named Non-Python files/directories in Section 13
NON_PYTHON_MAPPINGS = {
    "audit_log.jsonl": ROOT / "data" / "stores" / "audit_log.jsonl",
    "user_registry.json": ROOT / "data" / "stores" / "user_registry.json",
    "pharma.ttl": ROOT / "ontology" / "pharma.ttl",
    "pharma_kg.ttl": ROOT / "ontology" / "pharma_kg.ttl",
    "taxonomy_store.json": ROOT / "data" / "stores" / "taxonomy_store.json",
    "queries.sparql": ROOT / "queries" / "queries.sparql",
    "query_results": ROOT / "queries" / "query_results",
    "telemetry_store.json": ROOT / "data" / "stores" / "telemetry_store.json",
    "feedback_store.json": ROOT / "data" / "stores" / "feedback_store.json",
    "design_decisions.md": ROOT / "docs" / "design_decisions.md",
    "nfr_design.md": ROOT / "docs" / "nfr_design.md",
    "reflection.md": ROOT / "docs" / "reflection.md",
    "README.md": ROOT / "README.md",
}


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while chunk := f.read(65536):
            h.update(chunk)
    return h.hexdigest()


def generate_wrapper(module_name: str) -> str:
    return f'''"""
Watson PRD Section 13 Entry Point: {module_name}
Delegates dynamically to {module_name} in the canonical backend package.
Zero hardcoded absolute paths; strictly relative resolution.
"""
from __future__ import annotations

import sys
from pathlib import Path

# Add backend directory to path relative to this file
_ROOT = Path(__file__).resolve().parent
_BACKEND = _ROOT / "backend"
if str(_BACKEND) not in sys.path:
    sys.path.insert(0, str(_BACKEND))

# Import all exported symbols from canonical implementation
from {module_name} import *

if __name__ == "__main__":
    import importlib
    mod = importlib.import_module("{module_name}")
    if hasattr(mod, "main"):
        mod.main()
'''


def build_submission():
    print("=" * 70)
    print("BUILDING PRD SECTION 13 STANDALONE SUBMISSION DIRECTORY")
    print("=" * 70)

    # 1. Clean and initialize submission directory
    if SUBMISSION_DIR.exists():
        shutil.rmtree(SUBMISSION_DIR)
    SUBMISSION_DIR.mkdir(parents=True, exist_ok=True)
    DIST_DIR.mkdir(parents=True, exist_ok=True)

    # 2. Copy full supporting infrastructure
    for sub_dir in ["backend", "data", "ontology", "queries", "docs", "scripts"]:
        src = ROOT / sub_dir
        dst = SUBMISSION_DIR / sub_dir
        if src.exists():
            print(f" -> Copying infrastructure directory: {sub_dir} -> submission/Watson/{sub_dir}")
            shutil.copytree(src, dst, ignore=shutil.ignore_patterns("__pycache__", "*.pyc", ".git"))

    # Copy root demo.py and scripts
    for script_name in ["demo.py", "bootstrap.ps1", "start.ps1", "stop.ps1", "verify.ps1"]:
        src = ROOT / script_name
        if src.exists():
            shutil.copy2(src, SUBMISSION_DIR / script_name)

    # 3. Generate the 24 Root Python Wrappers
    print("\n -> Generating Root Delegating Wrappers for Section 13 Python Files...")
    for filename, pkg_path in MODULE_MAPPINGS.items():
        target = SUBMISSION_DIR / filename
        target.write_text(generate_wrapper(pkg_path), encoding="utf-8")
        print(f"    [+] {filename} -> {pkg_path}")

    # 4. Copy the 14 Named Non-Python files/directories
    print("\n -> Copying Section 13 Root Assets & Datastores...")
    for filename, src_path in NON_PYTHON_MAPPINGS.items():
        target = SUBMISSION_DIR / filename
        if src_path.is_dir():
            shutil.copytree(src_path, target, dirs_exist_ok=True)
            print(f"    [+] Directory {filename}/ copied ({len(list(target.glob('*')))} files)")
        elif src_path.exists():
            shutil.copy2(src_path, target)
            print(f"    [+] Asset {filename} copied ({src_path.stat().st_size} bytes)")
        else:
            print(f"    [!] Warning: Source asset missing: {src_path}")

    # 5. Build Deliverables Manifest
    print("\n -> Generating SECTION_13_DELIVERABLES_MANIFEST.json...")
    manifest = {
        "platform": "Watson Pharma Knowledge Intelligence Platform",
        "prd_version": "PRD Section 13 Compliant",
        "evaluator_root": "submission/Watson",
        "total_deliverables": 38,
        "deliverables": [],
    }

    # Verify and hash all 38 files
    all_38 = list(MODULE_MAPPINGS.keys()) + list(NON_PYTHON_MAPPINGS.keys()) + ["demo.py"]
    # De-duplicate if needed
    all_38_unique = sorted(list(set(all_38)))

    for item in all_38_unique:
        item_path = SUBMISSION_DIR / item
        if not item_path.exists():
            raise FileNotFoundError(f"Missing required deliverable: {item_path}")

        if item_path.is_file():
            file_hash = sha256_file(item_path)
            file_size = item_path.stat().st_size
            item_type = "file"
        else:
            file_hash = "DIR_SHA256_AGGREGATED"
            file_size = sum(f.stat().st_size for f in item_path.glob("**/*") if f.is_file())
            item_type = "directory"

        manifest["deliverables"].append({
            "name": item,
            "type": item_type,
            "size_bytes": file_size,
            "sha256": file_hash,
            "status": "PASS",
        })

    manifest_path = DOCS_DIR / "SECTION_13_DELIVERABLES_MANIFEST.json"
    with open(manifest_path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2)
    # Also copy manifest into submission root
    shutil.copy2(manifest_path, SUBMISSION_DIR / "SECTION_13_DELIVERABLES_MANIFEST.json")
    print(f"    [+] Manifest saved with {len(manifest['deliverables'])} verified deliverables.")

    # 6. Create Distribution ZIP (Watson_Submission.zip)
    print(f"\n -> Packaging Distribution ZIP: {ZIP_FILE}...")
    if ZIP_FILE.exists():
        ZIP_FILE.unlink()

    with zipfile.ZipFile(ZIP_FILE, "w", zipfile.ZIP_DEFLATED) as zipf:
        for file in SUBMISSION_DIR.rglob("*"):
            if "__pycache__" in str(file) or file.name.endswith(".pyc"):
                continue
            arcname = Path("Watson") / file.relative_to(SUBMISSION_DIR)
            zipf.write(file, arcname)

    zip_hash = sha256_file(ZIP_FILE)
    zip_size_mb = ZIP_FILE.stat().st_size / (1024 * 1024)
    print(f"    [+] Watson_Submission.zip created successfully!")
    print(f"    [+] Size: {zip_size_mb:.2f} MB")
    print(f"    [+] SHA-256: {zip_hash}")

    print("\n" + "=" * 70)
    print("SUBMISSION PACKAGING COMPLETED SUCCESSFULLY")
    print("=" * 70)
    return zip_hash


if __name__ == "__main__":
    build_submission()
