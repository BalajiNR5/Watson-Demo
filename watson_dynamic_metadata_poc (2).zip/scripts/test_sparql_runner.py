import sys
import re
import time
from pathlib import Path

# Add backend directory
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "backend"))

from watson.retrieval.graphrag_assembler import GraphRAGAssembler

assembler = GraphRAGAssembler()
queries_file = Path(__file__).resolve().parent.parent / "queries" / "queries.sparql"
content = queries_file.read_text(encoding="utf-8")
blocks = re.split(r"# =+\r?\n# (Q\d+): ([^\r\n]+)\r?\n", content)

templates = []
for i in range(1, len(blocks), 3):
    qid = blocks[i].strip()
    title = blocks[i+1].strip()
    rest = blocks[i+2]
    match = re.search(r"(PREFIX|SELECT)", rest)
    if match:
        desc = rest[:match.start()].strip()
        desc = re.sub(r"#+\s*", "", desc).replace("=", "").strip()
        sparql = rest[match.start():].strip()
        sparql = re.split(r"# =+", sparql)[0].strip()
        templates.append({"id": qid, "name": title, "sparql": sparql})

print(f"Testing {len(templates)} queries against in-memory graph ({len(assembler.graph)} triples)...")
for t in templates:
    t0 = time.time()
    try:
        res = assembler.graph.query(t["sparql"])
        rows = list(res)
        dur = round((time.time() - t0) * 1000, 1)
        print(f"[{t['id']}] {t['name']}: SUCCESS ({dur}ms, {len(rows)} rows, vars: {[str(v) for v in res.vars]})")
    except Exception as e:
        print(f"[{t['id']}] {t['name']}: FAILED ({e})")
