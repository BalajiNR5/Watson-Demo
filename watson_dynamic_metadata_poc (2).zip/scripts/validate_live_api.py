import urllib.request
import json

def test_query(label, q):
    print("=" * 70)
    print(f"TEST: {label}")
    print(f"QUERY: {q}")
    req = urllib.request.Request(
        "http://localhost:8000/api/chat",
        data=json.dumps({"query": q}).encode(),
        headers={"Content-Type": "application/json", "x-user-id": "D4"}
    )
    resp = json.loads(urllib.request.urlopen(req).read().decode())
    print("\nANSWER:\n", resp.get("answer"))
    print("\nROUTE:", resp.get("route"))
    print("STATUSES:", resp.get("pipeline_execution_status"), resp.get("answer_relevance_status"), resp.get("answer_grounding_status"))
    print("CITATIONS:", [c.get("source_uri") for c in resp.get("citations", [])])
    print("COVERAGE MATRIX:", resp.get("evidence_coverage_matrix"))

if __name__ == "__main__":
    test_query(
        "FAIL 1: Superiority Question",
        "can we conclude clinical superiority of Farxiga over Jardiance in CKD?"
    )
    test_query(
        "FAIL 2: Ontology Trace Question",
        "Using the semantic knowledge graph, explain the relationships surrounding Farxiga, its active ingredient, treated indications, therapeutic area, and supporting EU study document."
    )
    test_query(
        "FAIL 3: Conversational 'hi'",
        "hi"
    )
