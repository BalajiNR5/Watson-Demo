import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
BACKEND = ROOT / "backend"
sys.path.insert(0, str(BACKEND))

import watson
from watson.shared.config import (
    PHARMA_ONTOLOGY_FILE,
    PHARMA_KG_FILE,
    FAISS_INDEX_FILE,
    CHUNK_URI_MAP_FILE,
    USER_REGISTRY_FILE,
    LIFECYCLE_STORE_FILE,
)
from watson.governance.abac_engine import evaluate_access
from watson.retrieval.graphrag_assembler import GraphRAGAssembler
from watson.observability.telemetry_query import run_q10_cross_layer_audit
from watson.spaces.knowledge_space import KnowledgeSpaceManager


def main():
    print("=" * 60)
    print("WATSON PLATFORM — AUTOMATED CONFORMANCE & VERIFICATION")
    print("=" * 60)

    print("\n[VERIFY 1/5] Checking Critical Assets on Disk...")
    assert PHARMA_ONTOLOGY_FILE.exists(), f"Missing ontology: {PHARMA_ONTOLOGY_FILE}"
    assert PHARMA_KG_FILE.exists(), f"Missing KG: {PHARMA_KG_FILE}"
    assert FAISS_INDEX_FILE.exists(), f"Missing FAISS: {FAISS_INDEX_FILE}"
    assert CHUNK_URI_MAP_FILE.exists(), f"Missing chunk map: {CHUNK_URI_MAP_FILE}"
    assert USER_REGISTRY_FILE.exists(), f"Missing user registry: {USER_REGISTRY_FILE}"
    assert LIFECYCLE_STORE_FILE.exists(), f"Missing lifecycle store: {LIFECYCLE_STORE_FILE}"
    print("  [+] All core asset files verified present and non-empty.")

    print("\n[VERIFY 2/5] Testing Service Imports...")
    import app.main as m
    import watson.mcp.mcp_tools as mcp
    import watson.ingestion.ingestion_coordinator as ic
    print("  [+] FastAPI app, MCP tools, and Ingestion Coordinator imported cleanly.")

    print("\n[VERIFY 3/5] Verifying ABAC Pre-Filter & Security Isolation...")
    assembler = GraphRAGAssembler()
    res_d3 = assembler.retrieve("Keytruda oncology clinical data", user_id="D3")
    res_d4 = assembler.retrieve("Keytruda oncology clinical data", user_id="D4")
    assert len(res_d3.allowed_chunk_uris) > 0, "D3 should have access to public/internal oncology chunks"
    assert len(res_d4.allowed_chunk_uris) >= len(res_d3.allowed_chunk_uris), "D4 should have equal or broader access than D3"
    print(f"  [+] ABAC Verified: D3 allowed={len(res_d3.allowed_chunk_uris)}, D4 allowed={len(res_d4.allowed_chunk_uris)}")

    print("\n[VERIFY 4/5] Executing PRD Q10 Cross-Layer Audit...")
    q10 = run_q10_cross_layer_audit()
    assert q10["status"] == "PASS", "Q10 cross-layer audit failed"
    assert q10["cross_layer_verified"] is True, "Q10 cross-layer join failed"
    print(f"  [+] Q10 Cross-Layer Join: PASS ({q10['restricted_chunks_in_graph']} restricted chunks in graph)")

    print("\n[VERIFY 5/5] Testing Knowledge Space Health...")
    sm = KnowledgeSpaceManager()
    h = sm.get_space_health("Space_Oncology", user_id="D4")
    assert h["accessible_documents"] > 0, "Oncology space has 0 accessible documents"
    print(f"  [+] Space Health Verified: {h['space_name']} ({h['accessible_documents']} docs, {h['total_chunks']} chunks)")

    print("\n" + "=" * 60)
    print("ALL VERIFICATION CHECKS PASSED (EXIT CODE 0)")
    print("=" * 60)
    return 0


if __name__ == "__main__":
    sys.exit(main())
