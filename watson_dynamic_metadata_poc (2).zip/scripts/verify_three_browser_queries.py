import json
import urllib.request

QUERIES = [
    {
        "name": "TEST A — Dupixent US HCP Concerns & Recommendations",
        "query": "What concerns do healthcare professionals express about Dupixent for atopic dermatitis in the United States, and what improvements do they recommend?",
    },
    {
        "name": "TEST B — Three-Brand Cross-Market Comparison",
        "query": "Compare the market access considerations for Keytruda in EU oncology, Dupixent in US immunology, and Xolair in Indian respiratory care. What factors are common, and what differences can the available evidence establish?",
    },
    {
        "name": "TEST C — Temporal HCP Sentiment Trajectory",
        "query": "Which drugs had declining HCP sentiment before 2023 versus 2023 onward?",
    },
]

def run_tests():
    for item in QUERIES:
        name = item["name"]
        query = item["query"]
        print("=" * 80)
        print(f"RUNNING: {name}")
        print(f"QUERY: {query}")
        print("=" * 80)

        req_data = json.dumps({"query": query, "user_id": "D4"}).encode("utf-8")
        req = urllib.request.Request(
            "http://127.0.0.1:8000/api/chat",
            data=req_data,
            headers={"Content-Type": "application/json"},
        )
        try:
            resp = json.loads(urllib.request.urlopen(req).read().decode())
        except Exception as e:
            print(f"FAILED TO EXECUTE QUERY: {e}")
            continue

        print("\n1. QUERY INTENT:")
        print(f"   Route: {resp.get('route')}")
        print(f"   Pipeline Status: {resp.get('pipeline_execution_status')}")
        print(f"   Conversation Intent: {resp.get('conversation_intent')}")

        print("\n2. CANONICAL ENTITY MAPPINGS:")
        cov_matrix = resp.get("evidence_coverage_matrix") or {}
        subjects = cov_matrix.get("subjects", [])
        for s in subjects:
            print(f"   - Brand: {s.get('subject_brand')} | Drug: {s.get('drug')} | Indication: {s.get('indication')} | TA: {s.get('therapeutic_area')} | Geo: {s.get('geography')}")

        print("\n3. SELECTED RDF PATHS / KG FACTS:")
        kg_facts = resp.get("kg_facts", [])
        for f in kg_facts[:5]:
            print(f"   - {f.get('subject')} --[{f.get('predicate')}]--> {f.get('object')} (Type: {f.get('assertion_type')})")
        if len(kg_facts) > 5:
            print(f"   ... and {len(kg_facts) - 5} more facts.")

        print("\n4. RETRIEVED SOURCE DOCUMENTS & CHUNKS:")
        chunks = resp.get("scored_chunks", [])
        for c in chunks[:4]:
            print(f"   - Chunk: {c.get('chunk_uri')} (Doc: {c.get('doc_uri')}, Sim: {c.get('similarity', 0.0):.3f})")

        print("\n5. FINAL ANSWER:")
        print("-" * 60)
        print(resp.get("answer"))
        print("-" * 60)

        print("\n6. CITATION VERIFICATION:")
        cites = resp.get("citations", [])
        print(f"   Total Citations: {len(cites)}")
        for cite in cites[:5]:
            print(f"   - {cite.get('source_uri')} (Doc: {cite.get('doc_uri')})")

        print("\n7. GROUNDING RESULT:")
        print(f"   Grounding Status: {resp.get('answer_grounding_status')}")
        print(f"   Relevance Status: {resp.get('answer_relevance_status')}")
        print(f"   Guardrail Status: {resp.get('guardrail_status')}")

        # Validation check
        ans = resp.get("answer", "").lower()
        if "test a" in name.lower():
            passed = "dupixent" in ans and "atopic dermatitis" in ans and resp.get("answer_grounding_status") == "GROUNDED"
        elif "test b" in name.lower():
            keytruda_ok = "keytruda" in ans and "nsclc" in ans and not any("keytruda" in l and "asthma" in l for l in ans.splitlines() if "|" in l)
            dupixent_ok = "dupixent" in ans and "atopic dermatitis" in ans
            xolair_ok = "xolair" in ans and "asthma" in ans
            passed = keytruda_ok and dupixent_ok and xolair_ok
        elif "test c" in name.lower():
            passed = resp.get("route") == "SPARQL" and "opdivo" in ans and ("-0.17" in ans or "0.72" in ans)
        else:
            passed = True

        print(f"\n8. TEST STATUS: {'>>> PASS <<<' if passed else '>>> FAIL <<<'}\n\n")

if __name__ == "__main__":
    run_tests()
