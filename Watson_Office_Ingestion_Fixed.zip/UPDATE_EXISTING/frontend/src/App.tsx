import React, { useState, useEffect } from 'react';
import { api, UserProfile, DocumentRecord, ChatResponse, SearchResponse, SparqlTemplate, SparqlResponse } from './services/api';
import { SafeMarkdownRenderer } from './components/SafeMarkdownRenderer';
import { ReviewDocument, displayExpiry, displayValue } from './components/ReviewDocument';

export default function App() {
  const [activeTab, setActiveTab] = useState<'copilot' | 'ingestion' | 'hitl' | 'library' | 'kg' | 'spaces' | 'sparql' | 'governance' | 'health'>('copilot');
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [personas, setPersonas] = useState<UserProfile[]>([]);

  // Copilot State
  const [query, setQuery] = useState('');
  const [chatLoading, setChatLoading] = useState(false);
  const [chatHistory, setChatHistory] = useState<Array<{ sender: 'user' | 'watson'; text: string; data?: ChatResponse }>>([]);
  const [selectedCitation, setSelectedCitation] = useState<any | null>(null);
  const [activeCopilotPane, setActiveCopilotPane] = useState<'trace' | 'kg' | 'lineage' | 'quality' | 'why'>('trace');
  const [selectedLineage, setSelectedLineage] = useState<any | null>(null);
  const [selectedFact, setSelectedFact] = useState<any | null>(null);
  const [activeAnswer, setActiveAnswer] = useState<ChatResponse | null>(null);
  const [expandedStage, setExpandedStage] = useState<number | null>(null);

  // Documents State
  const [documents, setDocuments] = useState<DocumentRecord[]>([]);
  const [selectedDoc, setSelectedDoc] = useState<DocumentRecord | null>(null);

  // Ingestion & HITL State
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [uploadStatus, setUploadStatus] = useState<string>('');
  const [stagedDoc, setStagedDoc] = useState<any | null>(null);
  const [pendingDocs, setPendingDocs] = useState<any[]>([]);
  const [uploading, setUploading] = useState(false);
  const [reviewing, setReviewing] = useState(false);
  const [pendingError, setPendingError] = useState('');

  // Spaces State
  const [spaces, setSpaces] = useState<any[]>([]);
  const [selectedSpaceHealth, setSelectedSpaceHealth] = useState<any | null>(null);

  // Audit & Telemetry State
  const [auditLogs, setAuditLogs] = useState<any[]>([]);
  const [telemetry, setTelemetry] = useState<any | null>(null);
  const [q10Result, setQ10Result] = useState<any | null>(null);

  // SPARQL Studio State
  const [sparqlQuery, setSparqlQuery] = useState('');
  const [sparqlResults, setSparqlResults] = useState<SparqlResponse | null>(null);
  const [sparqlLoading, setSparqlLoading] = useState(false);
  const [sparqlError, setSparqlError] = useState<string | null>(null);
  const [sparqlTemplates, setSparqlTemplates] = useState<SparqlTemplate[]>([]);
  const [selectedTemplateId, setSelectedTemplateId] = useState<string>('Q01');
  const [sparqlFilter, setSparqlFilter] = useState('');
  const [sparqlCategoryFilter, setSparqlCategoryFilter] = useState('ALL');

  useEffect(() => {
    loadUserAndPersonas();
  }, []);

  useEffect(() => {
    if (activeTab === 'hitl') loadPendingDocuments();
    if (activeTab === 'library') loadDocuments();
    if (activeTab === 'spaces') loadSpaces();
    if (activeTab === 'governance') loadAuditLogs();
    if (activeTab === 'health') loadTelemetry();
    if (activeTab === 'sparql') loadSparqlTemplates();
  }, [activeTab, currentUser]);

  const loadUserAndPersonas = async () => {
    try {
      const u = await api.getCurrentUser();
      const p = await api.getPersonas();
      setCurrentUser(u);
      setPersonas(p);
    } catch (e) {
      console.error(e);
    }
  };

  const handleSwitchPersona = async (uid: string) => {
    try {
      const res = await api.switchPersona(uid);
      setCurrentUser(res.current_user);
      // Reload current tab content
      if (activeTab === 'library') loadDocuments();
      if (activeTab === 'spaces') loadSpaces();
    } catch (e) {
      console.error(e);
    }
  };

  const loadDocuments = async () => {
    try {
      const docs = await api.getDocuments();
      setDocuments(docs);
    } catch (e) {
      console.error(e);
    }
  };

  const loadSpaces = async () => {
    try {
      const s = await api.getSpaces();
      setSpaces(s);
      if (s.length > 0) {
        const h = await api.getSpaceHealth(s[0].space_id);
        setSelectedSpaceHealth(h);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const loadAuditLogs = async () => {
    try {
      const logs = await api.getAuditLogs();
      setAuditLogs(logs);
    } catch (e) {
      console.error(e);
    }
  };

  const loadTelemetry = async () => {
    try {
      const t = await api.getTelemetryStats();
      const q = await api.getQ10Audit();
      setTelemetry(t);
      setQ10Result(q);
    } catch (e) {
      console.error(e);
    }
  };

  const loadSparqlTemplates = async () => {
    try {
      const data = await api.getSparqlTemplates();
      setSparqlTemplates(data.templates);
      if (data.templates && data.templates.length > 0) {
        if (!sparqlQuery) {
          setSparqlQuery(data.templates[0].sparql);
          setSelectedTemplateId(data.templates[0].id);
        }
      }
    } catch (e) {
      console.error('Failed to load SPARQL templates:', e);
    }
  };

  const handleSelectTemplate = (template: SparqlTemplate) => {
    setSelectedTemplateId(template.id);
    setSparqlQuery(template.sparql);
    setSparqlError(null);
  };

  const handleExecuteSparql = async (queryToRun?: string) => {
    const q = (queryToRun !== undefined ? queryToRun : sparqlQuery).trim();
    if (!q) {
      setSparqlError('Please enter a SPARQL query to execute.');
      return;
    }
    setSparqlLoading(true);
    setSparqlError(null);
    try {
      const res = await api.executeSparql(q);
      setSparqlResults(res);
    } catch (err: any) {
      setSparqlError(err.message || 'SPARQL execution failed');
      setSparqlResults(null);
    } finally {
      setSparqlLoading(false);
    }
  };

  const insertStandardPrefixes = () => {
    const prefixes = [
      'PREFIX watson: <http://watson.pharma.org/ontology/>',
      'PREFIX entity: <http://watson.pharma.org/entity/>',
      'PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>',
      'PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>',
      'PREFIX owl: <http://www.w3.org/2002/07/owl#>',
    ];
    let q = sparqlQuery;
    prefixes.forEach((p) => {
      const prefixKey = p.split(':')[0];
      if (!q.includes(prefixKey)) {
        q = p + '\n' + q;
      }
    });
    setSparqlQuery(q);
  };

  const exportSparqlCsv = () => {
    if (!sparqlResults || !sparqlResults.results || sparqlResults.results.length === 0) return;
    const cols = sparqlResults.columns;
    const header = cols.join(',');
    const rows = sparqlResults.results.map((r) =>
      cols.map((c) => `"${(r[c] || '').replace(/"/g, '""')}"`).join(',')
    );
    const csvContent = [header, ...rows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `watson_sparql_${selectedTemplateId || 'query'}_${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const exportSparqlJson = () => {
    if (!sparqlResults) return;
    const blob = new Blob([JSON.stringify(sparqlResults, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `watson_sparql_${selectedTemplateId || 'query'}_${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const formatUriCell = (val: string) => {
    if (!val) return <span style={{ color: '#94a3b8' }}>—</span>;
    if (val.startsWith('http://watson.pharma.org/ontology/')) {
      return (
        <span title={val} style={{ color: '#2563eb', fontWeight: 500, fontFamily: 'var(--font-mono)' }}>
          watson:{val.replace('http://watson.pharma.org/ontology/', '')}
        </span>
      );
    }
    if (val.startsWith('http://watson.pharma.org/entity/')) {
      return (
        <span title={val} style={{ color: '#0d9488', fontWeight: 500, fontFamily: 'var(--font-mono)' }}>
          entity:{val.replace('http://watson.pharma.org/entity/', '')}
        </span>
      );
    }
    if (val.startsWith('http://www.w3.org/')) {
      const parts = val.split(/[#/]/);
      return (
        <span title={val} style={{ color: '#64748b', fontFamily: 'var(--font-mono)' }}>
          w3:{parts[parts.length - 1]}
        </span>
      );
    }
    if (val.startsWith('watson:')) {
      return (
        <span title={val} style={{ color: '#2563eb', fontWeight: 500, fontFamily: 'var(--font-mono)' }}>
          {val}
        </span>
      );
    }
    return <span title={val}>{val}</span>;
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim() || chatLoading) return;

    const userText = query;
    setQuery('');
    setChatHistory((prev) => [...prev, { sender: 'user', text: userText }]);
    setChatLoading(true);

    try {
      const res = await api.chat(userText);
      setChatHistory((prev) => [...prev, { sender: 'watson', text: res.answer, data: res }]);
      setActiveAnswer(res);
      if (res.lineage_records && res.lineage_records.length > 0) {
        setSelectedLineage(res.lineage_records[0]);
      }
      if (res.kg_facts && res.kg_facts.length > 0) {
        setSelectedFact(res.kg_facts[0]);
      }
    } catch (err: any) {
      setChatHistory((prev) => [
        ...prev,
        { sender: 'watson', text: `Access Denied or Guardrail Warning: ${err.message}` },
      ]);
    } finally {
      setChatLoading(false);
    }
  };

  const loadPendingDocuments = async () => {
    try {
      setPendingError('');
      const response = await api.getPendingDocuments();
      const docs = Array.isArray(response) ? response : [];
      setPendingDocs(docs);
      setStagedDoc((previous: any) => docs.find((d: any) => d.document_uri === previous?.document_uri) || docs[0] || null);
    } catch (err: any) { setPendingError(err.message); }
  };

  const handleFileUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!uploadFile || uploading) return;
    setUploading(true);
    setUploadStatus('Uploading and staging document through Layer 1...');
    try {
      const staged = await api.uploadDocument(uploadFile);
      setStagedDoc(staged);
      setUploadStatus(staged.duplicate_upload ? 'This document is already pending review. Reopening it.' : `Document staged: ${staged.doc_id} in state UNDER_REVIEW`);
      setActiveTab('hitl');
    } catch (err: any) {
      setUploadStatus(`Upload Error: ${err.message}`);
    } finally { setUploading(false); }
  };

  const handleApproveDocument = async (decision: 'APPROVE' | 'REJECT') => {
    if (!stagedDoc || reviewing) return;
    setReviewing(true);
    try {
      await api.reviewDocument({
        document_uri: stagedDoc.document_uri,
        decision,
        review_note: decision === 'APPROVE' ? 'Approved during HITL review' : 'Rejected',
        pii_override: stagedDoc.has_critical_pii,
      });
      alert(`Document ${decision === 'APPROVE' ? 'Approved & Activated' : 'Rejected'}!`);
      setStagedDoc(null);
      loadDocuments();
      setActiveTab('library');
    } catch (err: any) {
      alert(`Review error: ${err.message}`);
    } finally { setReviewing(false); }
  };

  return (
    <div className="app-container">
      {/* Sidebar */}
      <aside className="sidebar">
        <div className="sidebar-header">
          <div className="sidebar-logo">W</div>
          <div>
            <h2 style={{ fontSize: '16px', fontWeight: 700 }}>Watson Platform</h2>
            <p style={{ fontSize: '11px', color: '#94a3b8' }}>Pharma Intelligence</p>
          </div>
        </div>

        <nav className="sidebar-nav">
          <button className={`nav-item ${activeTab === 'copilot' ? 'active' : ''}`} onClick={() => setActiveTab('copilot')}>
            💬 Research Copilot
          </button>
          <button className={`nav-item ${activeTab === 'ingestion' ? 'active' : ''}`} onClick={() => setActiveTab('ingestion')}>
            📥 Ingestion Console
          </button>
          <button className={`nav-item ${activeTab === 'hitl' ? 'active' : ''}`} onClick={() => setActiveTab('hitl')}>
            ⚖️ HITL Workbench {stagedDoc && <span style={{ background: '#ef4444', color: '#fff', borderRadius: '10px', padding: '1px 6px', fontSize: '10px' }}>1</span>}
          </button>
          <button className={`nav-item ${activeTab === 'library' ? 'active' : ''}`} onClick={() => setActiveTab('library')}>
            📚 Document Library
          </button>
          <button className={`nav-item ${activeTab === 'kg' ? 'active' : ''}`} onClick={() => setActiveTab('kg')}>
            🕸️ KG Explorer
          </button>
          <button className={`nav-item ${activeTab === 'spaces' ? 'active' : ''}`} onClick={() => setActiveTab('spaces')}>
            🪐 Knowledge Spaces
          </button>
          <button className={`nav-item ${activeTab === 'sparql' ? 'active' : ''}`} onClick={() => setActiveTab('sparql')}>
            🔍 SPARQL Studio
          </button>
          <button className={`nav-item ${activeTab === 'governance' ? 'active' : ''}`} onClick={() => setActiveTab('governance')}>
            🛡️ Governance & Audit
          </button>
          <button className={`nav-item ${activeTab === 'health' ? 'active' : ''}`} onClick={() => setActiveTab('health')}>
            📊 System Health & Q10
          </button>
        </nav>
      </aside>

      {/* Main Content Area */}
      <main className="main-content">
        {/* Topbar with Persona Switcher */}
        <header className="topbar">
          <div className="topbar-title">
            {activeTab === 'copilot' && 'Pharma Research Copilot (GraphRAG)'}
            {activeTab === 'ingestion' && 'Governed Document Ingestion Console'}
            {activeTab === 'hitl' && 'Human-in-the-Loop Review Workbench'}
            {activeTab === 'library' && 'Governed Pharmaceutical Document Library'}
            {activeTab === 'kg' && 'Pharma Knowledge Graph & Ontology Explorer'}
            {activeTab === 'spaces' && 'Specialized Knowledge Spaces & Health (Q11)'}
            {activeTab === 'sparql' && 'Interactive SPARQL Query Studio'}
            {activeTab === 'governance' && 'Audit Log & ABAC Policy Enforcement'}
            {activeTab === 'health' && 'Platform Telemetry & Q10 Cross-Layer Audit'}
          </div>

          <div className="persona-switcher">
            <span style={{ fontSize: '12px', fontWeight: 600, color: '#475569' }}>Persona:</span>
            <select
              value={currentUser?.user_id || ''}
              onChange={(e) => handleSwitchPersona(e.target.value)}
              style={{ padding: '4px 8px', borderRadius: '4px', border: '1px solid #cbd5e1', fontSize: '13px', fontWeight: 500 }}
            >
              {personas.map((p) => (
                <option key={p.user_id} value={p.user_id}>
                  {p.name} ({p.role})
                </option>
              ))}
            </select>
            <span className={`badge badge-${currentUser?.role === 'VIEWER' ? 'internal' : 'restricted'}`}>
              {currentUser?.role}
            </span>
          </div>
        </header>

        {/* Content Body */}
        <div className="content-body">
          {/* TAB 1: COPILOT (4 COORDINATED VIEWS) */}
          {activeTab === 'copilot' && (
            <div style={{ display: 'grid', gridTemplateColumns: '1.1fr 1fr', height: '100%', gap: '16px' }}>
              {/* VIEW A: MAIN CHAT */}
              <div style={{ display: 'flex', flexDirection: 'column', height: '100%', gap: '12px', minWidth: 0 }}>
                <div style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '14px', paddingBottom: '16px' }}>
                  {chatHistory.length === 0 && (
                    <div className="card" style={{ textAlign: 'center', padding: '32px 20px', color: '#64748b' }}>
                      <h3 style={{ fontSize: '18px', color: '#1e293b', marginBottom: '8px' }}>Watson Pharmaceutical Intelligence Copilot</h3>
                      <p style={{ maxWidth: '480px', margin: '0 auto 16px', fontSize: '13px' }}>
                        Three-layer Semantic GraphRAG platform. Direct participation of OWL ontology, deductive knowledge graph, and ABAC-prefiltered document evidence.
                      </p>
                      <div style={{ display: 'flex', gap: '6px', justifyContent: 'center', flexWrap: 'wrap' }}>
                        <button className="btn btn-outline" style={{ fontSize: '11px', padding: '6px 10px' }} onClick={() => setQuery('What is the clinical evidence for Keytruda in NSCLC?')}>
                          Keytruda in NSCLC
                        </button>
                        <button className="btn btn-outline" style={{ fontSize: '11px', padding: '6px 10px' }} onClick={() => setQuery('Show declining sentiment trends for Farxiga over time')}>
                          Farxiga Sentiment Trends
                        </button>
                        <button className="btn btn-outline" style={{ fontSize: '11px', padding: '6px 10px' }} onClick={() => setQuery('Compare market access barriers for Dupixent across geographies')}>
                          Dupixent Market Access
                        </button>
                      </div>
                    </div>
                  )}

                  {chatHistory.map((msg, i) => (
                    <div key={i} style={{ display: 'flex', justifyContent: msg.sender === 'user' ? 'flex-end' : 'flex-start' }}>
                      <div
                        style={{
                          maxWidth: '85%',
                          padding: '14px 18px',
                          borderRadius: '12px',
                          background: msg.sender === 'user' ? 'var(--primary)' : '#ffffff',
                          color: msg.sender === 'user' ? '#ffffff' : '#0f172a',
                          border: msg.sender === 'user' ? 'none' : '1px solid var(--border)',
                          boxShadow: '0 1px 2px rgba(0,0,0,0.05)',
                        }}
                      >
                        {msg.sender === 'user' ? (
                          <p style={{ fontSize: '14px', whiteSpace: 'pre-wrap', lineHeight: 1.6, margin: 0 }}>{msg.text}</p>
                        ) : (
                          <SafeMarkdownRenderer
                            content={msg.text}
                            onCitationClick={(uri) => {
                              if (msg.data?.citations) {
                                const match = msg.data.citations.find((c: any) => c.source_uri === uri);
                                if (match) setSelectedCitation(match);
                              }
                              if (msg.data?.lineage_records) {
                                const matchLin = msg.data.lineage_records.find((l: any) => l.chunk_uri === uri);
                                if (matchLin) {
                                  setSelectedLineage(matchLin);
                                  setActiveCopilotPane('lineage');
                                }
                              }
                            }}
                          />
                        )}
                        {msg.data && (
                          <div style={{ marginTop: '12px', paddingTop: '10px', borderTop: '1px solid #e2e8f0', fontSize: '12px' }}>
                            <div style={{ display: 'flex', gap: '6px', alignItems: 'center', flexWrap: 'wrap', marginBottom: '8px' }}>
                              <span className="badge badge-internal">{msg.data.route} ROUTE</span>
                              {msg.data.route !== 'CONVERSATIONAL' && msg.data.active_provider !== 'CONVERSATIONAL_GATE' && msg.data.answer_relevance_status && (
                                <span style={{
                                  fontSize: '11px',
                                  fontWeight: 600,
                                  padding: '2px 8px',
                                  borderRadius: '4px',
                                  background: msg.data.answer_relevance_status === 'RELEVANT' ? '#dcfce7' :
                                              msg.data.answer_relevance_status === 'INSUFFICIENT_EVIDENCE' ? '#fef3c7' : '#fee2e2',
                                  color: msg.data.answer_relevance_status === 'RELEVANT' ? '#15803d' :
                                         msg.data.answer_relevance_status === 'INSUFFICIENT_EVIDENCE' ? '#b45309' : '#b91c1c',
                                }}>
                                  {msg.data.answer_relevance_status}
                                </span>
                              )}
                              {msg.data.route !== 'CONVERSATIONAL' && msg.data.active_provider !== 'CONVERSATIONAL_GATE' && msg.data.answer_grounding_status && msg.data.answer_grounding_status !== 'NOT_APPLICABLE' && (
                                <span style={{
                                  fontSize: '11px',
                                  fontWeight: 600,
                                  padding: '2px 8px',
                                  borderRadius: '4px',
                                  background: '#e0f2fe',
                                  color: '#0369a1',
                                }}>
                                  {msg.data.answer_grounding_status}
                                </span>
                              )}
                              <span style={{ background: '#f1f5f9', color: '#475569', padding: '2px 8px', borderRadius: '4px', fontSize: '11px' }}>
                                Provider: {msg.data.active_provider || msg.data.model_status}
                              </span>
                              <span style={{ color: '#64748b', fontSize: '11px' }}>{msg.data.latency_ms} ms</span>
                            </div>
                            {msg.data.citations && msg.data.citations.length > 0 && (
                              <div style={{ display: 'flex', alignItems: 'center', gap: '6px', flexWrap: 'wrap' }}>
                                <span style={{ fontWeight: 600, color: '#475569', fontSize: '11px' }}>Citations:</span>
                                {msg.data.citations.map((c, ci) => (
                                  <button
                                    key={ci}
                                    onClick={() => {
                                      setSelectedCitation(c);
                                      if (msg.data?.lineage_records) {
                                        const matched = msg.data.lineage_records.find((l: any) => l.chunk_uri === c.source_uri);
                                        if (matched) setSelectedLineage(matched);
                                      }
                                      setActiveCopilotPane('lineage');
                                    }}
                                    style={{
                                      padding: '2px 6px',
                                      background: '#e0f2fe',
                                      color: '#0369a1',
                                      border: '1px solid #bae6fd',
                                      borderRadius: '4px',
                                      fontSize: '11px',
                                      cursor: 'pointer',
                                    }}
                                  >
                                    [{c.source_uri.split(':').slice(-2).join(':')}]
                                  </button>
                                ))}
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>

                <form onSubmit={handleSendMessage} style={{ display: 'flex', gap: '10px' }}>
                  <input
                    type="text"
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder="Ask Watson a clinical or commercial intelligence question..."
                    style={{ flex: 1, padding: '12px 16px', borderRadius: '8px', border: '1px solid var(--border)', fontSize: '14px' }}
                  />
                  <button type="submit" className="btn btn-primary" disabled={chatLoading} style={{ padding: '0 20px' }}>
                    {chatLoading ? 'Synthesizing...' : 'Send'}
                  </button>
                </form>
              </div>

              {/* COORDINATED VIEWS B, C, D: LIVE INSPECTOR PANEL */}
              <div className="card" style={{ display: 'flex', flexDirection: 'column', height: '100%', padding: '0', overflow: 'hidden' }}>
                {/* Header Tabs */}
                <div style={{ display: 'flex', borderBottom: '1px solid var(--border)', background: '#f8fafc', padding: '6px 8px', gap: '4px' }}>
                  <button
                    className="btn"
                    style={{
                      fontSize: '11px',
                      padding: '6px 10px',
                      borderRadius: '6px',
                      background: activeCopilotPane === 'trace' ? '#2563eb' : 'transparent',
                      color: activeCopilotPane === 'trace' ? '#fff' : '#64748b',
                    }}
                    onClick={() => setActiveCopilotPane('trace')}
                  >
                    ⚡ Pipeline Trace {activeAnswer?.live_stages ? `(${activeAnswer.live_stages.length})` : ''}
                  </button>
                  <button
                    className="btn"
                    style={{
                      fontSize: '11px',
                      padding: '6px 10px',
                      borderRadius: '6px',
                      background: activeCopilotPane === 'kg' ? '#2563eb' : 'transparent',
                      color: activeCopilotPane === 'kg' ? '#fff' : '#64748b',
                    }}
                    onClick={() => setActiveCopilotPane('kg')}
                  >
                    🕸️ Semantic KG Evidence {activeAnswer?.kg_facts ? `(${activeAnswer.kg_facts.length})` : ''}
                  </button>
                  <button
                    className="btn"
                    style={{
                      fontSize: '11px',
                      padding: '6px 10px',
                      borderRadius: '6px',
                      background: activeCopilotPane === 'lineage' ? '#2563eb' : 'transparent',
                      color: activeCopilotPane === 'lineage' ? '#fff' : '#64748b',
                    }}
                    onClick={() => setActiveCopilotPane('lineage')}
                  >
                    🔍 Source & Lineage
                  </button>
                  <button
                    className="btn"
                    style={{
                      fontSize: '11px',
                      padding: '6px 10px',
                      borderRadius: '6px',
                      background: activeCopilotPane === 'quality' ? '#2563eb' : 'transparent',
                      color: activeCopilotPane === 'quality' ? '#fff' : '#64748b',
                    }}
                    onClick={() => setActiveCopilotPane('quality')}
                  >
                    🎯 Quality Diagnostics
                  </button>
                  <button
                    className="btn"
                    style={{
                      fontSize: '11px',
                      padding: '6px 10px',
                      borderRadius: '6px',
                      background: activeCopilotPane === 'why' ? '#2563eb' : 'transparent',
                      color: activeCopilotPane === 'why' ? '#fff' : '#64748b',
                    }}
                    onClick={() => setActiveCopilotPane('why')}
                  >
                    💡 Why This Answer?
                  </button>
                </div>

                {/* Sub-Views Content */}
                <div style={{ flex: 1, overflowY: 'auto', padding: '14px', display: 'flex', flexDirection: 'column', gap: '12px' }}>
                  {/* SUB-VIEW B: LIVE PIPELINE TRACE */}
                  {activeCopilotPane === 'trace' && (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <span style={{ fontSize: '13px', fontWeight: 600, color: '#1e293b' }}>
                          Live Processing & Evidence Trace (15 Stages)
                        </span>
                        <span style={{ fontSize: '11px', color: '#64748b' }}>
                          {activeAnswer ? `${activeAnswer.latency_ms} ms total` : 'Awaiting query...'}
                        </span>
                      </div>

                      {!activeAnswer && (
                        <p style={{ fontSize: '12px', color: '#94a3b8', fontStyle: 'italic', textAlign: 'center', padding: '40px 0' }}>
                          Submit a question to view live stage-by-stage execution.
                        </p>
                      )}

                      {activeAnswer?.live_stages?.map((stage, idx) => (
                        <div
                          key={idx}
                          style={{
                            border: '1px solid #e2e8f0',
                            borderRadius: '8px',
                            padding: '10px 12px',
                            background: '#ffffff',
                            boxShadow: '0 1px 2px rgba(0,0,0,0.02)',
                          }}
                        >
                          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '4px' }}>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                              <span style={{ fontSize: '12px', fontWeight: 600, color: '#0f172a' }}>
                                {stage.stage_number}. {stage.stage_name}
                              </span>
                              <span
                                style={{
                                  fontSize: '10px',
                                  padding: '1px 6px',
                                  borderRadius: '4px',
                                  fontWeight: 600,
                                  background:
                                    stage.status === 'COMPLETED' ? '#dcfce7' :
                                    stage.status === 'SKIPPED' ? '#f1f5f9' :
                                    stage.status === 'BLOCKED' ? '#fef3c7' : '#fee2e2',
                                  color:
                                    stage.status === 'COMPLETED' ? '#15803d' :
                                    stage.status === 'SKIPPED' ? '#64748b' :
                                    stage.status === 'BLOCKED' ? '#b45309' : '#b91c1c',
                                }}
                              >
                                {stage.status}
                              </span>
                            </div>
                            <span style={{ fontSize: '11px', color: '#64748b', fontFamily: 'monospace' }}>
                              {stage.elapsed_ms} ms
                            </span>
                          </div>
                          <p style={{ fontSize: '12px', color: '#475569', margin: '4px 0' }}>
                            {stage.summary}
                          </p>

                          {stage.details && Object.keys(stage.details).length > 0 && (
                            <div>
                              <button
                                onClick={() => setExpandedStage(expandedStage === idx ? null : idx)}
                                style={{ fontSize: '10px', color: '#2563eb', background: 'none', border: 'none', cursor: 'pointer', padding: '2px 0' }}
                              >
                                {expandedStage === idx ? '▲ Hide Diagnostics' : '▼ View Diagnostics'}
                              </button>
                              {expandedStage === idx && (
                                <pre style={{ marginTop: '6px', padding: '8px', background: '#f8fafc', borderRadius: '6px', fontSize: '10px', overflowX: 'auto', border: '1px solid #e2e8f0' }}>
                                  {JSON.stringify(stage.details, null, 2)}
                                </pre>
                              )}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  )}

                  {/* SUB-VIEW C: SEMANTIC EVIDENCE EXPLORER */}
                  {activeCopilotPane === 'kg' && (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <span style={{ fontSize: '13px', fontWeight: 600, color: '#1e293b' }}>
                          Semantic Knowledge Graph Facts
                        </span>
                        <span style={{ fontSize: '11px', color: '#64748b' }}>
                          {activeAnswer?.kg_facts?.length || 0} assertions
                        </span>
                      </div>

                      {(!activeAnswer?.kg_facts || activeAnswer.kg_facts.length === 0) && (
                        <p style={{ fontSize: '12px', color: '#94a3b8', fontStyle: 'italic', textAlign: 'center', padding: '40px 0' }}>
                          No direct Knowledge Graph facts associated with the active query.
                        </p>
                      )}

                      {activeAnswer?.kg_facts?.map((fact, fidx) => (
                        <div
                          key={fidx}
                          onClick={() => setSelectedFact(fact)}
                          style={{
                            border: selectedFact === fact ? '2px solid #2563eb' : '1px solid #e2e8f0',
                            borderRadius: '8px',
                            padding: '10px 12px',
                            background: selectedFact === fact ? '#eff6ff' : '#ffffff',
                            cursor: 'pointer',
                          }}
                        >
                          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
                            <span style={{ fontSize: '11px', fontFamily: 'monospace', fontWeight: 600, color: '#1e293b' }}>
                              {fact.subject.split('/').pop()}
                            </span>
                            <span
                              style={{
                                fontSize: '10px',
                                padding: '1px 6px',
                                borderRadius: '4px',
                                fontWeight: 600,
                                background: fact.assertion_type === 'ASSERTED' ? '#f3e8ff' : '#ccfbf1',
                                color: fact.assertion_type === 'ASSERTED' ? '#7e22ce' : '#0f766e',
                              }}
                            >
                              {fact.assertion_type}
                            </span>
                          </div>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '11px', color: '#475569' }}>
                            <span style={{ color: '#2563eb', fontWeight: 600 }}>--[{fact.predicate.split('/').pop()}]--&gt;</span>
                            <span style={{ fontWeight: 600, color: '#0f172a' }}>{fact.object.split('/').pop()}</span>
                          </div>
                          {fact.date && (
                            <div style={{ marginTop: '4px', fontSize: '10px', color: '#64748b' }}>
                              Assertion Date: {fact.date} {fact.score !== undefined && `| Score: ${fact.score}`}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  )}

                  {/* SUB-VIEW D: SOURCE & LINEAGE INSPECTOR */}
                  {activeCopilotPane === 'lineage' && (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <span style={{ fontSize: '13px', fontWeight: 600, color: '#1e293b' }}>
                          Claim-to-Source Provenance Inspector
                        </span>
                        <span style={{ fontSize: '11px', color: '#64748b' }}>
                          {activeAnswer?.lineage_records?.length || 0} chunks cited
                        </span>
                      </div>

                      {/* Cited Chunks Selector */}
                      {activeAnswer?.lineage_records && activeAnswer.lineage_records.length > 0 && (
                        <div style={{ display: 'flex', gap: '6px', overflowX: 'auto', paddingBottom: '4px' }}>
                          {activeAnswer.lineage_records.map((rec, ridx) => (
                            <button
                              key={ridx}
                              onClick={() => setSelectedLineage(rec)}
                              style={{
                                padding: '4px 8px',
                                borderRadius: '6px',
                                fontSize: '11px',
                                border: '1px solid #cbd5e1',
                                background: selectedLineage === rec ? '#2563eb' : '#f8fafc',
                                color: selectedLineage === rec ? '#fff' : '#475569',
                                cursor: 'pointer',
                                whiteSpace: 'nowrap',
                              }}
                            >
                              {rec.chunk_uri.split(':').slice(-2).join(':')}
                            </button>
                          ))}
                        </div>
                      )}

                      {!selectedLineage && (
                        <p style={{ fontSize: '12px', color: '#94a3b8', fontStyle: 'italic', textAlign: 'center', padding: '40px 0' }}>
                          Select a citation or submit a query to inspect provenance lineage.
                        </p>
                      )}

                      {selectedLineage && (
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                          {/* Provenance Chain Breadcrumb */}
                          <div style={{ padding: '8px 10px', background: '#f1f5f9', borderRadius: '6px', fontSize: '11px', lineHeight: 1.5 }}>
                            <span style={{ fontWeight: 600, color: '#0f172a' }}>Chain: </span>
                            <span style={{ color: '#2563eb' }}>{selectedLineage.source_filename}</span> &gt;{' '}
                            <span style={{ color: '#0f766e' }}>{selectedLineage.chunk_uri}</span> &gt;{' '}
                            <span style={{ color: '#7c3aed' }}>{selectedLineage.reviewer_id}</span> &gt;{' '}
                            <span style={{ color: '#15803d' }}>ACTIVE</span>
                          </div>

                          {/* Lineage Metadata Grid */}
                          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', fontSize: '11px' }}>
                            <div style={{ padding: '8px', background: '#fff', border: '1px solid #e2e8f0', borderRadius: '6px' }}>
                              <span style={{ color: '#64748b' }}>Document URI:</span>
                              <div style={{ fontWeight: 600, color: '#0f172a', wordBreak: 'break-all' }}>{selectedLineage.document_uri}</div>
                            </div>
                            <div style={{ padding: '8px', background: '#fff', border: '1px solid #e2e8f0', borderRadius: '6px' }}>
                              <span style={{ color: '#64748b' }}>Chunk URI:</span>
                              <div style={{ fontWeight: 600, color: '#0f172a', wordBreak: 'break-all' }}>{selectedLineage.chunk_uri}</div>
                            </div>
                            <div style={{ padding: '8px', background: '#fff', border: '1px solid #e2e8f0', borderRadius: '6px' }}>
                              <span style={{ color: '#64748b' }}>Reviewed By:</span>
                              <div style={{ fontWeight: 600, color: '#0f172a' }}>{selectedLineage.reviewer_id}</div>
                            </div>
                            <div style={{ padding: '8px', background: '#fff', border: '1px solid #e2e8f0', borderRadius: '6px' }}>
                              <span style={{ color: '#64748b' }}>Quality Score:</span>
                              <div style={{ fontWeight: 600, color: '#15803d' }}>{selectedLineage.quality_score.toFixed(2)} / 1.00</div>
                            </div>
                          </div>

                          {/* Source Excerpt */}
                          <div style={{ padding: '10px', background: '#fff', border: '1px solid #e2e8f0', borderRadius: '6px' }}>
                            <div style={{ fontSize: '11px', fontWeight: 600, color: '#475569', marginBottom: '4px' }}>
                              Source Excerpt ({selectedLineage.char_offsets}):
                            </div>
                            <div style={{ fontSize: '12px', color: '#1e293b', fontStyle: 'italic', lineHeight: 1.5, background: '#f8fafc', padding: '8px', borderRadius: '4px' }}>
                              {activeAnswer?.scored_chunks?.find((c: any) => c.chunk_uri === selectedLineage.chunk_uri)?.content ||
                               activeAnswer?.citations?.find((c: any) => c.source_uri === selectedLineage.chunk_uri)?.excerpt ||
                               'Excerpt text securely loaded from document store.'}
                            </div>
                          </div>

                          {/* RDF Lineage & Audit Details */}
                          <div style={{ padding: '8px', background: '#fff', border: '1px solid #e2e8f0', borderRadius: '6px', fontSize: '11px' }}>
                            <div style={{ color: '#64748b', marginBottom: '2px' }}>Knowledge Graph Triples Path:</div>
                            <code style={{ fontSize: '11px', color: '#7c3aed' }}>{selectedLineage.rdf_path || '[Concept] --(derivedFrom)--> [Doc]'}</code>
                            <div style={{ color: '#64748b', marginTop: '6px', marginBottom: '2px' }}>Tamper-Evident Audit Event:</div>
                            <code style={{ fontSize: '11px', color: '#0f766e' }}>{selectedLineage.audit_event_id}</code>
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {/* SUB-VIEW E: ANSWER QUALITY DIAGNOSTICS */}
                  {activeCopilotPane === 'quality' && (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <span style={{ fontSize: '13px', fontWeight: 600, color: '#1e293b' }}>
                          Answer Quality & Conformance Diagnostics
                        </span>
                        <span style={{ fontSize: '11px', color: '#64748b' }}>
                          3-Axis Evaluation
                        </span>
                      </div>

                      {!activeAnswer && (
                        <p style={{ fontSize: '12px', color: '#94a3b8', fontStyle: 'italic', textAlign: 'center', padding: '40px 0' }}>
                          Submit a query to evaluate answer quality, indication alignment, and grounding.
                        </p>
                      )}

                      {activeAnswer && (
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                          {/* 3-Axis Metric Cards */}
                          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '8px' }}>
                            <div style={{ padding: '10px', background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '8px', textAlign: 'center' }}>
                              <div style={{ fontSize: '10px', color: '#64748b', fontWeight: 600, textTransform: 'uppercase' }}>Pipeline Execution</div>
                              <div style={{ fontSize: '13px', fontWeight: 700, color: '#16a34a', marginTop: '4px' }}>
                                {activeAnswer.pipeline_execution_status || 'COMPLETED'}
                              </div>
                            </div>
                            <div style={{ padding: '10px', background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '8px', textAlign: 'center' }}>
                              <div style={{ fontSize: '10px', color: '#64748b', fontWeight: 600, textTransform: 'uppercase' }}>Grounding Status</div>
                              <div style={{ fontSize: '13px', fontWeight: 700, color: '#2563eb', marginTop: '4px' }}>
                                {activeAnswer.answer_grounding_status || 'GROUNDED'}
                              </div>
                            </div>
                            <div style={{ padding: '10px', background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '8px', textAlign: 'center' }}>
                              <div style={{ fontSize: '10px', color: '#64748b', fontWeight: 600, textTransform: 'uppercase' }}>Relevance Status</div>
                              <div style={{
                                fontSize: '13px',
                                fontWeight: 700,
                                color: activeAnswer.answer_relevance_status === 'RELEVANT' ? '#16a34a' :
                                       activeAnswer.answer_relevance_status === 'INSUFFICIENT_EVIDENCE' ? '#d97706' : '#dc2626',
                                marginTop: '4px'
                              }}>
                                {activeAnswer.answer_relevance_status || 'RELEVANT'}
                              </div>
                            </div>
                          </div>

                          {/* Diagnostics Details */}
                          <div style={{ background: '#ffffff', border: '1px solid #e2e8f0', borderRadius: '8px', padding: '12px', fontSize: '12px' }}>
                            <h4 style={{ fontSize: '12px', fontWeight: 600, color: '#334155', marginBottom: '8px' }}>Indication Alignment & Evidence Verification</h4>
                            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', marginBottom: '8px' }}>
                              <div>
                                <span style={{ color: '#64748b', fontSize: '11px' }}>Requested Indication:</span>
                                <div style={{ fontWeight: 600, color: '#0f172a' }}>
                                  {activeAnswer.quality_diagnostics?.requested_indication?.toUpperCase() || 'Not specified / Multi-indication'}
                                </div>
                              </div>
                              <div>
                                <span style={{ color: '#64748b', fontSize: '11px' }}>Addressed Indication:</span>
                                <div style={{ fontWeight: 600, color: '#0f172a' }}>
                                  {activeAnswer.quality_diagnostics?.answered_indication?.toUpperCase() || 'Aligned'}
                                </div>
                              </div>
                            </div>
                            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
                              <div>
                                <span style={{ color: '#64748b', fontSize: '11px' }}>Valid Citations:</span>
                                <div style={{ fontWeight: 600, color: '#16a34a' }}>
                                  {activeAnswer.quality_diagnostics?.valid_citations ?? activeAnswer.citations?.length} / {activeAnswer.quality_diagnostics?.total_citations ?? activeAnswer.citations?.length}
                                </div>
                              </div>
                              <div>
                                <span style={{ color: '#64748b', fontSize: '11px' }}>Active Provider:</span>
                                <div style={{ fontWeight: 600, color: '#475569' }}>
                                  {activeAnswer.active_provider}
                                </div>
                              </div>
                            </div>

                            {activeAnswer.evidence_gap_detected && (
                              <div style={{ marginTop: '10px', padding: '8px 10px', background: '#fffbeb', border: '1px solid #fef3c7', borderRadius: '6px', color: '#92400e', fontSize: '11px' }}>
                                ⚠️ <strong>Evidence Gap Acknowledged:</strong> No authorized documents or Knowledge Graph links associate the target product with the requested indication. The system avoided hallucination and reported insufficient context.
                              </div>
                            )}

                            {activeAnswer.quality_diagnostics?.warnings && activeAnswer.quality_diagnostics.warnings.length > 0 && (
                              <div style={{ marginTop: '10px', padding: '8px 10px', background: '#fef2f2', border: '1px solid #fecaca', borderRadius: '6px', color: '#b91c1c', fontSize: '11px' }}>
                                <strong>Warnings:</strong>
                                <ul style={{ paddingLeft: '16px', margin: '4px 0 0' }}>
                                  {activeAnswer.quality_diagnostics.warnings.map((w: string, wi: number) => (
                                    <li key={wi}>{w}</li>
                                  ))}
                                </ul>
                              </div>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {/* SUB-VIEW F: WHY THIS ANSWER? */}
                  {activeCopilotPane === 'why' && (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <span style={{ fontSize: '13px', fontWeight: 600, color: '#1e293b' }}>
                          💡 Why This Answer? — Semantic Grounding & Decision Explanation
                        </span>
                        <span style={{ fontSize: '11px', color: '#64748b' }}>
                          Real-Time Provenance & Evidence Verification
                        </span>
                      </div>

                      {!activeAnswer && (
                        <p style={{ fontSize: '12px', color: '#94a3b8', fontStyle: 'italic', textAlign: 'center', padding: '40px 0' }}>
                          Submit a query to inspect the complete semantic decision rationale, entity bindings, and evidence trail.
                        </p>
                      )}

                      {activeAnswer && (
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                          {/* 1. Six Validation Status Badges */}
                          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '6px' }}>
                            <div style={{ padding: '8px', background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '6px', textAlign: 'center' }}>
                              <div style={{ fontSize: '10px', color: '#64748b', fontWeight: 600 }}>Intent Match</div>
                              <div style={{ fontSize: '12px', fontWeight: 700, color: '#16a34a', marginTop: '2px' }}>
                                {activeAnswer.intent_match_status || 'MATCHED'}
                              </div>
                            </div>
                            <div style={{ padding: '8px', background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '6px', textAlign: 'center' }}>
                              <div style={{ fontSize: '10px', color: '#64748b', fontWeight: 600 }}>Entity Coverage</div>
                              <div style={{ fontSize: '12px', fontWeight: 700, color: activeAnswer.entity_coverage_status === 'COVERED' ? '#16a34a' : '#d97706', marginTop: '2px' }}>
                                {activeAnswer.entity_coverage_status || 'COVERED'}
                              </div>
                            </div>
                            <div style={{ padding: '8px', background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '6px', textAlign: 'center' }}>
                              <div style={{ fontSize: '10px', color: '#64748b', fontWeight: 600 }}>Geography Alignment</div>
                              <div style={{ fontSize: '12px', fontWeight: 700, color: activeAnswer.geography_alignment_status === 'ALIGNED' ? '#16a34a' : '#dc2626', marginTop: '2px' }}>
                                {activeAnswer.geography_alignment_status || 'ALIGNED'}
                              </div>
                            </div>
                            <div style={{ padding: '8px', background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '6px', textAlign: 'center' }}>
                              <div style={{ fontSize: '10px', color: '#64748b', fontWeight: 600 }}>Completeness</div>
                              <div style={{ fontSize: '12px', fontWeight: 700, color: activeAnswer.answer_completeness_status === 'COMPLETE' ? '#16a34a' : '#d97706', marginTop: '2px' }}>
                                {activeAnswer.answer_completeness_status || 'COMPLETE'}
                              </div>
                            </div>
                            <div style={{ padding: '8px', background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '6px', textAlign: 'center' }}>
                              <div style={{ fontSize: '10px', color: '#64748b', fontWeight: 600 }}>Claim Grounding</div>
                              <div style={{ fontSize: '12px', fontWeight: 700, color: activeAnswer.claim_grounding_status === 'GROUNDED' ? '#16a34a' : '#dc2626', marginTop: '2px' }}>
                                {activeAnswer.claim_grounding_status || activeAnswer.answer_grounding_status || 'GROUNDED'}
                              </div>
                            </div>
                            <div style={{ padding: '8px', background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '6px', textAlign: 'center' }}>
                              <div style={{ fontSize: '10px', color: '#64748b', fontWeight: 600 }}>Citation Validity</div>
                              <div style={{ fontSize: '12px', fontWeight: 700, color: activeAnswer.citation_validity_status === 'VALID' ? '#16a34a' : '#dc2626', marginTop: '2px' }}>
                                {activeAnswer.citation_validity_status || 'VALID'}
                              </div>
                            </div>
                          </div>

                          {/* 2. Route & Intent Rationale */}
                          <div style={{ background: '#ffffff', border: '1px solid #e2e8f0', borderRadius: '8px', padding: '10px', fontSize: '11px' }}>
                            <div style={{ fontWeight: 600, color: '#334155', marginBottom: '6px' }}>🎯 Execution Route & Strategy</div>
                            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '6px' }}>
                              <div><span style={{ color: '#64748b' }}>Route:</span> <strong>{activeAnswer.route}</strong></div>
                              <div><span style={{ color: '#64748b' }}>Strategy:</span> <strong>{activeAnswer.answer_plan?.strategy || activeAnswer.conversation_intent || 'DIRECT_SYNTHESIS'}</strong></div>
                              <div><span style={{ color: '#64748b' }}>Provider:</span> <strong>{activeAnswer.active_provider}</strong></div>
                              <div><span style={{ color: '#64748b' }}>Latency:</span> <strong>{activeAnswer.latency_ms} ms</strong></div>
                            </div>
                          </div>

                          {/* 3. Recognized Entities & Canonical Bindings */}
                          <div style={{ background: '#ffffff', border: '1px solid #e2e8f0', borderRadius: '8px', padding: '10px', fontSize: '11px' }}>
                            <div style={{ fontWeight: 600, color: '#334155', marginBottom: '6px' }}>🧬 Recognized Semantic Entity Bindings</div>
                            {activeAnswer.query_plan?.required_brand_drug_indication_bindings?.length > 0 ? (
                              <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                                {activeAnswer.query_plan.required_brand_drug_indication_bindings.map((b: any, bi: number) => (
                                  <div key={bi} style={{ padding: '6px 8px', background: '#f8fafc', borderRadius: '4px', border: '1px solid #e2e8f0' }}>
                                    <span style={{ fontWeight: 600, color: '#2563eb' }}>{b.brand || 'Brand'}</span> &rarr;{' '}
                                    <span style={{ color: '#0f766e' }}>{b.drug || 'Drug'}</span> &rarr;{' '}
                                    <span style={{ color: '#7c3aed' }}>{b.indication || 'Indication'}</span> ({b.therapeutic_area || 'TA'}, {b.geography || 'Geo'})
                                  </div>
                                ))}
                              </div>
                            ) : (
                              <div style={{ color: '#64748b', fontStyle: 'italic' }}>
                                Entities resolved across formal OWL ontology: {activeAnswer.query_plan?.requested_entities?.join(', ') || 'No explicit pharmaceutical brand entities.'}
                              </div>
                            )}
                          </div>

                          {/* 4. Knowledge Graph Traversal Paths */}
                          <div style={{ background: '#ffffff', border: '1px solid #e2e8f0', borderRadius: '8px', padding: '10px', fontSize: '11px' }}>
                            <div style={{ fontWeight: 600, color: '#334155', marginBottom: '6px' }}>
                              🕸️ Knowledge Graph Traversal Paths ({activeAnswer.kg_facts?.length || 0} Triples)
                            </div>
                            {activeAnswer.kg_facts && activeAnswer.kg_facts.length > 0 ? (
                              <div style={{ display: 'flex', flexDirection: 'column', gap: '4px', maxHeight: '120px', overflowY: 'auto' }}>
                                {activeAnswer.kg_facts.slice(0, 8).map((f: any, fi: number) => (
                                  <div key={fi} style={{ padding: '4px 6px', background: '#f8fafc', borderRadius: '4px', border: '1px solid #e2e8f0', fontFamily: 'monospace', fontSize: '10px' }}>
                                    <span style={{ color: '#2563eb' }}>{f.subject?.split('/')?.slice(-1)[0]}</span>{' '}
                                    <span style={{ color: '#d97706' }}>--({f.predicate?.split('/')?.slice(-1)[0]} [{f.assertion_type}])--&gt;</span>{' '}
                                    <span style={{ color: '#16a34a' }}>{f.object?.split('/')?.slice(-1)[0]}</span>
                                  </div>
                                ))}
                              </div>
                            ) : (
                              <div style={{ color: '#64748b', fontStyle: 'italic' }}>No direct RDF graph triples traversed for this execution route.</div>
                            )}
                          </div>

                          {/* 5. Selected Evidence Chunks & Scores */}
                          <div style={{ background: '#ffffff', border: '1px solid #e2e8f0', borderRadius: '8px', padding: '10px', fontSize: '11px' }}>
                            <div style={{ fontWeight: 600, color: '#334155', marginBottom: '6px' }}>
                              📄 Selected Evidence Chunks & Reranking Scores ({activeAnswer.scored_chunks?.length || 0})
                            </div>
                            {activeAnswer.scored_chunks && activeAnswer.scored_chunks.length > 0 ? (
                              <div style={{ display: 'flex', flexDirection: 'column', gap: '4px', maxHeight: '150px', overflowY: 'auto' }}>
                                {activeAnswer.scored_chunks.slice(0, 6).map((sc: any, sci: number) => (
                                  <div
                                    key={sci}
                                    style={{
                                      padding: '6px',
                                      background: '#f8fafc',
                                      borderRadius: '4px',
                                      border: '1px solid #e2e8f0',
                                      cursor: 'pointer',
                                    }}
                                    onClick={() => setSelectedCitation({ source_uri: sc.chunk_uri, doc_uri: sc.doc_uri, excerpt: sc.content, score: sc.composite_score })}
                                  >
                                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '2px' }}>
                                      <span style={{ fontWeight: 600, color: '#0f172a' }}>{sc.chunk_uri}</span>
                                      <span style={{ color: '#16a34a', fontWeight: 600 }}>Score: {sc.composite_score?.toFixed(3) || '1.000'}</span>
                                    </div>
                                    <div style={{ color: '#64748b', fontSize: '10px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                                      {sc.content}
                                    </div>
                                  </div>
                                ))}
                              </div>
                            ) : (
                              <div style={{ color: '#64748b', fontStyle: 'italic' }}>No vector chunks retrieved.</div>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: INGESTION CONSOLE */}
          {activeTab === 'ingestion' && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
              <div className="card">
                <h3 style={{ fontSize: '16px', fontWeight: 600, marginBottom: '12px' }}>Upload New Study Document</h3>
                <p style={{ fontSize: '13px', color: '#64748b', marginBottom: '16px' }}>
                  Supported formats: PDF (scan-warning safe), DOCX, PPTX (with slide notes), TXT. Executes multi-stage ingestion with SHA-256 deduplication and PII detection.
                </p>
                <form onSubmit={handleFileUpload} style={{ display: 'flex', flexDirection: 'column', gap: '16px', maxWidth: '500px' }}>
                  <input
                    type="file"
                    onChange={(e) => setUploadFile(e.target.files ? e.target.files[0] : null)}
                    style={{ border: '1px dashed #cbd5e1', padding: '24px', borderRadius: '8px', textAlign: 'center', cursor: 'pointer' }}
                  />
                  <button type="submit" className="btn btn-primary" disabled={!uploadFile || uploading}>
                    {uploading ? 'Uploading and processing…' : 'Stage for Review'}
                  </button>
                </form>
                {uploadStatus && <p style={{ marginTop: '12px', fontSize: '13px', fontWeight: 500, color: 'var(--primary)' }}>{uploadStatus}</p>}
              </div>
            </div>
          )}

          {/* TAB 3: HITL WORKBENCH */}
          {activeTab === 'hitl' && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
              {pendingError && <p role="alert">{pendingError}</p>}
              <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
                <button className="btn btn-outline" onClick={loadPendingDocuments}>Refresh pending documents</button>
                {pendingDocs.length > 0 && <select aria-label="Pending review document" value={stagedDoc?.document_uri || ''}
                  onChange={event => setStagedDoc(pendingDocs.find(d => d.document_uri === event.target.value) || null)}>
                  {pendingDocs.map(d => <option key={d.document_uri} value={d.document_uri}>{d.source_filename}</option>)}
                </select>}
              </div>
              {stagedDoc ? (
                <ReviewDocument document={stagedDoc} onReview={handleApproveDocument} busy={reviewing} />
              ) : (
                <div className="card" style={{ textAlign: 'center', padding: '40px', color: '#64748b' }}>
                  <h3>No Documents Currently Pending Review</h3>
                  <p style={{ fontSize: '13px', marginTop: '6px' }}>Upload a new study in the Ingestion Console to stage it for HITL review.</p>
                </div>
              )}
            </div>
          )}

          {/* TAB 4: DOCUMENT LIBRARY */}
          {activeTab === 'library' && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
              <div className="table-container">
                <table>
                  <thead>
                    <tr>
                      <th>Document URI</th>
                      <th>Filename</th>
                      <th>Sensitivity</th>
                      <th>Therapeutic Area</th>
                      <th>Quality</th>
                      <th>State</th>
                      <th>Expiry</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {documents.map((d, i) => (
                      <tr key={i}>
                        <td style={{ fontWeight: 600, color: '#0369a1' }}>{d.document_uri}</td>
                        <td>{d.source_filename}</td>
                        <td>
                          <span className={`badge badge-${d.sensitivity_level?.toLowerCase() || 'internal'}`}>
                            {d.sensitivity_level || 'INTERNAL'}
                          </span>
                        </td>
                        <td>{Array.isArray(d.allowed_therapeutic_areas) ? d.allowed_therapeutic_areas.join(', ') : d.allowed_therapeutic_areas || 'General'}</td>
                        <td>{displayValue(d.quality_score)}</td>
                        <td>
                          <span className={`badge badge-${d.lifecycle_state?.toLowerCase()}`}>
                            {d.lifecycle_state}
                          </span>
                        </td>
                        <td style={{ fontSize: '12px', color: '#64748b' }}>{displayExpiry(d.expiry_date)}</td>
                        <td>
                          {d.lifecycle_state === 'ACTIVE' ? (
                            <button
                              className="btn btn-outline"
                              style={{ padding: '2px 8px', fontSize: '11px' }}
                              onClick={async () => {
                                await api.archiveDocument(d.document_uri);
                                loadDocuments();
                              }}
                            >
                              Archive
                            </button>
                          ) : (
                            <button
                              className="btn btn-outline"
                              style={{ padding: '2px 8px', fontSize: '11px' }}
                              onClick={async () => {
                                await api.reinstateDocument(d.document_uri);
                                loadDocuments();
                              }}
                            >
                              Reinstate
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 5: KG EXPLORER */}
          {activeTab === 'kg' && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
              <div className="card">
                <h3 style={{ fontSize: '16px', fontWeight: 600, marginBottom: '8px' }}>Knowledge Graph & Ontology Model</h3>
                <p style={{ fontSize: '13px', color: '#64748b', marginBottom: '16px' }}>
                  Hand-crafted OWL ontology (pharma.ttl) and inferred graph (pharma_kg_inferred.ttl) with 10,047 triples.
                </p>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '12px' }}>
                  <div style={{ background: '#f8fafc', padding: '12px', borderRadius: '6px', border: '1px solid #e2e8f0' }}>
                    <span style={{ fontSize: '12px', color: '#64748b' }}>Total Triples</span>
                    <h4 style={{ fontSize: '20px', fontWeight: 700, color: 'var(--primary)' }}>10,047</h4>
                  </div>
                  <div style={{ background: '#f8fafc', padding: '12px', borderRadius: '6px', border: '1px solid #e2e8f0' }}>
                    <span style={{ fontSize: '12px', color: '#64748b' }}>Ontology Classes</span>
                    <h4 style={{ fontSize: '20px', fontWeight: 700, color: 'var(--primary)' }}>14</h4>
                  </div>
                  <div style={{ background: '#f8fafc', padding: '12px', borderRadius: '6px', border: '1px solid #e2e8f0' }}>
                    <span style={{ fontSize: '12px', color: '#64748b' }}>Deductive Ratio</span>
                    <h4 style={{ fontSize: '20px', fontWeight: 700, color: 'var(--primary)' }}>2.65x</h4>
                  </div>
                  <div style={{ background: '#f8fafc', padding: '12px', borderRadius: '6px', border: '1px solid #e2e8f0' }}>
                    <span style={{ fontSize: '12px', color: '#64748b' }}>Restricted Chunks</span>
                    <h4 style={{ fontSize: '20px', fontWeight: 700, color: '#ef4444' }}>14</h4>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 6: KNOWLEDGE SPACES */}
          {activeTab === 'spaces' && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '16px' }}>
                {spaces.map((s, idx) => (
                  <div
                    key={idx}
                    className="card"
                    style={{ cursor: 'pointer', border: selectedSpaceHealth?.space_id === s.space_id ? '2px solid var(--primary)' : '1px solid var(--border)' }}
                    onClick={async () => {
                      const h = await api.getSpaceHealth(s.space_id);
                      setSelectedSpaceHealth(h);
                    }}
                  >
                    <h4 style={{ fontSize: '15px', fontWeight: 600, color: '#1e293b', marginBottom: '4px' }}>{s.name}</h4>
                    <span className="badge badge-internal" style={{ marginBottom: '10px' }}>{s.therapeutic_area}</span>
                    <p style={{ fontSize: '12px', color: '#64748b', marginBottom: '12px' }}>{s.description}</p>
                    <div style={{ fontSize: '12px', color: '#475569' }}>
                      <span>SPOC: <strong>{s.spoc_user_id}</strong></span> | <span>Docs: <strong>{s.document_uris.length}</strong></span>
                    </div>
                  </div>
                ))}
              </div>

              {selectedSpaceHealth && (
                <div className="card">
                  <h3 style={{ fontSize: '16px', fontWeight: 600, marginBottom: '12px' }}>
                    Health Metrics for {selectedSpaceHealth.space_name} (Q11 Assessment)
                  </h3>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '12px' }}>
                    <div style={{ background: '#f8fafc', padding: '12px', borderRadius: '6px', border: '1px solid #e2e8f0' }}>
                      <span style={{ fontSize: '12px', color: '#64748b' }}>Accessible Documents</span>
                      <h4 style={{ fontSize: '18px', fontWeight: 700 }}>{selectedSpaceHealth.accessible_documents}</h4>
                    </div>
                    <div style={{ background: '#f8fafc', padding: '12px', borderRadius: '6px', border: '1px solid #e2e8f0' }}>
                      <span style={{ fontSize: '12px', color: '#64748b' }}>Indexed Chunks</span>
                      <h4 style={{ fontSize: '18px', fontWeight: 700 }}>{selectedSpaceHealth.total_chunks}</h4>
                    </div>
                    <div style={{ background: '#f8fafc', padding: '12px', borderRadius: '6px', border: '1px solid #e2e8f0' }}>
                      <span style={{ fontSize: '12px', color: '#64748b' }}>Avg Quality Score</span>
                      <h4 style={{ fontSize: '18px', fontWeight: 700 }}>{selectedSpaceHealth.average_quality_score}</h4>
                    </div>
                    <div style={{ background: '#f8fafc', padding: '12px', borderRadius: '6px', border: '1px solid #e2e8f0' }}>
                      <span style={{ fontSize: '12px', color: '#64748b' }}>Space Status</span>
                      <h4 style={{ fontSize: '18px', fontWeight: 700, color: 'var(--success)' }}>{selectedSpaceHealth.status}</h4>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 7: SPARQL STUDIO */}
          {/* TAB 7: SPARQL STUDIO */}
          {activeTab === 'sparql' && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
              {/* Studio Header Banner */}
              <div className="card" style={{ background: 'linear-gradient(135deg, #f8fafc 0%, #eff6ff 100%)', borderLeft: '4px solid #2563eb' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '12px' }}>
                  <div>
                    <h2 style={{ fontSize: '20px', fontWeight: 700, color: '#1e293b', display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <span>🔍</span> Interactive SPARQL Query Studio
                    </h2>
                    <p style={{ fontSize: '13px', color: '#64748b', marginTop: '4px' }}>
                      Direct SPARQL 1.1 read execution against the in-memory Layer 2 Semantic Knowledge Graph with OWL 2 RL inferences, PRD Q01–Q11 query validation, and data science exports.
                    </p>
                  </div>
                  <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
                    <span className="badge" style={{ background: '#dbeafe', color: '#1d4ed8' }}>
                      🌐 10,151 Triples
                    </span>
                    <span className="badge" style={{ background: '#dcfce7', color: '#15803d' }}>
                      ⚡ SPARQL 1.1 Read
                    </span>
                    <span className="badge" style={{ background: '#f1f5f9', color: '#475569' }}>
                      👤 {currentUser?.name} ({currentUser?.role})
                    </span>
                  </div>
                </div>
              </div>

              {/* Template Library Selection */}
              <div className="card">
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px', flexWrap: 'wrap', gap: '8px' }}>
                  <h3 style={{ fontSize: '15px', fontWeight: 600, color: '#1e293b' }}>
                    📚 Authoritative Query Suite & Templates
                  </h3>
                  {/* Category Filter Pills */}
                  <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
                    {['ALL', 'Target Discovery', 'Sentiment Analytics', 'Competitive Intelligence', 'Gap Analysis', 'Semantic Inference', 'Governance & Compliance', 'Lineage & Provenance', 'Health & Operations', 'Graph Exploration'].map((cat) => (
                      <button
                        key={cat}
                        className="btn"
                        onClick={() => setSparqlCategoryFilter(cat)}
                        style={{
                          padding: '4px 10px',
                          fontSize: '11px',
                          borderRadius: '9999px',
                          background: sparqlCategoryFilter === cat ? '#2563eb' : '#f1f5f9',
                          color: sparqlCategoryFilter === cat ? '#ffffff' : '#475569',
                          border: 'none',
                          fontWeight: sparqlCategoryFilter === cat ? 600 : 500,
                        }}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Templates Quick Selector */}
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))', gap: '10px' }}>
                  {sparqlTemplates
                    .filter((t) => sparqlCategoryFilter === 'ALL' || t.category === sparqlCategoryFilter)
                    .map((t) => (
                      <div
                        key={t.id}
                        onClick={() => handleSelectTemplate(t)}
                        style={{
                          padding: '10px 12px',
                          borderRadius: '6px',
                          border: selectedTemplateId === t.id ? '2px solid #2563eb' : '1px solid #e2e8f0',
                          background: selectedTemplateId === t.id ? '#eff6ff' : '#ffffff',
                          cursor: 'pointer',
                          transition: 'all 0.15s ease',
                        }}
                      >
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '4px' }}>
                          <span style={{ fontSize: '11px', fontWeight: 700, color: '#2563eb', fontFamily: 'var(--font-mono)' }}>
                            {t.id}
                          </span>
                          <span style={{ fontSize: '10px', padding: '2px 6px', borderRadius: '4px', background: '#f1f5f9', color: '#64748b' }}>
                            {t.category}
                          </span>
                        </div>
                        <div style={{ fontSize: '13px', fontWeight: 600, color: '#1e293b', marginBottom: '2px' }}>
                          {t.name}
                        </div>
                        <div style={{ fontSize: '11px', color: '#64748b', display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
                          {t.description}
                        </div>
                      </div>
                    ))}
                </div>

                {/* Selected Template Description Callout */}
                {selectedTemplateId && (
                  <div style={{ marginTop: '14px', padding: '10px 14px', background: '#f8fafc', borderRadius: '6px', border: '1px solid #e2e8f0', fontSize: '12px', color: '#475569' }}>
                    <span style={{ fontWeight: 600, color: '#1e293b' }}>Template Note: </span>
                    {sparqlTemplates.find((t) => t.id === selectedTemplateId)?.description || 'Custom query editor'}
                  </div>
                )}
              </div>

              {/* SPARQL Query Editor Card */}
              <div className="card">
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px', flexWrap: 'wrap', gap: '8px' }}>
                  <h3 style={{ fontSize: '15px', fontWeight: 600, color: '#1e293b' }}>
                    SPARQL 1.1 Query Editor
                  </h3>
                  <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                    <button
                      className="btn btn-outline"
                      onClick={insertStandardPrefixes}
                      title="Insert standard prefixes (watson, entity, rdfs, rdf, owl)"
                      style={{ fontSize: '12px', padding: '6px 10px' }}
                    >
                      + Standard Prefixes
                    </button>
                    <button
                      className="btn btn-outline"
                      onClick={() => {
                        const t = sparqlTemplates.find((t) => t.id === selectedTemplateId);
                        if (t) setSparqlQuery(t.sparql);
                      }}
                      title="Reset editor to current template"
                      style={{ fontSize: '12px', padding: '6px 10px' }}
                    >
                      ⟳ Reset
                    </button>
                    <button
                      className="btn btn-outline"
                      onClick={() => setSparqlQuery('')}
                      title="Clear query editor"
                      style={{ fontSize: '12px', padding: '6px 10px' }}
                    >
                      ✕ Clear
                    </button>
                    <button
                      className="btn btn-primary"
                      disabled={sparqlLoading}
                      onClick={() => handleExecuteSparql()}
                      style={{ fontSize: '13px', padding: '6px 16px', display: 'flex', alignItems: 'center', gap: '6px' }}
                    >
                      {sparqlLoading ? 'Executing...' : '▶ Execute Query'}
                      <span style={{ fontSize: '10px', opacity: 0.8, background: 'rgba(255,255,255,0.2)', padding: '2px 5px', borderRadius: '4px' }}>
                        Ctrl+Enter
                      </span>
                    </button>
                  </div>
                </div>

                <textarea
                  value={sparqlQuery}
                  onChange={(e) => setSparqlQuery(e.target.value)}
                  onKeyDown={(e) => {
                    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
                      e.preventDefault();
                      handleExecuteSparql();
                    }
                  }}
                  rows={9}
                  placeholder="Enter SPARQL 1.1 query (e.g. SELECT ?s ?p ?o WHERE { ?s ?p ?o } LIMIT 20)..."
                  style={{
                    width: '100%',
                    fontFamily: 'var(--font-mono)',
                    padding: '14px',
                    borderRadius: '6px',
                    border: '1px solid var(--border)',
                    fontSize: '13px',
                    background: '#0f172a',
                    color: '#f8fafc',
                    lineHeight: '1.5',
                    resize: 'vertical',
                  }}
                />
              </div>

              {/* Execution Error Banner */}
              {sparqlError && (
                <div style={{ padding: '14px 18px', background: '#fef2f2', border: '1px solid #fecaca', borderRadius: '8px', color: '#991b1b', fontSize: '13px' }}>
                  <div style={{ fontWeight: 700, marginBottom: '4px', display: 'flex', alignItems: 'center', gap: '6px' }}>
                    <span>⚠️</span> SPARQL Execution Error
                  </div>
                  <pre style={{ margin: 0, fontFamily: 'var(--font-mono)', fontSize: '12px', whiteSpace: 'pre-wrap', wordBreak: 'break-all' }}>
                    {sparqlError}
                  </pre>
                </div>
              )}

              {/* SPARQL Query Results Card */}
              {sparqlResults && (
                <div className="card" style={{ padding: '20px' }}>
                  {/* Results Metric & Export Header */}
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px', flexWrap: 'wrap', gap: '12px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '14px', flexWrap: 'wrap' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                        <span style={{ fontSize: '12px', color: '#64748b' }}>Execution Time:</span>
                        <span style={{ fontSize: '13px', fontWeight: 700, color: '#2563eb' }}>
                          ⚡ {sparqlResults.latency_ms} ms
                        </span>
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                        <span style={{ fontSize: '12px', color: '#64748b' }}>Rows:</span>
                        <span style={{ fontSize: '13px', fontWeight: 700, color: '#16a34a' }}>
                          {sparqlResults.row_count}
                        </span>
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                        <span style={{ fontSize: '12px', color: '#64748b' }}>Columns:</span>
                        <span style={{ fontSize: '12px', fontWeight: 600, color: '#475569' }}>
                          {sparqlResults.columns?.map((c) => `?${c}`).join(', ')}
                        </span>
                      </div>
                    </div>

                    <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                      <input
                        type="text"
                        placeholder="Filter rows..."
                        value={sparqlFilter}
                        onChange={(e) => setSparqlFilter(e.target.value)}
                        style={{
                          padding: '6px 12px',
                          fontSize: '12px',
                          border: '1px solid #cbd5e1',
                          borderRadius: '6px',
                          width: '180px',
                        }}
                      />
                      <button
                        className="btn btn-outline"
                        onClick={exportSparqlCsv}
                        disabled={sparqlResults.row_count === 0}
                        style={{ fontSize: '12px', padding: '6px 12px' }}
                      >
                        📥 Export CSV
                      </button>
                      <button
                        className="btn btn-outline"
                        onClick={exportSparqlJson}
                        disabled={sparqlResults.row_count === 0}
                        style={{ fontSize: '12px', padding: '6px 12px' }}
                      >
                        📥 Export JSON
                      </button>
                    </div>
                  </div>

                  {/* Results Table */}
                  <div className="table-container" style={{ maxHeight: '480px', overflowY: 'auto' }}>
                    <table>
                      <thead>
                        <tr>
                          <th style={{ width: '48px', textAlign: 'center' }}>#</th>
                          {sparqlResults.columns?.map((col: string, ci: number) => (
                            <th key={ci} style={{ fontFamily: 'var(--font-mono)', fontSize: '12px' }}>
                              ?{col}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {sparqlResults.results
                          ?.filter((row: any) => {
                            if (!sparqlFilter.trim()) return true;
                            const q = sparqlFilter.toLowerCase();
                            return Object.values(row).some((val) =>
                              String(val).toLowerCase().includes(q)
                            );
                          })
                          .map((row: any, ri: number) => (
                            <tr key={ri}>
                              <td style={{ fontSize: '11px', color: '#94a3b8', textAlign: 'center' }}>
                                {ri + 1}
                              </td>
                              {sparqlResults.columns?.map((col: string, ci: number) => (
                                <td key={ci} style={{ fontSize: '13px' }}>
                                  {formatUriCell(row[col])}
                                </td>
                              ))}
                            </tr>
                          ))}
                        {sparqlResults.results?.length === 0 && (
                          <tr>
                            <td
                              colSpan={(sparqlResults.columns?.length || 1) + 1}
                              style={{ textAlign: 'center', padding: '32px', color: '#94a3b8', fontSize: '14px' }}
                            >
                              Query returned 0 rows from knowledge graph.
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 8: GOVERNANCE & AUDIT */}
          {activeTab === 'governance' && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
              <div className="table-container">
                <table>
                  <thead>
                    <tr>
                      <th>Timestamp (UTC)</th>
                      <th>Event Type</th>
                      <th>User</th>
                      <th>Target Document</th>
                      <th>Message / Details</th>
                    </tr>
                  </thead>
                  <tbody>
                    {auditLogs.map((log, li) => (
                      <tr key={li}>
                        <td style={{ fontSize: '12px', color: '#64748b' }}>{log.timestamp}</td>
                        <td>
                          <span className={`badge ${log.event_type.includes('DENIED') || log.event_type.includes('RISK') ? 'badge-rejected' : 'badge-internal'}`}>
                            {log.event_type}
                          </span>
                        </td>
                        <td><strong>{log.user_id}</strong></td>
                        <td style={{ fontSize: '12px', color: '#0369a1' }}>{log.document_uri || '-'}</td>
                        <td style={{ fontSize: '12px' }}>{log.message}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 9: SYSTEM HEALTH & TELEMETRY */}
          {activeTab === 'health' && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
              <div className="card">
                <h3 style={{ fontSize: '16px', fontWeight: 600, marginBottom: '12px' }}>PRD Q10 Cross-Layer Access Audit Report</h3>
                {q10Result ? (
                  <div>
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '12px', marginBottom: '16px' }}>
                      <div style={{ background: '#f8fafc', padding: '12px', borderRadius: '6px', border: '1px solid #e2e8f0' }}>
                        <span style={{ fontSize: '12px', color: '#64748b' }}>Verification Status</span>
                        <h4 style={{ fontSize: '18px', fontWeight: 700, color: 'var(--success)' }}>{q10Result.status}</h4>
                      </div>
                      <div style={{ background: '#f8fafc', padding: '12px', borderRadius: '6px', border: '1px solid #e2e8f0' }}>
                        <span style={{ fontSize: '12px', color: '#64748b' }}>Restricted Chunks</span>
                        <h4 style={{ fontSize: '18px', fontWeight: 700 }}>{q10Result.restricted_chunks_in_graph}</h4>
                      </div>
                      <div style={{ background: '#f8fafc', padding: '12px', borderRadius: '6px', border: '1px solid #e2e8f0' }}>
                        <span style={{ fontSize: '12px', color: '#64748b' }}>Restricted Documents</span>
                        <h4 style={{ fontSize: '18px', fontWeight: 700 }}>{q10Result.restricted_documents_count}</h4>
                      </div>
                      <div style={{ background: '#f8fafc', padding: '12px', borderRadius: '6px', border: '1px solid #e2e8f0' }}>
                        <span style={{ fontSize: '12px', color: '#64748b' }}>Cross-Layer Join</span>
                        <h4 style={{ fontSize: '18px', fontWeight: 700, color: 'var(--success)' }}>VERIFIED</h4>
                      </div>
                    </div>
                  </div>
                ) : (
                  <p>Loading Q10 audit...</p>
                )}
              </div>
            </div>
          )}
        </div>
      </main>

      {/* Citation Drill-Down Modal */}
      {selectedCitation && (
        <div className="modal-overlay" onClick={() => setSelectedCitation(null)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
              <h3 style={{ fontSize: '16px', fontWeight: 600 }}>Evidence Chunk Drill-Down</h3>
              <button className="btn btn-outline" style={{ padding: '2px 8px' }} onClick={() => setSelectedCitation(null)}>✕</button>
            </div>
            <p style={{ fontSize: '13px', color: '#0369a1', fontWeight: 600, marginBottom: '8px' }}>
              Chunk URI: {selectedCitation.source_uri}
            </p>
            <p style={{ fontSize: '12px', color: '#64748b', marginBottom: '16px' }}>
              Source Document: {selectedCitation.doc_uri} | Score: {selectedCitation.score}
            </p>
            <div style={{ background: '#f8fafc', padding: '16px', borderRadius: '8px', border: '1px solid #e2e8f0', fontSize: '14px', lineHeight: 1.6 }}>
              {selectedCitation.excerpt}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
