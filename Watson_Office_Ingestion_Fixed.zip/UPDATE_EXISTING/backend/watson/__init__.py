import sys
from pathlib import Path

_watson_dir = Path(__file__).resolve().parent
for _sub in ["shared", "ingestion", "governance", "semantics", "retrieval", "spaces", "mcp", "observability"]:
    _p = str(_watson_dir / _sub)
    if _p not in sys.path:
        sys.path.insert(0, _p)
