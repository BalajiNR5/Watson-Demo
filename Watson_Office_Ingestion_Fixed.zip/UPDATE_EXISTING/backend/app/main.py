from __future__ import annotations

import json
import logging
import os
import re
import shutil
import sys
import time
import tempfile
from pathlib import Path
from typing import Any, Dict, List, Optional

_BACKEND_DIR = Path(__file__).resolve().parent.parent
if str(_BACKEND_DIR) not in sys.path:
    sys.path.insert(0, str(_BACKEND_DIR))
_ROOT_DIR = _BACKEND_DIR.parent
if str(_ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(_ROOT_DIR))

from fastapi import Depends, FastAPI, File, HTTPException, Header, Query, UploadFile
from starlette.middleware.trustedhost import TrustedHostMiddleware
from pydantic import BaseModel

from watson.governance.abac_engine import evaluate_access, load_lifecycle_store, load_user_registry
from watson.ingestion.ingestion_coordinator import IngestionCoordinator
from watson.retrieval.graphrag_assembler import GraphRAGAssembler
from watson.retrieval.guardrails import WatsonGuardrails
from watson.retrieval.qwen_interface import QwenInterface
from watson.shared.audit import log_audit_event, query_audit_logs
from watson.shared.config import (
    CHUNK_URI_MAP_FILE,
    LIFECYCLE_STORE_FILE,
    PHARMA_KG_FILE,
    PHARMA_KG_INFERRED_FILE,
    RAW_DATA_DIR,
    STORES_DATA_DIR,
    USER_REGISTRY_FILE,
)
from watson.shared.exceptions import ABACAccessDeniedError, LifecycleViolationError, DedupError, ParsingError
from watson.spaces.knowledge_space import KnowledgeSpaceManager

logger = logging.getLogger("watson.api")

app = FastAPI(
    title="Watson Pharma Knowledge Intelligence Platform API",
    version="2.0.0",
    description="PRD-aligned governed ingestion, semantic ontology, and GraphRAG API",
)

# Production UI and API share one origin; do not enable wildcard CORS.
app.add_middleware(TrustedHostMiddleware, allowed_hosts=["127.0.0.1", "localhost", "[::1]"])

# Global services
coordinator = IngestionCoordinator()
assembler = GraphRAGAssembler()
qwen = QwenInterface()
guardrails = WatsonGuardrails()
space_manager = KnowledgeSpaceManager()

# Active persona state for demo / UI session
CURRENT_USER_ID = "D4"  # Default to Admin for comprehensive overview


# ---------------------------------------------------------------------------
# Request & Response Schemas
# ---------------------------------------------------------------------------

class SwitchPersonaRequest(BaseModel):
    user_id: str


class SearchRequest(BaseModel):
    query: str
    top_k: int = 5
    therapeutic_area: Optional[str] = None


class ChatRequest(BaseModel):
    query: str
    top_k: int = 5


class ReviewRequest(BaseModel):
    document_uri: str
    decision: str  # APPROVE or REJECT
    review_note: str = ""
    pii_override: bool = False
    sensitivity_level: Optional[str] = None
    allowed_therapeutic_areas: Optional[List[str]] = None
    allowed_geographies: Optional[List[str]] = None
    expiry_date: Optional[str] = None


class SparqlRequest(BaseModel):
    query: str


class FeedbackRequest(BaseModel):
    correlation_id: str
    rating: int
    comment: str = ""


# ---------------------------------------------------------------------------
# Security & Auth Helper
# ---------------------------------------------------------------------------

def get_current_user(x_user_id: Optional[str] = Header(None)) -> Dict[str, Any]:
    global CURRENT_USER_ID
    uid = x_user_id or CURRENT_USER_ID
    reg = load_user_registry(USER_REGISTRY_FILE)
    users = reg.get("users", {})
    if uid not in users:
        # Fallback to D4 Admin if unregistered
        uid = "D4"
    user_info = users.get(uid, {})
    return {
        "user_id": uid,
        "name": user_info.get("name", "User"),
        "role": user_info.get("role", "VIEWER"),
        "allowed_therapeutic_areas": user_info.get("allowed_therapeutic_areas", []),
        "allowed_geographies": user_info.get("allowed_geographies", []),
    }


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@app.get("/api/health")
def health():
    return {
        "status": "healthy",
        "platform": "Watson Pharma Knowledge Intelligence Platform",
        "version": "2.0.0",
        "qwen_status": "ONLINE" if qwen.is_loaded else "BLOCKED",
        "primary_llm": qwen.model_name,
        "llm_transport": "OLLAMA",
        "ollama_url": qwen.ollama_url,
        "easy_setup_root": str(_ROOT_DIR),
        "blocked_reason": qwen.blocked_reason if not qwen.is_loaded else None,
        "current_active_user": CURRENT_USER_ID,
    }


@app.get("/api/auth/current")
def current_user(user: Dict[str, Any] = Depends(get_current_user)):
    return user


@app.get("/api/auth/personas")
def list_personas():
    reg = load_user_registry(USER_REGISTRY_FILE)
    return list(reg.get("users", {}).values())


@app.post("/api/auth/switch")
def switch_persona(req: SwitchPersonaRequest):
    global CURRENT_USER_ID
    reg = load_user_registry(USER_REGISTRY_FILE)
    if req.user_id not in reg.get("users", {}):
        raise HTTPException(status_code=400, detail=f"Unknown persona: {req.user_id}")
    CURRENT_USER_ID = req.user_id
    user_info = reg["users"][CURRENT_USER_ID]
    return {"status": "switched", "current_user": user_info}


@app.get("/api/documents")
def list_documents(user: Dict[str, Any] = Depends(get_current_user)):
    """Lists all documents filtered by user's ABAC permissions."""
    store = load_lifecycle_store(LIFECYCLE_STORE_FILE)
    accessible = []
    for doc_uri, record in store.items():
        allowed, _, _ = evaluate_access(
            user_id=user["user_id"],
            document_uri=doc_uri,
            user_registry_path=USER_REGISTRY_FILE,
            lifecycle_store_path=LIFECYCLE_STORE_FILE,
        )
        if allowed:
            accessible.append(record)
    return accessible


@app.post("/api/ingestion/upload")
def upload_document(file: UploadFile = File(...), user: Dict[str, Any] = Depends(get_current_user)):
    """Run blocking parsing in FastAPI's worker pool; preserve existing raw files."""
    filename = (file.filename or "").replace("\\", "/").split("/")[-1]
    if not filename or Path(filename).suffix.lower() not in {".pdf", ".docx", ".pptx", ".txt"}:
        raise HTTPException(status_code=400, detail="Choose a PDF, DOCX, PPTX or TXT document.")
    try:
        with tempfile.TemporaryDirectory(prefix="watson-upload-") as incoming:
            target = Path(incoming) / filename
            size = 0
            with target.open("wb") as output:
                while block := file.file.read(1024 * 1024):
                    size += len(block)
                    if size > 50 * 1024 * 1024:
                        raise HTTPException(status_code=413, detail="Upload limit is 50 MB.")
                    output.write(block)
            return coordinator.stage_file(target, actor_id=user["user_id"])
    except HTTPException:
        raise
    except DedupError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except (ParsingError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        logger.exception("Document staging failed")
        raise HTTPException(status_code=500, detail="Staging failed. Retry to reopen an existing pending review or try the upload again.") from exc


@app.get("/api/ingestion/pending")
def pending_documents(user: Dict[str, Any] = Depends(get_current_user)):
    return coordinator.pending_documents(user)


@app.post("/api/ingestion/review")
def review_document(req: ReviewRequest, user: Dict[str, Any] = Depends(get_current_user)):
    """Reviews a staged document and activates it upon approval."""
    try:
        result = coordinator.review_and_activate(
            doc_uri=req.document_uri,
            reviewer_id=user["user_id"],
            reviewer_role=user["role"],
            decision=req.decision,
            review_note=req.review_note,
            pii_override=req.pii_override,
            sensitivity_level=req.sensitivity_level,
            allowed_ta=req.allowed_therapeutic_areas,
            allowed_geo=req.allowed_geographies,
            expiry_date=req.expiry_date,
        )
        if result.get("status") == "ACTIVE":
            assembler.index_manager._load_index_and_map()
            assembler._load_graph()
        return result
    except ABACAccessDeniedError as e:
        raise HTTPException(status_code=403, detail=str(e))
    except (LifecycleViolationError, ValueError) as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/api/documents/{doc_id}/archive")
def archive_document(doc_id: str, user: Dict[str, Any] = Depends(get_current_user)):
    doc_uri = f"watson:Doc_{doc_id}" if not doc_id.startswith("watson:") else doc_id
    try:
        res = coordinator.archive_document(doc_uri, user_id=user["user_id"])
        return res
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/api/documents/{doc_id}/reinstate")
def reinstate_document(doc_id: str, user: Dict[str, Any] = Depends(get_current_user)):
    doc_uri = f"watson:Doc_{doc_id}" if not doc_id.startswith("watson:") else doc_id
    try:
        res = coordinator.reinstate_document(doc_uri, user_id=user["user_id"])
        return res
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/api/search")
def search(req: SearchRequest, user: Dict[str, Any] = Depends(get_current_user)):
    """Executes 6-stage monitored retrieval pipeline."""
    res = assembler.retrieve(query=req.query, user_id=user["user_id"], top_k=req.top_k)
    return res.dict()


from fastapi.responses import StreamingResponse


@app.post("/api/chat")
def chat(req: ChatRequest, user: Dict[str, Any] = Depends(get_current_user)):
    """Executes full GraphRAG answer synthesis with guardrails, citations, and lineage."""
    is_safe, msg = guardrails.check_prompt_injection(req.query)
    if not is_safe:
        log_audit_event(
            event_type="HALLUCINATION_RISK",
            user_id=user["user_id"],
            message=f"Prompt injection blocked: {req.query}",
        )
        raise HTTPException(status_code=400, detail=f"Security violation: {msg}")

    # Unified 15-Stage GraphRAG Pipeline
    ans = assembler.retrieve_and_synthesize(
        query=req.query,
        user_id=user["user_id"],
        top_k=req.top_k,
    )

    # Telemetry logging
    from watson.observability.telemetry import log_telemetry_event
    log_telemetry_event(
        user_id=user["user_id"],
        user_role=user["role"],
        query=req.query,
        route=ans.route.value,
        retrieved_count=len(ans.scored_chunks),
        latency_ms=ans.latency_ms,
        guardrail_status=ans.guardrail_status,
        document_uris_accessed=[c.doc_uri for c in ans.scored_chunks if c.doc_uri],
        correlation_id=ans.correlation_id,
    )

    return {
        "answer_id": ans.answer_id,
        "correlation_id": ans.correlation_id,
        "query": ans.query,
        "route": ans.route.value,
        "answer": ans.answer,
        "citations": [c.dict() for c in ans.citations],
        "scored_chunks": [c.dict() for c in ans.scored_chunks],
        "kg_facts": [f.dict() for f in ans.kg_facts],
        "lineage_records": [l.dict() for l in ans.lineage_records],
        "live_stages": [s.dict() for s in ans.live_stages],
        "guardrail_status": ans.guardrail_status,
        "model_status": ans.model_status,
        "active_provider": ans.active_provider,
        "latency_ms": ans.latency_ms,
        "user_role": user["role"],
        "pipeline_execution_status": ans.pipeline_execution_status,
        "answer_grounding_status": ans.answer_grounding_status,
        "answer_relevance_status": ans.answer_relevance_status,
        "quality_diagnostics": ans.quality_diagnostics,
        "evidence_gap_detected": ans.evidence_gap_detected,
        "evidence_coverage_matrix": ans.evidence_coverage_matrix if isinstance(ans.evidence_coverage_matrix, dict) else (ans.evidence_coverage_matrix.dict() if ans.evidence_coverage_matrix else None),
        "claims": [c.dict() for c in ans.claims],
        "clinical_claim_verified": ans.clinical_claim_verified,
        "conversation_intent": ans.conversation_intent,
    }


@app.get("/api/chat/stream")
def chat_stream(
    query: str = Query(..., description="User question"),
    top_k: int = Query(5, description="Number of chunks"),
    user: Dict[str, Any] = Depends(get_current_user),
):
    """Server-Sent Events (SSE) streaming endpoint for live execution trace."""
    def event_generator():
        ans = assembler.retrieve_and_synthesize(query=query, user_id=user["user_id"], top_k=top_k)
        for stage in ans.live_stages:
            payload = json.dumps({"event": "stage", "stage": stage.dict()})
            yield f"data: {payload}\n\n"
        complete_payload = json.dumps({
            "event": "complete",
            "answer": ans.answer,
            "citations": [c.dict() for c in ans.citations],
            "kg_facts": [f.dict() for f in ans.kg_facts],
            "lineage_records": [l.dict() for l in ans.lineage_records],
            "route": ans.route.value,
            "model_status": ans.model_status,
            "active_provider": ans.active_provider,
            "latency_ms": ans.latency_ms,
            "quality_diagnostics": ans.quality_diagnostics,
            "evidence_coverage_matrix": ans.evidence_coverage_matrix if isinstance(ans.evidence_coverage_matrix, dict) else (ans.evidence_coverage_matrix.dict() if ans.evidence_coverage_matrix else None),
            "claims": [c.dict() for c in ans.claims],
            "clinical_claim_verified": ans.clinical_claim_verified,
            "conversation_intent": ans.conversation_intent,
        })
        yield f"data: {complete_payload}\n\n"

    return StreamingResponse(event_generator(), media_type="text/event-stream")


@app.get("/api/spaces")
def list_spaces():
    return space_manager.list_spaces()


@app.get("/api/spaces/{space_id}/health")
def space_health(space_id: str, user: Dict[str, Any] = Depends(get_current_user)):
    return space_manager.get_space_health(space_id, user_id=user["user_id"])


@app.get("/api/audit/logs")
def audit_logs(event_type: Optional[str] = Query(None), user_id: Optional[str] = Query(None)):
    return query_audit_logs(event_type=event_type, user_id=user_id, limit=50)


@app.get("/api/telemetry/stats")
def telemetry_stats():
    from watson.observability.telemetry import get_telemetry_stats
    return get_telemetry_stats()


@app.get("/api/telemetry/q10-audit")
def q10_audit():
    from watson.observability.telemetry_query import run_q10_cross_layer_audit
    return run_q10_cross_layer_audit()


@app.post("/api/feedback")
def submit_feedback(req: FeedbackRequest, user: Dict[str, Any] = Depends(get_current_user)):
    from watson.observability.feedback_store import record_feedback
    res = record_feedback(
        correlation_id=req.correlation_id,
        user_id=user["user_id"],
        rating=req.rating,
        comment=req.comment,
    )
    return res


# ---------------------------------------------------------------------------
# Interactive SPARQL Query Studio Endpoints
# ---------------------------------------------------------------------------

_BUILTIN_SPARQL_TEMPLATES = [
    {
        "id": "Q01",
        "name": "Shared Target / Indication Discovery",
        "category": "Target Discovery",
        "description": "Identifies distinct brands sharing an indication with a selected target brand (e.g. Keytruda). Returns Brand, Drug, and Indication.",
        "sparql": """PREFIX watson: <http://watson.pharma.org/ontology/>
PREFIX entity: <http://watson.pharma.org/entity/>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>

SELECT DISTINCT ?brand ?brandName ?drug ?drugName ?indication ?indicationName
WHERE {
    VALUES ?targetBrand { <http://watson.pharma.org/entity/brand/keytruda> }
    ?targetBrand watson:treatsIndication ?indication .
    ?brand watson:treatsIndication ?indication ;
           watson:isBrandOf ?drug ;
           watson:canonicalName ?brandName .
    ?drug watson:canonicalName ?drugName .
    ?indication watson:canonicalName ?indicationName .
    FILTER(?brand != ?targetBrand)
}
ORDER BY ?brandName ?indicationName""",
    },
    {
        "id": "Q02",
        "name": "Negative Sentiment Surface",
        "category": "Sentiment Analytics",
        "description": "Brands whose average HCP sentiment is below 0.4 grouped by therapeutic area. Demonstrates GROUP BY, AVG, HAVING.",
        "sparql": """PREFIX watson: <http://watson.pharma.org/ontology/>

SELECT ?taName ?brandName (AVG(?score) AS ?avgSentiment) (COUNT(?sa) AS ?assertionCount)
WHERE {
    ?sa a watson:SentimentAssertion ;
        watson:sentimentAboutBrand ?brand ;
        watson:sentimentScore ?score .
    ?brand watson:canonicalName ?brandName ;
           watson:treatsIndication ?ind .
    ?ind watson:inTherapeuticArea ?ta .
    ?ta watson:canonicalName ?taName .
}
GROUP BY ?taName ?brandName
HAVING (AVG(?score) < 0.4)
ORDER BY ?taName ?avgSentiment""",
    },
    {
        "id": "Q03",
        "name": "Sentiment Trajectory",
        "category": "Sentiment Analytics",
        "description": "Temporal condition: sentiment > 0.6 before 2023 AND sentiment < 0.4 in 2023 or later. Multi-assertion temporal trajectory analysis.",
        "sparql": """PREFIX watson: <http://watson.pharma.org/ontology/>

SELECT DISTINCT ?brandName ?priorScore ?priorDate ?recentScore ?recentDate
WHERE {
    ?sa1 a watson:SentimentAssertion ;
         watson:sentimentAboutBrand ?brand ;
         watson:sentimentScore ?priorScore ;
         watson:assertionDate ?priorDate .
    FILTER(?priorScore > 0.6 && STR(?priorDate) < "2023-01-01")

    ?sa2 a watson:SentimentAssertion ;
         watson:sentimentAboutBrand ?brand ;
         watson:sentimentScore ?recentScore ;
         watson:assertionDate ?recentDate .
    FILTER(?recentScore < 0.4 && STR(?recentDate) >= "2023-01-01")

    ?brand watson:canonicalName ?brandName .
}
ORDER BY ?brandName""",
    },
    {
        "id": "Q04",
        "name": "Competitive Snapshot",
        "category": "Competitive Intelligence",
        "description": "Oncology competitive snapshot: brands, indication coverage, and average sentiment descending.",
        "sparql": """PREFIX watson: <http://watson.pharma.org/ontology/>

SELECT ?brandName (COUNT(DISTINCT ?ind) AS ?indicationCount) (AVG(?score) AS ?avgSentiment)
WHERE {
    ?brand a watson:Brand ;
           watson:canonicalName ?brandName ;
           watson:treatsIndication ?ind .
    ?ind watson:inTherapeuticArea ?ta .
    ?ta watson:canonicalName ?taName .
    FILTER(STR(?taName) = "Oncology")
    OPTIONAL {
        ?sa a watson:SentimentAssertion ;
            watson:sentimentAboutBrand ?brand ;
            watson:sentimentScore ?score .
    }
}
GROUP BY ?brandName
ORDER BY DESC(?avgSentiment) DESC(?indicationCount)""",
    },
    {
        "id": "Q05",
        "name": "Coverage Gap",
        "category": "Gap Analysis",
        "description": "Indications with < 2 market-research documents AND at least one brand targeting the indication.",
        "sparql": """PREFIX watson: <http://watson.pharma.org/ontology/>

SELECT ?indicationName (COUNT(DISTINCT ?doc) AS ?docCount) (COUNT(DISTINCT ?brand) AS ?brandCount)
WHERE {
    ?ind a watson:Indication ;
         watson:canonicalName ?indicationName .
    ?brand watson:treatsIndication ?ind .
    OPTIONAL {
        ?doc a watson:MarketResearchDocument ;
             watson:mentionsIndication ?ind .
    }
}
GROUP BY ?indicationName
HAVING (COUNT(DISTINCT ?doc) < 2 && COUNT(DISTINCT ?brand) >= 1)
ORDER BY ?docCount ?indicationName""",
    },
    {
        "id": "Q06",
        "name": "OWL Inference Test",
        "category": "Semantic Inference",
        "description": "Demonstrates polymorphic retrieval of HCPSentimentStudy when querying watson:Document due to subclass reasoning.",
        "sparql": """PREFIX watson: <http://watson.pharma.org/ontology/>

SELECT ?doc ?docType ?title ?sourceFilename
WHERE {
    ?doc a watson:Document ;
         watson:sourceFilename ?sourceFilename .
    OPTIONAL { ?doc watson:documentTitle ?title }
    OPTIONAL { ?doc a ?docType . FILTER(?docType = watson:HCPSentimentStudy) }
}
ORDER BY ?sourceFilename""",
    },
    {
        "id": "Q07",
        "name": "Complex Pharma Research Synthesis",
        "category": "Competitive Intelligence",
        "description": "Analyzes competitor brand co-occurrences in evidence chunks along with indication context and active document status.",
        "sparql": """PREFIX watson: <http://watson.pharma.org/ontology/>

SELECT ?brand1Name ?brand2Name ?indicationName (COUNT(DISTINCT ?chunk) AS ?coOccurrenceChunks) (AVG(?score) AS ?avgSentiment)
WHERE {
    ?b1 a watson:Brand ;
        watson:canonicalName ?brand1Name ;
        watson:competesWith ?b2 ;
        watson:treatsIndication ?ind .
    ?b2 a watson:Brand ;
        watson:canonicalName ?brand2Name ;
        watson:treatsIndication ?ind .
    ?ind watson:canonicalName ?indicationName .
    ?chunk a watson:DocumentChunk ;
           watson:mentionsBrand ?b1 ;
           watson:mentionsBrand ?b2 ;
           watson:chunkOf ?doc .
    ?doc watson:lifecycleState ?state .
    FILTER(STR(?state) = "ACTIVE")
    OPTIONAL {
        ?chunk watson:hasSentimentAssertion ?sa .
        ?sa watson:sentimentScore ?score .
    }
    FILTER(STR(?b1) < STR(?b2))
}
GROUP BY ?brand1Name ?brand2Name ?indicationName
ORDER BY DESC(?coOccurrenceChunks) ?brand1Name""",
    },
    {
        "id": "Q08",
        "name": "Expiry Surface",
        "category": "Governance & Compliance",
        "description": "ACTIVE documents expiring within time window -> document, study type, expiry date, owning TA.",
        "sparql": """PREFIX watson: <http://watson.pharma.org/ontology/>

SELECT ?docUri ?sourceFilename ?studyTypeName ?expiryDate ?taName
WHERE {
    ?doc a watson:MarketResearchDocument ;
         watson:documentUri ?docUri ;
         watson:sourceFilename ?sourceFilename ;
         watson:lifecycleState ?state ;
         watson:expiryDate ?expiryDate ;
         watson:hasStudyType ?st ;
         watson:inTherapeuticArea ?ta .
    ?st watson:canonicalName ?studyTypeName .
    ?ta watson:canonicalName ?taName .
    FILTER(STR(?state) = "ACTIVE")
    FILTER(STR(?expiryDate) >= "2026-01-01" && STR(?expiryDate) <= "2027-12-31")
}
ORDER BY ?expiryDate ?sourceFilename""",
    },
    {
        "id": "Q09",
        "name": "Lineage Trace",
        "category": "Lineage & Provenance",
        "description": "Given chunk URI, reconstructs parent document, title, enrichment model, timestamp, chunks produced, and reviewer.",
        "sparql": """PREFIX watson: <http://watson.pharma.org/ontology/>

SELECT ?chunkUri ?docUri ?sourceFilename ?enrichmentModel ?timestamp ?chunksProduced ?reviewedBy
WHERE {
    ?chunk a watson:DocumentChunk ;
           watson:chunkUri ?chunkUri ;
           watson:chunkOf ?doc .
    ?doc watson:documentUri ?docUri ;
         watson:sourceFilename ?sourceFilename ;
         watson:hasLineage ?lineage .
    ?lineage watson:actorOrSystem ?enrichmentModel ;
             watson:executionTimestamp ?timestamp .
    OPTIONAL { ?doc watson:reviewedBy ?reviewedBy }
    OPTIONAL { ?doc watson:chunksProduced ?chunksProduced }
}
ORDER BY ?chunkUri
LIMIT 15""",
    },
    {
        "id": "Q10",
        "name": "ABAC Governance Audit",
        "category": "Governance & Compliance",
        "description": "Identifies restricted and confidential chunks across therapy areas for user/session policy enforcement audit.",
        "sparql": """PREFIX watson: <http://watson.pharma.org/ontology/>

SELECT ?chunkUri ?docUri ?sensitivityLevel ?taName
WHERE {
    ?chunk a watson:DocumentChunk ;
           watson:chunkUri ?chunkUri ;
           watson:chunkOf ?doc .
    ?doc watson:documentUri ?docUri ;
         watson:sensitivityLevel ?sensitivityLevel ;
         watson:inTherapeuticArea ?ta .
    ?ta watson:canonicalName ?taName .
    FILTER(STR(?sensitivityLevel) IN ("RESTRICTED", "HIGHLY_RESTRICTED", "CONFIDENTIAL"))
}
ORDER BY ?sensitivityLevel ?chunkUri""",
    },
    {
        "id": "Q11",
        "name": "Knowledge Space Health",
        "category": "Health & Operations",
        "description": "Document count, avg quality score, latest ingest timestamp, and archived document count for each KnowledgeSpace.",
        "sparql": """PREFIX watson: <http://watson.pharma.org/ontology/>

SELECT ?spaceName ?owner (COUNT(DISTINCT ?doc) AS ?documentCount) (AVG(?qualityScore) AS ?avgQualityScore) (MAX(?ingestTime) AS ?latestIngestTimestamp) (SUM(IF(STR(?lifecycleState) = "ARCHIVED", 1, 0)) AS ?archivedCount)
WHERE {
    ?ks a watson:KnowledgeSpace ;
        watson:spaceName ?spaceName ;
        watson:spaceOwner ?owner .
    OPTIONAL {
        ?ks watson:containsDocument ?doc .
        ?doc watson:qualityScore ?qualityScore ;
             watson:ingestTimestamp ?ingestTime ;
             watson:lifecycleState ?lifecycleState .
    }
}
GROUP BY ?spaceName ?owner
ORDER BY DESC(?documentCount) ?spaceName""",
    },
    {
        "id": "EXP_BRANDS",
        "name": "Explore All Brands & Indications",
        "category": "Graph Exploration",
        "description": "Lists all pharmaceutical brands, active ingredients, and indications registered in the Knowledge Graph.",
        "sparql": """PREFIX watson: <http://watson.pharma.org/ontology/>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>

SELECT DISTINCT ?brandName ?drugName ?indicationName ?taName
WHERE {
    ?brand a watson:Brand ;
           watson:canonicalName ?brandName .
    OPTIONAL {
        ?brand watson:isBrandOf ?drug .
        ?drug watson:canonicalName ?drugName .
    }
    OPTIONAL {
        ?brand watson:treatsIndication ?ind .
        ?ind watson:canonicalName ?indicationName .
        OPTIONAL {
            ?ind watson:inTherapeuticArea ?ta .
            ?ta watson:canonicalName ?taName .
        }
    }
}
ORDER BY ?brandName ?indicationName
LIMIT 50""",
    },
    {
        "id": "EXP_CLASSES",
        "name": "Ontology Class Hierarchy & Counts",
        "category": "Graph Exploration",
        "description": "Lists OWL classes and instance counts currently asserted or inferred in the Knowledge Graph.",
        "sparql": """PREFIX owl: <http://www.w3.org/2002/07/owl#>
PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>

SELECT ?class (COUNT(?instance) AS ?instanceCount)
WHERE {
    ?instance rdf:type ?class .
    FILTER(STRSTARTS(STR(?class), "http://watson.pharma.org/ontology/"))
}
GROUP BY ?class
ORDER BY DESC(?instanceCount)""",
    },
]


@app.get("/api/graph/sparql/templates")
def get_sparql_templates():
    """Returns PRD Section 13 authoritative SPARQL query templates and exploration suites."""
    return {"templates": _BUILTIN_SPARQL_TEMPLATES}


@app.post("/api/graph/sparql")
def execute_sparql(req: SparqlRequest, user: Dict[str, Any] = Depends(get_current_user)):
    """Executes an interactive SPARQL query against the in-memory semantic Knowledge Graph."""
    if not req.query or not req.query.strip():
        raise HTTPException(status_code=400, detail="Query cannot be empty.")

    # Guard against SPARQL update / mutation
    q_upper = req.query.upper()
    prohibited = ["DROP", "DELETE", "INSERT", "CLEAR", "LOAD", "CREATE"]
    for keyword in prohibited:
        if re.search(rf"\b{keyword}\b", q_upper):
            raise HTTPException(
                status_code=403,
                detail=f"SPARQL mutation keyword '{keyword}' is prohibited. Read-only queries only.",
            )

    t0 = time.time()
    try:
        # Utilize the in-memory graph from assembler
        graph = assembler.graph
        if graph is None or len(graph) == 0:
            import rdflib
            graph = rdflib.Graph()
            from watson.shared.config import PHARMA_KG_INFERRED_FILE, PHARMA_KG_FILE
            kg_path = PHARMA_KG_INFERRED_FILE if PHARMA_KG_INFERRED_FILE.exists() else PHARMA_KG_FILE
            graph.parse(str(kg_path), format="turtle")

        res = graph.query(req.query)
        elapsed_ms = round((time.time() - t0) * 1000, 2)

        vars_list = [str(v) for v in res.vars] if res.vars else []
        rows = []
        for r in res:
            row_dict = {}
            for idx, var in enumerate(vars_list):
                val = r[idx]
                row_dict[var] = str(val) if val is not None else ""
            rows.append(row_dict)

        # Audit event
        log_audit_event(
            event_type="SPARQL_QUERY",
            user_id=user["user_id"],
            message=f"SPARQL Query executed: {len(rows)} rows returned in {elapsed_ms}ms",
            metadata={"row_count": len(rows), "latency_ms": elapsed_ms, "columns": vars_list},
        )

        return {
            "status": "SUCCESS",
            "query": req.query,
            "latency_ms": elapsed_ms,
            "triple_count": len(graph),
            "columns": vars_list,
            "row_count": len(rows),
            "results": rows,
            "user_id": user["user_id"],
            "user_role": user["role"],
        }
    except Exception as e:
        elapsed_ms = round((time.time() - t0) * 1000, 2)
        err_msg = str(e)
        logger.warning(f"SPARQL Execution Error: {err_msg}")
        raise HTTPException(
            status_code=400,
            detail=f"SPARQL Syntax / Execution Error: {err_msg}",
        )


# Mount React Production Frontend
from fastapi.staticfiles import StaticFiles

_FRONTEND_DIST = _ROOT_DIR / "frontend" / "dist"
if _FRONTEND_DIST.exists():
    app.mount("/", StaticFiles(directory=str(_FRONTEND_DIST), html=True), name="static")

